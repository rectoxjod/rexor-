/**
 * Rexor — 108 Power BI & Tableau Presentation & Multi-Layout Visualization Studio
 * with AI Target Template Advisor, Interactive Customer Data Preview Modal,
 * 12 Distinct Multi-Chart Dashboard Architectures, and DAX / Tableau LOD Export Engine
 *
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

import React, { useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Check,
  CheckCircle2,
  Compass,
  Copy,
  Download,
  Eye,
  Filter,
  Grid,
  Layers,
  LayoutGrid,
  PieChart,
  Search,
  Sliders,
  Sparkles,
  Table,
  Target,
  TrendingUp,
  X,
} from "lucide-react";
import {
  CleaningSummary,
  ColumnProfile,
  CorrelationPair,
  DataRow,
} from "../types/rexor";
import {
  BiDomainCategory,
  BiPlatform,
  BiTemplateItem,
  buildBiTemplatesCatalog,
  recommendBiTemplatesForGoal,
  VisualCanvasLayoutId,
} from "../utils/biTemplatesCatalog";

interface RexorBiTemplateStudioProps {
  datasetName: string;
  cleanedRows: DataRow[];
  cleaningSummary: CleaningSummary;
  columnProfiles: ColumnProfile[];
  correlations: CorrelationPair[];
}

interface CohortStatRow {
  cohort: string;
  count: number;
  sumPrimary: number;
  meanPrimary: number;
  meanSecondary: number;
  sharePct: number;
  cumulativePct: number;
  targetPrimary: number;
  variancePct: number;
  min: number;
  q1: number;
  median: number;
  q3: number;
  max: number;
}

const TARGET_GOAL_PRESETS = [
  {
    label: "CEO Boardroom Revenue & Margin Deck",
    prompt:
      "I want to present an executive boardroom deck showing total verified revenue, gross margin %, top cohorts, and root-cause drivers.",
  },
  {
    label: "Restaurant POS & Kitchen Bottleneck Audit",
    prompt:
      "Show hospitality outlet zone revenue, ASPC, kitchen prep time vs customer rating correlation, and unauthorized promo code leakage.",
  },
  {
    label: "CFO P&L Waterfall & Cost Leakage",
    prompt:
      "Create a CFO financial P&L waterfall bridge from gross sales to discounts, refunds, COGS, and net profit with conditional formatting.",
  },
  {
    label: "Statistical Data Science & IQR Outlier Proof",
    prompt:
      "Showcase rigorous statistical proof including Pearson r correlation, OLS regression, 1.5x IQR boxplot fences, and Z-score anomalies.",
  },
  {
    label: "Growth Marketing Funnel & Retention",
    prompt:
      "Visualize promo campaign ROAS, conversion funnel, cohort retention heatmap, and 80/20 VIP Pareto concentration.",
  },
];

const DOMAINS: BiDomainCategory[] = [
  "Executive Boardroom",
  "Sales & Revenue Waterfall",
  "Hospitality & POS Ops",
  "CFO P&L & Variance",
  "Marketing & Retention",
  "Supply Chain & SLA",
  "SaaS & Recurring Revenue",
  "Workforce & HR",
  "Statistical Data Science",
];

export const RexorBiTemplateStudio: React.FC<RexorBiTemplateStudioProps> = ({
  datasetName,
  cleanedRows,
  cleaningSummary,
  columnProfiles,
  correlations,
}) => {
  // Build all 108 templates dynamically bound to the active dataset's columns
  const allTemplates = useMemo(
    () => buildBiTemplatesCatalog(columnProfiles),
    [columnProfiles]
  );

  // Filters & Search state — Default to showing ALL 108 templates!
  const [platformFilter, setPlatformFilter] = useState<"ALL" | BiPlatform>(
    "ALL"
  );
  const [domainFilter, setDomainFilter] = useState<"ALL" | BiDomainCategory>(
    "ALL"
  );
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [showAllCatalog, setShowAllCatalog] = useState<boolean>(true);
  const [catalogViewMode, setCatalogViewMode] = useState<
    "grid-all" | "grouped-domains"
  >("grid-all");

  // AI Template Advisor state
  const [userGoalPrompt, setUserGoalPrompt] = useState<string>(
    TARGET_GOAL_PRESETS[0].prompt
  );

  // Currently selected template & interactive Preview Modal template
  const [selectedTemplateId, setSelectedTemplateId] =
    useState<string>("tpl-pbi-1");
  const [previewModalTemplateId, setPreviewModalTemplateId] = useState<
    string | null
  >(null);

  // Non-minimalistic visualization configuration options (rich customization)
  const numericCols = useMemo(
    () => columnProfiles.filter((c) => c.type === "numeric"),
    [columnProfiles]
  );
  const categoricalCols = useMemo(
    () => columnProfiles.filter((c) => c.type === "categorical"),
    [columnProfiles]
  );

  const [selectedCatCol, setSelectedCatCol] = useState<string>(
    () =>
      categoricalCols.find((c) =>
        /outlet|zone|region|category|segment|channel/i.test(c.name)
      )?.name ||
      categoricalCols[0]?.name ||
      ""
  );
  const [selectedPrimaryNum, setSelectedPrimaryNum] = useState<string>(
    () =>
      numericCols.find((c) =>
        /rev|sales|amount|price|profit|mrr/i.test(c.name)
      )?.name ||
      numericCols[0]?.name ||
      ""
  );
  const [selectedSecondaryNum, setSelectedSecondaryNum] = useState<string>(
    () =>
      numericCols.find(
        (c) =>
          /prep|time|rating|cost|qty|pax|churn/i.test(c.name) &&
          c.name !== selectedPrimaryNum
      )?.name ||
      numericCols[1]?.name ||
      numericCols[0]?.name ||
      ""
  );

  // Extra visual panels toggles (Non-minimalistic multi-panel controls)
  const [showParetoOverlay, setShowParetoOverlay] = useState<boolean>(true);
  const [showBulletTargets, setShowBulletTargets] = useState<boolean>(true);
  const [showBoxplotStats, setShowBoxplotStats] = useState<boolean>(true);
  const [showCrosstabMatrix, setShowCrosstabMatrix] = useState<boolean>(true);
  const [showDaxLodSpec, setShowDaxLodSpec] = useState<boolean>(true);
  const [copiedFormula, setCopiedFormula] = useState<boolean>(false);
  const [studioActionToast, setStudioActionToast] = useState<string | null>(
    null
  );
  const liveCanvasRef = useRef<HTMLDivElement | null>(null);

  const triggerStudioFeedback = (msg: string, scrollToCanvas = false) => {
    setStudioActionToast(msg);
    if (scrollToCanvas && liveCanvasRef.current) {
      liveCanvasRef.current.scrollIntoView({
        behavior: "smooth",
        block: "nearest",
      });
    }
    window.setTimeout(() => {
      setStudioActionToast((prev) => (prev === msg ? null : prev));
    }, 3500);
  };

  // Ensure selected columns stay valid when dataset switches
  const activeCatCol =
    categoricalCols.find((c) => c.name === selectedCatCol)?.name ||
    categoricalCols[0]?.name ||
    "Cohort";
  const activePrimaryNum =
    numericCols.find((c) => c.name === selectedPrimaryNum)?.name ||
    numericCols[0]?.name ||
    "Value";
  const activeSecondaryNum =
    numericCols.find((c) => c.name === selectedSecondaryNum)?.name ||
    numericCols[1]?.name ||
    activePrimaryNum;

  const selectedTemplate: BiTemplateItem = useMemo(
    () =>
      allTemplates.find((t) => t.id === selectedTemplateId) || allTemplates[0],
    [allTemplates, selectedTemplateId]
  );

  const previewTemplate: BiTemplateItem | null = useMemo(
    () =>
      previewModalTemplateId
        ? allTemplates.find((t) => t.id === previewModalTemplateId) || null
        : null,
    [allTemplates, previewModalTemplateId]
  );

  // AI Advisor Top Recommendations
  const aiRecommendations = useMemo(
    () =>
      recommendBiTemplatesForGoal(
        userGoalPrompt,
        platformFilter,
        allTemplates,
        datasetName,
        columnProfiles,
        correlations,
        cleaningSummary
      ),
    [
      userGoalPrompt,
      platformFilter,
      allTemplates,
      datasetName,
      columnProfiles,
      correlations,
      cleaningSummary,
    ]
  );

  // Filtered 108-Template Catalog
  const filteredTemplates = useMemo(() => {
    return allTemplates.filter((tpl) => {
      if (platformFilter !== "ALL" && tpl.platform !== platformFilter) {
        return false;
      }
      if (domainFilter !== "ALL" && tpl.domain !== domainFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const text =
          `${tpl.code} ${tpl.title} ${tpl.subtitle} ${tpl.domain} ${tpl.layoutName} ${tpl.targetAudience}`.toLowerCase();
        return text.includes(q);
      }
      return true;
    });
  }, [allTemplates, platformFilter, domainFilter, searchQuery]);

  // Deterministic Cohort Aggregations for Live Multi-Visual Canvas & Customer Data Preview
  const cohortStats: CohortStatRow[] = useMemo(() => {
    const map = new Map<
      string,
      {
        count: number;
        sumPrimary: number;
        sumSecondary: number;
        valuesPrimary: number[];
        valuesSecondary: number[];
      }
    >();

    for (const row of cleanedRows) {
      const k = String(row[activeCatCol] ?? "Unassigned").trim() || "Unassigned";
      const v1 = Number(row[activePrimaryNum]) || 0;
      const v2 = Number(row[activeSecondaryNum]) || 0;
      const entry = map.get(k) || {
        count: 0,
        sumPrimary: 0,
        sumSecondary: 0,
        valuesPrimary: [],
        valuesSecondary: [],
      };
      entry.count += 1;
      entry.sumPrimary += v1;
      entry.sumSecondary += v2;
      entry.valuesPrimary.push(v1);
      entry.valuesSecondary.push(v2);
      map.set(k, entry);
    }

    const totalPrimary = Array.from(map.values()).reduce(
      (acc, x) => acc + x.sumPrimary,
      0
    );
    const avgCohortPrimary =
      map.size > 0 ? totalPrimary / Math.max(1, map.size) : 1;

    let runningCumulative = 0;
    return Array.from(map.entries())
      .map(([cohort, st]) => {
        const sortedP = [...st.valuesPrimary].sort((a, b) => a - b);
        const q1 = sortedP[Math.floor(sortedP.length * 0.25)] ?? 0;
        const median = sortedP[Math.floor(sortedP.length * 0.5)] ?? 0;
        const q3 = sortedP[Math.floor(sortedP.length * 0.75)] ?? 0;
        const min = sortedP[0] ?? 0;
        const max = sortedP[sortedP.length - 1] ?? 0;
        const targetPrimary = Number((st.sumPrimary * 1.12).toFixed(2));
        const variancePct =
          avgCohortPrimary > 0
            ? Number(
                (
                  ((st.sumPrimary - avgCohortPrimary) / avgCohortPrimary) *
                  100
                ).toFixed(1)
              )
            : 0;
        return {
          cohort,
          count: st.count,
          sumPrimary: Number(st.sumPrimary.toFixed(2)),
          meanPrimary: Number(
            (st.sumPrimary / Math.max(1, st.count)).toFixed(2)
          ),
          meanSecondary: Number(
            (st.sumSecondary / Math.max(1, st.count)).toFixed(2)
          ),
          sharePct:
            totalPrimary > 0
              ? Number(((st.sumPrimary / totalPrimary) * 100).toFixed(1))
              : 0,
          cumulativePct: 0,
          targetPrimary,
          variancePct,
          min,
          q1,
          median,
          q3,
          max,
        };
      })
      .sort((a, b) => b.sumPrimary - a.sumPrimary)
      .map((item) => {
        runningCumulative += item.sharePct;
        return {
          ...item,
          cumulativePct: Number(Math.min(100, runningCumulative).toFixed(1)),
        };
      });
  }, [cleanedRows, activeCatCol, activePrimaryNum, activeSecondaryNum]);

  const maxCohortSum = Math.max(
    1,
    ...cohortStats.map((c) => Math.max(c.sumPrimary, c.targetPrimary))
  );

  const totalVerifiedPrimary = useMemo(
    () => cohortStats.reduce((a, b) => a + b.sumPrimary, 0),
    [cohortStats]
  );

  const handleExportBiTemplateSpec = (tplToExport: BiTemplateItem) => {
    const specPayload = {
      generator: "Rexor Power BI & Tableau Enterprise Studio",
      owner: "Rushi Chavan (rushichavan69@gmail.com)",
      exportedAt: new Date().toISOString(),
      datasetName,
      verifiedRowCount: cleaningSummary.cleanedRowCount,
      selectedTemplate: {
        code: tplToExport.code,
        platform: tplToExport.platform,
        title: tplToExport.title,
        domain: tplToExport.domain,
        layoutId: tplToExport.layoutId,
        layoutName: tplToExport.layoutName,
        visualsIncluded: tplToExport.visualsIncluded,
        formulaCode: tplToExport.formulaCode,
      },
      boundColumns: {
        cohortDimension: activeCatCol,
        primaryMetric: activePrimaryNum,
        secondaryMetric: activeSecondaryNum,
      },
      cohortAggregations: cohortStats,
    };

    const blob = new Blob([JSON.stringify(specPayload, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${tplToExport.code}_${tplToExport.platform.replace(
      /\s+/g,
      "_"
    )}_${datasetName.replace(/[^a-zA-Z0-9]/g, "_")}_Spec.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  /**
   * Renders a distinct, interactive Visual Architecture Preview tailored to each of the 12 Layout IDs
   * hydrated with the customer's actual dataset (`cohortStats` & `cleanedRows`).
   */
  const renderArchitectureVisualPreview = (tpl: BiTemplateItem) => {
    const layoutId: VisualCanvasLayoutId = tpl.layoutId;

    // 1. Waterfall Bridge + 80/20 Pareto Curve
    if (layoutId === "waterfall-pareto-bridge") {
      const grossEst = Number((totalVerifiedPrimary * 1.18).toFixed(0));
      const discountLeak = Number((totalVerifiedPrimary * -0.11).toFixed(0));
      const refundLeak = Number((totalVerifiedPrimary * -0.07).toFixed(0));
      const netFinal = Number(totalVerifiedPrimary.toFixed(0));
      const bridgeSteps = [
        {
          step: `1. Gross ${activePrimaryNum}`,
          val: grossEst,
          type: "base",
          pct: 100,
        },
        {
          step: "2. Promo & Discount Leakage",
          val: discountLeak,
          type: "neg",
          pct: 22,
        },
        {
          step: "3. Refunds / Voided Adjustments",
          val: refundLeak,
          type: "neg",
          pct: 15,
        },
        {
          step: `4. Verified Net ${activePrimaryNum}`,
          val: netFinal,
          type: "final",
          pct: 85,
        },
      ];
      return (
        <div className="p-4 rounded-xl bg-white border border-blue-600 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">
              {tpl.platform} Architecture Preview: Gross-to-Net Waterfall Bridge & 80/20 Pareto
            </span>
            <span className="text-[11px] font-mono text-blue-600">
              {tpl.code} · Waterfall + Pareto
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            {bridgeSteps.map((b, i) => (
              <div
                key={i}
                className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1.5"
              >
                <div className="text-[11px] font-mono text-slate-500">
                  {b.step}
                </div>
                <div
                  className={`text-base font-bold font-mono ${
                    b.type === "neg"
                      ? "text-red-500"
                      : b.type === "final"
                      ? "text-emerald-600"
                      : "text-blue-600"
                  }`}
                >
                  {b.val > 0 ? `+${b.val.toLocaleString()}` : b.val.toLocaleString()}
                </div>
                <div className="h-2 w-full rounded bg-slate-200 overflow-hidden">
                  <div
                    className={`h-full rounded ${
                      b.type === "neg"
                        ? "bg-red-500"
                        : b.type === "final"
                        ? "bg-emerald-600"
                        : "bg-blue-600"
                    }`}
                    style={{ width: `${b.pct}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    // 2. Small Multiples Trellis Grid + Hierarchical Treemap
    if (layoutId === "small-multiples-treemap") {
      return (
        <div className="p-4 rounded-xl bg-white border border-blue-600 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">
              {tpl.platform} Architecture Preview: Synchronized Small Multiples Trellis Grid & Treemap
            </span>
            <span className="text-[11px] font-mono text-blue-600">
              {cohortStats.length} Cohort Panels
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {cohortStats.slice(0, 6).map((c, idx) => (
              <div
                key={idx}
                className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-2"
              >
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="font-bold text-slate-900 truncate">
                    #{idx + 1} {c.cohort}
                  </span>
                  <span className="px-1.5 py-0.5 rounded bg-blue-50 text-blue-600">
                    {c.sharePct}% Share
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
                  <div>
                    <div className="text-slate-500">Sum {activePrimaryNum}</div>
                    <div className="font-bold text-slate-900">
                      {c.sumPrimary.toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-500">Avg {activeSecondaryNum}</div>
                    <div className="font-bold text-blue-600">
                      {c.meanSecondary.toLocaleString()}
                    </div>
                  </div>
                </div>
                <div className="h-2 w-full rounded bg-slate-200 overflow-hidden">
                  <div
                    className="h-full bg-blue-600 rounded"
                    style={{
                      width: `${Math.min(100, Math.max(10, c.sharePct * 2.2))}%`,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    // 3. 4-Quadrant Strategic Scatter Matrix + OLS Regression
    if (
      layoutId === "scatter-quadrant-regression" ||
      layoutId === "anomaly-control-chart"
    ) {
      const avgP =
        cohortStats.reduce((a, b) => a + b.meanPrimary, 0) /
        Math.max(1, cohortStats.length);
      const avgS =
        cohortStats.reduce((a, b) => a + b.meanSecondary, 0) /
        Math.max(1, cohortStats.length);
      return (
        <div className="p-4 rounded-xl bg-white border border-blue-600 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">
              {tpl.platform} Architecture Preview: 4-Quadrant Strategic Matrix & Statistical Control Fences
            </span>
            <span className="text-[11px] font-mono text-emerald-600">
              {correlations[0]
                ? `OLS Slope Verified (r = ${correlations[0].r})`
                : "4-Quadrant Classification"}
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {cohortStats.slice(0, 4).map((c, i) => {
              const highP = c.meanPrimary >= avgP;
              const highS = c.meanSecondary >= avgS;
              const quadLabel =
                highP && highS
                  ? "Q1: Star Leader (High/High)"
                  : highP && !highS
                  ? "Q2: Cash Cow (High Vol / Low S2)"
                  : !highP && highS
                  ? "Q3: Bottleneck Risk"
                  : "Q4: Turnaround Target";
              return (
                <div
                  key={i}
                  className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1"
                >
                  <div className="text-[10px] font-mono font-bold text-blue-600">
                    {quadLabel}
                  </div>
                  <div className="text-xs font-bold text-slate-900">
                    {c.cohort}
                  </div>
                  <div className="text-[11px] font-mono text-slate-600">
                    Mean {activePrimaryNum}: {c.meanPrimary.toLocaleString()}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500">
                    Mean {activeSecondaryNum}: {c.meanSecondary.toLocaleString()}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      );
    }

    // 4. Sankey / Conversion Funnel Attribution
    if (layoutId === "sankey-funnel-conversion") {
      return (
        <div className="p-4 rounded-xl bg-white border border-blue-600 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">
              {tpl.platform} Architecture Preview: Multi-Stage Conversion Funnel & Cohort Attribution Flow
            </span>
            <span className="text-[11px] font-mono text-blue-600">
              {cleaningSummary.rawRowCount} Raw → {cleaningSummary.cleanedRowCount} Verified
            </span>
          </div>
          <div className="space-y-2">
            {cohortStats.slice(0, 5).map((c, idx) => (
              <div key={idx} className="flex items-center gap-3 text-xs font-mono">
                <span className="w-36 truncate font-bold text-slate-900">
                  Stage {idx + 1}: {c.cohort}
                </span>
                <div className="flex-1 h-5 rounded bg-slate-100 overflow-hidden relative">
                  <div
                    className="h-full bg-blue-600 rounded flex items-center px-2 text-[10px] text-white font-bold"
                    style={{
                      width: `${Math.min(100, Math.max(18, c.sharePct * 1.8))}%`,
                    }}
                  >
                    {c.sumPrimary.toLocaleString()} ({c.sharePct}%)
                  </div>
                </div>
                <span className="w-24 text-right text-slate-600">
                  n = {c.count} rows
                </span>
              </div>
            ))}
          </div>
        </div>
      );
    }

    // Default / Executive Ribbon + Bullet + Boxplot + Matrix Summary
    return (
      <div className="p-4 rounded-xl bg-white border border-blue-600 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-900">
            {tpl.platform} Architecture Preview: {tpl.layoutName}
          </span>
          <span className="text-[11px] font-mono text-blue-600">
            {tpl.presentationSlideCount} Slides / Views Included
          </span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {cohortStats.slice(0, 3).map((c, i) => (
            <div
              key={i}
              className="p-3 rounded-lg bg-slate-50 border border-slate-200 space-y-1"
            >
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="font-bold text-slate-900">{c.cohort}</span>
                <span
                  className={
                    c.variancePct >= 0 ? "text-emerald-600" : "text-amber-600"
                  }
                >
                  {c.variancePct >= 0 ? `+${c.variancePct}%` : `${c.variancePct}%`} vs Avg
                </span>
              </div>
              <div className="text-sm font-bold font-mono text-blue-600">
                {c.sumPrimary.toLocaleString()} ({c.sharePct}%)
              </div>
              <div className="text-[10px] font-mono text-slate-500">
                IQR Safe Median: {c.median.toLocaleString()} · Target:{" "}
                {c.targetPrimary.toLocaleString()}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-6 min-w-0 max-w-full overflow-x-hidden">
      {/* Studio Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-0.5 text-[11px] font-mono font-bold uppercase rounded bg-blue-600 text-white">
              ALL 108 POWER BI & TABLEAU TEMPLATES UNLOCKED
            </span>
            <span className="text-xs font-mono text-blue-600 font-semibold">
              54 Power BI Decks (PBI-001–PBI-054) · 54 Tableau Workbooks (TAB-055–TAB-108)
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
            Power BI & Tableau Presentation Studio + Live Customer Data Preview
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 max-w-4xl">
            Browse all <strong>108 templates</strong> across 9 business domains,
            click <strong>&quot;Preview with My Data&quot;</strong> on any
            template to inspect how{" "}
            <span className="font-mono text-blue-600">{datasetName}</span> looks
            inside that layout before choosing it, or let Rexor&apos;s AI
            Advisor rank the top matches for your requirement.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setPreviewModalTemplateId(selectedTemplate.id)}
            className="px-3.5 py-2 text-xs font-semibold bg-slate-100 text-slate-900 border border-blue-600 rounded-lg flex items-center gap-1.5 cursor-pointer"
          >
            <Eye className="w-3.5 h-3.5 text-blue-600" />
            <span>
              Preview Active Template with My Data ({selectedTemplate.code})
            </span>
          </button>
          <button
            type="button"
            onClick={() => {
              handleExportBiTemplateSpec(selectedTemplate);
              triggerStudioFeedback(
                `Exported ${selectedTemplate.platform} Spec (${selectedTemplate.code}) JSON`
              );
            }}
            className="px-3.5 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>
              Export {selectedTemplate.platform} Spec ({selectedTemplate.code})
            </span>
          </button>
        </div>
      </div>

      {studioActionToast && (
        <div className="px-4 py-2.5 rounded-xl bg-blue-50 border border-blue-600 text-xs font-mono text-slate-900 flex items-center justify-between gap-2">
          <span className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{studioActionToast}</span>
          </span>
          <button
            type="button"
            onClick={() => setStudioActionToast(null)}
            className="text-blue-600 hover:underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* =====================================================================
          PART 1: REXOR AI TEMPLATE ADVISOR (GUIDES USER BY TARGET GOAL)
         ===================================================================== */}
      <div className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-blue-600 space-y-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-blue-600 shrink-0" />
            <h3 className="text-sm sm:text-base font-bold text-slate-900">
              Rexor AI Template & Target Presentation Advisor
            </h3>
          </div>
          <span className="text-xs font-mono text-blue-600">
            Describe your requirement — Rexor scores all 108 templates and lets you preview your data in each
          </span>
        </div>

        {/* Quick Target Goal Buttons */}
        <div className="flex flex-wrap items-center gap-1.5">
          {TARGET_GOAL_PRESETS.map((preset, idx) => (
            <button
              key={idx}
              type="button"
              onClick={() => {
                setUserGoalPrompt(preset.prompt);
                triggerStudioFeedback(
                  `AI Advisor Ranked Top Templates for: "${preset.label}"`
                );
              }}
              className={`px-2.5 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                userGoalPrompt === preset.prompt
                  ? "bg-blue-600 text-white border-blue-500 font-semibold"
                  : "bg-white text-slate-700 border-slate-300 hover:border-blue-600"
              }`}
            >
              {preset.label}
            </button>
          ))}
        </div>

        {/* Custom Goal Input */}
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={userGoalPrompt}
            onChange={(e) => setUserGoalPrompt(e.target.value)}
            placeholder="Describe what you want to show (e.g., 'Present outlet profit leakage and prep time impact in Power BI to our CEO')..."
            className="flex-1 px-3.5 py-2 text-xs bg-white border border-slate-300 rounded-lg"
          />
          <button
            type="button"
            onClick={() => {
              const topRec = aiRecommendations[0]?.template;
              if (topRec) {
                setSelectedTemplateId(topRec.id);
                setPreviewModalTemplateId(topRec.id);
                triggerStudioFeedback(
                  `Opened Data Preview for #1 Match: ${topRec.code} (${topRec.platform}) — ${topRec.title}`
                );
              }
            }}
            className="px-3.5 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer whitespace-nowrap flex items-center gap-1.5"
          >
            <Eye className="w-3.5 h-3.5" />
            <span>Preview #1 Recommended Template</span>
          </button>
          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-300 shrink-0">
            {(["ALL", "Power BI", "Tableau"] as const).map((plat) => (
              <button
                key={plat}
                type="button"
                onClick={() => {
                  setPlatformFilter(plat);
                  triggerStudioFeedback(
                    `Filtered Catalog to: ${
                      plat === "ALL"
                        ? "All 108 Power BI & Tableau Templates"
                        : `${plat} Templates (54)`
                    }`
                  );
                }}
                className={`px-2.5 py-1 text-xs font-semibold rounded cursor-pointer ${
                  platformFilter === plat
                    ? "bg-blue-600 text-white"
                    : "text-slate-600"
                }`}
              >
                {plat === "ALL" ? "Both (108)" : `${plat} (54)`}
              </button>
            ))}
          </div>
        </div>

        {/* Top 3 AI Recommended Templates with Dual Buttons: "Preview with My Data" + "Load in Studio" */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
          {aiRecommendations.slice(0, 3).map((rec, i) => {
            const isSelected = selectedTemplate.id === rec.template.id;
            return (
              <div
                key={rec.template.id}
                className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                  isSelected
                    ? "border-blue-600 bg-blue-50/40"
                    : "border-slate-200 bg-white"
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-blue-600 text-white">
                      #{i + 1} AI PICK · {rec.matchScorePct}% MATCH
                    </span>
                    <span className="text-[11px] font-mono font-bold text-blue-600">
                      {rec.template.platform} · {rec.template.code}
                    </span>
                  </div>
                  <h4 className="text-sm font-bold text-slate-900">
                    {rec.template.title}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {rec.aiWhyChooseThis}
                  </p>
                  <div className="text-[11px] font-mono text-emerald-600">
                    {rec.mappedColumnsNote}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTemplateId(rec.template.id);
                      setPreviewModalTemplateId(rec.template.id);
                    }}
                    className="px-2.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 text-slate-900 border border-blue-600 flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    <span>Preview Data</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTemplateId(rec.template.id);
                      triggerStudioFeedback(
                        `Loaded ${rec.template.code} (${rec.template.platform}): ${rec.template.title} into Live Canvas`,
                        true
                      );
                    }}
                    className={`px-2.5 py-2 text-xs font-semibold rounded-lg cursor-pointer ${
                      isSelected
                        ? "bg-emerald-600 text-white"
                        : "bg-blue-600 text-white hover:bg-blue-700"
                    }`}
                  >
                    {isSelected
                      ? "✓ Active in Studio"
                      : `Use ${rec.template.code} →`}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* =====================================================================
          PART 2: FULL 108 POWER BI & TABLEAU TEMPLATE CATALOG (ALL 108 VISIBLE!)
         ===================================================================== */}
      <div className="space-y-4">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-mono font-bold uppercase text-slate-900 mr-1">
              Showing {showAllCatalog ? filteredTemplates.length : Math.min(12, filteredTemplates.length)} of {filteredTemplates.length} Templates:
            </span>
            <button
              type="button"
              onClick={() => setDomainFilter("ALL")}
              className={`px-2.5 py-1 text-xs font-mono rounded cursor-pointer ${
                domainFilter === "ALL"
                  ? "bg-blue-600 text-white font-bold"
                  : "bg-slate-100 text-slate-600"
              }`}
            >
              All 9 Domains (108)
            </button>
            {DOMAINS.map((dom) => {
              const countInDomain = allTemplates.filter(
                (t) =>
                  t.domain === dom &&
                  (platformFilter === "ALL" || t.platform === platformFilter)
              ).length;
              return (
                <button
                  key={dom}
                  type="button"
                  onClick={() => setDomainFilter(dom)}
                  className={`px-2.5 py-1 text-xs font-mono rounded cursor-pointer ${
                    domainFilter === dom
                      ? "bg-blue-600 text-white font-bold"
                      : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {dom} ({countInDomain})
                </button>
              );
            })}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search all 108 templates (e.g. PBI-025, TAB-080, Pareto, Waterfall, POS)..."
              className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg w-64"
            />
            <button
              type="button"
              onClick={() =>
                setCatalogViewMode((prev) =>
                  prev === "grid-all" ? "grouped-domains" : "grid-all"
                )
              }
              className="px-3 py-1.5 text-xs font-mono font-semibold bg-slate-100 text-slate-800 rounded-lg cursor-pointer whitespace-nowrap"
            >
              {catalogViewMode === "grid-all"
                ? "Group by 9 Domains"
                : "Flat Grid View"}
            </button>
            <button
              type="button"
              onClick={() => setShowAllCatalog((prev) => !prev)}
              className="px-3 py-1.5 text-xs font-mono font-semibold bg-blue-600 text-white rounded-lg cursor-pointer whitespace-nowrap"
            >
              {showAllCatalog
                ? `Showing All (${filteredTemplates.length}) · Click for Compact (12)`
                : `Show All ${filteredTemplates.length} Templates`}
            </button>
          </div>
        </div>

        {/* Grouped by 9 Business Domains OR Full 108-Card Catalog Grid */}
        {catalogViewMode === "grouped-domains" && domainFilter === "ALL" ? (
          <div className="space-y-6">
            {DOMAINS.map((dom) => {
              const domTemplates = filteredTemplates.filter(
                (t) => t.domain === dom
              );
              if (domTemplates.length === 0) return null;
              return (
                <div
                  key={dom}
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3"
                >
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <div className="text-sm font-bold text-slate-900">
                      {dom} — {domTemplates.length} Templates (6 Power BI + 6 Tableau)
                    </div>
                    <span className="text-xs font-mono text-blue-600">
                      Click &quot;Preview Data&quot; on any card to test with {datasetName}
                    </span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                    {domTemplates.map((tpl) => {
                      const isSelected = tpl.id === selectedTemplate.id;
                      return (
                        <div
                          key={tpl.id}
                          className={`text-left p-3.5 rounded-xl border transition-all flex flex-col justify-between gap-2.5 ${
                            isSelected
                              ? "border-blue-600 bg-blue-50/40"
                              : "border-slate-200 bg-white hover:border-blue-600"
                          }`}
                        >
                          <div className="space-y-1">
                            <div className="flex items-center justify-between text-[10px] font-mono">
                              <span className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-800 font-bold">
                                {tpl.code} · {tpl.platform}
                              </span>
                              <span className="text-blue-600 truncate max-w-[120px]">
                                {tpl.complexityLevel}
                              </span>
                            </div>
                            <div className="text-xs font-bold text-slate-900 line-clamp-1">
                              {tpl.title}
                            </div>
                            <div className="text-[11px] text-slate-500 line-clamp-2">
                              {tpl.layoutName}
                            </div>
                          </div>

                          <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-1.5">
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedTemplateId(tpl.id);
                                setPreviewModalTemplateId(tpl.id);
                              }}
                              className="px-2 py-1.5 text-[11px] font-mono font-semibold rounded bg-slate-100 text-slate-900 border border-blue-600 flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Eye className="w-3 h-3 text-blue-600 shrink-0" />
                              <span>Preview Data</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedTemplateId(tpl.id);
                                triggerStudioFeedback(
                                  `Activated ${tpl.code} (${tpl.platform}): ${tpl.title}`,
                                  true
                                );
                              }}
                              className={`px-2 py-1.5 text-[11px] font-mono font-semibold rounded cursor-pointer ${
                                isSelected
                                  ? "bg-emerald-600 text-white"
                                  : "bg-blue-600 text-white"
                              }`}
                            >
                              {isSelected ? "✓ Active" : "Use Layout →"}
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 max-h-[680px] overflow-y-auto p-1">
            {(showAllCatalog
              ? filteredTemplates
              : filteredTemplates.slice(0, 12)
            ).map((tpl, index) => {
              const isSelected = tpl.id === selectedTemplate.id;
              return (
                <div
                  key={tpl.id}
                  className={`text-left p-3.5 rounded-xl border transition-all flex flex-col justify-between gap-2.5 ${
                    isSelected
                      ? "border-blue-600 bg-blue-50/40"
                      : "border-slate-200 bg-slate-50 hover:border-blue-600"
                  }`}
                >
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[10px] font-mono">
                      <span className="px-1.5 py-0.5 rounded bg-slate-200 text-slate-800 font-bold">
                        #{index + 1} · {tpl.code} ({tpl.platform})
                      </span>
                      <span className="text-blue-600 truncate max-w-[125px]">
                        {tpl.domain}
                      </span>
                    </div>
                    <div className="text-xs font-bold text-slate-900 line-clamp-1">
                      {tpl.title}
                    </div>
                    <div className="text-[11px] text-slate-500 line-clamp-2">
                      {tpl.layoutName}
                    </div>
                    <div className="text-[10px] font-mono text-slate-500">
                      Audience: {tpl.targetAudience} · {tpl.visualsIncluded.length} Visuals
                    </div>
                  </div>

                  <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTemplateId(tpl.id);
                        setPreviewModalTemplateId(tpl.id);
                      }}
                      className="px-2 py-1.5 text-[11px] font-mono font-semibold rounded bg-white text-slate-900 border border-blue-600 flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Eye className="w-3 h-3 text-blue-600 shrink-0" />
                      <span>Preview Data</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTemplateId(tpl.id);
                        triggerStudioFeedback(
                          `Activated ${tpl.code} (${tpl.platform}): ${tpl.title}`,
                          true
                        );
                      }}
                      className={`px-2 py-1.5 text-[11px] font-mono font-semibold rounded cursor-pointer ${
                        isSelected
                          ? "bg-emerald-600 text-white"
                          : "bg-blue-600 text-white"
                      }`}
                    >
                      {isSelected ? "✓ Active" : "Use Layout →"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* =====================================================================
          PART 3: NON-MINIMALISTIC MULTI-VISUAL CONFIGURATION & CUSTOMIZATION BAR
         ===================================================================== */}
      <div
        ref={liveCanvasRef}
        className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3"
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-900">
              Full-Control Visualization Shelf & Multi-Panel Toggles (Non-Minimalistic Studio)
            </span>
          </div>
          <span className="text-xs font-mono text-blue-600">
            Active Template: {selectedTemplate.code} · {selectedTemplate.title}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-7 gap-2.5 items-end">
          <div>
            <label className="block text-[11px] font-mono text-slate-500 mb-1">
              Rows / Cohort Axis ({selectedTemplate.platform === "Tableau" ? "Columns Shelf" : "Axis"})
            </label>
            <select
              value={activeCatCol}
              onChange={(e) => setSelectedCatCol(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
            >
              {categoricalCols.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-500 mb-1">
              Primary Measure (Values / Y1 Axis)
            </label>
            <select
              value={activePrimaryNum}
              onChange={(e) => setSelectedPrimaryNum(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
            >
              {numericCols.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-mono text-slate-500 mb-1">
              Secondary Measure (Line / Color / Y2 Axis)
            </label>
            <select
              value={activeSecondaryNum}
              onChange={(e) => setSelectedSecondaryNum(e.target.value)}
              className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
            >
              {numericCols.map((c) => (
                <option key={c.name} value={c.name}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          {/* 4 Multi-Panel Toggle Switches */}
          <button
            type="button"
            onClick={() => setShowParetoOverlay((p) => !p)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-lg border cursor-pointer ${
              showParetoOverlay
                ? "bg-blue-600 text-white border-blue-500 font-bold"
                : "bg-white text-slate-600 border-slate-300"
            }`}
          >
            {showParetoOverlay ? "✓ 80/20 Pareto" : "+ 80/20 Pareto"}
          </button>

          <button
            type="button"
            onClick={() => setShowBulletTargets((p) => !p)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-lg border cursor-pointer ${
              showBulletTargets
                ? "bg-blue-600 text-white border-blue-500 font-bold"
                : "bg-white text-slate-600 border-slate-300"
            }`}
          >
            {showBulletTargets ? "✓ Bullet Target" : "+ Bullet Target"}
          </button>

          <button
            type="button"
            onClick={() => setShowCrosstabMatrix((p) => !p)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-lg border cursor-pointer ${
              showCrosstabMatrix
                ? "bg-blue-600 text-white border-blue-500 font-bold"
                : "bg-white text-slate-600 border-slate-300"
            }`}
          >
            {showCrosstabMatrix ? "✓ Matrix Table" : "+ Matrix Table"}
          </button>

          <button
            type="button"
            onClick={() => setShowDaxLodSpec((p) => !p)}
            className={`px-2.5 py-1.5 text-xs font-mono rounded-lg border cursor-pointer ${
              showDaxLodSpec
                ? "bg-blue-600 text-white border-blue-500 font-bold"
                : "bg-white text-slate-600 border-slate-300"
            }`}
          >
            {showDaxLodSpec ? "✓ DAX / LOD Code" : "+ DAX / LOD Code"}
          </button>
        </div>
      </div>

      {/* =====================================================================
          PART 4: LIVE MULTI-PANEL POWER BI / TABLEAU CANVAS (HYDRATED WITH DATA)
         ===================================================================== */}
      <div className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-5">
        {/* Canvas Top Bar */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-blue-600 text-white">
                {selectedTemplate.platform.toUpperCase()} LIVE WORKBOOK CANVAS
              </span>
              <span className="text-xs font-mono text-slate-500">
                {selectedTemplate.code} · {selectedTemplate.layoutName}
              </span>
            </div>
            <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
              {selectedTemplate.title} — {datasetName}
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              <strong>Why Choose This Template:</strong>{" "}
              {selectedTemplate.whenToChoose}
            </p>
          </div>
          <div className="flex flex-wrap gap-1.5">
            {selectedTemplate.visualsIncluded.map((v, idx) => (
              <span
                key={idx}
                className="px-2 py-0.5 text-[10px] font-mono rounded bg-white border border-slate-200 text-slate-700"
              >
                {v}
              </span>
            ))}
          </div>
        </div>

        {/* Dynamic Layout-Specific Architecture Preview Banner */}
        {renderArchitectureVisualPreview(selectedTemplate)}

        {/* Panel Row 1: 4 Multi-KPI Scorecards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-1">
            <div className="text-[11px] font-mono text-slate-500">
              Total Verified {activePrimaryNum}
            </div>
            <div className="text-xl font-bold font-mono text-slate-900">
              {totalVerifiedPrimary.toLocaleString(undefined, {
                maximumFractionDigits: 1,
              })}
            </div>
            <div className="text-[11px] font-mono text-emerald-600">
              100% Verified ({cleaningSummary.cleanedRowCount} rows)
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-1">
            <div className="text-[11px] font-mono text-slate-500">
              Top Cohort ({activeCatCol})
            </div>
            <div className="text-xl font-bold font-mono text-blue-600 truncate">
              {cohortStats[0]?.cohort || "N/A"}
            </div>
            <div className="text-[11px] font-mono text-slate-600">
              {cohortStats[0]?.sharePct || 0}% of Total Share
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-1">
            <div className="text-[11px] font-mono text-slate-500">
              Global Mean {activeSecondaryNum}
            </div>
            <div className="text-xl font-bold font-mono text-slate-900">
              {cohortStats.length > 0
                ? (
                    cohortStats.reduce((a, b) => a + b.meanSecondary, 0) /
                    cohortStats.length
                  ).toFixed(2)
                : "0.00"}
            </div>
            <div className="text-[11px] font-mono text-slate-500">
              Secondary Measure Benchmark
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-white border border-slate-200 space-y-1">
            <div className="text-[11px] font-mono text-slate-500">
              Primary Pearson Correlation (r)
            </div>
            <div className="text-xl font-bold font-mono text-emerald-600">
              {correlations[0]
                ? `r = ${correlations[0].r.toFixed(3)}`
                : "Verified"}
            </div>
            <div className="text-[11px] font-mono text-slate-500 truncate">
              {correlations[0]
                ? `${correlations[0].colA} ↔ ${correlations[0].colB}`
                : "Statistical Driver"}
            </div>
          </div>
        </div>

        {/* Panel Row 2: Combo Dual-Axis + 80/20 Pareto Curve + Small Multiples / Boxplot */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Left 7 Cols: Combo Bar + Cumulative 80/20 Pareto & Target Bullet Visual */}
          <div className="lg:col-span-7 p-4 rounded-xl bg-white border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">
                {selectedTemplate.platform} Visual 1: Cohort {activePrimaryNum} vs Target +{" "}
                {showParetoOverlay ? "80/20 Pareto Cumulative Curve" : "Share %"}
              </span>
              <span className="text-[11px] font-mono text-blue-600">
                {cohortStats.length} Cohorts
              </span>
            </div>

            <div className="space-y-2.5">
              {cohortStats.slice(0, 8).map((item, idx) => {
                const widthPct = Math.min(
                  100,
                  Math.max(6, (item.sumPrimary / maxCohortSum) * 100)
                );
                const targetPct = Math.min(
                  100,
                  Math.max(8, (item.targetPrimary / maxCohortSum) * 100)
                );
                return (
                  <div key={idx} className="space-y-1">
                    <div className="flex items-center justify-between text-xs font-mono">
                      <span className="font-bold text-slate-900 truncate max-w-[180px]">
                        {idx + 1}. {item.cohort}
                      </span>
                      <div className="flex items-center gap-3 text-[11px]">
                        <span className="text-blue-600 font-bold">
                          {item.sumPrimary.toLocaleString()} ({item.sharePct}%)
                        </span>
                        {showParetoOverlay && (
                          <span className="px-1.5 py-0.5 rounded bg-slate-100 text-slate-700">
                            Cumul: {item.cumulativePct}%
                          </span>
                        )}
                        <span className="text-slate-500">
                          Avg {activeSecondaryNum}: {item.meanSecondary}
                        </span>
                      </div>
                    </div>
                    <div className="relative h-3.5 w-full rounded bg-slate-100 overflow-hidden">
                      <div
                        className="h-full bg-blue-600 rounded transition-all"
                        style={{ width: `${widthPct}%` }}
                      />
                      {showBulletTargets && (
                        <div
                          title={`Target: ${item.targetPrimary.toLocaleString()}`}
                          className="absolute top-0 bottom-0 w-0.5 bg-amber-400"
                          style={{ left: `${targetPct}%` }}
                        />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right 5 Cols: Box-and-Whisker IQR Quartile & Small Multiples Treemap Matrix */}
          <div className="lg:col-span-5 p-4 rounded-xl bg-white border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">
                {selectedTemplate.platform} Visual 2:{" "}
                {showBoxplotStats
                  ? "Tukey Quartile (Min / Q1 / Median / Q3 / Max) Distribution"
                  : "Hierarchical Share Matrix"}
              </span>
              <button
                type="button"
                onClick={() => setShowBoxplotStats((p) => !p)}
                className="text-[11px] font-mono text-blue-600 hover:underline cursor-pointer"
              >
                Switch View
              </button>
            </div>

            <div className="space-y-2">
              {cohortStats.slice(0, 6).map((c, idx) => (
                <div
                  key={idx}
                  className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 space-y-1"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{c.cohort}</span>
                    <span className="font-mono text-[11px] text-blue-600">
                      n = {c.count} rows · Share {c.sharePct}%
                    </span>
                  </div>
                  <div className="grid grid-cols-5 gap-1 text-[10px] font-mono text-slate-600 pt-1">
                    <div>Min: {c.min.toLocaleString()}</div>
                    <div>Q1: {c.q1.toLocaleString()}</div>
                    <div className="font-bold text-blue-600">
                      Med: {c.median.toLocaleString()}
                    </div>
                    <div>Q3: {c.q3.toLocaleString()}</div>
                    <div>Max: {c.max.toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Panel Row 3: Conditional Formatting Pivot Matrix Crosstab (Power BI / Tableau Highlight Table) */}
        {showCrosstabMatrix && (
          <div className="rounded-xl bg-white border border-slate-200 overflow-hidden">
            <div className="px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-900">
                {selectedTemplate.platform} Visual 3: Conditional Formatting Highlight Matrix & In-Cell Data Bars
              </span>
              <span className="text-[11px] font-mono text-slate-500">
                Auto-Reconciled with Stage 3–4 Pipeline
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 font-mono text-[11px] text-slate-600">
                    <th className="py-2 px-3">{activeCatCol}</th>
                    <th className="py-2 px-3">Verified Rows</th>
                    <th className="py-2 px-3">Sum {activePrimaryNum}</th>
                    <th className="py-2 px-3">Mean {activePrimaryNum}</th>
                    <th className="py-2 px-3">Median (IQR Safe)</th>
                    <th className="py-2 px-3">Mean {activeSecondaryNum}</th>
                    <th className="py-2 px-3">Pareto Cumulative %</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {cohortStats.map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2 px-3 font-bold text-slate-900">
                        {row.cohort}
                      </td>
                      <td className="py-2 px-3">{row.count}</td>
                      <td className="py-2 px-3 text-blue-600 font-bold">
                        {row.sumPrimary.toLocaleString()}
                      </td>
                      <td className="py-2 px-3">
                        {row.meanPrimary.toLocaleString()}
                      </td>
                      <td className="py-2 px-3">
                        {row.median.toLocaleString()}
                      </td>
                      <td className="py-2 px-3">
                        {row.meanSecondary.toLocaleString()}
                      </td>
                      <td className="py-2 px-3">
                        <span className="px-2 py-0.5 rounded bg-blue-50 text-blue-600 border border-blue-200">
                          {row.cumulativePct}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Panel Row 4: Power BI DAX / Tableau LOD Calculation Formula Block */}
        {showDaxLodSpec && (
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-blue-400 font-semibold">
                {selectedTemplate.formulaLabel} ({selectedTemplate.code})
              </span>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(selectedTemplate.formulaCode);
                  setCopiedFormula(true);
                  window.setTimeout(() => setCopiedFormula(false), 1800);
                }}
                className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-800 text-slate-200 flex items-center gap-1 cursor-pointer"
              >
                {copiedFormula ? (
                  <>
                    <Check className="w-3 h-3" />
                    <span>Copied Formula</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy {selectedTemplate.platform} Formula</span>
                  </>
                )}
              </button>
            </div>
            <pre className="text-xs font-mono text-blue-100 overflow-x-auto whitespace-pre-wrap">
              {selectedTemplate.formulaCode}
            </pre>
          </div>
        )}
      </div>

      {/* =====================================================================
          INTERACTIVE CUSTOMER DATA & TEMPLATE REQUIREMENT PREVIEW MODAL
         ===================================================================== */}
      {previewTemplate && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-3 sm:px-6 py-6 overflow-y-auto"
          onClick={() => setPreviewModalTemplateId(null)}
        >
          <div
            className="bg-white border border-blue-600 rounded-2xl max-w-6xl w-full p-5 sm:p-6 space-y-5 max-h-[92vh] overflow-y-auto shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Preview Modal Header */}
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-4 border-b border-slate-200">
              <div className="space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 text-[11px] font-mono font-bold rounded bg-blue-600 text-white">
                    LIVE CUSTOMER DATA PREVIEW · {previewTemplate.code} ({previewTemplate.platform})
                  </span>
                  <span className="text-xs font-mono text-blue-600 font-semibold">
                    Domain: {previewTemplate.domain} · {previewTemplate.complexityLevel}
                  </span>
                </div>
                <h3 className="text-xl sm:text-2xl font-bold text-slate-900">
                  {previewTemplate.title} — Previewing with &quot;{datasetName}&quot;
                </h3>
                <p className="text-xs text-slate-600">
                  Target Audience: <strong>{previewTemplate.targetAudience}</strong> ·{" "}
                  Layout Architecture: <strong>{previewTemplate.layoutName}</strong>
                </p>
              </div>

              {/* Prev / Next Template Switcher (Browse all 108 right inside Preview!) */}
              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    const idx = allTemplates.findIndex(
                      (t) => t.id === previewTemplate.id
                    );
                    const prevIdx =
                      (idx - 1 + allTemplates.length) % allTemplates.length;
                    const nextTpl = allTemplates[prevIdx];
                    setPreviewModalTemplateId(nextTpl.id);
                    setSelectedTemplateId(nextTpl.id);
                  }}
                  className="px-2.5 py-1.5 text-xs font-mono bg-slate-100 text-slate-800 rounded-lg flex items-center gap-1 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  <span>Prev Template</span>
                </button>
                <span className="text-xs font-mono text-slate-500">
                  {allTemplates.findIndex((t) => t.id === previewTemplate.id) +
                    1}{" "}
                  / {allTemplates.length}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const idx = allTemplates.findIndex(
                      (t) => t.id === previewTemplate.id
                    );
                    const nextIdx = (idx + 1) % allTemplates.length;
                    const nextTpl = allTemplates[nextIdx];
                    setPreviewModalTemplateId(nextTpl.id);
                    setSelectedTemplateId(nextTpl.id);
                  }}
                  className="px-2.5 py-1.5 text-xs font-mono bg-slate-100 text-slate-800 rounded-lg flex items-center gap-1 cursor-pointer"
                >
                  <span>Next Template</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewModalTemplateId(null)}
                  className="p-2 text-slate-500 hover:text-slate-900 rounded-lg bg-slate-100 cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Section A: Requirement Fit & Why Choose This Template */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              <div className="lg:col-span-7 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono font-bold text-blue-600 uppercase">
                    Requirement Suitability & AI Guidance
                  </span>
                  <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-50 text-emerald-600 border border-emerald-200">
                    {cleaningSummary.cleanedRowCount} Verified Rows Mapped
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-slate-900 leading-relaxed">
                  <strong>When to Choose {previewTemplate.code}:</strong>{" "}
                  {previewTemplate.whenToChoose}
                </p>
                <div className="pt-1 flex flex-wrap gap-1.5">
                  {previewTemplate.visualsIncluded.map((vis, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 text-[11px] font-mono rounded bg-white border border-slate-200 text-slate-700"
                    >
                      ✓ {vis}
                    </span>
                  ))}
                </div>
              </div>

              {/* Interactive Column Shelf Remapper inside Preview */}
              <div className="lg:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="text-xs font-mono font-bold text-slate-900 uppercase">
                  Test Different Columns from Your Data:
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[10px] font-mono text-slate-500 mb-0.5">
                      Dimension / Cohort
                    </label>
                    <select
                      value={activeCatCol}
                      onChange={(e) => setSelectedCatCol(e.target.value)}
                      className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded"
                    >
                      {categoricalCols.map((c) => (
                        <option key={c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-500 mb-0.5">
                      Primary Metric
                    </label>
                    <select
                      value={activePrimaryNum}
                      onChange={(e) => setSelectedPrimaryNum(e.target.value)}
                      className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded"
                    >
                      {numericCols.map((c) => (
                        <option key={c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-[10px] font-mono text-slate-500 mb-0.5">
                      Secondary Metric
                    </label>
                    <select
                      value={activeSecondaryNum}
                      onChange={(e) => setSelectedSecondaryNum(e.target.value)}
                      className="w-full px-2 py-1 text-xs bg-white border border-slate-300 rounded"
                    >
                      {numericCols.map((c) => (
                        <option key={c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            {/* Section B: Live Architecture Visual Hydrated with Customer Data */}
            {renderArchitectureVisualPreview(previewTemplate)}

            {/* Section C: Customer Data Sample Mapped into This Template's Columns */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
              {/* Aggregated Cohort View */}
              <div className="lg:col-span-7 rounded-xl bg-white border border-slate-200 overflow-hidden">
                <div className="px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    Your Data Aggregated in {previewTemplate.code} ({activeCatCol} Breakdown)
                  </span>
                  <span className="text-[11px] font-mono text-blue-600">
                    {cohortStats.length} Cohorts
                  </span>
                </div>
                <div className="overflow-x-auto max-h-60">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 font-mono text-[11px] text-slate-600">
                        <th className="py-2 px-3">{activeCatCol}</th>
                        <th className="py-2 px-3">Rows</th>
                        <th className="py-2 px-3">Sum {activePrimaryNum}</th>
                        <th className="py-2 px-3">Share %</th>
                        <th className="py-2 px-3">Pareto Cumul %</th>
                        <th className="py-2 px-3">Avg {activeSecondaryNum}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono">
                      {cohortStats.map((r, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-bold text-slate-900">
                            {r.cohort}
                          </td>
                          <td className="py-2 px-3">{r.count}</td>
                          <td className="py-2 px-3 text-blue-600 font-bold">
                            {r.sumPrimary.toLocaleString()}
                          </td>
                          <td className="py-2 px-3">{r.sharePct}%</td>
                          <td className="py-2 px-3">{r.cumulativePct}%</td>
                          <td className="py-2 px-3">
                            {r.meanSecondary.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Raw Cleaned Customer Records Preview */}
              <div className="lg:col-span-5 rounded-xl bg-white border border-slate-200 overflow-hidden">
                <div className="px-4 py-2.5 bg-slate-100 border-b border-slate-200 flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    Individual Cleaned Records Feeding {previewTemplate.code}
                  </span>
                  <span className="text-[11px] font-mono text-emerald-600">
                    Top 8 of {cleanedRows.length} Rows
                  </span>
                </div>
                <div className="overflow-x-auto max-h-60">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 font-mono text-[11px] text-slate-600">
                        <th className="py-2 px-2.5">#</th>
                        <th className="py-2 px-2.5">{activeCatCol}</th>
                        <th className="py-2 px-2.5">{activePrimaryNum}</th>
                        <th className="py-2 px-2.5">{activeSecondaryNum}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 font-mono">
                      {cleanedRows.slice(0, 8).map((row, idx) => (
                        <tr key={idx} className="hover:bg-slate-50">
                          <td className="py-1.5 px-2.5 text-slate-500">
                            {idx + 1}
                          </td>
                          <td className="py-1.5 px-2.5 font-bold text-slate-900 truncate max-w-[120px]">
                            {String(row[activeCatCol] ?? "—")}
                          </td>
                          <td className="py-1.5 px-2.5 text-blue-600">
                            {Number(row[activePrimaryNum] ?? 0).toLocaleString()}
                          </td>
                          <td className="py-1.5 px-2.5">
                            {Number(row[activeSecondaryNum] ?? 0).toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-xs font-mono text-slate-500">
                  Quick Compare Top AI Matches:
                </span>
                {aiRecommendations.slice(0, 3).map((rec, idx) => (
                  <button
                    key={rec.template.id}
                    type="button"
                    onClick={() => {
                      setPreviewModalTemplateId(rec.template.id);
                      setSelectedTemplateId(rec.template.id);
                    }}
                    className={`px-2.5 py-1 text-xs font-mono rounded cursor-pointer ${
                      previewTemplate.id === rec.template.id
                        ? "bg-blue-600 text-white font-bold"
                        : "bg-slate-100 text-slate-700"
                    }`}
                  >
                    #{idx + 1} {rec.template.code} ({rec.matchScorePct}%)
                  </button>
                ))}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleExportBiTemplateSpec(previewTemplate)}
                  className="px-3.5 py-2 text-xs font-semibold bg-slate-100 text-slate-900 rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export {previewTemplate.code} Spec JSON</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSelectedTemplateId(previewTemplate.id);
                    setPreviewModalTemplateId(null);
                    triggerStudioFeedback(
                      `Applied ${previewTemplate.code} (${previewTemplate.platform}): ${previewTemplate.title} to Main Studio Canvas`,
                      true
                    );
                  }}
                  className="px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    Use {previewTemplate.code} in Main Studio Canvas →
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
