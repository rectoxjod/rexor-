/**
 * Rexor — 5-Task Industry Business Data Analyst Deliverable Studio
 * Executes and presents all 5 official industry assessment tasks on ANY uploaded CSV/Excel or preset dataset:
 *   - Task 1: Data Inspection & Cleaning (Duplicates, Missing Values, Data Types, Categories, Unusual Quantities/Discounts + Separate Cleaned CSV)
 *   - Task 2: Business KPI Calculations (Total Orders, Gross Sales, Net Revenue, Gross Profit, AOV, Return Rate, On-Time Delivery + Formulas & Assumptions)
 *   - Task 3: Business Performance Analysis (Answers all 7 Management Questions with full ranked evidence tables)
 *   - Task 4: Interactive Executive Dashboard (KPI Cards + 5 Mandatory Visuals + Live Category/Region/Channel/Warehouse/Month Slicers)
 *   - Task 5: One-Page Management Report & Multi-Tool Code Pack (Executive Summary, 5 Findings, 3 Recommendations + Excel, SQL, Power BI, Python)
 *
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

import React, { useMemo, useState } from "react";
import {
  Check,
  CheckCircle2,
  Code2,
  Copy,
  Download,
  FileSpreadsheet,
  FileText,
  Filter,
  Layers,
  RotateCcw,
  Table as TableIcon,
} from "lucide-react";
import { CleaningSummary, ColumnProfile, DataRow } from "../types/rexor";
import { executeIndustryAssignmentDeliverables } from "../utils/industryAssignmentEngine";

interface RexorIndustryAssignmentStudioProps {
  datasetName: string;
  rawRows: DataRow[];
  cleanedRows: DataRow[];
  cleaningSummary: CleaningSummary;
  columnProfiles: ColumnProfile[];
  onLoadIndustryPreset?: () => void;
  onOpenExportModal?: () => void;
}

type DeliverableTab =
  | "all-deliverables"
  | "task1-cleaning"
  | "task2-kpis"
  | "task3-questions"
  | "task4-dashboard"
  | "task5-report";

type FormulaToolTab = "math" | "excel" | "sql" | "dax";
type SoftwareCodeTab = "python" | "sql" | "excel" | "powerbi";

export const RexorIndustryAssignmentStudio: React.FC<
  RexorIndustryAssignmentStudioProps
> = ({
  datasetName,
  rawRows,
  cleanedRows,
  cleaningSummary,
  columnProfiles,
  onLoadIndustryPreset,
  onOpenExportModal,
}) => {
  const [activeTab, setActiveTab] = useState<DeliverableTab>("all-deliverables");
  const [formulaTool, setFormulaTool] = useState<FormulaToolTab>("math");
  const [softwareTab, setSoftwareTab] = useState<SoftwareCodeTab>("python");
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Interactive Task 4 Dashboard Slicers
  const [categorySlicer, setCategorySlicer] = useState<string>("ALL");
  const [regionSlicer, setRegionSlicer] = useState<string>("ALL");
  const [channelSlicer, setChannelSlicer] = useState<string>("ALL");
  const [warehouseSlicer, setWarehouseSlicer] = useState<string>("ALL");
  const [monthSlicer, setMonthSlicer] = useState<string>("ALL");

  // Compute baseline report (unfiltered) to populate slicer dropdown options
  const baseDeliverable = useMemo(
    () =>
      executeIndustryAssignmentDeliverables(
        rawRows,
        cleanedRows,
        cleaningSummary,
        columnProfiles,
        datasetName
      ),
    [rawRows, cleanedRows, cleaningSummary, columnProfiles, datasetName]
  );

  // Compute live sliced deliverable report
  const report = useMemo(
    () =>
      executeIndustryAssignmentDeliverables(
        rawRows,
        cleanedRows,
        cleaningSummary,
        columnProfiles,
        datasetName,
        {
          category: categorySlicer,
          region: regionSlicer,
          channel: channelSlicer,
          warehouse: warehouseSlicer,
          month: monthSlicer,
        }
      ),
    [
      rawRows,
      cleanedRows,
      cleaningSummary,
      columnProfiles,
      datasetName,
      categorySlicer,
      regionSlicer,
      channelSlicer,
      warehouseSlicer,
      monthSlicer,
    ]
  );

  const distinctCategories = useMemo(
    () =>
      Array.from(
        new Set(baseDeliverable.normalizedRecords.map((r) => r.category))
      ).sort(),
    [baseDeliverable.normalizedRecords]
  );
  const distinctRegions = useMemo(
    () =>
      Array.from(
        new Set(baseDeliverable.normalizedRecords.map((r) => r.region))
      ).sort(),
    [baseDeliverable.normalizedRecords]
  );
  const distinctChannels = useMemo(
    () =>
      Array.from(
        new Set(baseDeliverable.normalizedRecords.map((r) => r.channel))
      ).sort(),
    [baseDeliverable.normalizedRecords]
  );
  const distinctWarehouses = useMemo(
    () =>
      Array.from(
        new Set(baseDeliverable.normalizedRecords.map((r) => r.warehouse))
      ).sort(),
    [baseDeliverable.normalizedRecords]
  );
  const distinctMonths = useMemo(
    () =>
      Array.from(
        new Set(baseDeliverable.normalizedRecords.map((r) => r.orderMonth))
      ).sort(),
    [baseDeliverable.normalizedRecords]
  );

  const hasActiveSlicer =
    categorySlicer !== "ALL" ||
    regionSlicer !== "ALL" ||
    channelSlicer !== "ALL" ||
    warehouseSlicer !== "ALL" ||
    monthSlicer !== "ALL";

  const resetSlicers = () => {
    setCategorySlicer("ALL");
    setRegionSlicer("ALL");
    setChannelSlicer("ALL");
    setWarehouseSlicer("ALL");
    setMonthSlicer("ALL");
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  // Download Task 1 Separate Cleaned Dataset (.csv) with all standardized fields & KPI columns
  const handleDownloadTask1CleanedCsv = () => {
    const records = baseDeliverable.normalizedRecords;
    if (records.length === 0) return;
    const headers = [
      "Order_ID",
      "Order_Date",
      "Order_Month",
      "Product_Category",
      "Product_Name",
      "Region",
      "Sales_Channel",
      "Warehouse",
      "Quantity",
      "Unit_Price",
      "Discount_Rate",
      "Unit_Cost",
      "Gross_Sales",
      "Discount_Amount",
      "Net_Revenue",
      "Product_Cost",
      "Gross_Profit",
      "Gross_Margin_Pct",
      "Order_Status",
      "Delivery_Status",
    ];
    const lines = [
      headers.join(","),
      ...records.map((r) =>
        [
          r.orderId,
          r.orderDate,
          r.orderMonth,
          `"${r.category.replace(/"/g, '""')}"`,
          `"${r.product.replace(/"/g, '""')}"`,
          `"${r.region.replace(/"/g, '""')}"`,
          `"${r.channel.replace(/"/g, '""')}"`,
          `"${r.warehouse.replace(/"/g, '""')}"`,
          r.quantity,
          r.unitPrice,
          r.discountRate,
          r.unitCost,
          r.grossSales,
          r.discountAmount,
          r.netRevenue,
          r.productCost,
          r.grossProfit,
          r.grossMarginPct,
          r.orderStatus,
          r.deliveryStatus,
        ].join(",")
      ),
    ];
    const blob = new Blob([lines.join("\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${datasetName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")}_task1_cleaned_dataset.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Download Task 5 One-Page Management Report (.md)
  const buildFullManagementReportMarkdown = () => {
    const kpiLines = report.task2Kpis
      .map(
        (k) =>
          `| **${k.kpiName}** | ${k.requirement} | **${k.formattedValue}** | \`${k.mathFormula}\` | ${k.assumptionExplained} |`
      )
      .join("\n");

    const qLines = report.task3Questions
      .map(
        (q) =>
          `### Q${q.questionNumber}. ${q.question}\n- **Answer**: **${q.headlineWinner}** — ${q.executiveAnswer}\n- **Supporting Evidence**: ${q.supportingEvidence}`
      )
      .join("\n\n");

    const findingsLines = report.task5Report.fiveFindings
      .map(
        (f) =>
          `${f.number}. **${f.title}**: ${f.detail} *(Evidence: ${f.metricProof})*`
      )
      .join("\n");

    const recLines = report.task5Report.threeRecommendations
      .map(
        (r) =>
          `${r.number}. **${r.title}** (*Target: ${r.targetArea}*)\n   - **Action**: ${r.actionSteps}\n   - **Expected Impact**: ${r.quantifiedImpact}`
      )
      .join("\n\n");

    return `# Official 5-Task Business Data Analysis Deliverable & Management Report
**Dataset**: ${datasetName}
**Prepared via**: Rexor Autonomous Data Analyst Suite (Architected by Rushi Chavan)
**Date**: ${new Date().toISOString().split("T")[0]}

---

## Executive Summary (Task 5)
${report.task5Report.executiveSummary}

---

## Five Important Business Findings (Task 5)
${findingsLines}

---

## Three Strategic Recommendations to Management (Task 5)
${recLines}

---

## Task 1 — Data Inspection & Cleaning Summary
- **Raw Records Inspected**: ${report.task1.rawRowCount}
- **Cleaned Deduplicated Records**: ${report.task1.cleanedRowCount} (${report.task1.eligibleOrderCount} Eligible Orders)
- **Duplicate Order IDs Removed**: ${report.task1.duplicateOrderIdsCount} (${report.task1.duplicateOrderIdsSample.join(", ") || "None"})
- **Missing Values Imputed**: ${report.task1.missingValuesCount}
- **Incorrect Data Types Standardized**: ${report.task1.incorrectDataTypesCount}
- **Inconsistent Category Labels Unified**: ${report.task1.inconsistentCategoriesCount}
- **Unusual Quantities & Discount Rates Fixed**: ${report.task1.unusualQuantitiesAndDiscountsCount}

---

## Task 2 — Official Business KPI Calculations, Formulas & Assumptions
| KPI | Requirement | Value | Formula | Business Assumption |
| :--- | :--- | :--- | :--- | :--- |
${kpiLines}

---

## Task 3 — Business Performance Analysis (7 Management Questions)
${qLines}
`;
  };

  const handleDownloadManagementReport = () => {
    const md = buildFullManagementReportMarkdown();
    const blob = new Blob([md], { type: "text/markdown;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${datasetName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")}_5_task_management_report.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const fmtCurr = (n: number) =>
    `${report.currencySymbol}${n.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;

  return (
    <div className="space-y-6">
      {/* Studio Header Card */}
      <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-4">
          <div className="space-y-1">
            <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
              <span>Official 5-Task Industry Data Analyst Deliverable Studio</span>
              <span>·</span>
              <span>100% Deterministic Execution on Active Dataset</span>
              <span>·</span>
              <span className="font-mono text-slate-700">
                {report.task1.rawRowCount} Raw Rows →{" "}
                {report.task1.eligibleOrderCount} Eligible Orders
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
              Complete 5-Task Business Data Analysis & Management Deliverable
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 max-w-4xl leading-relaxed">
              Automatically executes <strong>Task 1 (Data Cleaning)</strong>,{" "}
              <strong>Task 2 (7 Business KPIs + Formulas &amp; Assumptions)</strong>,{" "}
              <strong>Task 3 (7 Management Questions)</strong>,{" "}
              <strong>Task 4 (Interactive Dashboard with Slicers)</strong>, and{" "}
              <strong>Task 5 (One-Page Management Report + Excel / SQL / Power BI / Python Code)</strong>{" "}
              on <strong>{datasetName}</strong>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {onLoadIndustryPreset &&
              !datasetName.toLowerCase().includes("industry business assessment") && (
                <button
                  type="button"
                  onClick={onLoadIndustryPreset}
                  className="px-3.5 py-2 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
                >
                  Load Simulated Industry Assessment Dataset
                </button>
              )}
            <button
              type="button"
              onClick={handleDownloadTask1CleanedCsv}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <Download className="w-3.5 h-3.5 shrink-0" />
              <span>Download Cleaned Dataset (.csv)</span>
            </button>
            <button
              type="button"
              onClick={handleDownloadManagementReport}
              className="px-3.5 py-2 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5 shrink-0 text-blue-600" />
              <span>Export 1-Page Report (.md)</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Across the 5 Official Tasks */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 p-1 rounded-lg">
            {[
              { id: "all-deliverables", label: "All 5 Tasks Overview" },
              { id: "task1-cleaning", label: "Task 1: Data Cleaning" },
              { id: "task2-kpis", label: "Task 2: 7 KPIs & Formulas" },
              { id: "task3-questions", label: "Task 3: 7 Management Q&A" },
              { id: "task4-dashboard", label: "Task 4: Interactive Dashboard" },
              { id: "task5-report", label: "Task 5: 1-Page Report & Code" },
            ].map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setActiveTab(t.id as DeliverableTab)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  activeTab === t.id
                    ? "bg-blue-600 text-white font-semibold"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="text-xs font-mono text-slate-500">
            Mapped Columns: ID=<strong>{report.columnMapping.orderIdCol}</strong> · Cat=
            <strong>{report.columnMapping.categoryCol}</strong> · Reg=
            <strong>{report.columnMapping.regionCol}</strong> · WH=
            <strong>{report.columnMapping.warehouseCol}</strong>
          </div>
        </div>
      </section>

      {/* =====================================================================
          TASK 1: DATA INSPECTION AND CLEANING
         ===================================================================== */}
      {(activeTab === "all-deliverables" || activeTab === "task1-cleaning") && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <div className="text-xs text-slate-500">
                Task 1 Deliverable · High Priority · Data Hygiene &amp; Remediation
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                01. Data Inspection, Anomaly Discovery &amp; Separate Cleaned Dataset
              </h3>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleDownloadTask1CleanedCsv}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 whitespace-nowrap cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" />
                <span>Download Separate Cleaned Dataset (.csv)</span>
              </button>
              {onOpenExportModal && (
                <button
                  type="button"
                  onClick={onOpenExportModal}
                  className="px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg whitespace-nowrap cursor-pointer"
                >
                  Export Excel (.xlsx) / Parquet
                </button>
              )}
            </div>
          </div>

          {/* 6 Data Inspection Metric Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
              <div className="text-xs text-slate-500">Raw → Cleaned Rows</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 mt-1">
                {report.task1.rawRowCount} → {report.task1.cleanedRowCount}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                {report.task1.eligibleOrderCount} Eligible Orders
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
              <div className="text-xs text-slate-500">Duplicate Order IDs</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 mt-1">
                {report.task1.duplicateOrderIdsCount} Removed
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5 truncate">
                {report.task1.duplicateOrderIdsSample.join(", ") || "Deduplicated"}
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
              <div className="text-xs text-slate-500">Missing Values Found</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 mt-1">
                {report.task1.missingValuesCount} Imputed
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Median / Mode Imputation
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
              <div className="text-xs text-slate-500">Incorrect Data Types</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 mt-1">
                {report.task1.incorrectDataTypesCount} Fixed
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Currency, % &amp; Mixed Dates
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
              <div className="text-xs text-slate-500">Inconsistent Naming</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 mt-1">
                {report.task1.inconsistentCategoriesCount} Unified
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Category, Region &amp; WH
              </div>
            </div>

            <div className="p-3.5 rounded-lg border border-slate-200 bg-slate-50">
              <div className="text-xs text-slate-500">Unusual Qty &amp; Discounts</div>
              <div className="text-lg font-bold font-mono tabular-nums text-slate-900 mt-1">
                {report.task1.unusualQuantitiesAndDiscountsCount} Remediated
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Negatives &amp; &gt;100% Promos
              </div>
            </div>
          </div>

          {/* Detailed Task 1 Evidence Grids */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Unusual Quantities & Discount Rates Table */}
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <div className="px-3.5 py-2.5 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-800">
                Unusual Quantities &amp; Discount Rates Discovered &amp; Fixed
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/50">
                      <th className="py-2 px-3">Order ID</th>
                      <th className="py-2 px-3">Column</th>
                      <th className="py-2 px-3">Raw Value</th>
                      <th className="py-2 px-3">Cleaned Value</th>
                      <th className="py-2 px-3">Remediation Rule</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {report.task1.unusualNumericExamples.length > 0 ? (
                      report.task1.unusualNumericExamples.map((ex, i) => (
                        <tr key={i} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-semibold text-slate-900">
                            {ex.orderId}
                          </td>
                          <td className="py-2 px-3 text-slate-700">{ex.field}</td>
                          <td className="py-2 px-3 text-red-600 line-through">
                            {ex.rawValue}
                          </td>
                          <td className="py-2 px-3 text-emerald-700 font-bold">
                            {ex.fixedValue}
                          </td>
                          <td className="py-2 px-3 font-sans text-slate-600">
                            {ex.rule}
                          </td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td
                          colSpan={5}
                          className="py-3 px-3 text-slate-500 font-sans"
                        >
                          All numeric quantities and discount rates verified within valid bounds.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Inconsistent Category Naming & Data Type Fixes */}
            <div className="border border-slate-200 rounded-lg overflow-hidden">
              <div className="px-3.5 py-2.5 bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-800">
                Inconsistent Category Naming &amp; Data Type Standardization
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-500 bg-slate-50/50">
                      <th className="py-2 px-3">Column</th>
                      <th className="py-2 px-3">Raw Inconsistent Values</th>
                      <th className="py-2 px-3">Standardized Value</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {report.task1.inconsistentCategoryMappings.map((m, i) => (
                      <tr key={`cat-${i}`} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-semibold text-slate-900">
                          {m.column}
                        </td>
                        <td className="py-2 px-3 text-red-600">
                          {m.rawVariants.join(" / ")}
                        </td>
                        <td className="py-2 px-3 text-emerald-700 font-bold">
                          → {m.standardizedTo}
                        </td>
                      </tr>
                    ))}
                    {report.task1.incorrectDataTypeExamples.slice(0, 4).map((d, i) => (
                      <tr key={`dt-${i}`} className="hover:bg-slate-50">
                        <td className="py-2 px-3 font-semibold text-slate-900">
                          {d.column}
                        </td>
                        <td className="py-2 px-3 text-red-600">{d.rawSample}</td>
                        <td className="py-2 px-3 text-emerald-700 font-bold">
                          → {d.cleanedSample} ({d.reason})
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================================
          TASK 2: BUSINESS KPI CALCULATIONS (WITH FORMULAS & ASSUMPTIONS)
         ===================================================================== */}
      {(activeTab === "all-deliverables" || activeTab === "task2-kpis") && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <div className="text-xs text-slate-500">
                Task 2 Deliverable · 7 Mandatory Business KPIs with Formulas &amp; Assumptions
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                02. Official Business KPI Calculations &amp; Methodology
              </h3>
            </div>

            {/* Formula Syntax Switcher */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
              {[
                { id: "math", label: "Math Formula" },
                { id: "excel", label: "Excel Formula" },
                { id: "sql", label: "SQL Expression" },
                { id: "dax", label: "Power BI DAX" },
              ].map((ft) => (
                <button
                  key={ft.id}
                  type="button"
                  onClick={() => setFormulaTool(ft.id as FormulaToolTab)}
                  className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    formulaTool === ft.id
                      ? "bg-blue-600 text-white font-semibold"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {ft.label}
                </button>
              ))}
            </div>
          </div>

          {/* 7 KPI Cards Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3">
            {report.task2Kpis.map((kpi) => (
              <div
                key={kpi.id}
                className="p-3.5 rounded-lg border border-slate-200 bg-slate-50 flex flex-col justify-between"
              >
                <div className="text-xs font-medium text-slate-600">
                  {kpi.kpiName}
                </div>
                <div className="text-lg sm:text-xl font-bold font-mono tabular-nums text-slate-900 my-1.5">
                  {kpi.formattedValue}
                </div>
                <div className="text-[11px] text-slate-500">
                  {kpi.requirement}
                </div>
              </div>
            ))}
          </div>

          {/* Detailed Formulas & Assumptions Table */}
          <div className="border border-slate-200 rounded-lg overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                  <th className="py-2.5 px-3.5">KPI</th>
                  <th className="py-2.5 px-3.5">Requirement</th>
                  <th className="py-2.5 px-3.5 text-right">Calculated Value</th>
                  <th className="py-2.5 px-3.5">
                    {formulaTool === "math"
                      ? "Mathematical Formula"
                      : formulaTool === "excel"
                      ? "Microsoft Excel Formula"
                      : formulaTool === "sql"
                      ? "SQL Aggregation Expression"
                      : "Power BI DAX Measure"}
                  </th>
                  <th className="py-2.5 px-3.5">Assumptions &amp; Cleaning Rules Applied</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {report.task2Kpis.map((kpi) => {
                  const activeFormula =
                    formulaTool === "math"
                      ? kpi.mathFormula
                      : formulaTool === "excel"
                      ? kpi.excelFormula
                      : formulaTool === "sql"
                      ? kpi.sqlExpression
                      : kpi.daxMeasure;
                  return (
                    <tr key={kpi.id} className="hover:bg-slate-50/80">
                      <td className="py-2.5 px-3.5 font-bold text-slate-900 whitespace-nowrap">
                        {kpi.kpiName}
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 whitespace-nowrap">
                        {kpi.requirement}
                      </td>
                      <td className="py-2.5 px-3.5 text-right font-mono font-bold tabular-nums text-blue-700 whitespace-nowrap">
                        {kpi.formattedValue}
                      </td>
                      <td className="py-2.5 px-3.5 font-mono text-[11px] text-slate-800">
                        <code className="px-2 py-1 rounded bg-slate-100 border border-slate-200 block">
                          {activeFormula}
                        </code>
                      </td>
                      <td className="py-2.5 px-3.5 text-slate-600 leading-relaxed">
                        {kpi.assumptionExplained}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
      )}

      {/* =====================================================================
          TASK 3: BUSINESS PERFORMANCE ANALYSIS (7 MANAGEMENT QUESTIONS)
         ===================================================================== */}
      {(activeTab === "all-deliverables" || activeTab === "task3-questions") && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5">
          <div className="border-b border-slate-200 pb-4">
            <div className="text-xs text-slate-500">
              Task 3 Deliverable · Complete Quantitative Answers to All 7 Management Questions
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              03. Business Performance Analysis (Management Questions 1–7)
            </h3>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {report.task3Questions.map((q) => (
              <div
                key={q.questionNumber}
                className={`p-4 rounded-xl border border-slate-200 bg-slate-50/60 space-y-3 ${
                  q.questionNumber === 7 ? "lg:col-span-2" : ""
                }`}
              >
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div>
                    <span className="text-xs font-mono font-semibold text-blue-600">
                      Management Question 0{q.questionNumber}
                    </span>
                    <h4 className="text-sm sm:text-base font-bold text-slate-900">
                      {q.question}
                    </h4>
                  </div>
                  <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-md">
                    Winner / Answer: {q.headlineWinner}
                  </span>
                </div>

                <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
                  {q.executiveAnswer}
                </p>
                <div className="text-xs text-slate-500 font-mono">
                  Evidence: {q.supportingEvidence}
                </div>

                {/* Supporting Ranked Breakdown Table */}
                <div className="bg-white border border-slate-200 rounded-lg overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                        {q.tableHeaders.map((th, i) => (
                          <th
                            key={i}
                            className={`py-1.5 px-3 ${
                              i > 0 ? "text-right" : "text-left"
                            }`}
                          >
                            {th}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {q.tableRows.map((row, rIdx) => (
                        <tr
                          key={rIdx}
                          className={
                            rIdx === 0
                              ? "bg-blue-50/40 font-semibold text-slate-900"
                              : "hover:bg-slate-50 text-slate-700"
                          }
                        >
                          {row.map((cell, cIdx) => (
                            <td
                              key={cIdx}
                              className={`py-1.5 px-3 ${
                                cIdx > 0 ? "text-right" : "text-left"
                              }`}
                            >
                              {cell}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* =====================================================================
          TASK 4: INTERACTIVE EXECUTIVE DASHBOARD WITH SLICERS
         ===================================================================== */}
      {(activeTab === "all-deliverables" || activeTab === "task4-dashboard") && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <div className="text-xs text-slate-500">
                Task 4 Deliverable · Power BI / Excel Style Interactive Executive Dashboard
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                04. Interactive KPI Dashboard &amp; Multi-Dimensional Slicers
              </h3>
            </div>
            {hasActiveSlicer && (
              <button
                type="button"
                onClick={resetSlicers}
                className="px-3 py-1.5 text-xs font-semibold text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset All Dashboard Slicers</span>
              </button>
            )}
          </div>

          {/* Interactive Dashboard Slicers Bar */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                Slicer 1: Product Category
              </label>
              <select
                value={categorySlicer}
                onChange={(e) => setCategorySlicer(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="ALL">All Categories ({distinctCategories.length})</option>
                {distinctCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                Slicer 2: Region
              </label>
              <select
                value={regionSlicer}
                onChange={(e) => setRegionSlicer(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="ALL">All Regions ({distinctRegions.length})</option>
                {distinctRegions.map((r) => (
                  <option key={r} value={r}>
                    {r}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                Slicer 3: Sales Channel
              </label>
              <select
                value={channelSlicer}
                onChange={(e) => setChannelSlicer(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="ALL">All Channels ({distinctChannels.length})</option>
                {distinctChannels.map((ch) => (
                  <option key={ch} value={ch}>
                    {ch}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                Slicer 4: Warehouse
              </label>
              <select
                value={warehouseSlicer}
                onChange={(e) => setWarehouseSlicer(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="ALL">All Warehouses ({distinctWarehouses.length})</option>
                {distinctWarehouses.map((w) => (
                  <option key={w} value={w}>
                    {w}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600 mb-1">
                Slicer 5: Order Month
              </label>
              <select
                value={monthSlicer}
                onChange={(e) => setMonthSlicer(e.target.value)}
                className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg text-slate-900"
              >
                <option value="ALL">All Months ({distinctMonths.length})</option>
                {distinctMonths.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Dashboard Visuals Grid (Monthly Revenue Trend, Revenue by Category, Profit by Region, Return Rate, Delivery Performance) */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Chart 1: Monthly Revenue & Gross Profit Trend */}
            <div className="p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">
                  1. Monthly Net Revenue &amp; Gross Profit Trend
                </h4>
                <span className="text-xs font-mono text-slate-500">
                  Peak: {report.task4Dashboard.monthlyTrend.slice().sort((a, b) => b.netRevenue - a.netRevenue)[0]?.month || "N/A"}
                </span>
              </div>
              <div className="space-y-2.5">
                {report.task4Dashboard.monthlyTrend.map((m) => {
                  const maxRev = Math.max(
                    ...report.task4Dashboard.monthlyTrend.map((x) => x.netRevenue),
                    1
                  );
                  const pct = Math.max(6, Math.round((m.netRevenue / maxRev) * 100));
                  return (
                    <div key={m.month} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                        <span className="font-semibold text-slate-800">
                          {m.month} ({m.orders} orders)
                        </span>
                        <span className="text-slate-700">
                          Rev: <strong>{fmtCurr(m.netRevenue)}</strong> · Profit:{" "}
                          <strong className="text-emerald-700">
                            {fmtCurr(m.grossProfit)}
                          </strong>
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Chart 2: Revenue by Product Category */}
            <div className="p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">
                  2. Net Revenue by Product Category
                </h4>
                <span className="text-xs font-mono text-slate-500">
                  Top: {report.task4Dashboard.revenueByCategory[0]?.category || "N/A"}
                </span>
              </div>
              <div className="space-y-2.5">
                {report.task4Dashboard.revenueByCategory.map((c) => {
                  const maxRev = Math.max(
                    ...report.task4Dashboard.revenueByCategory.map((x) => x.netRevenue),
                    1
                  );
                  const pct = Math.max(6, Math.round((c.netRevenue / maxRev) * 100));
                  return (
                    <div key={c.category} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                        <span className="font-semibold text-slate-800">
                          {c.category} ({c.orders} orders)
                        </span>
                        <span className="text-slate-700">
                          <strong>{fmtCurr(c.netRevenue)}</strong> ({c.marginPct}% Margin)
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-blue-600 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Chart 3: Gross Profit by Region */}
            <div className="p-4 rounded-xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-slate-900">
                  3. Gross Profit by Region
                </h4>
                <span className="text-xs font-mono text-slate-500">
                  Leader: {report.task4Dashboard.profitByRegion[0]?.region || "N/A"}
                </span>
              </div>
              <div className="space-y-2.5">
                {report.task4Dashboard.profitByRegion.map((r) => {
                  const maxProf = Math.max(
                    ...report.task4Dashboard.profitByRegion.map((x) =>
                      Math.max(0, x.grossProfit)
                    ),
                    1
                  );
                  const pct = Math.max(
                    6,
                    Math.round((Math.max(0, r.grossProfit) / maxProf) * 100)
                  );
                  return (
                    <div key={r.region} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                        <span className="font-semibold text-slate-800">
                          {r.region} ({r.orders} orders)
                        </span>
                        <span className="text-emerald-700 font-bold">
                          {fmtCurr(r.grossProfit)} ({r.marginPct}% Margin)
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-emerald-600 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Chart 4: Return Rate Analysis & Delivery Performance by Warehouse */}
            <div className="p-4 rounded-xl border border-slate-200 space-y-4">
              <div>
                <h4 className="text-sm font-bold text-slate-900 mb-2">
                  4. Delivery Performance &amp; Delay Rate by Warehouse
                </h4>
                <div className="space-y-2">
                  {report.task4Dashboard.deliveryByWarehouse.map((w) => (
                    <div key={w.warehouse} className="space-y-1">
                      <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                        <span className="font-semibold text-slate-800">
                          {w.warehouse} ({w.totalOrders} orders)
                        </span>
                        <span className="text-slate-700">
                          On-Time: <strong className="text-emerald-700">{w.onTimePct}%</strong>{" "}
                          · Delayed: <strong className="text-amber-700">{w.delayRatePct}%</strong>
                        </span>
                      </div>
                      <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden flex">
                        <div
                          className="h-full bg-emerald-600"
                          style={{ width: `${w.onTimePct}%` }}
                        />
                        <div
                          className="h-full bg-amber-500"
                          style={{ width: `${w.delayRatePct}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200">
                <h4 className="text-sm font-bold text-slate-900 mb-2">
                  5. Top Products by Return Rate (%)
                </h4>
                <div className="space-y-1.5">
                  {report.task4Dashboard.returnRateByProduct.slice(0, 4).map((p) => (
                    <div
                      key={p.product}
                      className="flex items-center justify-between text-xs font-mono tabular-nums"
                    >
                      <span className="text-slate-800 truncate pr-2">
                        {p.product} ({p.category})
                      </span>
                      <span
                        className={`font-bold shrink-0 ${
                          p.returnRatePct > 25 ? "text-red-600" : "text-slate-700"
                        }`}
                      >
                        {p.returnRatePct}% ({p.returnedOrders}/{p.totalOrders} returned)
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      )}

      {/* =====================================================================
          TASK 5: ONE-PAGE MANAGEMENT REPORT & MULTI-SOFTWARE CODE PACK
         ===================================================================== */}
      {(activeTab === "all-deliverables" || activeTab === "task5-report") && (
        <section className="bg-white border border-slate-200 rounded-xl p-5 sm:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
            <div>
              <div className="text-xs text-slate-500">
                Task 5 Deliverable · Executive One-Page Management Report &amp; Multi-Software Scripts
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                05. One-Page Management Report (Executive Summary, 5 Findings &amp; 3 Recommendations)
              </h3>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  handleCopy("full-report", buildFullManagementReportMarkdown())
                }
                className="px-3 py-1.5 text-xs font-semibold text-slate-800 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                {copiedId === "full-report" ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>Copied 1-Page Report!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Full 1-Page Report</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleDownloadManagementReport}
                className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download 1-Page Report (.md)</span>
              </button>
            </div>
          </div>

          {/* Executive Summary */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2">
            <div className="text-xs font-bold text-slate-900">
              1. Executive Summary
            </div>
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed">
              {report.task5Report.executiveSummary}
            </p>
          </div>

          {/* 5 Important Business Findings */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-900">
              2. Five Important Business Findings (Backed by Supporting Numbers &amp; Evidence)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {report.task5Report.fiveFindings.map((f) => (
                <div
                  key={f.number}
                  className={`p-4 rounded-xl border border-slate-200 bg-white space-y-1.5 ${
                    f.number === 5 ? "md:col-span-2" : ""
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-bold text-slate-900">
                      Finding 0{f.number}: {f.title}
                    </span>
                    <span className="text-[11px] font-mono text-blue-700">
                      {f.metricProof}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {f.detail}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* 3 Strategic Recommendations to Management */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold text-slate-900">
              3. Three Recommendations to Management
            </h4>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-3.5">
              {report.task5Report.threeRecommendations.map((rec) => (
                <div
                  key={rec.number}
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 flex flex-col justify-between space-y-3"
                >
                  <div className="space-y-1.5">
                    <div className="text-xs font-mono font-semibold text-blue-600">
                      Recommendation 0{rec.number} · {rec.targetArea}
                    </div>
                    <h5 className="text-sm font-bold text-slate-900">
                      {rec.title}
                    </h5>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {rec.actionSteps}
                    </p>
                  </div>
                  <div className="pt-2.5 border-t border-slate-200 text-xs font-mono font-semibold text-emerald-700">
                    Impact: {rec.quantifiedImpact}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 3 of Assignment: Software Allowed Code & Explanation Pack */}
          <div className="pt-4 border-t border-slate-200 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h4 className="text-sm font-bold text-slate-900">
                  4. Software Implementation &amp; Code Explanation Pack (Excel, SQL, Power BI, Python)
                </h4>
                <p className="text-xs text-slate-500">
                  Ready-to-submit code and formulas explaining every step of your work across all 4 allowed tools.
                </p>
              </div>
              <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
                {[
                  { id: "python", label: "Python (Pandas & Matplotlib)" },
                  { id: "sql", label: "SQL Queries" },
                  { id: "excel", label: "Microsoft Excel" },
                  { id: "powerbi", label: "Power BI (DAX)" },
                ].map((st) => (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => setSoftwareTab(st.id as SoftwareCodeTab)}
                    className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                      softwareTab === st.id
                        ? "bg-blue-600 text-white font-semibold"
                        : "text-slate-600 hover:text-slate-900"
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="relative">
              <button
                type="button"
                onClick={() => {
                  const text =
                    softwareTab === "python"
                      ? report.softwareCodePack.pythonScript
                      : softwareTab === "sql"
                      ? report.softwareCodePack.sqlScript
                      : softwareTab === "excel"
                      ? report.softwareCodePack.excelGuide
                      : report.softwareCodePack.powerBiDax;
                  handleCopy(`code-${softwareTab}`, text);
                }}
                className="absolute top-3 right-3 px-2.5 py-1 text-xs font-mono bg-slate-800 hover:bg-slate-700 text-slate-100 rounded border border-slate-600 flex items-center gap-1 cursor-pointer"
              >
                {copiedId === `code-${softwareTab}` ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
              <pre className="p-4 rounded-xl bg-slate-900 text-blue-100 text-xs font-mono overflow-x-auto leading-relaxed max-h-96">
                {softwareTab === "python"
                  ? report.softwareCodePack.pythonScript
                  : softwareTab === "sql"
                  ? report.softwareCodePack.sqlScript
                  : softwareTab === "excel"
                  ? report.softwareCodePack.excelGuide
                  : report.softwareCodePack.powerBiDax}
              </pre>
            </div>
          </div>
        </section>
      )}
    </div>
  );
};
