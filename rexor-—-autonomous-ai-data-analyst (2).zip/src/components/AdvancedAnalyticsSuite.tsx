import React, { useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Download,
  GitBranch,
  Grid,
  TrendingUp,
} from "lucide-react";
import { ColumnProfile, DataRow } from "../types/rexor";
import { toValidFiniteNumber } from "../utils/dataEngine";

interface AdvancedAnalyticsSuiteProps {
  rows: DataRow[];
  columnProfiles: ColumnProfile[];
  datasetName: string;
}

type AdvancedTab =
  | "pivot"
  | "hypothesis"
  | "forecast"
  | "anomaly"
  | "simpson"
  | "monte-carlo";

// Normal CDF approximation (Abramowitz & Stegun) for two-tailed p-value calculation
function normalCdf(x: number): number {
  const t = 1 / (1 + 0.2316419 * Math.abs(x));
  const d = 0.3989423 * Math.exp((-x * x) / 2);
  const prob =
    d *
    t *
    (0.3193815 +
      t * (-0.3565638 + t * (1.781478 + t * (-1.821256 + t * 1.330274))));
  return x > 0 ? 1 - prob : prob;
}

function twoTailedPValueFromT(tStat: number, df: number): number {
  if (df <= 0 || Number.isNaN(tStat)) return 1;
  // Cornwall-Fisher normal approximation for Student's t distribution
  const absT = Math.abs(tStat);
  const z = absT * (1 - 1 / (4 * Math.max(df, 2)));
  const p = 2 * (1 - normalCdf(z));
  return Math.max(0.0001, Math.min(1, Number(p.toFixed(4))));
}

function getMedian(vals: number[]): number {
  if (vals.length === 0) return 0;
  const sorted = [...vals].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2;
}

export const AdvancedAnalyticsSuite: React.FC<AdvancedAnalyticsSuiteProps> = ({
  rows,
  columnProfiles,
  datasetName,
}) => {
  const [activeTab, setActiveTab] = useState<AdvancedTab>("pivot");

  const numericCols = useMemo(
    () => columnProfiles.filter((c) => c.type === "numeric").map((c) => c.name),
    [columnProfiles]
  );
  const categoricalCols = useMemo(
    () =>
      columnProfiles
        .filter((c) => c.type === "categorical" || c.type === "date")
        .map((c) => c.name),
    [columnProfiles]
  );

  const nonIdCats = useMemo(() => {
    const pureCats = columnProfiles
      .filter((c) => c.type === "categorical")
      .map((c) => c.name)
      .filter(
        (c) =>
          !c.toLowerCase().includes("id") &&
          !c.toLowerCase().includes("name") &&
          !c.toLowerCase().includes("timestamp") &&
          !c.toLowerCase().includes("date")
      );
    if (pureCats.length >= 2) return pureCats;
    const fallback = categoricalCols.filter(
      (c) =>
        !c.toLowerCase().includes("id") &&
        !c.toLowerCase().includes("timestamp")
    );
    return fallback.length > 0 ? fallback : categoricalCols;
  }, [columnProfiles, categoricalCols]);

  const preferredValCol = useMemo(
    () =>
      numericCols.find((n) =>
        /^(net_revenue_inr|mrr_usd|profit_contribution_usd|on_time_pct|customer_rating)$/i.test(
          n
        )
      ) ||
      numericCols[numericCols.length - 1] ||
      numericCols[0] ||
      "",
    [numericCols]
  );

  // ---------------------------------------------------------------------------
  // 1. PIVOT TABLE & CROSS-TABULATION STATE
  // ---------------------------------------------------------------------------
  const [pivotRowCol, setPivotRowCol] = useState<string>(
    () => nonIdCats[0] || categoricalCols[0] || ""
  );
  const [pivotColCol, setPivotColCol] = useState<string>(
    () => nonIdCats[1] || nonIdCats[0] || categoricalCols[0] || ""
  );
  const [pivotValCol, setPivotValCol] = useState<string>(() => preferredValCol);
  const [pivotAgg, setPivotAgg] = useState<
    "SUM" | "AVG" | "MEDIAN" | "COUNT" | "PCT_TOTAL"
  >("AVG");

  // Keep defaults synced when dataset changes
  React.useEffect(() => {
    setPivotRowCol(nonIdCats[0] || categoricalCols[0] || "");
    setPivotColCol(nonIdCats[1] || nonIdCats[0] || categoricalCols[0] || "");
    setPivotValCol(preferredValCol);
  }, [nonIdCats, categoricalCols, preferredValCol]);

  const pivotMatrix = useMemo(() => {
    if (!rows.length || !pivotRowCol || !pivotColCol || !pivotValCol) {
      return { rowKeys: [], colKeys: [], cells: {}, rowTotals: {}, colTotals: {}, grandTotal: 0 };
    }

    const rowKeySet = new Set<string>();
    const colKeySet = new Set<string>();
    const bucket: Record<string, Record<string, number[]>> = {};
    const allVals: number[] = [];

    for (const r of rows) {
      const rk = String(r[pivotRowCol] ?? "Unspecified");
      const ck = String(r[pivotColCol] ?? "Unspecified");
      const v = toValidFiniteNumber(r[pivotValCol]);
      rowKeySet.add(rk);
      colKeySet.add(ck);
      if (!bucket[rk]) bucket[rk] = {};
      if (!bucket[rk][ck]) bucket[rk][ck] = [];
      if (v !== null) {
        bucket[rk][ck].push(v);
        allVals.push(v);
      }
    }

    const rowKeys = Array.from(rowKeySet).slice(0, 12);
    const colKeys = Array.from(colKeySet).slice(0, 8);
    const grandSum = allVals.reduce((a, b) => a + b, 0);

    const computeAgg = (arr: number[]): number => {
      if (!arr || arr.length === 0) return 0;
      const sum = arr.reduce((a, b) => a + b, 0);
      if (pivotAgg === "COUNT") return arr.length;
      if (pivotAgg === "SUM") return Number(sum.toFixed(2));
      if (pivotAgg === "AVG") return Number((sum / arr.length).toFixed(2));
      if (pivotAgg === "MEDIAN") return Number(getMedian(arr).toFixed(2));
      if (pivotAgg === "PCT_TOTAL") {
        return grandSum === 0 ? 0 : Number(((sum / grandSum) * 100).toFixed(1));
      }
      return 0;
    };

    const cells: Record<string, Record<string, number>> = {};
    const rowTotals: Record<string, number> = {};
    const colTotals: Record<string, number> = {};

    for (const rk of rowKeys) {
      cells[rk] = {};
      const rowAll: number[] = [];
      for (const ck of colKeys) {
        const vals = bucket[rk]?.[ck] || [];
        cells[rk][ck] = computeAgg(vals);
        rowAll.push(...vals);
      }
      rowTotals[rk] = computeAgg(rowAll);
    }

    for (const ck of colKeys) {
      const colAll: number[] = [];
      for (const rk of rowKeys) {
        colAll.push(...(bucket[rk]?.[ck] || []));
      }
      colTotals[ck] = computeAgg(colAll);
    }

    const grandTotal = computeAgg(allVals);

    return { rowKeys, colKeys, cells, rowTotals, colTotals, grandTotal };
  }, [rows, pivotRowCol, pivotColCol, pivotValCol, pivotAgg]);

  const handleExportPivotCsv = () => {
    const { rowKeys, colKeys, cells, rowTotals, colTotals, grandTotal } =
      pivotMatrix;
    if (!rowKeys.length) return;
    const lines = [
      [pivotRowCol, ...colKeys, "Row Total"].join(","),
      ...rowKeys.map((rk) =>
        [
          `"${rk}"`,
          ...colKeys.map((ck) => cells[rk]?.[ck] ?? 0),
          rowTotals[rk] ?? 0,
        ].join(",")
      ),
      ["Column Total", ...colKeys.map((ck) => colTotals[ck] ?? 0), grandTotal].join(
        ","
      ),
    ];
    const blob = new Blob([lines.join("\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${datasetName.toLowerCase().replace(/[^a-z0-9]+/g, "_")}_pivot_matrix.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // ---------------------------------------------------------------------------
  // 2. STATISTICAL SIGNIFICANCE & WELCH'S T-TEST LAB STATE
  // ---------------------------------------------------------------------------
  const [testGroupCol, setTestGroupCol] = useState<string>(
    () => nonIdCats[0] || categoricalCols[0] || ""
  );
  const availableCohorts = useMemo(() => {
    if (!testGroupCol) return [];
    return Array.from(
      new Set(rows.map((r) => String(r[testGroupCol] ?? "Unspecified")))
    );
  }, [rows, testGroupCol]);

  const [cohortA, setCohortA] = useState<string>("");
  const [cohortB, setCohortB] = useState<string>("");
  const [testMetricCol, setTestMetricCol] = useState<string>(
    () => numericCols[numericCols.length - 1] || numericCols[0] || ""
  );

  React.useEffect(() => {
    const firstCat = nonIdCats[0] || categoricalCols[0] || "";
    setTestGroupCol(firstCat);
    setTestMetricCol(numericCols[numericCols.length - 1] || numericCols[0] || "");
  }, [nonIdCats, categoricalCols, numericCols]);

  React.useEffect(() => {
    setCohortA(availableCohorts[0] || "");
    setCohortB(availableCohorts[1] || availableCohorts[0] || "");
  }, [availableCohorts]);

  const tTestResult = useMemo(() => {
    const valsA = rows
      .filter((r) => String(r[testGroupCol]) === cohortA)
      .map((r) => toValidFiniteNumber(r[testMetricCol]))
      .filter((n): n is number => n !== null);
    const valsB = rows
      .filter((r) => String(r[testGroupCol]) === cohortB)
      .map((r) => toValidFiniteNumber(r[testMetricCol]))
      .filter((n): n is number => n !== null);

    const nA = valsA.length;
    const nB = valsB.length;
    if (nA < 2 || nB < 2) {
      return null;
    }

    const meanA = valsA.reduce((a, b) => a + b, 0) / nA;
    const meanB = valsB.reduce((a, b) => a + b, 0) / nB;
    const varA =
      valsA.reduce((acc, v) => acc + (v - meanA) ** 2, 0) / (nA - 1);
    const varB =
      valsB.reduce((acc, v) => acc + (v - meanB) ** 2, 0) / (nB - 1);

    const se = Math.sqrt(varA / nA + varB / nB) || 0.0001;
    const diff = meanA - meanB;
    const tStat = diff / se;

    // Welch-Satterthwaite degrees of freedom
    const dfNum = (varA / nA + varB / nB) ** 2;
    const dfDen =
      (varA / nA) ** 2 / (nA - 1) + (varB / nB) ** 2 / (nB - 1) || 1;
    const df = Math.max(1, Math.round(dfNum / dfDen));

    const pValue = twoTailedPValueFromT(tStat, df);
    const pooledSd = Math.sqrt(((nA - 1) * varA + (nB - 1) * varB) / (nA + nB - 2)) || 1;
    const cohensD = Math.abs(diff) / pooledSd;

    const ciLow = diff - 1.96 * se;
    const ciHigh = diff + 1.96 * se;

    return {
      nA,
      nB,
      meanA: Number(meanA.toFixed(2)),
      meanB: Number(meanB.toFixed(2)),
      stdA: Number(Math.sqrt(varA).toFixed(2)),
      stdB: Number(Math.sqrt(varB).toFixed(2)),
      diff: Number(diff.toFixed(2)),
      pctDiff:
        meanB !== 0 ? Number((((meanA - meanB) / Math.abs(meanB)) * 100).toFixed(1)) : 0,
      tStat: Number(tStat.toFixed(3)),
      df,
      pValue,
      cohensD: Number(cohensD.toFixed(2)),
      ciLow: Number(ciLow.toFixed(2)),
      ciHigh: Number(ciHigh.toFixed(2)),
      isSignificant: pValue < 0.05,
    };
  }, [rows, testGroupCol, cohortA, cohortB, testMetricCol]);

  // ---------------------------------------------------------------------------
  // 3. TIME-SERIES & TREND FORECASTING STUDIO STATE
  // ---------------------------------------------------------------------------
  const [forecastCol, setForecastCol] = useState<string>(
    () => numericCols[numericCols.length - 1] || numericCols[0] || ""
  );
  const [horizonPeriods, setHorizonPeriods] = useState<number>(6);
  const [forecastModel, setForecastModel] = useState<"holt" | "linear" | "ma">(
    "holt"
  );

  React.useEffect(() => {
    setForecastCol(numericCols[numericCols.length - 1] || numericCols[0] || "");
  }, [numericCols]);

  const forecastOutput = useMemo(() => {
    // Chronologically sort rows by the primary date/timestamp column (if present) before time-series extraction
    const dateCol = columnProfiles.find((c) => c.type === "date")?.name;
    const orderedRows = dateCol
      ? [...rows].sort((a, b) =>
          String(a[dateCol] ?? "").localeCompare(String(b[dateCol] ?? ""))
        )
      : rows;

    const series = orderedRows
      .map((r) => toValidFiniteNumber(r[forecastCol]))
      .filter((v): v is number => v !== null);
    if (series.length < 4) return null;

    const n = series.length;
    // Ordinary Least Squares linear trend
    const meanT = (n - 1) / 2;
    const meanY = series.reduce((a, b) => a + b, 0) / n;
    let num = 0;
    let den = 0;
    for (let t = 0; t < n; t++) {
      num += (t - meanT) * (series[t] - meanY);
      den += (t - meanT) ** 2;
    }
    const slope = den === 0 ? 0 : num / den;
    const intercept = meanY - slope * meanT;

    // Holt's Double Exponential Smoothing (alpha = 0.45, beta = 0.25)
    const alpha = 0.45;
    const beta = 0.25;
    let level = series[0];
    let trend = series[1] - series[0];
    const fitted: number[] = [series[0]];

    for (let t = 1; t < n; t++) {
      const prevLevel = level;
      level = alpha * series[t] + (1 - alpha) * (level + trend);
      trend = beta * (level - prevLevel) + (1 - beta) * trend;
      fitted.push(Number((prevLevel + trend).toFixed(2)));
    }

    // Residual standard error for 95% confidence cone
    const residuals = series.map((y, idx) => y - ( slope * idx + intercept ));
    const residualVariance =
      residuals.reduce((acc, r) => acc + r * r, 0) / Math.max(1, n - 2);
    const rmse = Math.sqrt(residualVariance);

    // Moving average window (k=4)
    const lastWindowAvg =
      series.slice(-4).reduce((a, b) => a + b, 0) / Math.min(4, series.length);

    const projections: {
      step: number;
      label: string;
      pointForecast: number;
      lower95: number;
      upper95: number;
    }[] = [];

    for (let h = 1; h <= horizonPeriods; h++) {
      let pred = 0;
      if (forecastModel === "linear") {
        pred = intercept + slope * (n - 1 + h);
      } else if (forecastModel === "holt") {
        pred = level + h * trend;
      } else {
        pred = lastWindowAvg + slope * 0.5 * h;
      }
      const margin = 1.96 * rmse * Math.sqrt(1 + h * 0.15);
      projections.push({
        step: n + h,
        label: `T+${h}`,
        pointForecast: Number(pred.toFixed(2)),
        lower95: Number((pred - margin).toFixed(2)),
        upper95: Number((pred + margin).toFixed(2)),
      });
    }

    return {
      historical: series,
      fitted,
      projections,
      rmse: Number(rmse.toFixed(2)),
      slope: Number(slope.toFixed(2)),
      lastActual: series[n - 1],
      finalForecast: projections[projections.length - 1]?.pointForecast ?? 0,
    };
  }, [rows, columnProfiles, forecastCol, horizonPeriods, forecastModel]);

  // ---------------------------------------------------------------------------
  // 4. MULTIVARIATE Z-SCORE ANOMALY INSPECTOR STATE
  // ---------------------------------------------------------------------------
  const [zThreshold, setZThreshold] = useState<number>(1.8);

  const anomalyRecords = useMemo(() => {
    if (!rows.length || !numericCols.length) return [];

    // Compute mean and sample stdDev (ddof = 1, Bessel's correction) per numeric column
    const stats: Record<string, { mean: number; std: number }> = {};
    for (const col of numericCols) {
      const vals = rows
        .map((r) => toValidFiniteNumber(r[col]))
        .filter((v): v is number => v !== null);
      const mean = vals.reduce((a, b) => a + b, 0) / (vals.length || 1);
      const variance =
        vals.reduce((acc, v) => acc + (v - mean) ** 2, 0) /
        Math.max(1, vals.length - 1);
      stats[col] = { mean, std: Math.sqrt(variance) || 1 };
    }

    const firstIdCol = Object.keys(rows[0])[0] || "id";
    const secondCol = Object.keys(rows[0])[1] || firstIdCol;

    const flagged: {
      rowIdx: number;
      recordId: string;
      Descriptor: string;
      maxZ: number;
      rmsZ: number;
      triggerColumn: string;
      triggerVal: number;
      columnMean: number;
    }[] = [];

    rows.forEach((row, idx) => {
      let maxAbsZ = 0;
      let sumSqZ = 0;
      let triggerCol = numericCols[0];
      let triggerVal = toValidFiniteNumber(row[triggerCol]) ?? 0;

      for (const col of numericCols) {
        const val = toValidFiniteNumber(row[col]);
        if (val === null) continue;
        const z = Math.abs((val - stats[col].mean) / stats[col].std);
        sumSqZ += z * z;
        if (z > maxAbsZ) {
          maxAbsZ = z;
          triggerCol = col;
          triggerVal = val;
        }
      }

      const rmsZ = Math.sqrt(sumSqZ / numericCols.length);
      if (maxAbsZ >= zThreshold) {
        flagged.push({
          rowIdx: idx + 1,
          recordId: String(row[firstIdCol] ?? `Row ${idx + 1}`),
          Descriptor: String(row[secondCol] ?? ""),
          maxZ: Number(maxAbsZ.toFixed(2)),
          rmsZ: Number(rmsZ.toFixed(2)),
          triggerColumn: triggerCol,
          triggerVal: Number(triggerVal.toFixed(2)),
          columnMean: Number(stats[triggerCol].mean.toFixed(2)),
        });
      }
    });

    return flagged.sort((a, b) => b.maxZ - a.maxZ);
  }, [rows, numericCols, zThreshold]);

  // ---------------------------------------------------------------------------
  // 5. SIMPSON'S PARADOX & MIX-SHIFT DECOMPOSER STATE
  // ---------------------------------------------------------------------------
  const [confounderCol, setConfounderCol] = useState<string>(
    () =>
      nonIdCats.find((c) => c !== testGroupCol) ||
      nonIdCats[1] ||
      categoricalCols.find((c) => c !== testGroupCol) ||
      categoricalCols[0] ||
      ""
  );

  React.useEffect(() => {
    const candidate =
      nonIdCats.find((c) => c !== testGroupCol) ||
      categoricalCols.find((c) => c !== testGroupCol) ||
      nonIdCats[0] ||
      categoricalCols[0] ||
      "";
    setConfounderCol(candidate);
  }, [testGroupCol, nonIdCats, categoricalCols]);

  const simpsonAnalysis = useMemo(() => {
    if (!rows.length || !testGroupCol || !confounderCol || !testMetricCol || !cohortA || !cohortB) {
      return null;
    }

    const rowsA = rows.filter(
      (r) =>
        String(r[testGroupCol] ?? "") === cohortA &&
        toValidFiniteNumber(r[testMetricCol]) !== null
    );
    const rowsB = rows.filter(
      (r) =>
        String(r[testGroupCol] ?? "") === cohortB &&
        toValidFiniteNumber(r[testMetricCol]) !== null
    );

    if (rowsA.length === 0 || rowsB.length === 0) return null;

    const meanA =
      rowsA.reduce((acc, r) => acc + (toValidFiniteNumber(r[testMetricCol]) ?? 0), 0) /
      rowsA.length;
    const meanB =
      rowsB.reduce((acc, r) => acc + (toValidFiniteNumber(r[testMetricCol]) ?? 0), 0) /
      rowsB.length;
    const totalDiff = meanA - meanB;

    const subSegments = Array.from(
      new Set(
        [...rowsA, ...rowsB].map((r) => String(r[confounderCol] ?? "Unspecified"))
      )
    ).slice(0, 10);

    let withinSegmentEffect = 0;
    let mixShiftEffect = 0;
    let segmentsWhereAWins = 0;
    let segmentsWhereBWins = 0;
    let validComparedSegments = 0;

    const segmentBreakdown = subSegments.map((seg) => {
      const segA = rowsA
        .filter((r) => String(r[confounderCol] ?? "Unspecified") === seg)
        .map((r) => toValidFiniteNumber(r[testMetricCol])!)
        .filter((v) => v !== null);
      const segB = rowsB
        .filter((r) => String(r[confounderCol] ?? "Unspecified") === seg)
        .map((r) => toValidFiniteNumber(r[testMetricCol])!)
        .filter((v) => v !== null);

      const nSegA = segA.length;
      const nSegB = segB.length;
      const wA = nSegA / rowsA.length;
      const wB = nSegB / rowsB.length;

      const avgA =
        nSegA > 0 ? segA.reduce((a, b) => a + b, 0) / nSegA : meanA;
      const avgB =
        nSegB > 0 ? segB.reduce((a, b) => a + b, 0) / nSegB : meanB;

      // Kitagawa-Oaxaca symmetric decomposition:
      // ΔY = Σ [ 0.5*(wA_i + wB_i)*(avgA_i - avgB_i) ]  (Within-Segment Rate Effect)
      //    + Σ [ (wA_i - wB_i)*0.5*(avgA_i + avgB_i) ]  (Mix-Shift / Compositional Effect)
      const rateContribution = 0.5 * (wA + wB) * (avgA - avgB);
      const mixContribution = (wA - wB) * 0.5 * (avgA + avgB);

      withinSegmentEffect += rateContribution;
      mixShiftEffect += mixContribution;

      if (nSegA > 0 && nSegB > 0) {
        validComparedSegments++;
        if (avgA > avgB) segmentsWhereAWins++;
        else if (avgB > avgA) segmentsWhereBWins++;
      }

      return {
        segment: seg,
        nA: nSegA,
        nB: nSegB,
        shareAPct: Number((wA * 100).toFixed(1)),
        shareBPct: Number((wB * 100).toFixed(1)),
        meanA: nSegA > 0 ? Number(avgA.toFixed(2)) : null,
        meanB: nSegB > 0 ? Number(avgB.toFixed(2)) : null,
        segDiff: nSegA > 0 && nSegB > 0 ? Number((avgA - avgB).toFixed(2)) : 0,
        rateContribution: Number(rateContribution.toFixed(2)),
        mixContribution: Number(mixContribution.toFixed(2)),
      };
    });

    const isSimpsonsParadox =
      validComparedSegments >= 2 &&
      ((totalDiff > 0 && segmentsWhereBWins > segmentsWhereAWins) ||
        (totalDiff < 0 && segmentsWhereAWins > segmentsWhereBWins) ||
        Math.sign(totalDiff) !== Math.sign(withinSegmentEffect));

    return {
      meanA: Number(meanA.toFixed(2)),
      meanB: Number(meanB.toFixed(2)),
      totalDiff: Number(totalDiff.toFixed(2)),
      withinSegmentEffect: Number(withinSegmentEffect.toFixed(2)),
      mixShiftEffect: Number(mixShiftEffect.toFixed(2)),
      segmentsWhereAWins,
      segmentsWhereBWins,
      validComparedSegments,
      isSimpsonsParadox,
      segmentBreakdown,
    };
  }, [rows, testGroupCol, confounderCol, testMetricCol, cohortA, cohortB]);

  // ---------------------------------------------------------------------------
  // 6. MONTE CARLO STOCHASTIC P10 / P50 / P90 RISK SIMULATOR (1,000 TRIALS)
  // ---------------------------------------------------------------------------
  const [mcDriftPct, setMcDriftPct] = useState<number>(10);
  const [mcVolatilityMult, setMcVolatilityMult] = useState<number>(1.0);

  const monteCarloOutput = useMemo(() => {
    const vals = rows
      .map((r) => toValidFiniteNumber(r[forecastCol]))
      .filter((v): v is number => v !== null);
    if (vals.length < 3) return null;

    const n = vals.length;
    const baseMean = vals.reduce((a, b) => a + b, 0) / n;
    const baseTotal = baseMean * n;
    const sampleVar =
      vals.reduce((acc, v) => acc + (v - baseMean) ** 2, 0) /
      Math.max(1, n - 1);
    const sampleStd = Math.sqrt(sampleVar) || Math.abs(baseMean) * 0.15 || 1;
    // Standard error of the cohort total across n records, scaled by user volatility multiplier
    const totalSigma =
      sampleStd * Math.sqrt(n) * mcVolatilityMult +
      Math.abs(baseTotal) * 0.08 * mcVolatilityMult;
    const driftedMeanTotal = baseTotal * (1 + mcDriftPct / 100);

    // Deterministic Box-Muller 1,000-trial Gaussian simulation (seeded LCG for reproducibility)
    const trials = 1000;
    const simTotals: number[] = [];
    let seed = 133742;
    const nextRand = () => {
      seed = (seed * 1664525 + 1013904223) % 4294967296;
      return Math.max(1e-7, seed / 4294967296);
    };

    let beatBaselineCount = 0;
    for (let i = 0; i < trials; i++) {
      const u1 = nextRand();
      const u2 = nextRand();
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);
      const simVal = driftedMeanTotal + z * totalSigma;
      simTotals.push(simVal);
      if (simVal >= baseTotal) beatBaselineCount++;
    }

    simTotals.sort((a, b) => a - b);
    const p10 = Number(simTotals[Math.floor(trials * 0.1)].toFixed(2));
    const p50 = Number(simTotals[Math.floor(trials * 0.5)].toFixed(2));
    const p90 = Number(simTotals[Math.floor(trials * 0.9)].toFixed(2));
    const minSim = simTotals[0];
    const maxSim = simTotals[trials - 1];
    const binCount = 16;
    const binWidth = (maxSim - minSim) / binCount || 1;
    const bins = Array.from({ length: binCount }, (_, idx) => ({
      binCenter: Number((minSim + (idx + 0.5) * binWidth).toFixed(0)),
      count: 0,
    }));

    for (const v of simTotals) {
      const bIdx = Math.min(
        binCount - 1,
        Math.max(0, Math.floor((v - minSim) / binWidth))
      );
      bins[bIdx].count++;
    }

    return {
      baseTotal: Number(baseTotal.toFixed(2)),
      p10,
      p50,
      p90,
      valueAtRisk90: Number((baseTotal - p10).toFixed(2)),
      probBeatBaselinePct: Number(((beatBaselineCount / trials) * 100).toFixed(1)),
      bins,
    };
  }, [rows, forecastCol, mcDriftPct, mcVolatilityMult]);

  return (
    <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 min-w-0 max-w-full overflow-x-hidden">
      {/* Header & 6-Module Switcher */}
      <div className="flex flex-col gap-4 pb-5 border-b border-slate-200 min-w-0">
        <div className="min-w-0">
          <div className="text-xs text-slate-500">
            Advanced Data Science & BI Workbench · Zero External Tools Needed
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 mt-0.5 break-words">
            Rexor Advanced Statistical & Predictive Suite
          </h2>
        </div>

        {/* Segmented Control for the 6 Advanced Modules */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 rounded-lg w-full">
          <button
            onClick={() => setActiveTab("pivot")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "pivot"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Grid className="w-3.5 h-3.5 shrink-0" />
            <span>1. 2D Pivot Matrix</span>
          </button>

          <button
            onClick={() => setActiveTab("hypothesis")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "hypothesis"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Activity className="w-3.5 h-3.5 shrink-0" />
            <span>2. Hypothesis & p-Value Lab</span>
          </button>

          <button
            onClick={() => setActiveTab("forecast")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "forecast"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5 shrink-0" />
            <span>3. Predictive Forecasting</span>
          </button>

          <button
            onClick={() => setActiveTab("anomaly")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "anomaly"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
            <span>4. Z-Score Anomaly Radar</span>
          </button>

          <button
            onClick={() => setActiveTab("simpson")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "simpson"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <GitBranch className="w-3.5 h-3.5 shrink-0" />
            <span>5. Simpson&apos;s Paradox & Mix-Shift</span>
          </button>

          <button
            onClick={() => setActiveTab("monte-carlo")}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === "monte-carlo"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Activity className="w-3.5 h-3.5 shrink-0" />
            <span>6. Monte Carlo Risk Simulator</span>
          </button>
        </div>
      </div>

      {/* =====================================================================
          MODULE 1: 2D PIVOT TABLE & CROSS-TABULATION MATRIX
         ===================================================================== */}
      {activeTab === "pivot" && (
        <div className="pt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Row Dimension
              </label>
              <select
                value={pivotRowCol}
                onChange={(e) => setPivotRowCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {columnProfiles.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Column Dimension
              </label>
              <select
                value={pivotColCol}
                onChange={(e) => setPivotColCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {columnProfiles.map((c) => (
                  <option key={c.name} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Value Metric
              </label>
              <select
                value={pivotValCol}
                onChange={(e) => setPivotValCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {numericCols.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Aggregation Mode
              </label>
              <select
                value={pivotAgg}
                onChange={(e) => setPivotAgg(e.target.value as any)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                <option value="AVG">Mean (AVG)</option>
                <option value="SUM">Total Sum (SUM)</option>
                <option value="MEDIAN">Median (50th Pct)</option>
                <option value="COUNT">Record Count</option>
                <option value="PCT_TOTAL">% of Grand Total</option>
              </select>
            </div>

            <div className="flex items-end">
              <button
                onClick={handleExportPivotCsv}
                className="w-full px-3 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Pivot CSV</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">
                    {pivotRowCol} \ {pivotColCol}
                  </th>
                  {pivotMatrix.colKeys.map((ck) => (
                    <th
                      key={ck}
                      className="py-2.5 px-3 font-medium text-right whitespace-nowrap"
                    >
                      {ck}
                    </th>
                  ))}
                  <th className="py-2.5 px-3 font-semibold text-right text-slate-900">
                    Row Total
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs font-mono tabular-nums">
                {pivotMatrix.rowKeys.map((rk) => (
                  <tr key={rk} className="hover:bg-slate-50">
                    <td className="py-2.5 px-3 font-sans font-semibold text-slate-900 whitespace-nowrap">
                      {rk}
                    </td>
                    {pivotMatrix.colKeys.map((ck) => {
                      const cellVal = pivotMatrix.cells[rk]?.[ck] ?? 0;
                      return (
                        <td
                          key={ck}
                          className="py-2.5 px-3 text-right text-slate-700"
                        >
                          {cellVal === 0
                            ? "—"
                            : `${cellVal.toLocaleString()}${
                                pivotAgg === "PCT_TOTAL" ? "%" : ""
                              }`}
                        </td>
                      );
                    })}
                    <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                      {(pivotMatrix.rowTotals[rk] ?? 0).toLocaleString()}
                      {pivotAgg === "PCT_TOTAL" ? "%" : ""}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-slate-300 text-xs font-mono tabular-nums font-bold">
                  <td className="py-2.5 px-3 font-sans text-slate-900">
                    Column Total / Overall
                  </td>
                  {pivotMatrix.colKeys.map((ck) => (
                    <td
                      key={ck}
                      className="py-2.5 px-3 text-right text-slate-900"
                    >
                      {(pivotMatrix.colTotals[ck] ?? 0).toLocaleString()}
                      {pivotAgg === "PCT_TOTAL" ? "%" : ""}
                    </td>
                  ))}
                  <td className="py-2.5 px-3 text-right text-blue-600">
                    {pivotMatrix.grandTotal.toLocaleString()}
                    {pivotAgg === "PCT_TOTAL" ? "%" : ""}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODULE 2: STATISTICAL SIGNIFICANCE & WELCH'S T-TEST LAB
         ===================================================================== */}
      {activeTab === "hypothesis" && (
        <div className="pt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Grouping Variable
              </label>
              <select
                value={testGroupCol}
                onChange={(e) => setTestGroupCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {categoricalCols.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Cohort A (Baseline)
              </label>
              <select
                value={cohortA}
                onChange={(e) => setCohortA(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {availableCohorts.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Cohort B (Comparison)
              </label>
              <select
                value={cohortB}
                onChange={(e) => setCohortB(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {availableCohorts.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Evaluation Metric
              </label>
              <select
                value={testMetricCol}
                onChange={(e) => setTestMetricCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {numericCols.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {!tTestResult ? (
            <div className="py-8 text-center text-xs text-slate-500">
              Select two cohorts with at least 2 observations each to compute
              Welch’s two-sample t-test.
            </div>
          ) : (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Cohort A: {cohortA} (n={tTestResult.nA})
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                    Mean: {tTestResult.meanA.toLocaleString()}
                  </div>
                  <div className="text-xs font-mono tabular-nums text-slate-500 mt-0.5">
                    Std Dev: ±{tTestResult.stdA.toLocaleString()}
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Cohort B: {cohortB} (n={tTestResult.nB})
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                    Mean: {tTestResult.meanB.toLocaleString()}
                  </div>
                  <div className="text-xs font-mono tabular-nums text-slate-500 mt-0.5">
                    Std Dev: ±{tTestResult.stdB.toLocaleString()}
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Welch t-Statistic & Two-Tailed p-Value
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                    t = {tTestResult.tStat} · p = {tTestResult.pValue}
                  </div>
                  <div className="text-xs font-mono tabular-nums text-slate-500 mt-0.5">
                    Degrees of Freedom (df): {tTestResult.df} · Cohen’s d:{" "}
                    {tTestResult.cohensD}
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    95% Confidence Interval (Δ Mean)
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                    [{tTestResult.ciLow}, {tTestResult.ciHigh}]
                  </div>
                  <div className="text-xs font-mono tabular-nums text-slate-500 mt-0.5">
                    Observed Δ: {tTestResult.diff > 0 ? `+${tTestResult.diff}` : tTestResult.diff}{" "}
                    ({tTestResult.pctDiff > 0 ? `+${tTestResult.pctDiff}%` : `${tTestResult.pctDiff}%`})
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                <div className="font-semibold text-slate-900 mb-1">
                  Statistical Verdict (α = 0.05 Threshold):{" "}
                  {tTestResult.isSignificant
                    ? "STATISTICALLY SIGNIFICANT DIFFERENCE CONFIRMED"
                    : "NO STATISTICALLY SIGNIFICANT DIFFERENCE (NULL RETAINED)"}
                </div>
                <p className="text-slate-700 leading-relaxed">
                  Comparing <strong>{cohortA}</strong> vs.{" "}
                  <strong>{cohortB}</strong> on{" "}
                  <strong>{testMetricCol}</strong> yields a mean difference of{" "}
                  <span className="font-mono tabular-nums">
                    {tTestResult.diff}
                  </span>{" "}
                  (two-tailed <span className="font-mono">p = {tTestResult.pValue}</span>,
                  effect size{" "}
                  <span className="font-mono">d = {tTestResult.cohensD}</span>).{" "}
                  {tTestResult.isSignificant
                    ? "Because p < 0.05, the divergence between these two cohorts is structural rather than random sampling noise."
                    : "Because p >= 0.05, the observed difference could arise from sampling variance."}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          MODULE 3: PREDICTIVE TIME-SERIES & TREND FORECASTING STUDIO
         ===================================================================== */}
      {activeTab === "forecast" && (
        <div className="pt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Target Metric to Forecast
              </label>
              <select
                value={forecastCol}
                onChange={(e) => setForecastCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {numericCols.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Forecasting Algorithm
              </label>
              <select
                value={forecastModel}
                onChange={(e) => setForecastModel(e.target.value as any)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                <option value="holt">
                  Holt Double Exponential Smoothing (Level + Trend)
                </option>
                <option value="linear">
                  OLS Linear Regression Extrapolation
                </option>
                <option value="ma">
                  4-Period Moving Average + Drift
                </option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Forecast Horizon (Future Periods)
              </label>
              <select
                value={horizonPeriods}
                onChange={(e) => setHorizonPeriods(Number(e.target.value))}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                <option value={4}>+4 Periods Ahead</option>
                <option value={6}>+6 Periods Ahead</option>
                <option value={10}>+10 Periods Ahead</option>
              </select>
            </div>
          </div>

          {forecastOutput && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* SVG Multi-Horizon Forecast Chart with 95% Confidence Cone */}
              <div className="lg:col-span-7 border border-slate-200 rounded-lg p-4 bg-[#090C10]">
                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="font-semibold text-[#39FF14]">
                    Historical Trajectory + {horizonPeriods}-Period Forecast (95% CI Cone)
                  </span>
                  <span className="font-mono tabular-nums text-[#B4C2D0]">
                    RMSE: ±{forecastOutput.rmse.toLocaleString()} · Slope:{" "}
                    {forecastOutput.slope > 0
                      ? `+${forecastOutput.slope}`
                      : forecastOutput.slope}
                    /period
                  </span>
                </div>

                {(() => {
                  const hist = forecastOutput.historical.slice(-18);
                  const projs = forecastOutput.projections;
                  const totalPts = hist.length + projs.length;
                  const allY = [
                    ...hist,
                    ...projs.map((p) => p.lower95),
                    ...projs.map((p) => p.upper95),
                  ];
                  const minY = Math.min(...allY);
                  const maxY = Math.max(...allY);
                  const rangeY = maxY - minY || 1;

                  const W = 560;
                  const H = 220;
                  const padL = 48;
                  const padR = 20;
                  const padT = 16;
                  const padB = 28;
                  const plotW = W - padL - padR;
                  const plotH = H - padT - padB;

                  const getX = (idx: number) =>
                    padL + (idx / Math.max(1, totalPts - 1)) * plotW;
                  const getY = (val: number) =>
                    padT + plotH - ((val - minY) / rangeY) * plotH;

                  const histPoints = hist
                    .map((v, i) => `${getX(i)},${getY(v)}`)
                    .join(" ");

                  const lastHistIdx = hist.length - 1;
                  const lastHistVal = hist[lastHistIdx];

                  const forecastPoints = [
                    `${getX(lastHistIdx)},${getY(lastHistVal)}`,
                    ...projs.map(
                      (p, i) =>
                        `${getX(lastHistIdx + 1 + i)},${getY(p.pointForecast)}`
                    ),
                  ].join(" ");

                  const conePolygon = [
                    `${getX(lastHistIdx)},${getY(lastHistVal)}`,
                    ...projs.map(
                      (p, i) =>
                        `${getX(lastHistIdx + 1 + i)},${getY(p.upper95)}`
                    ),
                    ...[...projs]
                      .reverse()
                      .map((p, revIdx) => {
                        const origIdx = projs.length - 1 - revIdx;
                        return `${getX(lastHistIdx + 1 + origIdx)},${getY(
                          p.lower95
                        )}`;
                      }),
                  ].join(" ");

                  return (
                    <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-56">
                      {/* Horizontal grid */}
                      {[0, 0.5, 1].map((t) => {
                        const yPos = padT + plotH * (1 - t);
                        const v = minY + t * rangeY;
                        return (
                          <g key={t}>
                            <line
                              x1={padL}
                              y1={yPos}
                              x2={W - padR}
                              y2={yPos}
                              stroke="#1B222C"
                              strokeWidth={1}
                            />
                            <text
                              x={padL - 6}
                              y={yPos + 4}
                              textAnchor="end"
                              className="fill-[#B4C2D0] text-[10px] font-mono"
                            >
                              {v >= 1000 ? `${(v / 1000).toFixed(1)}k` : v.toFixed(0)}
                            </text>
                          </g>
                        );
                      })}

                      {/* 95% Prediction Interval Shaded Cone */}
                      <polygon
                        points={conePolygon}
                        fill="rgba(57, 255, 20, 0.14)"
                        stroke="rgba(212, 220, 230, 0.35)"
                        strokeWidth={1}
                        strokeDasharray="2 2"
                      />

                      {/* Divider line between Actuals and Forecast */}
                      <line
                        x1={getX(lastHistIdx)}
                        y1={padT}
                        x2={getX(lastHistIdx)}
                        y2={padT + plotH}
                        stroke="#8E9BAE"
                        strokeWidth={1}
                        strokeDasharray="3 3"
                      />

                      {/* Historical Polyline */}
                      <polyline
                        fill="none"
                        stroke="#39FF14"
                        strokeWidth={2.2}
                        points={histPoints}
                      />

                      {/* Forecast Polyline */}
                      <polyline
                        fill="none"
                        stroke="#D4DCE6"
                        strokeWidth={2.2}
                        strokeDasharray="5 3"
                        points={forecastPoints}
                      />
                    </svg>
                  );
                })()}
              </div>

              {/* Forecast Horizon Table */}
              <div className="lg:col-span-5 border border-slate-200 rounded-lg p-4 overflow-x-auto">
                <div className="text-xs font-semibold text-slate-900 mb-2">
                  Projected Future Horizon Values & 95% Confidence Bounds
                </div>
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500">
                      <th className="py-2 px-2 font-medium">Horizon</th>
                      <th className="py-2 px-2 font-medium text-right">
                        Point Forecast
                      </th>
                      <th className="py-2 px-2 font-medium text-right">
                        95% Lower
                      </th>
                      <th className="py-2 px-2 font-medium text-right">
                        95% Upper
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs font-mono tabular-nums">
                    {forecastOutput.projections.map((p) => (
                      <tr key={p.label} className="hover:bg-slate-50">
                        <td className="py-2 px-2 text-slate-900 font-semibold">
                          {p.label}
                        </td>
                        <td className="py-2 px-2 text-right font-bold text-blue-600">
                          {p.pointForecast.toLocaleString()}
                        </td>
                        <td className="py-2 px-2 text-right text-slate-500">
                          {p.lower95.toLocaleString()}
                        </td>
                        <td className="py-2 px-2 text-right text-slate-500">
                          {p.upper95.toLocaleString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          MODULE 4: MULTIVARIATE Z-SCORE ANOMALY & OUTLIER INSPECTOR
         ===================================================================== */}
      {activeTab === "anomaly" && (
        <div className="pt-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 p-4 bg-slate-50 border border-slate-200 rounded-lg">
            <div>
              <div className="text-xs font-semibold text-slate-900">
                Z-Score Sensitivity Threshold (|z| ≥ {zThreshold}σ)
              </div>
              <p className="text-xs text-slate-500">
                Flags records whose numeric features deviate by at least{" "}
                {zThreshold} sample standard deviations (ddof=1) from the column mean.
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <input
                type="range"
                min={1.2}
                max={3.0}
                step={0.1}
                value={zThreshold}
                onChange={(e) => setZThreshold(Number(e.target.value))}
                className="w-36 cursor-pointer"
              />
              <span className="font-mono tabular-nums text-xs font-bold text-slate-900">
                {anomalyRecords.length} Flagged Rows
              </span>
            </div>
          </div>

          <div className="overflow-x-auto max-h-72 overflow-y-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-xs text-slate-500">
                  <th className="py-2.5 px-3 font-medium">Row #</th>
                  <th className="py-2.5 px-3 font-medium">Record Identifier</th>
                  <th className="py-2.5 px-3 font-medium">Primary Trigger Column</th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Observed Value
                  </th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Column Mean
                  </th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Peak |Z-Score|
                  </th>
                  <th className="py-2.5 px-3 font-medium text-right">
                    Multivariate RMS-Z
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs font-mono tabular-nums">
                {anomalyRecords.length === 0 ? (
                  <tr>
                    <td
                      colSpan={7}
                      className="py-8 text-center font-sans text-slate-500"
                    >
                      No records exceed |z| ≥ {zThreshold}σ. Lower the slider
                      threshold to inspect mild deviations.
                    </td>
                  </tr>
                ) : (
                  anomalyRecords.map((rec) => (
                    <tr key={rec.rowIdx} className="hover:bg-slate-50">
                      <td className="py-2.5 px-3 text-slate-500">
                        #{rec.rowIdx}
                      </td>
                      <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">
                        {rec.recordId}{" "}
                        {rec.Descriptor ? `· ${rec.Descriptor}` : ""}
                      </td>
                      <td className="py-2.5 px-3 text-slate-800">
                        {rec.triggerColumn}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-slate-900">
                        {rec.triggerVal.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-500">
                        {rec.columnMean.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-right font-bold text-red-600">
                        {rec.maxZ}σ
                      </td>
                      <td className="py-2.5 px-3 text-right text-slate-700">
                        {rec.rmsZ}σ
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* =====================================================================
          MODULE 5: SIMPSON'S PARADOX & KITAGAWA-OAXACA MIX-SHIFT DECOMPOSER
         ===================================================================== */}
      {activeTab === "simpson" && (
        <div className="pt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Primary Cohort Dimension
              </label>
              <select
                value={testGroupCol}
                onChange={(e) => setTestGroupCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {categoricalCols.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Cohort A (Baseline)
              </label>
              <select
                value={cohortA}
                onChange={(e) => setCohortA(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {availableCohorts.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Cohort B (Comparison)
              </label>
              <select
                value={cohortB}
                onChange={(e) => setCohortB(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {availableCohorts.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Confounding / Sub-Segment Variable
              </label>
              <select
                value={confounderCol}
                onChange={(e) => setConfounderCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {categoricalCols.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Evaluation Metric
              </label>
              <select
                value={testMetricCol}
                onChange={(e) => setTestMetricCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {numericCols.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {!simpsonAnalysis ? (
            <div className="py-8 text-center text-xs text-slate-500">
              Select two valid cohorts and a confounding dimension to decompose
              Within-Segment Performance vs. Mix-Shift Effects.
            </div>
          ) : (
            <div className="space-y-4">
              {/* Simpson's Paradox Alert Banner */}
              <div
                className={`p-4 rounded-lg border text-xs ${
                  simpsonAnalysis.isSimpsonsParadox
                    ? "bg-amber-50 border-amber-300 text-amber-950"
                    : "bg-slate-50 border-slate-200 text-slate-800"
                }`}
              >
                <div className="font-bold text-sm mb-1">
                  {simpsonAnalysis.isSimpsonsParadox
                    ? "⚠️ SIMPSON'S PARADOX / COMPOSITIONAL REVERSAL DETECTED"
                    : "✓ NO SIMPSON'S PARADOX REVERSAL (DIRECTIONALLY CONSISTENT)"}
                </div>
                <p className="leading-relaxed">
                  Overall, <strong>{cohortA}</strong> ({simpsonAnalysis.meanA.toLocaleString()}) vs.{" "}
                  <strong>{cohortB}</strong> ({simpsonAnalysis.meanB.toLocaleString()}) shows a headline difference of{" "}
                  <span className="font-mono font-bold">
                    {simpsonAnalysis.totalDiff > 0
                      ? `+${simpsonAnalysis.totalDiff}`
                      : simpsonAnalysis.totalDiff}
                  </span>
                  . Kitagawa-Oaxaca decomposition reveals that{" "}
                  <span className="font-mono font-bold">
                    {simpsonAnalysis.withinSegmentEffect > 0
                      ? `+${simpsonAnalysis.withinSegmentEffect}`
                      : simpsonAnalysis.withinSegmentEffect}
                  </span>{" "}
                  comes from <strong>Pure Within-Segment Performance</strong> across{" "}
                  <span className="font-mono">{confounderCol}</span>, while{" "}
                  <span className="font-mono font-bold">
                    {simpsonAnalysis.mixShiftEffect > 0
                      ? `+${simpsonAnalysis.mixShiftEffect}`
                      : simpsonAnalysis.mixShiftEffect}
                  </span>{" "}
                  is driven by <strong>Traffic / Volume Mix-Shift</strong> across sub-segments.
                </p>
              </div>

              {/* 3 Decomposition Summary Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Headline Observed Difference (Δ Mean)
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                    {simpsonAnalysis.totalDiff > 0
                      ? `+${simpsonAnalysis.totalDiff.toLocaleString()}`
                      : simpsonAnalysis.totalDiff.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5 font-mono">
                    {cohortA}: {simpsonAnalysis.meanA} vs. {cohortB}:{" "}
                    {simpsonAnalysis.meanB}
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Pure Within-Segment Rate Effect
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-blue-600 mt-1">
                    {simpsonAnalysis.withinSegmentEffect > 0
                      ? `+${simpsonAnalysis.withinSegmentEffect.toLocaleString()}`
                      : simpsonAnalysis.withinSegmentEffect.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Holding {confounderCol} volume mix constant
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Compositional Mix-Shift Effect
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-emerald-700 mt-1">
                    {simpsonAnalysis.mixShiftEffect > 0
                      ? `+${simpsonAnalysis.mixShiftEffect.toLocaleString()}`
                      : simpsonAnalysis.mixShiftEffect.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Due to volume distribution shift across {confounderCol}
                  </div>
                </div>
              </div>

              {/* Sub-Segment Breakdown Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500">
                      <th className="py-2.5 px-3 font-medium">
                        {confounderCol} Sub-Segment
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        {cohortA} Mix Share
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        {cohortB} Mix Share
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        {cohortA} Mean
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        {cohortB} Mean
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        Within-Segment Δ
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        Mix-Shift Contribution
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs font-mono tabular-nums">
                    {simpsonAnalysis.segmentBreakdown.map((seg) => (
                      <tr key={seg.segment} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-sans font-semibold text-slate-900">
                          {seg.segment}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">
                          {seg.shareAPct}% (n={seg.nA})
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-600">
                          {seg.shareBPct}% (n={seg.nB})
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-900">
                          {seg.meanA !== null ? seg.meanA.toLocaleString() : "—"}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-900">
                          {seg.meanB !== null ? seg.meanB.toLocaleString() : "—"}
                        </td>
                        <td
                          className={`py-2.5 px-3 text-right font-bold ${
                            seg.segDiff > 0
                              ? "text-emerald-700"
                              : seg.segDiff < 0
                              ? "text-red-600"
                              : "text-slate-500"
                          }`}
                        >
                          {seg.meanA !== null && seg.meanB !== null
                            ? seg.segDiff > 0
                              ? `+${seg.segDiff}`
                              : seg.segDiff
                            : "—"}
                        </td>
                        <td className="py-2.5 px-3 text-right text-slate-700">
                          {seg.mixContribution > 0
                            ? `+${seg.mixContribution}`
                            : seg.mixContribution}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          MODULE 6: 1,000-TRIAL MONTE CARLO STOCHASTIC P10 / P50 / P90 SIMULATOR
         ===================================================================== */}
      {activeTab === "monte-carlo" && (
        <div className="pt-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs text-slate-500 mb-1">
                Simulated Metric Column
              </label>
              <select
                value={forecastCol}
                onChange={(e) => setForecastCol(e.target.value)}
                className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
              >
                {numericCols.map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-500">Expected Drift / Shock (%)</span>
                <span className="font-mono font-bold text-blue-600">
                  {mcDriftPct >= 0 ? `+${mcDriftPct}%` : `${mcDriftPct}%`}
                </span>
              </div>
              <input
                type="range"
                min={-30}
                max={50}
                step={5}
                value={mcDriftPct}
                onChange={(e) => setMcDriftPct(Number(e.target.value))}
                className="w-full cursor-pointer"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-500">Volatility Multiplier (σ)</span>
                <span className="font-mono font-bold text-slate-900">
                  {mcVolatilityMult.toFixed(1)}x
                </span>
              </div>
              <input
                type="range"
                min={0.5}
                max={2.0}
                step={0.1}
                value={mcVolatilityMult}
                onChange={(e) => setMcVolatilityMult(Number(e.target.value))}
                className="w-full cursor-pointer"
              />
            </div>
          </div>

          {monteCarloOutput && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    P10 Downside Bear Case (10th Pct)
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-red-600 mt-1">
                    {monteCarloOutput.p10.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5 font-mono">
                    90% confidence floor
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    P50 Expected Median Case (50th Pct)
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-blue-600 mt-1">
                    {monteCarloOutput.p50.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5 font-mono">
                    Baseline Total: {monteCarloOutput.baseTotal.toLocaleString()}
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    P90 Upside Bull Case (90th Pct)
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-emerald-700 mt-1">
                    {monteCarloOutput.p90.toLocaleString()}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5 font-mono">
                    Top decile outcome
                  </div>
                </div>

                <div className="p-4 border border-slate-200 rounded-lg">
                  <div className="text-xs text-slate-500">
                    Probability of Beating Baseline
                  </div>
                  <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-1">
                    {monteCarloOutput.probBeatBaselinePct}%
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5 font-mono">
                    Across 1,000 Box-Muller trials
                  </div>
                </div>
              </div>

              {/* Probability Distribution Histogram */}
              <div className="p-4 rounded-lg border border-slate-200 bg-[#090C10]">
                <div className="flex items-center justify-between text-xs mb-3">
                  <span className="font-semibold text-[#39FF14]">
                    1,000-Trial Stochastic Probability Distribution ({forecastCol})
                  </span>
                  <span className="font-mono text-[#B4C2D0]">
                    P10: {monteCarloOutput.p10.toLocaleString()} · P50:{" "}
                    {monteCarloOutput.p50.toLocaleString()} · P90:{" "}
                    {monteCarloOutput.p90.toLocaleString()}
                  </span>
                </div>
                {(() => {
                  const maxBin = Math.max(
                    ...monteCarloOutput.bins.map((b) => b.count),
                    1
                  );
                  return (
                    <div className="grid grid-cols-16 gap-1.5 items-end h-36 pt-4">
                      {monteCarloOutput.bins.map((b, i) => {
                        const heightPct = Math.max(
                          6,
                          Math.round((b.count / maxBin) * 100)
                        );
                        return (
                          <div
                            key={i}
                            className="flex flex-col items-center justify-end h-full gap-1"
                          >
                            <div className="text-[10px] font-mono text-[#B4C2D0]">
                              {b.count}
                            </div>
                            <div
                              style={{ height: `${heightPct}%` }}
                              className="w-full rounded-t bg-[#39FF14]/80 hover:bg-[#39FF14] transition-all"
                              title={`Outcome ~ ${b.binCenter.toLocaleString()}: ${b.count} trials`}
                            />
                            <div className="text-[9px] font-mono text-[#8E9BAE] truncate max-w-full">
                              {b.binCenter >= 1000
                                ? `${(b.binCenter / 1000).toFixed(0)}k`
                                : b.binCenter}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
