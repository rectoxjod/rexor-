/**
 * Rexor — Power-User Keyboard Shortcuts & Command Palette Manager
 * Maps and executes global shortcuts:
 *   - Ctrl+Space : Run Full 6-Stage Autopilot
 *   - Ctrl+B     : Toggle Rexor AI Copilot Sidebar
 *   - Ctrl+R     : Reset Everything (Return to Fresh Upload / Dataset Launchpad)
 *   - Ctrl+K / ? : Open Command Palette & Keyboard Shortcuts Cheat Sheet
 *   - Ctrl+U     : Upload / Switch Dataset
 *   - Ctrl+E     : Open Dataset Export Studio (.xlsx / .csv / .json / .parquet)
 *   - Ctrl+P     : Save Executive Board Deck PDF (.pdf)
 *   - Ctrl+G     : Toggle Newbie Guided Assistant
 *   - Alt+1..5   : Jump directly to Stage Views (Overview, 1-2, 3, 4, 5-6)
 *
 * @author Rushi Chavan
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */
import React, { useMemo, useState } from "react";
import {
  Command,
  Compass,
  Download,
  FileSpreadsheet,
  Keyboard,
  MessageSquare,
  RotateCcw,
  Search,
  Sparkles,
  Upload,
  X,
} from "lucide-react";

export interface ShortcutCommandItem {
  id: string;
  title?: string;
  label?: string;
  description: string;
  category: string;
  keys: string[];
  action: () => void;
  disabled?: boolean;
}

interface RexorShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
  commands: ShortcutCommandItem[];
  isSideChatOpen?: boolean;
  hasActiveDataset: boolean;
}

export const RexorShortcutsModal: React.FC<RexorShortcutsModalProps> = ({
  isOpen,
  onClose,
  commands,
  hasActiveDataset,
}) => {
  const [searchQuery, setSearchQuery] = useState("");

  const filteredCommands = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return commands;
    return commands.filter(
      (cmd) =>
        (cmd.title || cmd.label || "").toLowerCase().includes(q) ||
        cmd.description.toLowerCase().includes(q) ||
        cmd.category.toLowerCase().includes(q) ||
        cmd.keys.join(" ").toLowerCase().includes(q)
    );
  }, [commands, searchQuery]);

  if (!isOpen) return null;

  const categories: Array<ShortcutCommandItem["category"]> = [
    "Core Actions",
    "Stage Navigation",
    "Data & Exports",
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 py-6 overflow-y-auto">
      <div className="bg-white border border-slate-300 rounded-xl max-w-2xl w-full p-5 sm:p-6 space-y-5 my-auto shadow-2xl">
        {/* Modal Header */}
        <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-200">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-blue-50 border border-blue-600 text-blue-600">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-mono text-slate-500">
                POWER-USER NAVIGATION · COMMAND PALETTE
              </div>
              <h3 className="text-lg font-bold text-slate-900">
                Rexor Keyboard Shortcuts & Quick Commands
              </h3>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Instant Command Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search shortcuts or commands (e.g., 'Reset Everything', 'Autopilot', 'Sidebar', 'Export')..."
            autoFocus
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
          />
        </div>

        {/* Highlighted Power-User Trio Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div className="p-3 rounded-lg bg-blue-50 border border-blue-600 flex flex-col justify-between gap-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-blue-600" />
                Run Autopilot
              </span>
              <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-slate-900 text-slate-100 rounded border border-slate-700">
                Ctrl + Space
              </kbd>
            </div>
            <p className="text-[11px] text-slate-600">
              Executes all 6 lifecycle stages automatically.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-blue-50 border border-blue-600 flex flex-col justify-between gap-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 flex items-center gap-1">
                <MessageSquare className="w-3.5 h-3.5 text-blue-600" />
                Toggle Sidebar
              </span>
              <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-slate-900 text-slate-100 rounded border border-slate-700">
                Ctrl + B
              </kbd>
            </div>
            <p className="text-[11px] text-slate-600">
              Shows or hides the Rexor AI Copilot dock.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-blue-50 border border-blue-600 flex flex-col justify-between gap-1.5">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-900 flex items-center gap-1">
                <RotateCcw className="w-3.5 h-3.5 text-blue-600" />
                Reset Everything
              </span>
              <kbd className="px-1.5 py-0.5 text-[10px] font-mono bg-slate-900 text-slate-100 rounded border border-slate-700">
                Ctrl + R
              </kbd>
            </div>
            <p className="text-[11px] text-slate-600">
              Clears workspace & returns to Data Upload screen.
            </p>
          </div>
        </div>

        {/* Grouped Command List */}
        <div className="max-h-80 overflow-y-auto space-y-4 pr-1">
          {categories.map((cat) => {
            const items = filteredCommands.filter((c) => c.category === cat);
            if (items.length === 0) return null;
            return (
              <div key={cat} className="space-y-2">
                <div className="text-[11px] font-mono uppercase tracking-wider text-slate-500 font-semibold">
                  {cat}
                </div>
                <div className="divide-y divide-slate-200 border border-slate-200 rounded-lg overflow-hidden">
                  {items.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      disabled={item.disabled}
                      onClick={() => {
                        item.action();
                        onClose();
                      }}
                      className="w-full px-3.5 py-2.5 bg-slate-50 hover:bg-slate-100 disabled:opacity-45 transition-colors flex items-center justify-between gap-3 text-left cursor-pointer"
                    >
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-900">
                          {item.title || item.label}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">
                          {item.description}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 shrink-0">
                        {item.keys.map((k, idx) => (
                          <React.Fragment key={idx}>
                            <kbd className="px-2 py-1 text-[11px] font-mono bg-slate-900 text-slate-100 rounded border border-slate-700">
                              {k}
                            </kbd>
                            {idx < item.keys.length - 1 && (
                              <span className="text-xs text-slate-500">+</span>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Modal Footer */}
        <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
          <span>
            Tip: Press <strong className="font-mono text-slate-900">Ctrl + K</strong>{" "}
            anytime to open this Command Palette, or click any row above to trigger it.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 text-xs font-semibold bg-slate-100 text-slate-700 rounded-lg cursor-pointer"
          >
            Close (Esc)
          </button>
        </div>
      </div>
    </div>
  );
};
