import React, { useState } from "react";
import { DataRow } from "../types/rexor";
import { executeGroupByAggregation } from "../utils/dataEngine";

interface BarChartProps {
  rows: DataRow[];
  xCol: string;
  yCol: string;
  aggFn: "AVG" | "SUM" | "COUNT" | "MEDIAN";
  title?: string;
}

export const InteractiveBarChart: React.FC<BarChartProps> = ({
  rows,
  xCol,
  yCol,
  aggFn,
}) => {
  const [hoveredIdx, setHoveredIdx] = useState<number | null>(null);
  const aggregated = executeGroupByAggregation(rows, xCol, yCol, aggFn).slice(
    0,
    10
  );

  if (aggregated.length === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-sm text-slate-500">
        Select valid categorical and numeric columns to render comparison chart.
      </div>
    );
  }

  const maxVal = Math.max(...aggregated.map((d) => Math.abs(d.value)), 1);

  return (
    <div className="w-full">
      <div className="space-y-3">
        {aggregated.map((item, idx) => {
          const pct = Math.max(
            4,
            Math.min(100, Math.round((Math.abs(item.value) / maxVal) * 100))
          );
          const isNegative = item.value < 0;
          const isHovered = hoveredIdx === idx;

          return (
            <div
              key={item.group}
              onMouseEnter={() => setHoveredIdx(idx)}
              onMouseLeave={() => setHoveredIdx(null)}
              className="group cursor-pointer"
            >
              <div className="flex items-center justify-between text-xs mb-1">
                <div className="flex items-center gap-2 text-slate-900 font-medium truncate max-w-[60%]">
                  <span className="font-mono text-slate-500 tabular-nums">
                    {String(idx + 1).padStart(2, "0")}
                  </span>
                  <span className="truncate">{item.group}</span>
                  <span className="text-slate-500 font-normal">
                    · n={item.count}
                  </span>
                </div>
                <div className="font-mono tabular-nums font-semibold text-blue-600">
                  {item.value.toLocaleString(undefined, {
                    maximumFractionDigits: 2,
                  })}
                </div>
              </div>
              <div className="w-full h-6 bg-slate-900 border border-slate-200 rounded overflow-hidden relative">
                <div
                  className={`h-full transition-opacity duration-150 rounded ${
                    isNegative ? "bg-[#FF5555]" : "bg-blue-600"
                  } ${isHovered ? "opacity-85" : "opacity-100"}`}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface ScatterPlotProps {
  rows: DataRow[];
  xCol: string;
  yCol: string;
  colorCol?: string;
}

export const InteractiveScatterPlot: React.FC<ScatterPlotProps> = ({
  rows,
  xCol,
  yCol,
  colorCol,
}) => {
  const [hoveredPoint, setHoveredPoint] = useState<{
    x: number;
    y: number;
    label: string;
    category: string;
  } | null>(null);

  const firstKey = rows.length > 0 ? Object.keys(rows[0])[0] : "id";

  const points = rows
    .map((r, i) => ({
      x: Number(r[xCol]),
      y: Number(r[yCol]),
      label: String(r[firstKey] || `Row ${i + 1}`),
      category: colorCol ? String(r[colorCol] ?? "Default") : "Record",
    }))
    .filter((p) => !Number.isNaN(p.x) && !Number.isNaN(p.y));

  if (points.length < 2) {
    return (
      <div className="h-64 flex items-center justify-center text-sm text-slate-500">
        Insufficient numeric pairs for scatter regression plot.
      </div>
    );
  }

  const xs = points.map((p) => p.x);
  const ys = points.map((p) => p.y);
  const minX = Math.min(...xs);
  const maxX = Math.max(...xs);
  const minY = Math.min(...ys);
  const maxY = Math.max(...ys);

  const rangeX = maxX - minX || 1;
  const rangeY = maxY - minY || 1;

  // Compute Ordinary Least Squares (OLS) regression line & R² on 100% of valid points
  const n = points.length;
  const meanX = xs.reduce((a, b) => a + b, 0) / n;
  const meanY = ys.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let denX = 0;
  let denY = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - meanX;
    const dy = ys[i] - meanY;
    num += dx * dy;
    denX += dx * dx;
    denY += dy * dy;
  }
  const slope = denX === 0 ? 0 : num / denX;
  const intercept = meanY - slope * meanX;
  const rVal = denX === 0 || denY === 0 ? 0 : num / Math.sqrt(denX * denY);
  const rSquared = rVal * rVal;

  // Stratified-sample rendered SVG circles at 1,000 max to prevent DOM lag on 15,000+ row CSVs
  const MAX_RENDERED_POINTS = 1000;
  const renderedPoints =
    points.length <= MAX_RENDERED_POINTS
      ? points
      : Array.from({ length: MAX_RENDERED_POINTS }, (_, idx) => {
          const srcIdx = Math.min(
            points.length - 1,
            Math.floor((idx * points.length) / MAX_RENDERED_POINTS)
          );
          return points[srcIdx];
        });

  const width = 560;
  const height = 260;
  const padLeft = 52;
  const padRight = 24;
  const padTop = 20;
  const padBottom = 36;
  const plotW = width - padLeft - padRight;
  const plotH = height - padTop - padBottom;

  const toSvgX = (x: number) => padLeft + ((x - minX) / rangeX) * plotW;
  const toSvgY = (y: number) => padTop + plotH - ((y - minY) / rangeY) * plotH;

  const regY1 = slope * minX + intercept;
  const regY2 = slope * maxX + intercept;

  const categories = Array.from(new Set(points.map((p) => p.category)));
  const palette = [
    "var(--rexor-accent)",
    "var(--rexor-accent-secondary)",
    "var(--rexor-heading)",
    "var(--rexor-body-text)",
  ];

  return (
    <div className="relative w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        className="w-full h-64 overflow-visible border border-slate-200 rounded bg-slate-900"
      >
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((t) => {
          const yPos = padTop + plotH * (1 - t);
          const val = minY + t * rangeY;
          return (
            <g key={t}>
              <line
                x1={padLeft}
                y1={yPos}
                x2={width - padRight}
                y2={yPos}
                stroke="var(--rexor-border)"
                strokeOpacity={0.5}
                strokeWidth={1}
              />
              <text
                x={padLeft - 8}
                y={yPos + 4}
                textAnchor="end"
                fill="var(--rexor-body-text)"
                className="text-[10px] font-mono"
              >
                {val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val.toFixed(1)}
              </text>
            </g>
          );
        })}

        {/* X Axis labels */}
        {[0, 0.5, 1].map((t) => {
          const xPos = padLeft + plotW * t;
          const val = minX + t * rangeX;
          return (
            <text
              key={t}
              x={xPos}
              y={height - 10}
              textAnchor="middle"
              fill="var(--rexor-heading)"
              className="text-[10px] font-mono"
            >
              {val >= 1000 ? `${(val / 1000).toFixed(1)}k` : val.toFixed(1)}
            </text>
          );
        })}

        {/* OLS Regression Line */}
        <line
          x1={toSvgX(minX)}
          y1={Math.max(padTop, Math.min(padTop + plotH, toSvgY(regY1)))}
          x2={toSvgX(maxX)}
          y2={Math.max(padTop, Math.min(padTop + plotH, toSvgY(regY2)))}
          stroke="var(--rexor-accent-secondary)"
          strokeWidth={1.8}
          strokeDasharray="4 4"
        />

        {/* Scatter Points (Stratified-sampled at 1,000 max DOM nodes) */}
        {renderedPoints.map((pt, i) => {
          const cx = toSvgX(pt.x);
          const cy = toSvgY(pt.y);
          const catIdx = Math.max(0, categories.indexOf(pt.category));
          const fill = palette[catIdx % palette.length];
          return (
            <circle
              key={i}
              cx={cx}
              cy={cy}
              r={5.2}
              fill={fill}
              fillOpacity={0.92}
              stroke="var(--rexor-bg-main)"
              strokeWidth={1.2}
              className="cursor-pointer transition-transform duration-150 hover:scale-125"
              onMouseEnter={() => setHoveredPoint(pt)}
              onMouseLeave={() => setHoveredPoint(null)}
            />
          );
        })}
      </svg>

      <div className="flex items-center justify-between text-xs text-slate-500 mt-2">
        <div className="flex items-center gap-3 flex-wrap">
          <span className="text-slate-900">X: {xCol}</span>
          <span>·</span>
          <span className="text-slate-900">Y: {yCol}</span>
          <span>·</span>
          <span className="font-mono tabular-nums text-slate-600">
            OLS: y = {slope.toFixed(2)}x + {intercept.toFixed(1)} · R² ={" "}
            {rSquared.toFixed(3)} ({(rSquared * 100).toFixed(1)}%)
          </span>
          {points.length > MAX_RENDERED_POINTS && (
            <span className="font-mono text-[11px] text-blue-600">
              (1,000 sampled of {points.length.toLocaleString()} pts)
            </span>
          )}
        </div>
        {hoveredPoint && (
          <div className="font-mono text-xs text-slate-900 bg-slate-50 border border-blue-600 px-2 py-0.5 rounded">
            {hoveredPoint.label} ({hoveredPoint.category}): {xCol}=
            {hoveredPoint.x}, {yCol}={hoveredPoint.y}
          </div>
        )}
      </div>
    </div>
  );
};

interface DistributionChartProps {
  rows: DataRow[];
  col: string;
}

export const InteractiveHistogram: React.FC<DistributionChartProps> = ({
  rows,
  col,
}) => {
  const nums = rows
    .map((r) => Number(r[col]))
    .filter((n) => !Number.isNaN(n))
    .sort((a, b) => a - b);

  if (nums.length === 0) {
    return (
      <div className="h-56 flex items-center justify-center text-sm text-slate-500">
        No numeric observations available for distribution histogram.
      </div>
    );
  }

  const min = nums[0];
  const max = nums[nums.length - 1];
  const meanVal = nums.reduce((a, b) => a + b, 0) / nums.length;
  const midIdx = Math.floor(nums.length / 2);
  const medianVal =
    nums.length % 2 === 0
      ? (nums[midIdx - 1] + nums[midIdx]) / 2
      : nums[midIdx];

  // Sturges' Rule for adaptive histogram bin count: clamp between 6 and 20 bins
  const binCount = Math.min(
    20,
    Math.max(6, Math.ceil(Math.log2(nums.length) + 1))
  );
  const range = max - min || 1;
  const step = range / binCount;

  const bins = Array.from({ length: binCount }, (_, i) => {
    const start = min + i * step;
    const end = i === binCount - 1 ? max + 0.0001 : min + (i + 1) * step;
    const count = nums.filter((v) => v >= start && v < end).length;
    return {
      label: `${
        start >= 1000 ? `${(start / 1000).toFixed(1)}k` : start.toFixed(0)
      }`,
      rangeText: `${start.toFixed(1)} – ${(min + (i + 1) * step).toFixed(1)}`,
      count,
    };
  });

  const maxBin = Math.max(...bins.map((b) => b.count), 1);
  const meanPct = Math.max(
    2,
    Math.min(98, ((meanVal - min) / range) * 100)
  );
  const medianPct = Math.max(
    2,
    Math.min(98, ((medianVal - min) / range) * 100)
  );

  return (
    <div className="w-full">
      <div className="relative h-52 flex items-end gap-2 pt-7 pb-2 px-2 border border-slate-200 rounded bg-slate-900 overflow-hidden">
        {/* Vertical Dashed Reference Line for Mean */}
        <div
          className="absolute top-0 bottom-6 border-l-2 border-dashed border-amber-400 pointer-events-none z-10"
          style={{ left: `${meanPct}%` }}
          title={`Mean: ${meanVal.toFixed(2)}`}
        >
          <span className="px-1 py-0.5 text-[9px] font-mono bg-amber-400 text-slate-950 font-bold rounded-br whitespace-nowrap">
            μ={meanVal.toFixed(1)}
          </span>
        </div>

        {/* Vertical Dashed Reference Line for Median */}
        <div
          className="absolute top-0 bottom-6 border-l-2 border-dashed border-emerald-400 pointer-events-none z-10"
          style={{ left: `${medianPct}%` }}
          title={`Median: ${medianVal.toFixed(2)}`}
        >
          <span className="px-1 py-0.5 text-[9px] font-mono bg-emerald-400 text-slate-950 font-bold rounded-tr whitespace-nowrap mt-4 inline-block">
            Med={medianVal.toFixed(1)}
          </span>
        </div>

        {bins.map((b, idx) => {
          const heightPct = Math.max(6, Math.round((b.count / maxBin) * 100));
          return (
            <div
              key={idx}
              className="flex-1 flex flex-col items-center justify-end h-full group"
              title={`${b.rangeText}: ${b.count} records`}
            >
              <span className="text-[11px] font-mono tabular-nums text-blue-600 mb-1">
                {b.count}
              </span>
              <div
                className="w-full bg-blue-600 transition-colors rounded-t"
                style={{ height: `${heightPct}%` }}
              />
              <span className="text-[10px] font-mono tabular-nums text-slate-500 mt-1.5 truncate max-w-full">
                {b.label}
              </span>
            </div>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500 mt-2 font-mono tabular-nums">
        <span className="text-slate-900">Min: {min.toLocaleString()}</span>
        <span>·</span>
        <span className="text-amber-600 font-semibold">
          Mean (μ): {meanVal.toFixed(2)}
        </span>
        <span>·</span>
        <span className="text-emerald-600 font-semibold">
          Median: {medianVal.toFixed(2)}
        </span>
        <span>·</span>
        <span>
          n={nums.length} ({binCount} Sturges bins)
        </span>
        <span>·</span>
        <span className="text-slate-900">Max: {max.toLocaleString()}</span>
      </div>
    </div>
  );
};
