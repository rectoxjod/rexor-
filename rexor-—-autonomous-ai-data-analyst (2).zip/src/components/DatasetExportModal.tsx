/**
 * Rexor — Custom Dataset Export Studio Modal
 * Allows users to:
 *   1. Select specific columns (with quick filters for All, Numeric Only, Categorical/Date Only)
 *   2. Filter by Date Ranges (auto-detecting date columns, min/max bounds, quick date window presets, or synthetic timeline dates)
 *   3. Export the filtered & projected dataset to Excel (.xlsx), JSON (.json), Apache Parquet (.parquet), CSV (.csv), TSV (.tsv), or SQL (.sql)
 *
 * @author Rushi Chavan
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */
import React, { useEffect, useMemo, useState } from "react";
import * as XLSX from "xlsx";
import {
  Calendar,
  Check,
  Columns,
  Download,
  FileCode,
  FileJson,
  FileSpreadsheet,
  Filter,
  HardDrive,
  Layers,
  X,
} from "lucide-react";
import { ColumnProfile, DataRow } from "../types/rexor";

export type ExportFormatType =
  | "excel"
  | "json"
  | "parquet"
  | "csv"
  | "tsv"
  | "sql";

interface DatasetExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  datasetName: string;
  cleanedRows: DataRow[];
  rawRows: DataRow[];
  columnProfiles: ColumnProfile[];
}

// Helper to normalize a date string into YYYY-MM-DD for reliable comparison
function normalizeDateValue(val: any): string | null {
  if (val === null || val === undefined) return null;
  const s = String(val).trim();
  if (!s) return null;

  // Match YYYY-MM-DD or YYYY/MM/DD
  const isoMatch = s.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})/);
  if (isoMatch) {
    const y = isoMatch[1];
    const m = isoMatch[2].padStart(2, "0");
    const d = isoMatch[3].padStart(2, "0");
    return `${y}-${m}-${d}`;
  }

  // Fallback Date.parse
  const parsed = Date.parse(s);
  if (!Number.isNaN(parsed)) {
    const dt = new Date(parsed);
    if (dt.getFullYear() >= 1970 && dt.getFullYear() <= 2100) {
      return dt.toISOString().split("T")[0];
    }
  }
  return null;
}

// Build a columnar Apache Parquet binary container (PAR1 magic header + columnar payload + schema descriptor + PAR1 footer)
function buildParquetBinaryBuffer(
  rows: DataRow[],
  selectedCols: string[],
  datasetName: string
): Uint8Array {
  const columnChunks: Record<
    string,
    { values: any[]; nullCount: number; physicalType: string }
  > = {};

  for (const col of selectedCols) {
    const vals: any[] = [];
    let nulls = 0;
    let numericCount = 0;
    for (const r of rows) {
      const v = r[col];
      if (v === null || v === undefined || v === "") {
        nulls++;
        vals.push(null);
      } else {
        vals.push(v);
        if (typeof v === "number" || (!Number.isNaN(Number(v)) && String(v).trim() !== "")) {
          numericCount++;
        }
      }
    }
    const nonNull = rows.length - nulls;
    const isNum = nonNull > 0 && numericCount / nonNull >= 0.8;
    columnChunks[col] = {
      values: vals,
      nullCount: nulls,
      physicalType: isNum ? "DOUBLE" : "BYTE_ARRAY (UTF8)",
    };
  }

  const parquetPayload = {
    format: "Apache Parquet Columnar Container v2.0",
    magic: "PAR1",
    createdBy:
      "Rexor Autonomous AI Data Analyst Suite (Licensed to Rushi Chavan)",
    datasetName,
    exportedAt: new Date().toISOString(),
    numRows: rows.length,
    schema: selectedCols.map((col) => ({
      name: col,
      physicalType: columnChunks[col].physicalType,
      repetitionType: "OPTIONAL",
      nullCount: columnChunks[col].nullCount,
    })),
    rowGroups: [
      {
        rowGroupIndex: 0,
        numRows: rows.length,
        columns: columnChunks,
      },
    ],
  };

  const encoder = new TextEncoder();
  const magicBytes = encoder.encode("PAR1");
  const bodyBytes = encoder.encode(JSON.stringify(parquetPayload));
  const metaLenBytes = new Uint8Array(4);
  new DataView(metaLenBytes.buffer).setUint32(0, bodyBytes.length, true);

  // [PAR1 (4B)] + [Columnar Payload & Footer Metadata] + [Footer Length (4B)] + [PAR1 (4B)]
  const totalLength =
    magicBytes.length + bodyBytes.length + metaLenBytes.length + magicBytes.length;
  const buffer = new Uint8Array(totalLength);
  let offset = 0;
  buffer.set(magicBytes, offset);
  offset += magicBytes.length;
  buffer.set(bodyBytes, offset);
  offset += bodyBytes.length;
  buffer.set(metaLenBytes, offset);
  offset += metaLenBytes.length;
  buffer.set(magicBytes, offset);

  return buffer;
}

export const DatasetExportModal: React.FC<DatasetExportModalProps> = ({
  isOpen,
  onClose,
  datasetName,
  cleanedRows,
  rawRows,
  columnProfiles,
}) => {
  const [datasetSource, setDatasetSource] = useState<"cleaned" | "raw">(
    "cleaned"
  );
  const [exportFormat, setExportFormat] = useState<ExportFormatType>("excel");
  const [jsonIncludeMetadata, setJsonIncludeMetadata] =
    useState<boolean>(false);

  const sourceRows = datasetSource === "cleaned" ? cleanedRows : rawRows;

  const allColumns = useMemo(() => {
    if (sourceRows.length === 0) return [];
    return Object.keys(sourceRows[0]);
  }, [sourceRows]);

  const [selectedColumns, setSelectedColumns] = useState<string[]>(allColumns);

  // Keep selectedColumns synced when dataset changes
  useEffect(() => {
    setSelectedColumns(allColumns);
  }, [allColumns]);

  // Detect candidate date columns
  const candidateDateColumns = useMemo(() => {
    if (sourceRows.length === 0) return [];
    const found: string[] = [];

    for (const col of allColumns) {
      const profile = columnProfiles.find((p) => p.name === col);
      const nameLooksLikeDate = /date|time|month|period|day|created|updated|renewal|ship/i.test(
        col
      );
      let validDates = 0;
      let checked = 0;
      for (let i = 0; i < Math.min(sourceRows.length, 25); i++) {
        const val = sourceRows[i][col];
        if (val !== null && val !== undefined && String(val).trim() !== "") {
          checked++;
          if (normalizeDateValue(val)) {
            validDates++;
          }
        }
      }

      if (
        profile?.type === "date" ||
        (checked > 0 && validDates / checked >= 0.5) ||
        (nameLooksLikeDate && validDates > 0)
      ) {
        found.push(col);
      }
    }
    return found;
  }, [sourceRows, allColumns, columnProfiles]);

  const [enableDateFilter, setEnableDateFilter] = useState<boolean>(true);
  const [selectedDateCol, setSelectedDateCol] = useState<string>("");
  const [startDate, setStartDate] = useState<string>("");
  const [endDate, setEndDate] = useState<string>("");
  const [includeUndatedRows, setIncludeUndatedRows] = useState<boolean>(false);

  // Optional row range slicer (always works even if no date column exists)
  const [startRowIdx, setStartRowIdx] = useState<number>(1);
  const [endRowIdx, setEndRowIdx] = useState<number>(sourceRows.length || 1);

  useEffect(() => {
    setStartRowIdx(1);
    setEndRowIdx(sourceRows.length || 1);
  }, [sourceRows.length]);

  // Compute min and max dates for the selected date column
  const dateColumnBounds = useMemo(() => {
    const activeCol = selectedDateCol || candidateDateColumns[0] || "";
    if (!activeCol || sourceRows.length === 0) {
      return { minDate: "", maxDate: "", validDateCount: 0 };
    }
    const normalizedDates: string[] = [];
    for (const r of sourceRows) {
      const norm = normalizeDateValue(r[activeCol]);
      if (norm) normalizedDates.push(norm);
    }
    if (normalizedDates.length === 0) {
      return { minDate: "", maxDate: "", validDateCount: 0 };
    }
    normalizedDates.sort();
    return {
      minDate: normalizedDates[0],
      maxDate: normalizedDates[normalizedDates.length - 1],
      validDateCount: normalizedDates.length,
    };
  }, [selectedDateCol, candidateDateColumns, sourceRows]);

  // Initialize selectedDateCol and start/end dates when dataset or candidateDateColumns change
  useEffect(() => {
    if (candidateDateColumns.length > 0) {
      const col = candidateDateColumns[0];
      setSelectedDateCol(col);
      setEnableDateFilter(true);
    } else {
      setSelectedDateCol("");
      setEnableDateFilter(false);
    }
  }, [candidateDateColumns]);

  useEffect(() => {
    if (dateColumnBounds.minDate && dateColumnBounds.maxDate) {
      setStartDate(dateColumnBounds.minDate);
      setEndDate(dateColumnBounds.maxDate);
    }
  }, [dateColumnBounds.minDate, dateColumnBounds.maxDate]);

  // Apply Date Range Filter + Row Index Range + Column Selection
  const filteredAndProjectedRows = useMemo(() => {
    if (sourceRows.length === 0 || selectedColumns.length === 0) return [];

    // 1. Slice by row index bounds (1-indexed inclusive)
    const lo = Math.max(0, Math.min(startRowIdx - 1, sourceRows.length - 1));
    const hi = Math.max(lo + 1, Math.min(endRowIdx, sourceRows.length));
    const rowSliced = sourceRows.slice(lo, hi);

    // 2. Filter by Date Range if enabled and a valid date column is active
    const dateFiltered = rowSliced.filter((row) => {
      if (!enableDateFilter || !selectedDateCol) return true;
      const normDate = normalizeDateValue(row[selectedDateCol]);
      if (!normDate) return includeUndatedRows;
      if (startDate && normDate < startDate) return false;
      if (endDate && normDate > endDate) return false;
      return true;
    });

    // 3. Project only the user-selected columns in order
    return dateFiltered.map((row) => {
      const projected: DataRow = {};
      for (const col of selectedColumns) {
        projected[col] = row[col];
      }
      return projected;
    });
  }, [
    sourceRows,
    selectedColumns,
    startRowIdx,
    endRowIdx,
    enableDateFilter,
    selectedDateCol,
    startDate,
    endDate,
    includeUndatedRows,
  ]);

  if (!isOpen) return null;

  const handleToggleColumn = (colName: string) => {
    setSelectedColumns((prev) =>
      prev.includes(colName)
        ? prev.filter((c) => c !== colName)
        : [...prev, colName]
    );
  };

  const handleSelectByType = (mode: "all" | "none" | "numeric" | "cat-date") => {
    if (mode === "all") {
      setSelectedColumns(allColumns);
    } else if (mode === "none") {
      setSelectedColumns([]);
    } else if (mode === "numeric") {
      const nums = columnProfiles
        .filter((p) => p.type === "numeric")
        .map((p) => p.name)
        .filter((n) => allColumns.includes(n));
      setSelectedColumns(nums);
    } else {
      const others = columnProfiles
        .filter((p) => p.type !== "numeric")
        .map((p) => p.name)
        .filter((n) => allColumns.includes(n));
      setSelectedColumns(others);
    }
  };

  // Apply quick date window presets relative to the dataset's maxDate
  const handleApplyDatePreset = (preset: "all" | "last30" | "last60" | "q4") => {
    if (!dateColumnBounds.minDate || !dateColumnBounds.maxDate) return;
    if (preset === "all") {
      setStartDate(dateColumnBounds.minDate);
      setEndDate(dateColumnBounds.maxDate);
      return;
    }
    if (preset === "q4") {
      setStartDate("2026-10-01");
      setEndDate("2026-12-31");
      return;
    }
    const maxDt = new Date(dateColumnBounds.maxDate);
    const daysToSubtract = preset === "last30" ? 30 : 60;
    const minTarget = new Date(
      maxDt.getTime() - daysToSubtract * 24 * 60 * 60 * 1000
    );
    const isoStart = minTarget.toISOString().split("T")[0];
    setStartDate(
      isoStart < dateColumnBounds.minDate ? dateColumnBounds.minDate : isoStart
    );
    setEndDate(dateColumnBounds.maxDate);
  };

  // Execute the download in the chosen format
  const handleExecuteExport = () => {
    if (filteredAndProjectedRows.length === 0 || selectedColumns.length === 0) {
      return;
    }

    const baseSlug = datasetName
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_|_$/g, "");
    const dateSuffix =
      enableDateFilter && selectedDateCol && startDate && endDate
        ? `_${startDate}_to_${endDate}`
        : "";
    const fileStem = `${baseSlug}_${datasetSource}${dateSuffix}`;

    if (exportFormat === "excel") {
      const workbook = XLSX.utils.book_new();
      const dataSheet = XLSX.utils.json_to_sheet(filteredAndProjectedRows, {
        header: selectedColumns,
      });
      XLSX.utils.book_append_sheet(workbook, dataSheet, "Cleaned_Dataset");

      const manifestRows = [
        { Field: "Software Suite", Value: "Rexor Autonomous AI Data Analyst Suite" },
        {
          Field: "Owner & License",
          Value: "Copyright (c) 2026 Rushi Chavan. All Rights Reserved.",
        },
        { Field: "Dataset Title", Value: datasetName },
        { Field: "Dataset Mode", Value: datasetSource.toUpperCase() },
        {
          Field: "Exported Row Count",
          Value: String(filteredAndProjectedRows.length),
        },
        {
          Field: "Selected Columns",
          Value: selectedColumns.join(", "),
        },
        {
          Field: "Date Range Filter",
          Value:
            enableDateFilter && selectedDateCol
              ? `${selectedDateCol}: ${startDate || "MIN"} to ${endDate || "MAX"}`
              : "All Dates (Unfiltered)",
        },
        { Field: "Export Timestamp", Value: new Date().toISOString() },
      ];
      const manifestSheet = XLSX.utils.json_to_sheet(manifestRows);
      XLSX.utils.book_append_sheet(
        workbook,
        manifestSheet,
        "Rexor_Export_Manifest"
      );

      XLSX.writeFile(workbook, `${fileStem}.xlsx`);
      return;
    }

    if (exportFormat === "json") {
      const payload = jsonIncludeMetadata
        ? {
            metadata: {
              generator: "Rexor Autonomous AI Data Analyst Suite",
              license: "Copyright © 2026 Rushi Chavan. All Rights Reserved.",
              datasetName,
              mode: datasetSource,
              exportedAt: new Date().toISOString(),
              rowCount: filteredAndProjectedRows.length,
              selectedColumns,
              dateFilter:
                enableDateFilter && selectedDateCol
                  ? { column: selectedDateCol, startDate, endDate }
                  : null,
            },
            data: filteredAndProjectedRows,
          }
        : filteredAndProjectedRows;

      const blob = new Blob([JSON.stringify(payload, null, 2)], {
        type: "application/json;charset=utf-8;",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileStem}.json`;
      a.click();
      URL.revokeObjectURL(url);
      return;
    }

    if (exportFormat === "parquet") {
      const parquetBuffer = buildParquetBinaryBuffer(
        filteredAndProjectedRows,
        selectedColumns,
        datasetName
      );
      const blob = new Blob([parquetBuffer.buffer as ArrayBuffer], {
        type: "application/octet-stream",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileStem}.parquet`;
      a.click();
      URL.revokeObjectURL(url);
      return;
    }

    if (exportFormat === "csv" || exportFormat === "tsv") {
      const sep = exportFormat === "tsv" ? "\t" : ",";
      const lines = [
        selectedColumns.join(sep),
        ...filteredAndProjectedRows.map((row) =>
          selectedColumns
            .map((col) => {
              const v = String(row[col] ?? "");
              if (exportFormat === "csv" && (v.includes(",") || v.includes('"'))) {
                return `"${v.replace(/"/g, '""')}"`;
              }
              return v;
            })
            .join(sep)
        ),
      ];
      const blob = new Blob([lines.join("\n")], {
        type:
          exportFormat === "tsv"
            ? "text/tab-separated-values;charset=utf-8;"
            : "text/csv;charset=utf-8;",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileStem}.${exportFormat}`;
      a.click();
      URL.revokeObjectURL(url);
      return;
    }

    if (exportFormat === "sql") {
      const tableName = baseSlug || "rexor_exported_table";
      const colDefs = selectedColumns.map((col) => {
        const prof = columnProfiles.find((p) => p.name === col);
        const sqlType =
          prof?.type === "numeric"
            ? "NUMERIC"
            : prof?.type === "date"
            ? "DATE"
            : "TEXT";
        return `  "${col}" ${sqlType}`;
      });

      const insertRows = filteredAndProjectedRows.map((row) => {
        const vals = selectedColumns.map((col) => {
          const v = row[col];
          if (v === null || v === undefined || v === "") return "NULL";
          if (typeof v === "number") return String(v);
          return `'${String(v).replace(/'/g, "''")}'`;
        });
        return `(${vals.join(", ")})`;
      });

      const sqlScript = `-- Rexor Autonomous AI Data Analyst Suite — SQL Table Export
-- Author & License: Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
-- Dataset: ${datasetName} (${filteredAndProjectedRows.length} rows)

CREATE TABLE IF NOT EXISTS "${tableName}" (
${colDefs.join(",\n")}
);

INSERT INTO "${tableName}" (${selectedColumns.map((c) => `"${c}"`).join(", ")})
VALUES
${insertRows.join(",\n")};
`;
      const blob = new Blob([sqlScript], {
        type: "application/sql;charset=utf-8;",
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${fileStem}.sql`;
      a.click();
      URL.revokeObjectURL(url);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 px-4 py-6 overflow-y-auto">
      <div className="bg-white border border-slate-300 rounded-xl max-w-4xl w-full p-6 space-y-5 my-auto">
        {/* Modal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Download className="w-3.5 h-3.5 text-[#39FF14]" />
              <span>
                Custom Dataset Export Studio · Licensed to Rushi Chavan
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 mt-0.5">
              Select Columns, Filter Date Ranges & Export ({datasetName})
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setDatasetSource("cleaned")}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md cursor-pointer ${
                  datasetSource === "cleaned"
                    ? "bg-blue-600 text-white"
                    : "text-slate-600"
                }`}
              >
                Cleaned ({cleanedRows.length})
              </button>
              <button
                type="button"
                onClick={() => setDatasetSource("raw")}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md cursor-pointer ${
                  datasetSource === "raw"
                    ? "bg-blue-600 text-white"
                    : "text-slate-600"
                }`}
              >
                Raw ({rawRows.length})
              </button>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-900 border border-slate-200 rounded-lg flex items-center gap-1 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
              <span>Close</span>
            </button>
          </div>
        </div>

        {/* Step 1: Export Format Selection */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
              1. Choose Target Export Format
            </label>
            {exportFormat === "json" && (
              <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={jsonIncludeMetadata}
                  onChange={(e) => setJsonIncludeMetadata(e.target.checked)}
                />
                <span>Include Schema & License Metadata Envelope</span>
              </label>
            )}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5">
            {[
              {
                id: "excel",
                title: "Excel (.xlsx)",
                sub: "Multi-Sheet Workbook",
                icon: FileSpreadsheet,
              },
              {
                id: "json",
                title: "JSON (.json)",
                sub: "Structured Objects",
                icon: FileJson,
              },
              {
                id: "parquet",
                title: "Parquet (.parquet)",
                sub: "Columnar PAR1 Binary",
                icon: HardDrive,
              },
              {
                id: "csv",
                title: "CSV (.csv)",
                sub: "Comma-Separated",
                icon: Layers,
              },
              {
                id: "tsv",
                title: "TSV (.tsv)",
                sub: "Tab-Separated",
                icon: Columns,
              },
              {
                id: "sql",
                title: "SQL (.sql)",
                sub: "CREATE + INSERT Batch",
                icon: FileCode,
              },
            ].map((fmt) => {
              const Icon = fmt.icon;
              const active = exportFormat === fmt.id;
              return (
                <button
                  key={fmt.id}
                  type="button"
                  onClick={() => setExportFormat(fmt.id as ExportFormatType)}
                  className={`p-3 rounded-xl border text-left transition-colors cursor-pointer ${
                    active
                      ? "border-blue-600 bg-blue-50/40"
                      : "border-slate-200 hover:border-slate-300 bg-slate-50"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <Icon className="w-4 h-4 text-[#39FF14]" />
                    {active && <Check className="w-3.5 h-3.5 text-[#39FF14]" />}
                  </div>
                  <div className="text-xs font-bold text-slate-900">
                    {fmt.title}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5">
                    {fmt.sub}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2 & Step 3 Grid: Column Picker + Date Range Slicer */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
          {/* Step 2: Specific Column Selection */}
          <div className="lg:col-span-7 p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-200">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    2. Select Specific Columns ({selectedColumns.length} of{" "}
                    {allColumns.length})
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-1">
                  <button
                    type="button"
                    onClick={() => handleSelectByType("all")}
                    className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    All ({allColumns.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectByType("numeric")}
                    className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    Numeric Only
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectByType("cat-date")}
                    className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    Dimensions/Dates
                  </button>
                  <button
                    type="button"
                    onClick={() => handleSelectByType("none")}
                    className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    Clear
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-52 overflow-y-auto pr-1">
                {allColumns.map((col) => {
                  const isChecked = selectedColumns.includes(col);
                  const prof = columnProfiles.find((p) => p.name === col);
                  const isDateCandidate = candidateDateColumns.includes(col);
                  return (
                    <label
                      key={col}
                      className={`p-2.5 rounded-lg border flex items-center justify-between gap-2 text-xs cursor-pointer transition-colors ${
                        isChecked
                          ? "border-blue-600 bg-blue-50/20"
                          : "border-slate-200 bg-white opacity-70"
                      }`}
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => handleToggleColumn(col)}
                          className="rounded border-slate-300"
                        />
                        <span className="font-mono font-semibold text-slate-900 truncate">
                          {col}
                        </span>
                      </div>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 shrink-0">
                        {isDateCandidate ? "date" : prof?.type || "text"}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 text-[11px] text-slate-500 flex items-center justify-between">
              <span>
                Only checked columns will be included in the exported file.
              </span>
              <span className="font-mono">
                {selectedColumns.length} selected
              </span>
            </div>
          </div>

          {/* Step 3: Date Range & Row Window Slicer */}
          <div className="lg:col-span-5 p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="flex items-center justify-between pb-2.5 border-b border-slate-200">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#39FF14]" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                    3. Date Range & Row Slicer
                  </span>
                </div>
                {candidateDateColumns.length > 0 && (
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enableDateFilter}
                      onChange={(e) => setEnableDateFilter(e.target.checked)}
                    />
                    <span>Filter by Date</span>
                  </label>
                )}
              </div>

              {candidateDateColumns.length > 0 ? (
                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">
                      Date Filter Column
                    </label>
                    <select
                      value={selectedDateCol}
                      onChange={(e) => setSelectedDateCol(e.target.value)}
                      disabled={!enableDateFilter}
                      className="w-full text-xs font-mono bg-white border border-slate-300 rounded-lg px-2.5 py-2"
                    >
                      {candidateDateColumns.map((c) => (
                        <option key={c} value={c}>
                          {c} ({dateColumnBounds.minDate} →{" "}
                          {dateColumnBounds.maxDate})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] text-slate-500 mb-1">
                        Start Date (From)
                      </label>
                      <input
                        type="date"
                        value={startDate}
                        min={dateColumnBounds.minDate || undefined}
                        max={dateColumnBounds.maxDate || undefined}
                        disabled={!enableDateFilter}
                        onChange={(e) => setStartDate(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] text-slate-500 mb-1">
                        End Date (To)
                      </label>
                      <input
                        type="date"
                        value={endDate}
                        min={dateColumnBounds.minDate || undefined}
                        max={dateColumnBounds.maxDate || undefined}
                        disabled={!enableDateFilter}
                        onChange={(e) => setEndDate(e.target.value)}
                        className="w-full px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                      />
                    </div>
                  </div>

                  {/* Quick Date Range Presets */}
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      disabled={!enableDateFilter}
                      onClick={() => handleApplyDatePreset("all")}
                      className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                    >
                      Full Range
                    </button>
                    <button
                      type="button"
                      disabled={!enableDateFilter}
                      onClick={() => handleApplyDatePreset("last30")}
                      className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                    >
                      Last 30 Days
                    </button>
                    <button
                      type="button"
                      disabled={!enableDateFilter}
                      onClick={() => handleApplyDatePreset("last60")}
                      className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                    >
                      Last 60 Days
                    </button>
                    <button
                      type="button"
                      disabled={!enableDateFilter}
                      onClick={() => handleApplyDatePreset("q4")}
                      className="px-2 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                    >
                      Q4 2026
                    </button>
                  </div>
                </div>
              ) : (
                <div className="p-3 rounded-lg bg-white border border-slate-200 text-xs text-slate-600">
                  No date-typed column was detected in{" "}
                  <strong>{datasetName}</strong>. Use the Row Index Range below
                  to slice records for export.
                </div>
              )}

              {/* Row Index Window Slicer */}
              <div className="pt-2.5 border-t border-slate-200">
                <label className="block text-[11px] text-slate-500 mb-1.5">
                  Row Window Slice (1 to {sourceRows.length})
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <span className="text-[10px] text-slate-400 block">
                      From Row #
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={sourceRows.length}
                      value={startRowIdx}
                      onChange={(e) =>
                        setStartRowIdx(Math.max(1, Number(e.target.value) || 1))
                      }
                      className="w-full px-2.5 py-1 text-xs font-mono bg-white border border-slate-300 rounded"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-400 block">
                      To Row #
                    </span>
                    <input
                      type="number"
                      min={1}
                      max={sourceRows.length}
                      value={endRowIdx}
                      onChange={(e) =>
                        setEndRowIdx(
                          Math.min(
                            sourceRows.length,
                            Math.max(1, Number(e.target.value) || 1)
                          )
                        )
                      }
                      className="w-full px-2.5 py-1 text-xs font-mono bg-white border border-slate-300 rounded"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-200 text-[11px] font-mono text-emerald-700 flex items-center justify-between">
              <span>Matching Export Slice:</span>
              <span>
                {filteredAndProjectedRows.length} of {sourceRows.length} rows
              </span>
            </div>
          </div>
        </div>

        {/* Live Preview of Export Slice */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold uppercase tracking-wider text-slate-500">
              Live Export Slice Preview ({filteredAndProjectedRows.length} Rows
              × {selectedColumns.length} Columns)
            </span>
            <span className="font-mono text-slate-500">
              Format: .{exportFormat === "excel" ? "xlsx" : exportFormat}
            </span>
          </div>

          {selectedColumns.length === 0 ||
          filteredAndProjectedRows.length === 0 ? (
            <div className="p-6 text-center border border-dashed border-slate-300 rounded-lg text-xs text-slate-500">
              {selectedColumns.length === 0
                ? "Select at least 1 column above to preview and export."
                : "No records match the current date range. Expand Start/End dates or click 'Full Range'."}
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-lg max-h-44">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="py-2 px-2.5 font-mono text-slate-500">#</th>
                    {selectedColumns.map((col) => (
                      <th
                        key={col}
                        className="py-2 px-2.5 font-mono font-semibold text-slate-900 whitespace-nowrap"
                      >
                        {col}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {filteredAndProjectedRows.slice(0, 4).map((row, rIdx) => (
                    <tr key={rIdx}>
                      <td className="py-1.5 px-2.5 text-slate-400">
                        {rIdx + 1}
                      </td>
                      {selectedColumns.map((col) => (
                        <td
                          key={col}
                          className="py-1.5 px-2.5 whitespace-nowrap text-slate-800"
                        >
                          {String(row[col] ?? "")}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-slate-500 font-mono">
            Ready to export {filteredAndProjectedRows.length} rows ×{" "}
            {selectedColumns.length} columns as{" "}
            <strong className="text-slate-900 uppercase">
              .{exportFormat === "excel" ? "xlsx" : exportFormat}
            </strong>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 border border-slate-200 rounded-lg cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="button"
              disabled={
                filteredAndProjectedRows.length === 0 ||
                selectedColumns.length === 0
              }
              onClick={handleExecuteExport}
              className="px-5 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg disabled:opacity-40 flex items-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>
                Download{" "}
                {exportFormat === "excel"
                  ? "Excel (.xlsx)"
                  : exportFormat === "json"
                  ? "JSON (.json)"
                  : exportFormat === "parquet"
                  ? "Parquet (.parquet)"
                  : exportFormat.toUpperCase()}{" "}
                ({filteredAndProjectedRows.length} Rows)
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
