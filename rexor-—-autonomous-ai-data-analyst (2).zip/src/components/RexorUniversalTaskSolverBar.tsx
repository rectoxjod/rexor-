/**
 * Rexor — Universal Simple AI Data Editor & Every-Stage Task Problem Solver Bar
 * Gives users a dead-simple, plain-English bar across EVERY stage/task where they can:
 * 1. Make any change to their uploaded CSV/Excel data AND immediately see a
 *    100% Verified "Before -> After" Cell & Row Diff Receipt (with 1-Click Undo & CSV Download).
 * 2. Ask any business, operational, chart, or data question for the current task
 *    in plain English (zero coding required, with optional technical formula toggle).
 *
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

import React, { useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Code2,
  Download,
  Edit3,
  Eye,
  HelpCircle,
  Play,
  RotateCcw,
  Sparkles,
  Table as TableIcon,
  Wrench,
  X,
} from "lucide-react";
import {
  CleaningSummary,
  ColumnProfile,
  CorrelationPair,
  DataRow,
} from "../types/rexor";
import {
  AdaptiveUserRequirement,
  RuleExecutionSummary,
} from "../utils/adaptiveEngine";
import { executeDeterministicTaskAgainstDataset } from "../utils/dataEngine";
import {
  executeIndustryAssignmentDeliverables,
  isMultiTaskIndustryAssignmentPrompt,
} from "../utils/industryAssignmentEngine";

interface RexorUniversalTaskSolverBarProps {
  activeView: string;
  datasetName: string;
  businessQuestion: string;
  rawRows?: DataRow[];
  cleanedRows: DataRow[];
  cleaningSummary: CleaningSummary;
  columnProfiles: ColumnProfile[];
  correlations: CorrelationPair[];
  userRequirements: AdaptiveUserRequirement[];
  adaptiveExecutionSummary: RuleExecutionSummary;
  onApplyInstruction: (instruction: string) => AdaptiveUserRequirement;
  onUndoLastRequirement: () => void;
  onClearAllRequirements: () => void;
  onDownloadCleanedCsv: () => void;
  onNavigateView: (view: any) => void;
}

interface SolverAnswerState {
  question: string;
  plainAnswer: string;
  workaroundSteps: string;
  suggestedEditCommand?: string;
  sqlOrFormula?: string;
  computedColumns?: string[];
  computedRows?: string[][];
  isLoadingAi?: boolean;
  isMultiTaskDeliverable?: boolean;
}

export const RexorUniversalTaskSolverBar: React.FC<
  RexorUniversalTaskSolverBarProps
> = ({
  activeView,
  datasetName,
  businessQuestion,
  rawRows = [],
  cleanedRows,
  cleaningSummary,
  columnProfiles,
  correlations,
  userRequirements,
  adaptiveExecutionSummary,
  onApplyInstruction,
  onUndoLastRequirement,
  onClearAllRequirements,
  onDownloadCleanedCsv,
  onNavigateView,
}) => {
  const [mode, setMode] = useState<"auto" | "edit" | "ask">("auto");
  const [inputText, setInputText] = useState<string>("");
  const [showDiffTable, setShowDiffTable] = useState<boolean>(true);
  const [showCodeDetails, setShowCodeDetails] = useState<boolean>(false);
  const [lastAppliedRule, setLastAppliedRule] =
    useState<AdaptiveUserRequirement | null>(null);
  const [solverAnswer, setSolverAnswer] = useState<SolverAnswerState | null>(
    null
  );

  const numCols = columnProfiles.filter((c) => c.type === "numeric");
  const catCols = columnProfiles.filter((c) => c.type !== "numeric");
  const primaryNum = numCols[numCols.length - 1] || numCols[0];
  const primaryDriver = numCols[0];
  const primaryCat = catCols[0];
  const topCatValue = primaryCat?.topCategories?.[0]?.value || "Paid";

  // Context-aware plain-English quick actions for the current task/stage
  const stageQuickExamples = [
    {
      type: "ask" as const,
      label: `📋 Solve Full 5-Task Industry Assignment (KPIs, 7 Q&A, Dashboard & Report)`,
      prompt: `Execute all 5 official tasks: Task 1 Data Inspection & Cleaning (duplicate Order IDs, missing values, inconsistent categories, unusual quantities/discounts), Task 2 Business KPI Calculations (Total Orders, Gross Sales, Net Revenue, Gross Profit, AOV, Return Rate, On-Time Delivery with formulas), Task 3 Answer all 7 Management Questions, Task 4 Dashboard, and Task 5 Management Report.`,
    },
    {
      type: "edit" as const,
      label: `✏️ Cap ${primaryDriver?.name || "Outliers"} <= ${
        primaryDriver?.q75 ?? 30
      }`,
      prompt: `Cap ${primaryDriver?.name || "Prep_Time_Mins"} at maximum ${
        primaryDriver?.q75 ?? 30
      }`,
    },
    {
      type: "edit" as const,
      label: `✏️ Increase ${primaryNum?.name || "Revenue"} by 10%`,
      prompt: `Increase ${primaryNum?.name || "Net_Revenue"} by 10%`,
    },
    {
      type: "edit" as const,
      label: `✏️ Keep Only "${topCatValue}"`,
      prompt: `Keep only rows where ${primaryCat?.name || "Zone"} is ${topCatValue}`,
    },
    {
      type: "ask" as const,
      label: `💡 Are discounts improving sales or reducing profitability?`,
      prompt: `Are discounts improving sales or reducing profitability? Compare discount brackets and profit margins.`,
    },
  ];

  // Auto-detect whether user is asking to EDIT the spreadsheet vs ASK a question
  const isEditIntent = (text: string): boolean => {
    if (isMultiTaskIndustryAssignmentPrompt(text)) return false;
    if (mode === "edit") return true;
    if (mode === "ask") return false;
    const lower = text.toLowerCase().trim();
    if (
      lower.endsWith("?") ||
      lower.startsWith("why ") ||
      lower.startsWith("what ") ||
      lower.startsWith("how ") ||
      lower.startsWith("which ") ||
      lower.startsWith("who ") ||
      lower.startsWith("explain") ||
      lower.startsWith("compare") ||
      lower.startsWith("summarize") ||
      lower.startsWith("tell me") ||
      lower.startsWith("execute all") ||
      lower.includes("task 1") ||
      lower.includes("task 2")
    ) {
      return false;
    }
    return /^(apply|rule|cap|floor|filter|keep|remove|exclude|delete|drop|replace|change|swap|set|increase|decrease|reduce|boost|raise|lower|add|subtract|impute|fill|clean|canonicalize|flag|mark|create|derive)\b/i.test(
      lower
    );
  };

  const handleRunCommand = async (customText?: string, forceMode?: "edit" | "ask") => {
    const text = (customText ?? inputText).trim();
    if (!text) return;
    if (!customText) setInputText("");

    const treatAsEdit =
      forceMode === "edit"
        ? true
        : forceMode === "ask"
        ? false
        : isEditIntent(text);

    if (treatAsEdit) {
      const cleanRuleText = text.replace(/^(apply|rule|adapt):?\s*/i, "").trim();
      const compiledRule = onApplyInstruction(cleanRuleText);
      setLastAppliedRule(compiledRule);
      setShowDiffTable(true);
      return;
    }

    // Check if the user pasted a multi-task industry assignment prompt or asked about the 7 official KPIs / 7 management questions
    if (
      isMultiTaskIndustryAssignmentPrompt(text) ||
      /are discounts improving sales|highest return rate|most delivery delays|gross sales.*net revenue/i.test(
        text
      )
    ) {
      const deliverable = executeIndustryAssignmentDeliverables(
        rawRows.length > 0 ? rawRows : cleanedRows,
        cleanedRows,
        cleaningSummary,
        columnProfiles,
        datasetName
      );
      const kpiText = deliverable.task2Kpis
        .map((k) => `• ${k.kpiName}: ${k.formattedValue} (${k.mathFormula})`)
        .join("\n");
      const qText = deliverable.task3Questions
        .map((q) => `Q${q.questionNumber}. ${q.question}\n   → ${q.headlineWinner}: ${q.executiveAnswer}`)
        .join("\n\n");

      setSolverAnswer({
        question: text.length > 140 ? `${text.slice(0, 140)}... (Full 5-Task Assignment)` : text,
        plainAnswer: `✅ SOLVED ALL 5 OFFICIAL INDUSTRY DELIVERABLES ON "${datasetName.toUpperCase()}":\n\n` +
          `[TASK 1 — DATA INSPECTION & CLEANING]\n` +
          `• Raw Rows: ${deliverable.task1.rawRowCount} → Eligible Cleaned Orders: ${deliverable.task1.eligibleOrderCount}\n` +
          `• Duplicate Order IDs Removed: ${deliverable.task1.duplicateOrderIdsCount} (${deliverable.task1.duplicateOrderIdsSample.join(", ") || "Deduplicated"})\n` +
          `• Missing Values Imputed: ${deliverable.task1.missingValuesCount} | Data Types Fixed: ${deliverable.task1.incorrectDataTypesCount} | Categories Standardized: ${deliverable.task1.inconsistentCategoriesCount} | Unusual Qty/Discounts Fixed: ${deliverable.task1.unusualQuantitiesAndDiscountsCount}\n\n` +
          `[TASK 2 — OFFICIAL BUSINESS KPI CALCULATIONS]\n${kpiText}\n\n` +
          `[TASK 3 — ANSWERS TO ALL 7 MANAGEMENT QUESTIONS]\n${qText}\n\n` +
          `[TASK 5 — EXECUTIVE MANAGEMENT SUMMARY]\n${deliverable.task5Report.executiveSummary}`,
        workaroundSteps: deliverable.task5Report.threeRecommendations
          .map((r) => `${r.number}. ${r.title}: ${r.actionSteps} (Impact: ${r.quantifiedImpact})`)
          .join("\n\n"),
        suggestedEditCommand: `Cap ${deliverable.columnMapping.discountCol} at maximum 0.15`,
        sqlOrFormula: deliverable.softwareCodePack.sqlScript,
        computedColumns: ["KPI Name", "Calculated Value", "Formula", "Assumption"],
        computedRows: deliverable.task2Kpis.map((k) => [
          k.kpiName,
          k.formattedValue,
          k.mathFormula,
          k.assumptionExplained,
        ]),
        isLoadingAi: false,
        isMultiTaskDeliverable: true,
      });
      setShowCodeDetails(true);
      return;
    }

    // Otherwise, solve as a plain-English Business / Task Question
    const det = executeDeterministicTaskAgainstDataset({
      rows: cleanedRows,
      columnProfiles,
      correlations,
      datasetName,
      taskPrompt: text,
    });

    const suggestedCmd =
      primaryDriver && primaryNum
        ? `Cap ${primaryDriver.name} at maximum ${
            primaryDriver.q75 ?? primaryDriver.mean ?? 30
          }`
        : undefined;

    setSolverAnswer({
      question: text,
      plainAnswer: det.directAnswer,
      workaroundSteps: `1. Focus on your top statistical lever (${
        correlations[0]
          ? `${correlations[0].colA} ↔ ${correlations[0].colB}, r = ${correlations[0].r}`
          : primaryDriver?.name || "Primary Driver"
      }).\n2. Compare top vs. bottom cohorts in the table below to reallocate resources.\n3. Click "Apply Suggested Fix to My Data" below if you want Rexor to update the spreadsheet automatically.`,
      suggestedEditCommand: suggestedCmd,
      sqlOrFormula: det.sqlQuery,
      computedColumns: det.outputColumns,
      computedRows: det.outputRows.slice(0, 6),
      isLoadingAi: true,
    });

    try {
      const res = await fetch("/api/rexor/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: [],
          activeView,
          datasetName,
          businessQuestion,
          cleaningSummary,
          columns: columnProfiles,
          topCorrelations: correlations.slice(0, 5),
          deterministicResult: {
            taskTitle: det.taskTitle,
            directAnswer: det.directAnswer,
            outputColumns: det.outputColumns,
            outputRows: det.outputRows.slice(0, 6),
          },
          sampleRows: cleanedRows.slice(0, 4),
        }),
      });
      if (res.ok) {
        const aiData = await res.json();
        if (aiData?.reply) {
          setSolverAnswer((prev) =>
            prev
              ? {
                  ...prev,
                  isLoadingAi: false,
                  plainAnswer: `${det.directAnswer}\n\n${aiData.reply}`,
                  workaroundSteps:
                    aiData.workaroundStrategy || prev.workaroundSteps,
                  suggestedEditCommand:
                    aiData.executableRuleCommand || prev.suggestedEditCommand,
                  sqlOrFormula: aiData.customSqlOrFormula || prev.sqlOrFormula,
                }
              : null
          );
          return;
        }
      }
    } catch {
      // Keep instant deterministic plain-English answer if offline
    }
    setSolverAnswer((prev) => (prev ? { ...prev, isLoadingAi: false } : null));
  };

  const activeRulesCount = userRequirements.filter((r) => r.enabled).length;
  const recentDiffs = adaptiveExecutionSummary.cellDiffs || [];

  return (
    <section className="bg-white border-2 border-blue-600 rounded-xl p-4 sm:p-5 space-y-4 shadow-sm">
      {/* Top Header & Simple Mode Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
        <div className="space-y-0.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded bg-blue-600 text-white">
              SIMPLE AI DATA EDITOR & TASK SOLVER
            </span>
            <span className="text-xs font-mono text-slate-500">
              Active File: <strong>{datasetName}</strong> (
              {cleaningSummary.cleanedRowCount} rows)
            </span>
            {activeRulesCount > 0 && (
              <span className="px-2 py-0.5 text-[11px] font-mono font-semibold rounded bg-emerald-50 text-emerald-700 border border-emerald-300">
                ✓ {activeRulesCount} Custom Change
                {activeRulesCount > 1 ? "s" : ""} Applied (
                {adaptiveExecutionSummary.totalCellsModified} cells/rows updated)
              </span>
            )}
          </div>
          <h2 className="text-sm sm:text-base font-bold text-slate-900">
            Want to change something in your Excel/CSV or ask a business question? Type it in plain English:
          </h2>
        </div>

        {/* Simple 3-Button Intent Selector */}
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg self-start lg:self-auto shrink-0">
          <button
            type="button"
            onClick={() => setMode("auto")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              mode === "auto"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            ✨ Auto-Detect
          </button>
          <button
            type="button"
            onClick={() => setMode("edit")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 cursor-pointer ${
              mode === "edit"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <Edit3 className="w-3 h-3" />
            <span>Edit My Data</span>
          </button>
          <button
            type="button"
            onClick={() => setMode("ask")}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 cursor-pointer ${
              mode === "ask"
                ? "bg-blue-600 text-white"
                : "text-slate-600 hover:text-slate-900"
            }`}
          >
            <HelpCircle className="w-3 h-3" />
            <span>Ask Question</span>
          </button>
        </div>
      </div>

      {/* Main Plain-English Input Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleRunCommand();
        }}
        className="flex flex-col sm:flex-row gap-2"
      >
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={
            mode === "edit"
              ? `e.g., "Increase ${primaryNum?.name || "price"} by 10%", "Keep only ${topCatValue}", or "Replace Pending with Paid"...`
              : mode === "ask"
              ? `e.g., "Why is ${primaryNum?.name || "revenue"} dropping and what should we do first?"...`
              : `Type any change (e.g. "Increase ${primaryNum?.name || "revenue"} by 10%", "Cap ${primaryDriver?.name || "prep time"} at 30") OR any business question...`
          }
          className="flex-1 px-4 py-2.5 text-xs sm:text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:bg-white focus:border-blue-600"
        />
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="submit"
            disabled={!inputText.trim()}
            className="px-4 py-2.5 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>
              {mode === "edit"
                ? "Apply Change to Data"
                : mode === "ask"
                ? "Solve Question"
                : "Run / Solve Now"}
            </span>
          </button>
          {activeRulesCount > 0 && (
            <button
              type="button"
              onClick={() => {
                onUndoLastRequirement();
                setLastAppliedRule(null);
              }}
              title="Undo the most recent change applied to your dataset"
              className="px-3 py-2.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg flex items-center gap-1 cursor-pointer whitespace-nowrap"
            >
              <RotateCcw className="w-3.5 h-3.5 shrink-0" />
              <span>Undo Last Change</span>
            </button>
          )}
        </div>
      </form>

      {/* 1-Click Everyday Examples (Edit Data + Ask Business Questions) */}
      <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
        <span className="text-[11px] font-medium text-slate-500 mr-1">
          1-Click Try:
        </span>
        {stageQuickExamples.map((ex, i) => (
          <button
            key={i}
            type="button"
            onClick={() => handleRunCommand(ex.prompt, ex.type)}
            className="px-2.5 py-1 text-[11px] font-medium bg-slate-50 hover:bg-blue-50 text-slate-700 hover:text-blue-700 border border-slate-200 rounded-md transition-colors cursor-pointer"
          >
            {ex.label}
          </button>
        ))}
      </div>

      {/* =====================================================================
          100% VERIFIED CHANGE RECEIPT (PROVES EXACTLY WHAT CHANGED IN THE DATA)
         ===================================================================== */}
      {activeRulesCount > 0 && (
        <div className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-300 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-start sm:items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5 sm:mt-0" />
              <div>
                <div className="text-xs sm:text-sm font-bold text-slate-900">
                  ✅ Data Change Verified! Your Excel/CSV Pipeline Was Updated:
                </div>
                <div className="text-xs text-slate-600 font-mono mt-0.5">
                  Rows Before: {adaptiveExecutionSummary.totalRowsBefore} → Rows
                  Now:{" "}
                  <strong className="text-emerald-700">
                    {adaptiveExecutionSummary.totalRowsAfter}
                  </strong>{" "}
                  · Total Cells/Rows Modified:{" "}
                  <strong className="text-emerald-700">
                    {adaptiveExecutionSummary.totalCellsModified}
                  </strong>
                  {adaptiveExecutionSummary.newColumnsCreated.length > 0 &&
                    ` · New Columns Added: ${adaptiveExecutionSummary.newColumnsCreated.join(
                      ", "
                    )}`}
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setShowDiffTable((prev) => !prev)}
                className="px-2.5 py-1.5 text-xs font-semibold bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <Eye className="w-3.5 h-3.5 text-blue-600" />
                <span>
                  {showDiffTable
                    ? "Hide Before/After Proof ▲"
                    : `Show Exact Changes (${recentDiffs.length}) ▼`}
                </span>
              </button>
              <button
                type="button"
                onClick={() => onNavigateView("cleaning")}
                className="px-2.5 py-1.5 text-xs font-semibold bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <TableIcon className="w-3.5 h-3.5 text-blue-600" />
                <span>View Full Table</span>
              </button>
              <button
                type="button"
                onClick={onDownloadCleanedCsv}
                className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-1 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Updated CSV</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  onClearAllRequirements();
                  setLastAppliedRule(null);
                }}
                className="px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 border border-red-200 rounded-lg cursor-pointer"
              >
                Reset All Custom Edits
              </button>
            </div>
          </div>

          {/* Active Rules Pills */}
          <div className="flex flex-wrap items-center gap-1.5">
            {userRequirements
              .filter((r) => r.enabled)
              .map((req) => (
                <span
                  key={req.id}
                  className="px-2.5 py-1 text-[11px] font-mono bg-white border border-emerald-300 rounded-md text-slate-800"
                >
                  <strong>{req.title}</strong> —{" "}
                  {adaptiveExecutionSummary.perRuleImpact[req.id]?.description ||
                    "Active"}
                </span>
              ))}
          </div>

          {/* Before -> After Cell Proof Table */}
          {showDiffTable && recentDiffs.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
              <div className="px-3 py-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between text-xs font-semibold text-slate-700">
                <span>
                  Live Before → After Proof (Showing {recentDiffs.length} sample
                  modified cells/rows)
                </span>
                {lastAppliedRule && (
                  <span className="font-mono text-[11px] text-blue-600">
                    Latest Rule: {lastAppliedRule.title}
                  </span>
                )}
              </div>
              <div className="overflow-x-auto max-h-48">
                <table className="w-full text-left border-collapse text-xs font-mono tabular-nums">
                  <thead>
                    <tr className="border-b border-slate-200 bg-slate-50/60 text-slate-500">
                      <th className="py-1.5 px-3">Row #</th>
                      <th className="py-1.5 px-3">Column Changed</th>
                      <th className="py-1.5 px-3">Before (Old Value)</th>
                      <th className="py-1.5 px-3">After (New Value in File)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {recentDiffs.slice(0, 12).map((diff, idx) => (
                      <tr key={idx} className="hover:bg-slate-50">
                        <td className="py-1.5 px-3 text-slate-500">
                          Row {diff.rowNumber}
                        </td>
                        <td className="py-1.5 px-3 font-semibold text-slate-900">
                          {diff.column}
                        </td>
                        <td className="py-1.5 px-3 text-red-600 line-through">
                          {diff.beforeValue}
                        </td>
                        <td className="py-1.5 px-3 text-emerald-700 font-bold">
                          → {diff.afterValue}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          PLAIN-ENGLISH BUSINESS & TASK SOLUTION CARD (ZERO CODE CLUTTER)
         ===================================================================== */}
      {solverAnswer && (
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-0.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded bg-blue-600 text-white">
                  PLAIN-ENGLISH SOLUTION & WORKAROUND
                </span>
                {solverAnswer.isLoadingAi && (
                  <span className="text-xs font-mono text-blue-600 animate-pulse">
                    Enriching with Gemini Strategy...
                  </span>
                )}
              </div>
              <h3 className="text-sm font-bold text-slate-900">
                Q: &ldquo;{solverAnswer.question}&rdquo;
              </h3>
            </div>
            <button
              type="button"
              onClick={() => setSolverAnswer(null)}
              className="p-1 text-slate-400 hover:text-slate-700 rounded cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="text-xs sm:text-sm text-slate-800 leading-relaxed whitespace-pre-line bg-white p-3.5 rounded-lg border border-slate-200">
            {solverAnswer.plainAnswer}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-stretch">
            {/* Step-by-Step Business & Data Workaround */}
            <div className="lg:col-span-7 p-3.5 rounded-lg bg-white border border-blue-200 space-y-1.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-blue-700">
                <Wrench className="w-3.5 h-3.5" />
                <span>Recommended Business & Data Workaround</span>
              </div>
              <div className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                {solverAnswer.workaroundSteps}
              </div>
            </div>

            {/* 1-Click Apply Suggested Fix to Dataset */}
            <div className="lg:col-span-5 p-3.5 rounded-lg bg-white border border-emerald-200 flex flex-col justify-between gap-2">
              <div>
                <div className="text-xs font-bold text-emerald-700">
                  Want Rexor to apply a fix to your data automatically?
                </div>
                <p className="text-[11px] text-slate-600 mt-0.5 font-mono">
                  Rule:{" "}
                  {solverAnswer.suggestedEditCommand ||
                    `Cap ${primaryDriver?.name} outliers`}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                {solverAnswer.isMultiTaskDeliverable && (
                  <button
                    type="button"
                    onClick={() => onNavigateView("industry-assignment")}
                    className="px-3 py-1.5 text-xs font-semibold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                    <span>Open Full 5-Task Deliverable Studio & Dashboard</span>
                  </button>
                )}
                {solverAnswer.suggestedEditCommand && (
                  <button
                    type="button"
                    onClick={() =>
                      handleRunCommand(
                        solverAnswer.suggestedEditCommand!,
                        "edit"
                      )
                    }
                    className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
                  >
                    <Play className="w-3 h-3" />
                    <span>Apply This Fix to My Data Now</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => setShowCodeDetails((prev) => !prev)}
                  className="px-2.5 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1 cursor-pointer"
                >
                  <Code2 className="w-3.5 h-3.5" />
                  <span>
                    {showCodeDetails
                      ? "Hide Table & SQL"
                      : "Show Numbers Table & SQL"}
                  </span>
                </button>
              </div>
            </div>
          </div>

          {/* Optional Technical Table & SQL Toggle (Hidden by default so non-coders aren't overwhelmed) */}
          {showCodeDetails && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 pt-1">
              {solverAnswer.computedColumns &&
                solverAnswer.computedRows &&
                solverAnswer.computedRows.length > 0 && (
                  <div className="bg-white border border-slate-200 rounded-lg overflow-x-auto">
                    <table className="w-full text-left border-collapse text-[11px] font-mono tabular-nums">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200 text-slate-600">
                          {solverAnswer.computedColumns
                            .slice(0, 5)
                            .map((col, i) => (
                              <th key={i} className="py-1.5 px-2.5">
                                {col}
                              </th>
                            ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {solverAnswer.computedRows.map((row, rIdx) => (
                          <tr key={rIdx}>
                            {row.slice(0, 5).map((cell, cIdx) => (
                              <td key={cIdx} className="py-1.5 px-2.5">
                                {cell}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              {solverAnswer.sqlOrFormula && (
                <pre className="bg-slate-900 text-blue-100 p-3 rounded-lg text-[11px] font-mono overflow-x-auto leading-relaxed">
                  {solverAnswer.sqlOrFormula}
                </pre>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
};
