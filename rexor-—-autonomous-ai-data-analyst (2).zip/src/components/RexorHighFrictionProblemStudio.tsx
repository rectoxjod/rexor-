import React, { useState, useMemo } from "react";
import {
  Utensils,
  PackageSearch,
  Wallet,
  Stethoscope,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  CloudRain,
  Sun,
  Flame,
  Calendar,
  Play,
  FileSpreadsheet,
  Sliders,
  ShieldCheck,
  Zap,
  Compass,
  PhoneCall,
  MessageSquare,
  RefreshCw,
} from "lucide-react";
import {
  HIGH_FRICTION_PROBLEMS,
  SELECTION_DECISION_MATRIX,
  HighFrictionProblemId,
  HighFrictionProblemSpec,
  simulateProblem1CloudKitchen,
  simulateProblem2DeadCapital,
  simulateProblem3CashFlow,
  simulateProblem4ClinicNoShows,
} from "../utils/highFrictionProblemsEngine";

interface RexorHighFrictionProblemStudioProps {
  onLoadProblemDataset: (problem: HighFrictionProblemSpec) => void;
  onOpenBiStudio?: () => void;
}

export const RexorHighFrictionProblemStudio: React.FC<RexorHighFrictionProblemStudioProps> = ({
  onLoadProblemDataset,
  onOpenBiStudio,
}) => {
  const [selectedProblemId, setSelectedProblemId] = useState<HighFrictionProblemId>(
    "problem-1-cloud-kitchen"
  );

  // Problem 1 Interactive Controls
  const [p1Weather, setP1Weather] = useState<"Monsoon Rain" | "Clear" | "Heatwave">("Monsoon Rain");
  const [p1DayType, setP1DayType] = useState<"Weekday" | "Weekend" | "Festival / Holiday">("Weekend");
  const [disputedTicketIds, setDisputedTicketIds] = useState<string[]>([]);

  // Problem 2 Interactive Controls
  const [p2HoldingCostPct, setP2HoldingCostPct] = useState<number>(24);
  const [appliedMarkdownSkus, setAppliedMarkdownSkus] = useState<string[]>([]);

  // Problem 3 Interactive Controls
  const [p3ClientDelayDays, setP3ClientDelayDays] = useState<number>(45);
  const [cancelledVendorIds, setCancelledVendorIds] = useState<string[]>([]);

  // Problem 4 Interactive Controls
  const [escalatedApptIds, setEscalatedApptIds] = useState<string[]>([]);
  const [autoFilledApptIds, setAutoFilledApptIds] = useState<string[]>([]);

  const [loadedDatasetBanner, setLoadedDatasetBanner] = useState<string | null>(null);

  const activeProblem = useMemo(
    () =>
      HIGH_FRICTION_PROBLEMS.find((p) => p.id === selectedProblemId) || HIGH_FRICTION_PROBLEMS[0],
    [selectedProblemId]
  );

  const p1Sim = useMemo(
    () => simulateProblem1CloudKitchen(p1Weather, p1DayType),
    [p1Weather, p1DayType]
  );
  const p2Sim = useMemo(
    () => simulateProblem2DeadCapital(p2HoldingCostPct),
    [p2HoldingCostPct]
  );
  const p3Sim = useMemo(
    () => simulateProblem3CashFlow(p3ClientDelayDays),
    [p3ClientDelayDays]
  );
  const p4Sim = useMemo(() => simulateProblem4ClinicNoShows(), []);

  const getProblemIcon = (id: HighFrictionProblemId) => {
    switch (id) {
      case "problem-1-cloud-kitchen":
        return <Utensils className="w-5 h-5" />;
      case "problem-2-dead-capital":
        return <PackageSearch className="w-5 h-5" />;
      case "problem-3-cashflow-leaks":
        return <Wallet className="w-5 h-5" />;
      case "problem-4-clinic-noshows":
        return <Stethoscope className="w-5 h-5" />;
    }
  };

  const handleLoadIntoPipeline = (problem: HighFrictionProblemSpec) => {
    onLoadProblemDataset(problem);
    setLoadedDatasetBanner(
      `Loaded "${problem.shortTitle}" messy dataset + business problem framing into Rexor's 6-Stage Pipeline!`
    );
    setTimeout(() => setLoadedDatasetBanner(null), 5000);
  };

  return (
    <section className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
      {/* Header Banner */}
      <div className="p-6 border-b border-slate-800 bg-gradient-to-r from-indigo-950/60 via-slate-900 to-emerald-950/30">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 text-xs font-semibold">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              HIGH-FRICTION, URGENT ROI AUTONOMOUS DATA AGENTS
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              4 High-Impact Operational Problem Agents & Decision Matrix
            </h2>
            <p className="text-sm text-slate-400 max-w-3xl">
              Built for operators who lack time or technical staff to write SQL or build dashboards
              when data is messy and decisions are urgent. Test each live domain agent below or load
              its raw messy dataset directly into Rexor&apos;s 6-stage deterministic sandbox.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={() => handleLoadIntoPipeline(activeProblem)}
              className="px-4 py-2.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4" />
              Load {activeProblem.numberLabel} Messy Data into 6-Stage Pipeline
            </button>
            {onOpenBiStudio && (
              <button
                onClick={onOpenBiStudio}
                className="px-3.5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-amber-400" />
                Open in 108 BI Studio
              </button>
            )}
          </div>
        </div>

        {loadedDatasetBanner && (
          <div className="mt-4 p-3 rounded-lg bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-between gap-3 text-xs text-emerald-200">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span className="font-medium">{loadedDatasetBanner}</span>
            </div>
            <span className="text-[11px] text-emerald-300/80">
              All 6 pipeline stages updated automatically
            </span>
          </div>
        )}
      </div>

      {/* How to Select the Right One — Interactive Decision Matrix */}
      <div className="p-5 bg-slate-950/60 border-b border-slate-800">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-indigo-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
              How to Select the Right Problem Agent (Strategic Decision Matrix)
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            Click any strategic priority to launch that autonomous agent
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3">
          {SELECTION_DECISION_MATRIX.map((item) => {
            const isSelected = selectedProblemId === item.bestFitId;
            return (
              <button
                key={item.criterion}
                onClick={() => setSelectedProblemId(item.bestFitId)}
                className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer flex flex-col justify-between ${
                  isSelected
                    ? "bg-indigo-950/50 border-indigo-500/60 ring-1 ring-indigo-500/30"
                    : "bg-slate-900/90 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-400">
                      {item.criterion}
                    </span>
                  </div>
                  <div className="text-sm font-bold text-white mb-1">{item.bestFitLabel}</div>
                  <p className="text-xs text-slate-400 leading-relaxed">{item.rationale}</p>
                </div>
                <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Click to activate workbench</span>
                  <span className="text-indigo-400 font-semibold flex items-center gap-1 shrink-0">
                    {isSelected ? "Active" : "Inspect"}
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* 4 Problem Selector Tabs */}
      <div className="px-5 pt-4 border-b border-slate-800 bg-slate-900/60 flex flex-wrap gap-2">
        {HIGH_FRICTION_PROBLEMS.map((problem) => {
          const active = problem.id === selectedProblemId;
          return (
            <button
              key={problem.id}
              onClick={() => setSelectedProblemId(problem.id)}
              className={`px-4 py-3 rounded-t-xl text-xs font-semibold flex items-center gap-2.5 border-t border-x transition-all cursor-pointer ${
                active
                  ? "bg-slate-900 text-white border-slate-700 border-b-transparent -mb-px shadow-sm"
                  : "bg-slate-950/60 text-slate-400 border-slate-800/70 hover:text-slate-200 hover:bg-slate-900/40"
              }`}
            >
              <span
                className={`p-1.5 rounded-lg ${
                  active ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-400"
                }`}
              >
                {getProblemIcon(problem.id)}
              </span>
              <div className="text-left">
                <div className="text-[10px] uppercase tracking-wider text-indigo-400 font-bold">
                  {problem.numberLabel} • {problem.selectionCriterionBadge}
                </div>
                <div className="text-xs font-bold text-slate-100">{problem.shortTitle}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Active Problem Blueprint & Interactive Workbench */}
      <div className="p-6 space-y-6">
        {/* Top Problem Framing Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Context & Problem Statement */}
          <div className="lg:col-span-5 bg-slate-950/70 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between gap-2 flex-wrap">
                <span className="px-2.5 py-1 rounded-md bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-semibold">
                  {activeProblem.numberLabel}: High-Friction Operational Pain
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {activeProblem.industryBadge}
                </span>
              </div>
              <h3 className="text-lg font-bold text-white leading-snug">{activeProblem.title}</h3>
              <div className="space-y-1">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-400">
                  Context & Pain Point
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {activeProblem.contextAndPainPoint}
                </p>
              </div>
              <div className="p-3.5 rounded-lg bg-indigo-950/40 border border-indigo-500/30 space-y-1">
                <div className="text-[11px] font-semibold uppercase tracking-wider text-indigo-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                  The Problem Statement
                </div>
                <p className="text-xs text-indigo-100 italic leading-relaxed">
                  &ldquo;{activeProblem.problemStatement}&rdquo;
                </p>
              </div>
            </div>

            {/* Primary Metrics to Move */}
            <div className="pt-3 border-t border-slate-800/80">
              <div className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400 mb-2">
                Primary Metrics to Move (Direct Business ROI)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {activeProblem.primaryMetricsToMove.map((metricText, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-lg bg-emerald-950/25 border border-emerald-500/30 flex items-start gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div className="text-xs font-semibold text-white leading-snug">
                      {metricText}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* What Your Agent Does (3 Pillars) */}
          <div className="lg:col-span-7 bg-slate-950/70 border border-slate-800 rounded-xl p-5 flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                <div className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4" />
                  What Your Autonomous Agent Does (3 Deterministic Pillars)
                </div>
                <span className="text-[11px] text-slate-400">
                  Zero Math Hallucinations • Sandboxed Execution
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
                {activeProblem.whatAgentDoes.map((cap, idx) => (
                  <div
                    key={cap.capability}
                    className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between space-y-3"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="w-6 h-6 rounded-md bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 text-xs font-bold flex items-center justify-center">
                          0{idx + 1}
                        </span>
                        <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">
                          Active Module
                        </span>
                      </div>
                      <h4 className="text-sm font-bold text-white">{cap.capability}</h4>
                      <p className="text-xs text-slate-300 leading-relaxed">{cap.detail}</p>
                    </div>
                    <div className="pt-2.5 border-t border-slate-800 text-[11px] text-slate-400 font-mono">
                      Dataset: {activeProblem.datasetName}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Bottom Action Bar inside Pillars Card */}
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="text-xs font-semibold text-white">
                  Want to run SQL, Python Sandbox, or 108 BI Visuals on {activeProblem.numberLabel}
                  &apos;s messy dataset?
                </div>
                <div className="text-[11px] text-slate-400">
                  Includes intentional duplicate IDs, ₹ currency symbols, and high-friction
                  operational anomalies for Pre-Flight Hygiene checks.
                </div>
              </div>
              <button
                onClick={() => handleLoadIntoPipeline(activeProblem)}
                className="px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold shrink-0 flex items-center gap-1.5 cursor-pointer transition-colors"
              >
                <Play className="w-3.5 h-3.5" />
                Load Dataset into Pipeline
              </button>
            </div>
          </div>
        </div>

        {/* =====================================================================
            LIVE INTERACTIVE AGENT WORKBENCH PER PROBLEM
        ===================================================================== */}
        {selectedProblemId === "problem-1-cloud-kitchen" && (
          <div className="space-y-5">
            {/* Problem 1 Controls & KPI Strip */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  External Prep Forecast Inputs:
                </div>
                {/* Weather Toggle */}
                <div className="flex items-center bg-slate-900 p-1 rounded-lg border border-slate-800">
                  {(["Monsoon Rain", "Clear", "Heatwave"] as const).map((w) => (
                    <button
                      key={w}
                      onClick={() => setP1Weather(w)}
                      className={`px-2.5 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
                        p1Weather === w
                          ? "bg-indigo-600 text-white"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      {w === "Monsoon Rain" && <CloudRain className="w-3.5 h-3.5" />}
                      {w === "Clear" && <Sun className="w-3.5 h-3.5" />}
                      {w === "Heatwave" && <Flame className="w-3.5 h-3.5" />}
                      {w}
                    </button>
                  ))}
                </div>
                {/* Day Type Toggle */}
                <div className="flex items-center bg-slate-900 p-1 rounded-lg border border-slate-800">
                  {(["Weekday", "Weekend", "Festival / Holiday"] as const).map((d) => (
                    <button
                      key={d}
                      onClick={() => setP1DayType(d)}
                      className={`px-2.5 py-1 rounded-md text-xs font-medium flex items-center gap-1.5 transition-colors cursor-pointer ${
                        p1DayType === d
                          ? "bg-emerald-600 text-white"
                          : "text-slate-400 hover:text-slate-200"
                      }`}
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      {d}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs">
                <div className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30">
                  <span className="text-slate-400">Daily Waste Saved: </span>
                  <span className="font-bold text-emerald-400">
                    ₹{p1Sim.totalDailyWasteSavedInr.toLocaleString()}/day
                  </span>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-amber-950/40 border border-amber-500/30">
                  <span className="text-slate-400">Recoverable Aggregator Leakage: </span>
                  <span className="font-bold text-amber-400">
                    ₹{p1Sim.totalWeeklyAggregatorRecoveryInr.toLocaleString()}/wk
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
              {/* Pillar 1: Daily Prep Sizing Table */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                    1. Daily Perishable Prep Sizing ({p1Weather} • {p1DayType})
                  </h4>
                  <span className="text-[11px] text-emerald-400 font-semibold">
                    15–25% Waste Cut
                  </span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[11px]">
                        <th className="py-2 pr-2">Perishable Batch</th>
                        <th className="py-2 px-2">Static Prep</th>
                        <th className="py-2 px-2">Rexor Batch</th>
                        <th className="py-2 pl-2 text-right">Saved</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60">
                      {p1Sim.prepItems.map((row) => (
                        <tr key={row.item} className="hover:bg-slate-900/50">
                          <td className="py-2.5 pr-2 font-medium text-slate-200">
                            <div>{row.item}</div>
                            <div className="text-[10px] text-slate-400">
                              Shelf life: {row.shelfLifeHrs}h • {row.weatherSensitivity}
                            </div>
                          </td>
                          <td className="py-2.5 px-2 text-slate-400">
                            {row.manualStaticPrepKg} kg
                          </td>
                          <td className="py-2.5 px-2 font-bold text-indigo-300">
                            {row.aiRecommendedKg} kg
                          </td>
                          <td className="py-2.5 pl-2 text-right font-semibold text-emerald-400">
                            ₹{row.dailySavingsInr.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Pillar 2: Aggregator Deduction Audit */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    2. Aggregator Payout vs POS Ticket Audit
                  </h4>
                  <span className="text-[11px] text-amber-300 font-semibold">
                    {disputedTicketIds.length}/{p1Sim.aggregatorDisputes.length} Disputed
                  </span>
                </div>
                <div className="space-y-2.5">
                  {p1Sim.aggregatorDisputes.map((audit) => {
                    const isDisputed = disputedTicketIds.includes(audit.ticketId);
                    return (
                      <div
                        key={audit.ticketId}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">
                            {audit.platform} •{" "}
                            <span className="font-mono text-indigo-300">{audit.ticketId}</span>
                          </span>
                          <span className="text-xs font-extrabold text-rose-400">
                            -₹{audit.leakageInr.toLocaleString()} leak
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-300">{audit.discrepancyType}</p>
                        <div className="flex items-center justify-between pt-1 gap-2">
                          <span className="text-[10px] text-slate-400">{audit.autoAction}</span>
                          <button
                            onClick={() =>
                              setDisputedTicketIds((prev) =>
                                prev.includes(audit.ticketId)
                                  ? prev.filter((id) => id !== audit.ticketId)
                                  : [...prev, audit.ticketId]
                              )
                            }
                            className={`px-2.5 py-1 rounded text-[10px] font-semibold cursor-pointer transition-colors shrink-0 ${
                              isDisputed
                                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                                : "bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40"
                            }`}
                          >
                            {isDisputed ? "✓ Claim Queued" : "Auto-Draft Claim"}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Pillar 3: Ingredient Inflation Tracker */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400">
                    3. Supplier Ingredient Inflation & Dish Margin
                  </h4>
                  <span className="text-[11px] text-rose-300 font-semibold">
                    {p1Sim.ingredientAlerts.length} Dishes Below Target
                  </span>
                </div>
                <div className="space-y-2.5">
                  {p1Sim.ingredientAlerts.map((ing) => (
                    <div
                      key={ing.impactedDish}
                      className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{ing.impactedDish}</span>
                        <span className="px-2 py-0.5 rounded bg-rose-500/15 border border-rose-500/30 text-rose-300 text-[10px] font-bold">
                          +{ing.inflationPct}% Cost Spike
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {ing.ingredient}: ₹{ing.prevWeekCostInr} →{" "}
                        <span className="text-rose-300 font-semibold">
                          ₹{ing.currWeekCostInr}
                        </span>{" "}
                        • Margin dipped to{" "}
                        <span className="text-amber-300 font-bold">{ing.newMarginPct}%</span>{" "}
                        (Target {ing.targetMarginPct}%)
                      </div>
                      <div className="text-[11px] text-emerald-300 bg-emerald-950/30 border border-emerald-500/20 px-2.5 py-1 rounded">
                        Action: {ing.prescribedFix}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedProblemId === "problem-2-dead-capital" && (
          <div className="space-y-5">
            {/* Problem 2 Controls & KPI Strip */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  Annualized Warehouse Carrying & Depreciation Rate:
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={12}
                    max={36}
                    step={2}
                    value={p2HoldingCostPct}
                    onChange={(e) => setP2HoldingCostPct(Number(e.target.value))}
                    className="w-36 accent-indigo-500 cursor-pointer"
                  />
                  <span className="px-2.5 py-1 rounded bg-indigo-500/20 border border-indigo-500/40 text-indigo-300 font-mono text-xs font-bold">
                    {p2HoldingCostPct}% / yr
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 text-xs">
                <div className="px-3 py-1.5 rounded-lg bg-rose-950/40 border border-rose-500/30">
                  <span className="text-slate-400">Frozen Dead Capital: </span>
                  <span className="font-bold text-rose-400">
                    ₹{p2Sim.totalBlockedCapitalInr.toLocaleString()}
                  </span>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30">
                  <span className="text-slate-400">Working Capital Released (30d): </span>
                  <span className="font-bold text-emerald-400">
                    ₹{p2Sim.totalCapitalFreed30dInr.toLocaleString()}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
              {/* Velocity Anomaly & Graduated Markdown Table */}
              <div className="xl:col-span-7 bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                    1 & 2. 21-Day Velocity Anomaly Detection & Graduated Markdowns
                  </h4>
                  <span className="text-[11px] text-emerald-400 font-semibold">
                    Preserves Brand Margin vs Flat Clearance
                  </span>
                </div>
                <div className="space-y-2.5">
                  {p2Sim.skus
                    .filter((s) => s.status === "DEAD CAPITAL (LIQUIDATE)")
                    .map((c) => {
                      const isApplied = appliedMarkdownSkus.includes(c.sku);
                      return (
                        <div
                          key={c.sku}
                          className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-mono text-xs font-bold text-indigo-300">
                                {c.sku}
                              </span>
                              <span className="text-xs font-bold text-white">{c.name}</span>
                              <span className="px-2 py-0.5 rounded bg-rose-500/15 text-rose-300 text-[10px] font-semibold">
                                -{c.velocityDrop21dPct}% Velocity Drop (21d)
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {c.units} units • Age: {c.daysAged}d • Blocked Capital:{" "}
                              <span className="text-white font-semibold">
                                ₹{c.blockedCapitalInr.toLocaleString()}
                              </span>{" "}
                              • Carrying Fee: ₹{c.monthlyCarryingFeeInr.toLocaleString()}/mo
                            </div>
                            <div className="text-[11px] text-emerald-300 font-medium">
                              Prescription: {c.graduatedPlan}
                            </div>
                          </div>
                          <button
                            onClick={() =>
                              setAppliedMarkdownSkus((prev) =>
                                prev.includes(c.sku)
                                  ? prev.filter((s) => s !== c.sku)
                                  : [...prev, c.sku]
                              )
                            }
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 cursor-pointer transition-colors ${
                              isApplied
                                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                                : "bg-indigo-600 hover:bg-indigo-500 text-white"
                            }`}
                          >
                            {isApplied
                              ? "✓ Markdown Synced to Shopify"
                              : `Apply ${c.recommendedDiscountPct}% Graduated Tier`}
                          </button>
                        </div>
                      );
                    })}
                </div>
              </div>

              {/* Stockout Early Warning on High-Margin Anchor SKUs */}
              <div className="xl:col-span-5 bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    3. High-Margin Anchor SKU Stockout Early Warning
                  </h4>
                  <span className="text-[11px] text-rose-400 font-semibold">
                    Lead-Time vs Stock Left
                  </span>
                </div>
                <div className="space-y-3">
                  {p2Sim.skus
                    .filter((s) => s.status === "STOCKOUT ALERT (ANCHOR SKU)")
                    .map((w) => (
                      <div
                        key={w.sku}
                        className="p-3.5 rounded-lg bg-slate-900 border border-amber-500/30 space-y-2"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">
                            {w.sku} • {w.name}
                          </span>
                          <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold">
                            {w.status}
                          </span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-950 p-2.5 rounded border border-slate-800">
                          <div>
                            <span className="text-slate-400">Stock Left: </span>
                            <span className="font-bold text-rose-400">
                              {w.daysOfInventoryLeft} Days ({w.units} units)
                            </span>
                          </div>
                          <div>
                            <span className="text-slate-400">Supplier Lead: </span>
                            <span className="font-bold text-amber-300">
                              {w.leadTimeDays} Days
                            </span>
                          </div>
                        </div>
                        <div className="text-[11px] text-indigo-300 font-medium">
                          {w.graduatedPlan}
                        </div>
                      </div>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedProblemId === "problem-3-cashflow-leaks" && (
          <div className="space-y-5">
            {/* Problem 3 Controls & KPI Strip */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-300">
                  <Sliders className="w-4 h-4 text-indigo-400" />
                  Runway Simulation — What if Anchor Client Pays Late By:
                </div>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min={15}
                    max={60}
                    step={5}
                    value={p3ClientDelayDays}
                    onChange={(e) => setP3ClientDelayDays(Number(e.target.value))}
                    className="w-36 accent-indigo-500 cursor-pointer"
                  />
                  <span className="px-2.5 py-1 rounded bg-rose-500/20 border border-rose-500/40 text-rose-300 font-mono text-xs font-bold">
                    +{p3ClientDelayDays} Days Late
                  </span>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-3 text-xs">
                <div className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30">
                  <span className="text-slate-400">Target DSO Reduction: </span>
                  <span className="font-bold text-emerald-400">-30% DSO</span>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-amber-950/40 border border-amber-500/30">
                  <span className="text-slate-400">Annual SaaS Leak Recovery: </span>
                  <span className="font-bold text-amber-400">
                    ₹{p3Sim.annualSaasSavingsInr.toLocaleString()}/yr
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
              {/* Pillar 1: Payer Behavior Profiling */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                    1. Payer Behavior & Delinquency Profiler
                  </h4>
                  <span className="text-[11px] text-slate-400">Pre-Due Risk Flagging</span>
                </div>
                <div className="space-y-2.5">
                  {p3Sim.arInvoices.map((p) => (
                    <div
                      key={p.invoiceId}
                      className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{p.clientName}</span>
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                          {p.delinquencyRiskPct}% Late Risk (Avg +{p.avgHistoricalDelayDays}d)
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-300">
                        Invoice <span className="font-mono text-indigo-300">{p.invoiceId}</span>:{" "}
                        <span className="font-bold text-white">
                          ₹{p.amountInr.toLocaleString()}
                        </span>{" "}
                        • {p.status}
                      </div>
                      <div className="text-[11px] text-emerald-300 bg-emerald-950/30 border border-emerald-500/20 px-2.5 py-1 rounded">
                        Chasing Sequence: {p.chasingSequence}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Pillar 2: Subscription Creep & Zombie SaaS Auditor */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-rose-400">
                    2. Silent SaaS & Vendor Creep Auditor
                  </h4>
                  <span className="text-[11px] text-emerald-400 font-semibold">
                    ₹{p3Sim.monthlySaasSavingsInr.toLocaleString()}/mo Recoverable
                  </span>
                </div>
                <div className="space-y-2.5">
                  {p3Sim.saasLeaks.map((v) => {
                    const isCancelled = cancelledVendorIds.includes(v.vendor);
                    return (
                      <div
                        key={v.vendor}
                        className="p-3 rounded-lg bg-slate-900 border border-slate-800 space-y-1.5"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">{v.vendor}</span>
                          <span className="text-xs font-extrabold text-rose-400">
                            Save ₹{v.annualSavingsInr.toLocaleString()}/yr
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {v.leakType} • Spend:{" "}
                          <span className="text-rose-300 font-semibold">
                            ₹{v.monthlySpendInr.toLocaleString()}/mo
                          </span>
                        </div>
                        <div className="flex items-center justify-between pt-1 gap-2">
                          <span className="text-[10px] text-slate-300">{v.action}</span>
                          <button
                            onClick={() =>
                              setCancelledVendorIds((prev) =>
                                prev.includes(v.vendor)
                                  ? prev.filter((id) => id !== v.vendor)
                                  : [...prev, v.vendor]
                              )
                            }
                            className={`px-2.5 py-1 rounded text-[10px] font-semibold cursor-pointer shrink-0 ${
                              isCancelled
                                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                                : "bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40"
                            }`}
                          >
                            {isCancelled ? "✓ Seats Revoked" : "Revoke / Downgrade"}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Pillar 3: 60-Day Cash Runway Stress Test */}
              <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400">
                    3. 60-Day Treasury & Cash Shortfall Simulator
                  </h4>
                  <span className="text-[11px] text-amber-300 font-mono">
                    Delay: {p3ClientDelayDays}d
                  </span>
                </div>
                <div className="space-y-3">
                  <div className="p-3.5 rounded-lg bg-rose-950/25 border border-rose-500/40 space-y-1.5">
                    <div className="text-xs font-bold text-white">
                      Scenario A: Unmanaged (+{p3ClientDelayDays}d Client Delay + Vendor Bills on
                      1st)
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">Projected Day-30 Cash Trough:</span>
                      <span className="font-mono font-extrabold text-rose-400">
                        ₹{p3Sim.projectedDay30CashWithoutAgent.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-[11px] text-rose-300">
                      Risk: Payroll & GST buffer breached if Vertex & Apex slip past 1st of month.
                    </div>
                  </div>

                  <div className="p-3.5 rounded-lg bg-emerald-950/25 border border-emerald-500/40 space-y-1.5">
                    <div className="text-xs font-bold text-white">
                      Scenario B: With Rexor Treasury & SaaS Audit Agent
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400">Protected Day-30 Cash Balance:</span>
                      <span className="font-mono font-extrabold text-emerald-400">
                        ₹{p3Sim.projectedDay30CashWithAgent.toLocaleString()}
                      </span>
                    </div>
                    <div className="text-[11px] text-emerald-300">
                      Recovers ₹{p3Sim.monthlySaasSavingsInr.toLocaleString()}/mo in zombie SaaS +
                      accelerates 65% of delinquent AR via milestone split.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {selectedProblemId === "problem-4-clinic-noshows" && (
          <div className="space-y-5">
            {/* Problem 4 KPI Strip */}
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-2 text-xs text-slate-300">
                <Stethoscope className="w-4 h-4 text-indigo-400" />
                <span>
                  Risk-stratified appointment triage replaces blanket SMS blasts with targeted
                  deposits & instant waitlist backfilling.
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs shrink-0">
                <div className="px-3 py-1.5 rounded-lg bg-rose-950/40 border border-rose-500/30">
                  <span className="text-slate-400">Billable Value at Risk: </span>
                  <span className="font-bold text-rose-400">
                    ₹{p4Sim.totalRevenueAtRiskInr.toLocaleString()}/day
                  </span>
                </div>
                <div className="px-3 py-1.5 rounded-lg bg-emerald-950/40 border border-emerald-500/30">
                  <span className="text-slate-400">Recovered via Waitlist Backfill: </span>
                  <span className="font-bold text-emerald-400">
                    ₹{p4Sim.recoveredRevenueInr.toLocaleString()}/day (+8–12% utilization)
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
              {/* Patient No-Show Risk Scoring & Targeted Front-Desk Escalation */}
              <div className="xl:col-span-7 bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400">
                    1 & 2. Patient No-Show Risk Scoring & Targeted Front-Desk Escalation
                  </h4>
                  <span className="text-[11px] text-slate-400">
                    Lead Time + Prior Cancellations + Distance
                  </span>
                </div>
                <div className="space-y-2.5">
                  {p4Sim.appointments.map((apt) => {
                    const isEscalated = escalatedApptIds.includes(apt.bookingId);
                    return (
                      <div
                        key={apt.bookingId}
                        className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono text-xs font-bold text-indigo-300">
                              {apt.bookingId}
                            </span>
                            <span className="text-xs font-bold text-white">
                              {apt.patientName} ({apt.slotTime})
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                apt.riskTier.includes("Tier 3")
                                  ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                                  : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                              }`}
                            >
                              {apt.riskScorePct}% No-Show Risk ({apt.riskTier})
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {apt.department} • {apt.procedure} • Billable:{" "}
                            <span className="text-white font-semibold">
                              ₹{apt.slotValueInr.toLocaleString()}
                            </span>{" "}
                            • Lead: {apt.leadTimeDays}d • Prior No-Shows: {apt.priorNoShows} •{" "}
                            {apt.distanceKm}km
                          </div>
                          <div className="text-[11px] text-indigo-300 font-medium">
                            Playbook: {apt.escalationAction}
                          </div>
                        </div>

                        <button
                          onClick={() =>
                            setEscalatedApptIds((prev) =>
                              prev.includes(apt.bookingId)
                                ? prev.filter((id) => id !== apt.bookingId)
                                : [...prev, apt.bookingId]
                            )
                          }
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 flex items-center gap-1.5 cursor-pointer transition-colors ${
                            isEscalated
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                              : "bg-indigo-600 hover:bg-indigo-500 text-white"
                          }`}
                        >
                          {apt.riskTier.includes("Tier 3") ? (
                            <PhoneCall className="w-3.5 h-3.5" />
                          ) : (
                            <MessageSquare className="w-3.5 h-3.5" />
                          )}
                          {isEscalated ? "✓ Escalation Triggered" : "Trigger Escalation"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Automated Schedule Gap Re-Filling */}
              <div className="xl:col-span-5 bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400">
                    3. Automated Waitlist Schedule Gap Re-Filler
                  </h4>
                  <span className="text-[11px] text-emerald-300 font-semibold">
                    30–40% Empty Slot Cut
                  </span>
                </div>
                <div className="space-y-3">
                  {p4Sim.appointments.map((m) => {
                    const isFilled = autoFilledApptIds.includes(m.bookingId);
                    return (
                      <div
                        key={m.bookingId}
                        className="p-3.5 rounded-lg bg-slate-900 border border-emerald-500/30 space-y-2.5"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">
                            Slot {m.bookingId} ({m.slotTime})
                          </span>
                          <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 text-[10px] font-bold">
                            Protect ₹{m.slotValueInr.toLocaleString()}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-300">
                          Procedure: <span className="font-semibold">{m.procedure}</span> • Matched
                          Standby: <span className="text-emerald-400 font-bold">{m.waitlistMatch}</span>
                        </div>
                        <button
                          onClick={() =>
                            setAutoFilledApptIds((prev) =>
                              prev.includes(m.bookingId)
                                ? prev.filter((id) => id !== m.bookingId)
                                : [...prev, m.bookingId]
                            )
                          }
                          className={`w-full py-2 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
                            isFilled
                              ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                              : "bg-emerald-600 hover:bg-emerald-500 text-white"
                          }`}
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          {isFilled
                            ? "✓ Slot Confirmed & Waitlist Patient Booked"
                            : "Auto-Dispatch Instant Waitlist Claim Offer"}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
