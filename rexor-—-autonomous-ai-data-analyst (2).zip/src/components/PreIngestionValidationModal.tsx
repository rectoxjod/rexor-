/**
 * Rexor — Pre-Ingestion Data Validation & Structural Diagnostic Gate UI
 * Detects and resolves:
 *   1. EMPTY_FILE (0 bytes, whitespace-only, empty JSON array, or header-only 0 data rows)
 *   2. MISSING_HEADER_ROW (Row 1 contains numeric/date/currency literals, blank headers, or duplicate headers)
 *   3. MALFORMED_DELIMITERS (Unclosed quotes, ragged column counts across lines, mixed delimiters, or single-column collapse)
 *
 * @author Rushi Chavan
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */
import React, { useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  Check,
  FileSpreadsheet,
  FileWarning,
  RefreshCw,
  ShieldAlert,
  Sliders,
  Upload,
  X,
} from "lucide-react";
import {
  DataRow,
  DelimiterChoice,
  FileValidationResult,
} from "../types/rexor";

interface PreIngestionValidationModalProps {
  validationResult: FileValidationResult;
  delimiterOverride: DelimiterChoice;
  treatFirstRowAsData: boolean;
  onChangeOptions: (newOptions: {
    delimiterOverride: DelimiterChoice;
    treatFirstRowAsData: boolean;
  }) => void;
  onConfirmIngest: (finalRows: DataRow[], finalFileName: string) => void;
  onCancel: () => void;
  onBrowseAnotherFile: () => void;
}

export const PreIngestionValidationModal: React.FC<
  PreIngestionValidationModalProps
> = ({
  validationResult,
  delimiterOverride,
  treatFirstRowAsData,
  onChangeOptions,
  onConfirmIngest,
  onCancel,
  onBrowseAnotherFile,
}) => {
  // Allow user to customize column header names before ingestion (especially when Row 1 was missing headers)
  const [customHeaderNames, setCustomHeaderNames] = useState<string[]>(
    validationResult.previewHeaders
  );

  useEffect(() => {
    setCustomHeaderNames(validationResult.previewHeaders);
  }, [validationResult.previewHeaders]);

  // Apply any user-edited custom header names to the parsed rows before ingestion
  const previewRowsWithCustomHeaders = useMemo(() => {
    const origHeaders = validationResult.previewHeaders;
    if (origHeaders.length === 0) return [];
    return validationResult.parsedRows.map((row) => {
      const mapped: DataRow = {};
      origHeaders.forEach((origH, idx) => {
        const cleanCustom =
          (customHeaderNames[idx] || "").trim() || `col_${idx + 1}`;
        mapped[cleanCustom] = row[origH];
      });
      return mapped;
    });
  }, [
    validationResult.parsedRows,
    validationResult.previewHeaders,
    customHeaderNames,
  ]);

  const hasEmptyFileIssue = validationResult.issues.some(
    (i) => i.type === "EMPTY_FILE"
  );
  const hasMissingHeaderIssue = validationResult.issues.some(
    (i) => i.type === "MISSING_HEADER_ROW"
  );
  const hasMalformedDelimiterIssue = validationResult.issues.some(
    (i) => i.type === "MALFORMED_DELIMITERS"
  );

  const delimiterLabel =
    validationResult.detectedDelimiter === "\t"
      ? "Tab (\\t)"
      : validationResult.detectedDelimiter === ";"
      ? "Semicolon (;)"
      : validationResult.detectedDelimiter === "|"
      ? "Pipe (|)"
      : "Comma (,)";

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 px-4 py-6 overflow-y-auto">
      <div className="bg-white border border-slate-300 rounded-xl max-w-4xl w-full p-6 space-y-5 my-auto">
        {/* Top Modal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-lg bg-amber-50 border border-amber-300 text-amber-700 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-mono uppercase tracking-wider text-amber-700 font-bold">
                  Stage 02 Pre-Ingestion Validation Gate
                </span>
                <span className="text-xs font-mono text-slate-500">
                  · {validationResult.fileName} ({validationResult.fileSizeBytes}{" "}
                  bytes)
                </span>
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                {hasEmptyFileIssue
                  ? "Ingestion Blocked: Empty or Zero-Record File Detected"
                  : `Pre-Ingestion Data Validation Warning (${validationResult.issues.length} Structural Issue${
                      validationResult.issues.length === 1 ? "" : "s"
                    } Detected)`}
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={onCancel}
            className="px-3 py-1.5 text-xs font-medium text-slate-500 hover:text-slate-900 border border-slate-200 rounded-lg flex items-center gap-1 self-start cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
            <span>Dismiss</span>
          </button>
        </div>

        {/* Summary Telemetry Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] text-slate-500">Detected Format</div>
            <div className="text-sm font-bold font-mono uppercase text-slate-900 mt-0.5">
              {validationResult.fileFormat} ({validationResult.fileSizeBytes} B)
            </div>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] text-slate-500">Active Delimiter</div>
            <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
              {delimiterLabel}
            </div>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] text-slate-500">
              Parsed Columns × Rows
            </div>
            <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
              {validationResult.previewHeaders.length} Cols ×{" "}
              {validationResult.parsedRows.length} Rows
            </div>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200">
            <div className="text-[11px] text-slate-500">Validation Status</div>
            <div
              className={`text-sm font-bold font-mono mt-0.5 ${
                hasEmptyFileIssue
                  ? "text-red-600"
                  : validationResult.issues.length > 0
                  ? "text-amber-700"
                  : "text-emerald-700"
              }`}
            >
              {hasEmptyFileIssue
                ? "BLOCKED (EMPTY)"
                : validationResult.issues.length > 0
                ? `${validationResult.issues.length} WARNING(S)`
                : "READY TO INGEST"}
            </div>
          </div>
        </div>

        {/* Specific Warning Cards for Detected Issues */}
        {validationResult.issues.length > 0 ? (
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Detected Pre-Ingestion Warnings & Diagnostics
            </div>
            {validationResult.issues.map((issue, idx) => {
              const isCritical = issue.severity === "critical";
              return (
                <div
                  key={idx}
                  className={`p-4 rounded-xl border space-y-2 ${
                    isCritical
                      ? "bg-red-50 border-red-200"
                      : "bg-amber-50 border-amber-200"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <AlertTriangle
                        className={`w-4 h-4 shrink-0 ${
                          isCritical ? "text-red-600" : "text-amber-700"
                        }`}
                      />
                      <span
                        className={`px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded border ${
                          isCritical
                            ? "bg-red-50 border-red-200 text-red-600"
                            : "bg-amber-50 border-amber-200 text-amber-700"
                        }`}
                      >
                        {issue.type.replace(/_/g, " ")}
                      </span>
                      <h4 className="text-sm font-bold text-slate-900">
                        {issue.title}
                      </h4>
                    </div>
                    {issue.affectedLines && issue.affectedLines.length > 0 && (
                      <span className="text-xs font-mono text-slate-500">
                        Affected Line(s):{" "}
                        {issue.affectedLines.slice(0, 6).join(", ")}
                        {issue.affectedLines.length > 6 ? "..." : ""}
                      </span>
                    )}
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed">
                    {issue.description}
                  </p>

                  <div className="p-2.5 rounded-lg bg-slate-900 text-slate-100 text-xs font-mono overflow-x-auto">
                    {issue.diagnosticDetail}
                  </div>

                  <div className="text-xs text-emerald-700 font-medium">
                    <strong>Recommended Resolution:</strong>{" "}
                    {issue.suggestedAction}
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs text-emerald-800">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>
                <strong>All Structural Validation Checks Passed:</strong> Header
                row and column delimiters are aligned across{" "}
                {validationResult.parsedRows.length} records.
              </span>
            </div>
          </div>
        )}

        {/* Interactive Pre-Ingestion Repair Controls (Delimiter Override & Header Recovery) */}
        {validationResult.fileFormat !== "json" && (
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700">
                <Sliders className="w-3.5 h-3.5 text-blue-600" />
                <span>
                  Interactive Pre-Ingestion Repair & Recovery Controls
                </span>
              </div>
              <span className="text-[11px] text-slate-500">
                Adjusting options below re-validates the file live
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Control 1: Delimiter Override */}
              {validationResult.fileFormat !== "excel" && (
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                    1. Delimiter Override{" "}
                    {hasMalformedDelimiterIssue && (
                      <span className="text-amber-700 font-mono">
                        (Fix Malformed Delimiters)
                      </span>
                    )}
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {[
                      { id: "auto", label: "Auto-Detect" },
                      { id: ",", label: "Comma (,)" },
                      { id: ";", label: "Semicolon (;)" },
                      { id: "\t", label: "Tab (\\t)" },
                      { id: "|", label: "Pipe (|)" },
                    ].map((d) => (
                      <button
                        key={d.id}
                        type="button"
                        onClick={() =>
                          onChangeOptions({
                            delimiterOverride: d.id as DelimiterChoice,
                            treatFirstRowAsData,
                          })
                        }
                        className={`px-2.5 py-1.5 text-xs font-mono rounded-lg border transition-colors cursor-pointer ${
                          delimiterOverride === d.id
                            ? "bg-blue-600 text-white border-blue-600 font-bold"
                            : "bg-white text-slate-700 border-slate-300 hover:border-slate-400"
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Control 2: Missing Header Row Recovery */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                  2. Header Row Handling{" "}
                  {hasMissingHeaderIssue && (
                    <span className="text-amber-700 font-mono">
                      (Fix Missing Header Row)
                    </span>
                  )}
                </label>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      onChangeOptions({
                        delimiterOverride,
                        treatFirstRowAsData: false,
                      })
                    }
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      !treatFirstRowAsData
                        ? "bg-blue-600 text-white border-blue-600 font-semibold"
                        : "bg-white text-slate-700 border-slate-300"
                    }`}
                  >
                    Use Row 1 as Column Headers
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onChangeOptions({
                        delimiterOverride,
                        treatFirstRowAsData: true,
                      })
                    }
                    className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors cursor-pointer ${
                      treatFirstRowAsData
                        ? "bg-blue-600 text-white border-blue-600 font-semibold"
                        : "bg-white text-slate-700 border-slate-300"
                    }`}
                  >
                    Row 1 is Data → Auto-Generate Headers (col_1..N)
                  </button>
                </div>
              </div>
            </div>

            {/* Editable Column Names Bar when headers are present */}
            {customHeaderNames.length > 0 && (
              <div className="pt-3 border-t border-slate-200">
                <div className="text-xs font-medium text-slate-600 mb-2">
                  Customize or Repair Column Header Names Before Ingestion:
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
                  {customHeaderNames.map((hName, idx) => (
                    <div key={idx}>
                      <span className="text-[10px] font-mono text-slate-400 block">
                        Column #{idx + 1}
                      </span>
                      <input
                        type="text"
                        value={hName}
                        onChange={(e) => {
                          const updated = [...customHeaderNames];
                          updated[idx] = e.target.value;
                          setCustomHeaderNames(updated);
                        }}
                        className="w-full px-2 py-1 text-xs font-mono bg-white border border-slate-300 rounded focus:outline-none focus:border-blue-600"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* Live Pre-Ingestion Data Preview Table */}
        {previewRowsWithCustomHeaders.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold uppercase tracking-wider text-slate-500">
                Pre-Ingestion Preview (First{" "}
                {Math.min(5, previewRowsWithCustomHeaders.length)} of{" "}
                {previewRowsWithCustomHeaders.length} Parsed Rows)
              </span>
              <span className="font-mono text-slate-500">
                Ragged cells are automatically padded/aligned
              </span>
            </div>
            <div className="overflow-x-auto border border-slate-200 rounded-lg max-h-52">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 sticky top-0">
                  <tr>
                    <th className="py-2 px-2.5 font-mono text-slate-500">#</th>
                    {customHeaderNames.map((col, idx) => (
                      <th
                        key={idx}
                        className="py-2 px-2.5 font-mono font-semibold text-slate-900 whitespace-nowrap"
                      >
                        {col || `col_${idx + 1}`}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {previewRowsWithCustomHeaders.slice(0, 5).map((r, rIdx) => (
                    <tr key={rIdx}>
                      <td className="py-1.5 px-2.5 text-slate-400">
                        {rIdx + 1}
                      </td>
                      {customHeaderNames.map((col, cIdx) => {
                        const key = (col || "").trim() || `col_${cIdx + 1}`;
                        const val = r[key];
                        const isEmpty =
                          val === "" || val === null || val === undefined;
                        return (
                          <td
                            key={cIdx}
                            className={`py-1.5 px-2.5 whitespace-nowrap ${
                              isEmpty ? "text-amber-700" : "text-slate-800"
                            }`}
                          >
                            {isEmpty ? "<EMPTY>" : String(val)}
                          </td>
                        );
                      })}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Action Buttons Footer */}
        <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onBrowseAnotherFile}
              className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 cursor-pointer"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Different File</span>
            </button>
            <button
              type="button"
              onClick={onCancel}
              className="px-3.5 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 rounded-lg cursor-pointer"
            >
              Cancel Ingestion
            </button>
          </div>

          <button
            type="button"
            disabled={!validationResult.canRecoverAndIngest}
            onClick={() =>
              onConfirmIngest(
                previewRowsWithCustomHeaders,
                validationResult.fileName
              )
            }
            className="px-5 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg disabled:opacity-40 flex items-center justify-center gap-2 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>
              {validationResult.issues.length > 0
                ? `Ingest Validated & Repaired Dataset (${previewRowsWithCustomHeaders.length} Rows)`
                : `Confirm & Ingest Dataset (${previewRowsWithCustomHeaders.length} Rows)`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
