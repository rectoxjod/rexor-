import React, { useState } from "react";
import {
  Award,
  BookOpen,
  Brain,
  Check,
  Copy,
  Plus,
  Sparkles,
  ThumbsUp,
  Trash2,
  Wand2,
  Zap,
} from "lucide-react";
import {
  ColumnProfile,
  CorrelationPair,
  DataRow,
} from "../types/rexor";
import {
  AdaptiveRuleType,
  AdaptiveUserRequirement,
  compileUserRequirementToRule,
  distillSessionKnowledgeFromDataset,
  EcosystemAnalystKnowledge,
  RuleExecutionSummary,
  saveEcosystemKnowledge,
  saveUserRequirements,
} from "../utils/adaptiveEngine";

interface RexorAdaptiveKnowledgeHubProps {
  datasetName: string;
  domainContext: string;
  businessQuestion?: string;
  columnProfiles: ColumnProfile[];
  correlations: CorrelationPair[];
  sampleRows?: DataRow[];
  cleanedRows?: DataRow[];
  userRequirements: AdaptiveUserRequirement[];
  onUpdateRequirements?: (next: AdaptiveUserRequirement[]) => void;
  onAddUserRequirement?: (req: AdaptiveUserRequirement) => void;
  onToggleUserRequirement?: (id: string) => void;
  onRemoveUserRequirement?: (id: string) => void;
  onClearAllRequirements?: () => void;
  ruleExecutionSummary: RuleExecutionSummary;
  ecosystemKnowledge: EcosystemAnalystKnowledge[];
  onUpdateEcosystemKnowledge?: React.Dispatch<
    React.SetStateAction<EcosystemAnalystKnowledge[]>
  >;
  onAddEcosystemKnowledge?: (entry: EcosystemAnalystKnowledge) => void;
  onUpvoteKnowledge?: (id: string) => void;
  onDeleteKnowledge?: (id: string) => void;
  onTriggerNotice?: (msg: string) => void;
}

export const RexorAdaptiveKnowledgeHub: React.FC<
  RexorAdaptiveKnowledgeHubProps
> = ({
  datasetName,
  domainContext,
  businessQuestion = "Analyze operational drivers, data hygiene, and profitability across cohorts.",
  columnProfiles,
  correlations,
  sampleRows,
  cleanedRows,
  userRequirements,
  onUpdateRequirements,
  onAddUserRequirement,
  onToggleUserRequirement,
  onRemoveUserRequirement,
  onClearAllRequirements,
  ruleExecutionSummary,
  ecosystemKnowledge,
  onUpdateEcosystemKnowledge,
  onAddEcosystemKnowledge,
  onUpvoteKnowledge,
  onDeleteKnowledge,
  onTriggerNotice,
}) => {
  const [activeTab, setActiveTab] = useState<
    "user-requirements" | "ecosystem-vault" | "teach-rexor"
  >("user-requirements");

  // Natural Language Requirement State
  const [nlInstruction, setNlInstruction] = useState<string>("");
  const [isCompilingAiRule, setIsCompilingAiRule] = useState<boolean>(false);
  const [feedbackBanner, setFeedbackBanner] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [autoLearnCount, setAutoLearnCount] = useState<number>(0);
  const [newlyLearnedId, setNewlyLearnedId] = useState<string | null>(null);

  const effectiveSampleRows = sampleRows || cleanedRows || [];

  // Unified Safe Dispatchers (supports both onUpdate* and granular onAdd*/onToggle* props)
  const dispatchAddRequirement = (req: AdaptiveUserRequirement) => {
    if (onAddUserRequirement) {
      onAddUserRequirement(req);
    } else if (onUpdateRequirements) {
      const next = [req, ...userRequirements];
      onUpdateRequirements(next);
      saveUserRequirements(next);
    }
  };

  const dispatchToggleRequirement = (id: string) => {
    if (onToggleUserRequirement) {
      onToggleUserRequirement(id);
    } else if (onUpdateRequirements) {
      const next = userRequirements.map((r) =>
        r.id === id ? { ...r, enabled: !r.enabled } : r
      );
      onUpdateRequirements(next);
      saveUserRequirements(next);
    }
  };

  const dispatchRemoveRequirement = (id: string) => {
    if (onRemoveUserRequirement) {
      onRemoveUserRequirement(id);
    } else if (onUpdateRequirements) {
      const next = userRequirements.filter((r) => r.id !== id);
      onUpdateRequirements(next);
      saveUserRequirements(next);
    }
  };

  const dispatchClearAllRequirements = () => {
    if (onClearAllRequirements) {
      onClearAllRequirements();
    } else if (onUpdateRequirements) {
      onUpdateRequirements([]);
      saveUserRequirements([]);
    }
    triggerBanner("Cleared all custom user requirements and restored baseline dataset.");
  };

  const dispatchAddKnowledge = (entry: EcosystemAnalystKnowledge) => {
    if (onAddEcosystemKnowledge) {
      onAddEcosystemKnowledge(entry);
    } else if (onUpdateEcosystemKnowledge) {
      const next = [entry, ...ecosystemKnowledge];
      onUpdateEcosystemKnowledge(next);
      saveEcosystemKnowledge(next);
    }
  };

  const dispatchUpvoteKnowledge = (id: string) => {
    if (onUpvoteKnowledge) {
      onUpvoteKnowledge(id);
    } else if (onUpdateEcosystemKnowledge) {
      const next = ecosystemKnowledge.map((k) =>
        k.id === id ? { ...k, upvotes: k.upvotes + 1 } : k
      );
      onUpdateEcosystemKnowledge(next);
      saveEcosystemKnowledge(next);
    }
  };

  const dispatchDeleteKnowledge = (id: string) => {
    if (onDeleteKnowledge) {
      onDeleteKnowledge(id);
    } else if (onUpdateEcosystemKnowledge) {
      const next = ecosystemKnowledge.filter((k) => k.id !== id);
      onUpdateEcosystemKnowledge(next);
      saveEcosystemKnowledge(next);
    }
    triggerBanner("Removed contributed playbook from Ecosystem Knowledge Vault.");
  };

  // Structured Rule Builder State
  const allCols = columnProfiles.map((c) => c.name);
  const numCols = columnProfiles
    .filter((c) => c.type === "numeric")
    .map((c) => c.name);
  const catCols = columnProfiles
    .filter((c) => c.type !== "numeric")
    .map((c) => c.name);

  const [showStructuredBuilder, setShowStructuredBuilder] =
    useState<boolean>(false);
  const [builderRuleType, setBuilderRuleType] =
    useState<AdaptiveRuleType>("CAP_MAX");
  const [builderTargetCol, setBuilderTargetCol] = useState<string>(
    () => numCols[0] || allCols[0] || ""
  );
  const [builderSecondCol, setBuilderSecondCol] = useState<string>(
    () => numCols[1] || catCols[0] || allCols[0] || ""
  );
  const [builderNumParam, setBuilderNumParam] = useState<string>("30");
  const [builderCompareVal, setBuilderCompareVal] = useState<string>("Paid");
  const [builderOutCol, setBuilderOutCol] = useState<string>("Custom_Metric");

  // Teach Rexor (Contribute Senior Analyst Knowledge) State
  const [analystName, setAnalystName] = useState<string>("Rushi Chavan");
  const [analystRole, setAnalystRole] = useState<string>(
    "Principal Data Analyst"
  );
  const [knowledgeDomain, setKnowledgeDomain] = useState<string>(
    domainContext || "Enterprise Operations & Financial Audit"
  );
  const [expYears, setExpYears] = useState<string>("10");
  const [knowledgeTitle, setKnowledgeTitle] = useState<string>("");
  const [problemPattern, setProblemPattern] = useState<string>("");
  const [expertHeuristic, setExpertHeuristic] = useState<string>("");
  const [executableRuleText, setExecutableRuleText] = useState<string>("");

  const triggerBanner = (msg: string) => {
    setFeedbackBanner(msg);
    if (onTriggerNotice) {
      onTriggerNotice(msg);
    }
    setTimeout(() => setFeedbackBanner(null), 7000);
  };

  // Apply Plain-English User Requirement (Uses AI endpoint with deterministic fallback)
  const handleApplyNaturalLanguageRequirement = async (
    overrideText?: string,
    authorLabel: string = "User Requirement"
  ) => {
    const textToCompile = (overrideText ?? nlInstruction).trim();
    if (!textToCompile) return;

    setIsCompilingAiRule(true);
    try {
      const response = await fetch("/api/rexor/adapt-rule", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          instruction: textToCompile,
          datasetName,
          businessQuestion,
          columns: columnProfiles.map((c) => ({
            name: c.name,
            type: c.type,
            mean: c.mean,
            median: c.median,
            q1: c.q25,
            q3: c.q75,
          })),
          sampleRows: effectiveSampleRows.slice(0, 6),
        }),
      });

      if (response.ok) {
        const aiRule = await response.json();
        if (aiRule && aiRule.ruleType && aiRule.targetColumn) {
          const compiled: AdaptiveUserRequirement = {
            id: `req-${Date.now()}`,
            title: aiRule.title || `Custom Rule on ${aiRule.targetColumn}`,
            rawInstruction: textToCompile,
            ruleType: aiRule.ruleType,
            targetColumn: aiRule.targetColumn,
            secondaryColumn: aiRule.secondaryColumn,
            operator: aiRule.operator,
            compareValue: aiRule.compareValue,
            numericParameter:
              aiRule.numericParameter !== undefined
                ? Number(aiRule.numericParameter)
                : undefined,
            formulaExpression: aiRule.formulaExpression,
            outputColumnName: aiRule.outputColumnName,
            flagLabelTrue: aiRule.flagLabelTrue,
            flagLabelFalse: aiRule.flagLabelFalse,
            pythonEquivalent:
              aiRule.pythonEquivalent ||
              `# Applied: ${textToCompile}\ndf["${aiRule.targetColumn}"] = df["${aiRule.targetColumn}"]`,
            sqlEquivalent:
              aiRule.sqlEquivalent ||
              `-- Applied: ${textToCompile}\nSELECT * FROM cleaned_dataset;`,
            enabled: true,
            createdAt: new Date().toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            }),
            sourceAuthor: authorLabel,
          };
          dispatchAddRequirement(compiled);
          if (!overrideText) setNlInstruction("");
          triggerBanner(
            `Applied Requirement: "${compiled.title}" — All 6 stages, charts, SQL queries, and Python outputs have adapted automatically!`
          );
          return;
        }
      }
      throw new Error("Fallback to deterministic compiler");
    } catch {
      const deterministicRule = compileUserRequirementToRule(
        textToCompile,
        columnProfiles,
        authorLabel
      );
      dispatchAddRequirement(deterministicRule);
      if (!overrideText) setNlInstruction("");
      triggerBanner(
        `Applied Requirement: "${deterministicRule.title}" — Live dataset, charts, and statistics updated!`
      );
    } finally {
      setIsCompilingAiRule(false);
    }
  };

  // Apply Structured Rule Builder
  const handleAddStructuredRule = () => {
    const target = builderTargetCol || allCols[0] || "Value";
    const numVal = Number(builderNumParam) || 25;
    let promptDesc = "";

    if (builderRuleType === "CAP_MAX") {
      promptDesc = `Cap ${target} at maximum ${numVal}`;
    } else if (builderRuleType === "FLOOR_MIN") {
      promptDesc = `Enforce minimum floor ${target} at least ${numVal}`;
    } else if (builderRuleType === "FILTER_KEEP") {
      promptDesc = `Filter keep rows where ${target} == ${builderCompareVal}`;
    } else if (builderRuleType === "FILTER_EXCLUDE") {
      promptDesc = `Remove rows where ${target} == ${builderCompareVal}`;
    } else if (builderRuleType === "CONDITIONAL_FLAG") {
      promptDesc = `Flag rows where ${target} > ${numVal} as ${builderOutCol}`;
    } else if (builderRuleType === "CANONICALIZE_TEXT") {
      promptDesc = `Canonicalize text in ${target} to Title Case`;
    } else if (builderRuleType === "COHORT_MEAN_IMPUTE") {
      promptDesc = `Impute missing ${target} using cohort group mean by ${builderSecondCol}`;
    } else {
      promptDesc = `Create column ${builderOutCol} = ${target} * ${numVal}`;
    }

    const rule = compileUserRequirementToRule(
      promptDesc,
      columnProfiles,
      "Structured Rule Builder"
    );
    rule.ruleType = builderRuleType;
    rule.targetColumn = target;
    if (builderSecondCol) rule.secondaryColumn = builderSecondCol;
    if (builderOutCol) rule.outputColumnName = builderOutCol;

    dispatchAddRequirement(rule);
    triggerBanner(`Added & Applied Structured Rule: "${rule.title}"`);
  };

  // Contribute New Senior Analyst Knowledge
  const handleContributeKnowledge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!knowledgeTitle.trim() || !expertHeuristic.trim()) return;

    const autoPrompt =
      executableRuleText.trim() ||
      `Flag records where ${numCols[0] || "Prep_Time_Mins"} > 25`;
    const compiledRule = compileUserRequirementToRule(
      autoPrompt,
      columnProfiles,
      analystName
    );

    const newEntry: EcosystemAnalystKnowledge = {
      id: `eco-custom-${Date.now()}`,
      analystName: analystName.trim() || "Senior Data Analyst",
      analystRole: analystRole.trim() || "Principal Analytics Architect",
      domain: knowledgeDomain.trim() || domainContext || "Enterprise Analytics",
      experienceYears: Math.max(1, Number(expYears) || 8),
      title: knowledgeTitle.trim(),
      problemPattern:
        problemPattern.trim() ||
        `Unfiltered domain anomalies in ${datasetName} can bias downstream KPIs if not governed by domain rules.`,
      expertHeuristic: expertHeuristic.trim(),
      statisticalRationale:
        "Empirically validated by senior ecosystem practitioners to preserve unbiased cohort estimators and prevent KPI leakage.",
      executablePrompt: autoPrompt,
      pythonTemplate: compiledRule.pythonEquivalent,
      upvotes: 1,
      verifiedParity: true,
      createdAt: new Date().toISOString().slice(0, 10),
      isUserContributed: true,
    };

    dispatchAddKnowledge(newEntry);
    setNewlyLearnedId(newEntry.id);
    setKnowledgeTitle("");
    setProblemPattern("");
    setExpertHeuristic("");
    setExecutableRuleText("");
    setActiveTab("ecosystem-vault");
    triggerBanner(
      `Saved to Ecosystem Knowledge Vault: "${newEntry.title}" by ${newEntry.analystName}! Rexor now uses this wisdom across analyses.`
    );
  };

  // Auto-Distill Knowledge from Current Session
  const handleAutoDistillFromDataset = () => {
    const passIndex = autoLearnCount;
    setAutoLearnCount((prev) => prev + 1);

    const distilled = distillSessionKnowledgeFromDataset({
      datasetName,
      domainContext,
      columnProfiles,
      correlations,
      activeRequirements: userRequirements.filter((r) => r.enabled),
      existingCount: passIndex,
    });

    dispatchAddKnowledge(distilled);
    setNewlyLearnedId(distilled.id);

    // Also compile and apply the distilled executable rule to the live dataset if not already present
    const alreadyExists = userRequirements.some(
      (r) =>
        r.rawInstruction.toLowerCase() ===
        distilled.executablePrompt.toLowerCase()
    );
    if (!alreadyExists) {
      const autoRule = compileUserRequirementToRule(
        distilled.executablePrompt,
        columnProfiles,
        "Rexor Auto-Learn Engine"
      );
      dispatchAddRequirement(autoRule);
    }

    setActiveTab("ecosystem-vault");
    triggerBanner(
      `Auto-Learned & Applied Heuristic #${passIndex + 1} from ${datasetName}: "${distilled.title}" — Added to Ecosystem Vault and applied to live dataset!`
    );
  };

  const quickAdaptationChips = [
    `Cap ${
      allCols.find((c) => /prep_time/i.test(c)) || numCols[0] || "Prep_Time_Mins"
    } at maximum 30`,
    allCols.some((c) => /discount_code/i.test(c))
      ? "Audit unauthorized MORNING10 discounts applied at or after 11:00 AM"
      : `Flag records where ${numCols[0] || "Value"} > 25 as High_Risk_SLA`,
    allCols.some((c) => /payment_status/i.test(c))
      ? "Isolate Paid orders where Payment_Status == 'Paid'"
      : `Canonicalize ${catCols[0] || "Outlet_Zone"} text to Title Case`,
    `Create column Net_Contribution = ${
      allCols.find((c) => /profit|revenue/i.test(c)) || numCols[0] || "Revenue"
    } * 0.85`,
    `Impute missing ${
      allCols.find((c) => /rating|score/i.test(c)) || numCols[0] || "Rating"
    } using cohort group mean by ${catCols[0] || "Outlet_Zone"}`,
  ];

  const activeReqCount = userRequirements.filter((r) => r.enabled).length;

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5 min-w-0 max-w-full overflow-x-hidden">
      {/* Header & 3-Mode Switcher */}
      <div className="flex flex-col gap-4 pb-5 border-b border-slate-200 min-w-0">
        <div className="min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
            <Brain className="w-4 h-4 text-[#39FF14] shrink-0" />
            <span>
              Adaptive Requirement Engine & Senior Analyst Ecosystem Brain ·
              Licensed to Rushi Chavan
            </span>
            <span aria-hidden="true">·</span>
            <span className="font-mono">
              {activeReqCount} Active Rules Applied · {ecosystemKnowledge.length}{" "}
              Ecosystem Playbooks Learned
            </span>
          </div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 mt-1 break-words">
            Rexor Adaptive User-Requirement Executor & Ecosystem Analyst
            Knowledge Vault
          </h2>
          <p className="text-xs text-slate-600 mt-1 max-w-4xl leading-relaxed">
            Tell Rexor any custom requirement, filter, cap, audit check, or
            derived formula to apply—Rexor executes it live on{" "}
            <strong>{datasetName}</strong> across all 6 stages, and continuously
            learns domain wisdom from experienced data analysts in the
            ecosystem.
          </p>
        </div>

        {/* Responsive 3-Tab Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 rounded-lg">
            <button
              type="button"
              onClick={() => setActiveTab("user-requirements")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "user-requirements"
                  ? "bg-blue-600 text-white"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Wand2 className="w-3.5 h-3.5 shrink-0" />
              <span>
                1. Adapt to User Requirements ({activeReqCount} Active)
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("ecosystem-vault")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "ecosystem-vault"
                  ? "bg-blue-600 text-white"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <BookOpen className="w-3.5 h-3.5 shrink-0" />
              <span>
                2. Senior Analyst Ecosystem Vault ({ecosystemKnowledge.length})
              </span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab("teach-rexor")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors flex items-center gap-1.5 cursor-pointer ${
                activeTab === "teach-rexor"
                  ? "bg-blue-600 text-white"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <Award className="w-3.5 h-3.5 shrink-0" />
              <span>3. Teach Rexor New Analyst Wisdom</span>
            </button>
          </div>

          <button
            type="button"
            onClick={handleAutoDistillFromDataset}
            className="px-3.5 py-2 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-1.5 shadow-sm transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#39FF14] shrink-0" />
            <span>
              Auto-Learn Heuristic from {datasetName}
              {autoLearnCount > 0 ? ` (${autoLearnCount} Learned)` : ""}
            </span>
          </button>
        </div>
      </div>

      {feedbackBanner && (
        <div className="px-4 py-3 bg-emerald-50 border border-emerald-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs text-emerald-800">
          <span className="font-medium break-words">{feedbackBanner}</span>
          <button
            type="button"
            onClick={() => setFeedbackBanner(null)}
            className="underline font-semibold cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* =====================================================================
          TAB 1: LIVE USER-REQUIREMENT ADAPTATION ENGINE
         ===================================================================== */}
      {activeTab === "user-requirements" && (
        <div className="space-y-5 min-w-0">
          {/* Plain-English User Requirement Command Bar */}
          <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3 min-w-0">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5 text-[#39FF14] shrink-0" />
                <span>
                  Instruct Rexor What Requirement or Business Rule to Apply Live:
                </span>
              </label>
              <button
                type="button"
                onClick={() => setShowStructuredBuilder((prev) => !prev)}
                className="text-xs font-medium text-blue-600 hover:underline cursor-pointer"
              >
                {showStructuredBuilder
                  ? "Hide Structured Rule Builder"
                  : "Open Dropdown Rule Builder →"}
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleApplyNaturalLanguageRequirement();
              }}
              className="flex flex-col sm:flex-row gap-2 min-w-0"
            >
              <input
                type="text"
                value={nlInstruction}
                onChange={(e) => setNlInstruction(e.target.value)}
                placeholder="e.g., Cap Prep_Time_Mins at maximum 30, or Create column Net_After_Tax = Gross_Profit_INR * 0.82, or Isolate Paid orders..."
                className="flex-1 min-w-0 px-3.5 py-2.5 text-xs sm:text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
              />
              <button
                type="submit"
                disabled={isCompilingAiRule || !nlInstruction.trim()}
                className="px-4 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
              >
                <Wand2 className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {isCompilingAiRule
                    ? "Adapting Dataset..."
                    : "Apply Requirement Live"}
                </span>
              </button>
            </form>

            {/* 1-Click Instant Requirement Templates */}
            <div className="space-y-1.5">
              <div className="text-[11px] text-slate-500">
                1-Click Adaptive Requirements (Click any rule below to apply it
                immediately to {datasetName}):
              </div>
              <div className="flex flex-wrap items-center gap-1.5">
                {quickAdaptationChips.map((chip, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() =>
                      handleApplyNaturalLanguageRequirement(
                        chip,
                        "Quick User Requirement"
                      )
                    }
                    className="px-2.5 py-1 text-[11px] font-mono bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-md transition-colors cursor-pointer text-left break-words"
                  >
                    + {chip}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Optional Dropdown Structured Rule Builder */}
          {showStructuredBuilder && (
            <div className="p-4 rounded-xl border border-slate-200 bg-white space-y-3 min-w-0">
              <div className="text-xs font-bold text-slate-900">
                Precision Dropdown Rule Builder
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Transformation Type
                  </label>
                  <select
                    value={builderRuleType}
                    onChange={(e) =>
                      setBuilderRuleType(e.target.value as AdaptiveRuleType)
                    }
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                  >
                    <option value="CAP_MAX">Cap Outliers at Max (≤)</option>
                    <option value="FLOOR_MIN">Enforce Min Floor (≥)</option>
                    <option value="FILTER_KEEP">Filter Keep Matching Rows</option>
                    <option value="FILTER_EXCLUDE">Exclude Matching Rows</option>
                    <option value="DERIVE_FORMULA">
                      Engineer Scaled Column (×)
                    </option>
                    <option value="CONDITIONAL_FLAG">
                      Flag Rows Above Threshold
                    </option>
                    <option value="CANONICALIZE_TEXT">
                      Canonicalize Text (Title Case)
                    </option>
                    <option value="COHORT_MEAN_IMPUTE">
                      Impute Missing via Cohort Mean
                    </option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Target Column
                  </label>
                  <select
                    value={builderTargetCol}
                    onChange={(e) => setBuilderTargetCol(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                  >
                    {allCols.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Threshold / Factor / Value
                  </label>
                  {builderRuleType === "FILTER_KEEP" ||
                  builderRuleType === "FILTER_EXCLUDE" ? (
                    <input
                      type="text"
                      value={builderCompareVal}
                      onChange={(e) => setBuilderCompareVal(e.target.value)}
                      placeholder="e.g., Paid"
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    />
                  ) : (
                    <input
                      type="number"
                      step="any"
                      value={builderNumParam}
                      onChange={(e) => setBuilderNumParam(e.target.value)}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    />
                  )}
                </div>

                <div>
                  <label className="block text-[11px] text-slate-500 mb-1">
                    Output / Grouping Column
                  </label>
                  {builderRuleType === "COHORT_MEAN_IMPUTE" ? (
                    <select
                      value={builderSecondCol}
                      onChange={(e) => setBuilderSecondCol(e.target.value)}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    >
                      {catCols.map((c) => (
                        <option key={c} value={c}>
                          Group by: {c}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={builderOutCol}
                      onChange={(e) => setBuilderOutCol(e.target.value)}
                      placeholder="New column name"
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    />
                  )}
                </div>

                <div className="flex items-end">
                  <button
                    type="button"
                    onClick={handleAddStructuredRule}
                    className="w-full px-3 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5 shrink-0" />
                    <span>Add & Apply Rule</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Live Adaptation Telemetry Strip */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-slate-500">Active User Requirements</div>
              <div className="text-lg font-bold font-mono text-slate-900 mt-0.5">
                {activeReqCount} / {userRequirements.length} Rules Active
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Applied before Stage 4–6 analytics
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-slate-500">Adapted Row Count</div>
              <div className="text-lg font-bold font-mono text-slate-900 mt-0.5">
                {ruleExecutionSummary.totalRowsBefore} →{" "}
                {ruleExecutionSummary.totalRowsAfter} Rows
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Live filtered & validated cohort
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-slate-500">Cells & Values Adapted</div>
              <div className="text-lg font-bold font-mono text-emerald-700 mt-0.5">
                {ruleExecutionSummary.totalCellsModified.toLocaleString()}{" "}
                Modifications
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                100% deterministic execution
              </div>
            </div>

            <div className="p-3.5 rounded-lg bg-slate-50 border border-slate-200">
              <div className="text-slate-500">Engineered Columns Added</div>
              <div className="text-lg font-bold font-mono text-blue-600 mt-0.5 truncate">
                {ruleExecutionSummary.newColumnsCreated.length > 0
                  ? ruleExecutionSummary.newColumnsCreated.join(", ")
                  : "0 Custom Columns"}
              </div>
              <div className="text-[11px] text-slate-500 mt-0.5">
                Available in SQL, Charts & Python
              </div>
            </div>
          </div>

          {/* Active User Requirements List */}
          {userRequirements.length === 0 ? (
            <div className="p-6 text-center border border-dashed border-slate-300 rounded-xl text-xs text-slate-500">
              No custom user requirements applied yet. Type any instruction
              above, click a 1-click template chip, or apply a Senior Analyst
              Playbook from Tab 2 to watch Rexor adapt immediately!
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="text-xs font-bold text-slate-900">
                  Active Requirement Pipeline ({userRequirements.length} Rules)
                </span>
                <button
                  type="button"
                  onClick={dispatchClearAllRequirements}
                  className="text-xs text-red-600 hover:underline cursor-pointer"
                >
                  Reset All Custom Requirements
                </button>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {userRequirements.map((req) => {
                  const impact = ruleExecutionSummary.perRuleImpact[req.id];
                  return (
                    <div
                      key={req.id}
                      className={`p-4 rounded-xl border transition-colors min-w-0 ${
                        req.enabled
                          ? "border-blue-600 bg-blue-50/20"
                          : "border-slate-200 bg-slate-50 opacity-70"
                      }`}
                    >
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0 flex-1">
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <input
                              type="checkbox"
                              checked={req.enabled}
                              onChange={() => dispatchToggleRequirement(req.id)}
                              className="rounded border-slate-300 cursor-pointer"
                            />
                            <span className="font-bold text-slate-900 break-words">
                              {req.title}
                            </span>
                            <span className="text-[11px] font-mono text-slate-500">
                              [{req.ruleType}] · Source: {req.sourceAuthor} ·{" "}
                              {req.createdAt}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 break-words">
                            Instruction: &ldquo;{req.rawInstruction}&rdquo;
                          </p>
                          {impact && req.enabled && (
                            <div className="text-xs font-mono text-emerald-700">
                              Live Impact: {impact.description}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              navigator.clipboard.writeText(
                                req.pythonEquivalent
                              );
                              setCopiedId(req.id);
                              setTimeout(() => setCopiedId(null), 1500);
                            }}
                            className="px-2.5 py-1 text-[11px] font-mono bg-slate-100 hover:bg-slate-200 text-slate-700 rounded flex items-center gap-1 cursor-pointer"
                          >
                            {copiedId === req.id ? (
                              <>
                                <Check className="w-3 h-3" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3 h-3" />
                                <span>Copy pandas</span>
                              </>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => dispatchRemoveRequirement(req.id)}
                            title="Remove requirement"
                            className="p-1.5 text-slate-400 hover:text-red-600 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <div className="mt-3 grid grid-cols-1 lg:grid-cols-2 gap-2.5 text-[11px] font-mono">
                        <div className="p-2.5 rounded bg-slate-900 text-slate-100 overflow-x-auto">
                          <span className="text-slate-400 block mb-0.5">
                            # Python (pandas) Execution:
                          </span>
                          <code>{req.pythonEquivalent}</code>
                        </div>
                        <div className="p-2.5 rounded bg-slate-900 text-slate-100 overflow-x-auto">
                          <span className="text-slate-400 block mb-0.5">
                            -- Warehouse SQL Equivalent:
                          </span>
                          <code>{req.sqlEquivalent}</code>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* =====================================================================
          TAB 2: SENIOR ANALYST ECOSYSTEM KNOWLEDGE VAULT
         ===================================================================== */}
      {activeTab === "ecosystem-vault" && (
        <div className="space-y-4 min-w-0">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-600">
            <span>
              Battle-tested domain heuristics, statistical guardrails, and audit
              playbooks from experienced Principal & Senior Data Analysts in the
              Rexor ecosystem. Click{" "}
              <strong>&ldquo;Apply Analyst Rule to {datasetName}&rdquo;</strong>{" "}
              on any card to execute it live.
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {ecosystemKnowledge.map((item) => {
              const isNewlyLearned = item.id === newlyLearnedId;
              return (
                <div
                  key={item.id}
                  className={`p-4 rounded-xl border flex flex-col justify-between gap-4 min-w-0 transition-all ${
                    isNewlyLearned
                      ? "border-emerald-500 bg-emerald-50/20 ring-1 ring-emerald-500"
                      : "border-slate-200 bg-slate-50/50"
                  }`}
                >
                  <div className="space-y-2.5 min-w-0">
                    <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="font-semibold text-slate-900 flex flex-wrap items-center gap-1.5">
                        {isNewlyLearned && (
                          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase rounded bg-emerald-500 text-slate-950">
                            NEWLY AUTO-LEARNED
                          </span>
                        )}
                        <span>{item.analystName}</span> ·{" "}
                        <span className="text-slate-500 font-normal">
                          {item.analystRole} ({item.experienceYears} yrs exp)
                        </span>
                      </div>
                      <span className="font-mono text-[11px] text-emerald-700">
                        {item.domain}
                      </span>
                    </div>

                    <h3 className="text-sm sm:text-base font-bold text-slate-900 break-words">
                      {item.title}
                    </h3>

                    <div className="text-xs text-slate-600 space-y-1.5 leading-relaxed">
                      <p className="break-words">
                        <strong className="text-slate-900">
                          Real-World Data Trap:
                        </strong>{" "}
                        {item.problemPattern}
                      </p>
                      <p className="break-words">
                        <strong className="text-slate-900">
                          Senior Analyst Heuristic:
                        </strong>{" "}
                        {item.expertHeuristic}
                      </p>
                      <p className="text-[11px] text-slate-500 break-words">
                        <strong>Statistical Proof:</strong>{" "}
                        {item.statisticalRationale}
                      </p>
                    </div>

                    <pre className="p-2.5 rounded-lg bg-slate-900 text-slate-100 text-[11px] font-mono overflow-x-auto">
                      {item.pythonTemplate}
                    </pre>
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => dispatchUpvoteKnowledge(item.id)}
                        className="px-2.5 py-1.5 text-xs font-mono bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg flex items-center gap-1.5 cursor-pointer"
                      >
                        <ThumbsUp className="w-3.5 h-3.5 shrink-0" />
                        <span>Endorse ({item.upvotes})</span>
                      </button>
                      {item.isUserContributed && (
                        <button
                          type="button"
                          onClick={() => dispatchDeleteKnowledge(item.id)}
                          className="p-1.5 text-slate-400 hover:text-red-600 rounded cursor-pointer"
                          title="Delete contributed entry"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    <button
                      type="button"
                      onClick={() => {
                        handleApplyNaturalLanguageRequirement(
                          item.executablePrompt,
                          `${item.analystName} (Ecosystem Playbook)`
                        );
                        setActiveTab("user-requirements");
                      }}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
                    >
                      <Wand2 className="w-3.5 h-3.5 shrink-0" />
                      <span>Apply Analyst Rule to {datasetName}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: TEACH REXOR NEW ANALYST WISDOM (CONTRIBUTE TO ECOSYSTEM)
         ===================================================================== */}
      {activeTab === "teach-rexor" && (
        <form
          onSubmit={handleContributeKnowledge}
          className="p-4 sm:p-5 rounded-xl border border-slate-200 bg-slate-50 space-y-4 min-w-0"
        >
          <div>
            <h3 className="text-sm sm:text-base font-bold text-slate-900">
              Contribute Senior Analyst Domain Knowledge to Rexor’s Permanent
              Memory
            </h3>
            <p className="text-xs text-slate-600 mt-0.5">
              Teach Rexor a domain rule, statistical guardrail, or operational
              audit pattern. Rexor stores this in its Ecosystem Knowledge Vault
              and applies it across future datasets and AI reports.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Analyst Name
              </label>
              <input
                type="text"
                value={analystName}
                onChange={(e) => setAnalystName(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Analyst Role / Title
              </label>
              <input
                type="text"
                value={analystRole}
                onChange={(e) => setAnalystRole(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Industry / Analytics Domain
              </label>
              <input
                type="text"
                value={knowledgeDomain}
                onChange={(e) => setKnowledgeDomain(e.target.value)}
                required
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Years of Analytics Experience
              </label>
              <input
                type="number"
                min={1}
                max={50}
                value={expYears}
                onChange={(e) => setExpYears(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Playbook / Heuristic Title
              </label>
              <input
                type="text"
                value={knowledgeTitle}
                onChange={(e) => setKnowledgeTitle(e.target.value)}
                placeholder="e.g., Weekend Promo Cannibalization & Margin Guardrail"
                required
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Executable Rule Instruction (So Rexor Can Apply It in 1 Click)
              </label>
              <input
                type="text"
                value={executableRuleText}
                onChange={(e) => setExecutableRuleText(e.target.value)}
                placeholder={`e.g., Cap ${
                  numCols[0] || "Prep_Time_Mins"
                } at maximum 30`}
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                What Data Trap or Problem Does This Solve?
              </label>
              <textarea
                rows={3}
                value={problemPattern}
                onChange={(e) => setProblemPattern(e.target.value)}
                placeholder="Describe the common mistake junior analysts make when analyzing this type of data..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Senior Analyst Heuristic & Recommended Methodology
              </label>
              <textarea
                rows={3}
                value={expertHeuristic}
                onChange={(e) => setExpertHeuristic(e.target.value)}
                placeholder="Explain the exact cleaning, statistical, or feature engineering rule Rexor should follow..."
                required
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2 pt-2">
            <button
              type="submit"
              className="px-4 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 shrink-0" />
              <span>Save Analyst Wisdom to Rexor Ecosystem Vault</span>
            </button>
          </div>
        </form>
      )}
    </section>
  );
};
