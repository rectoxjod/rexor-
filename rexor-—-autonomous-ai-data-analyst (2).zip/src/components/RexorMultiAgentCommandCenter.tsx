/**
 * Rexor — Multi-Agent System & Autonomous Enterprise Intelligence Hub
 * Implements:
 * 1. Deterministic Sandboxed Execution (Python pandas/Polars & DuckDB SQL with Self-Healing Loop)
 * 2. Persistent Semantic Memory Layer & Business Glossary
 * 3. Pre-Flight 3-Second Data Hygiene & Sanity Checks
 * 4. 1-Click Read-Only Live Connectors (Google Sheets, Postgres, Shopify, Stripe, Tally, GA4)
 * 5. Proactive "Push" Briefings (Monday 8:00 AM WhatsApp & Slack Text/Voice Briefings)
 * 6. Multi-Table Relational Auto-Join Studio, Target Goal-Seek Solver & Industry Playbooks
 *
 * @author Rushi Chavan
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

import React, { useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Bell,
  BookOpen,
  Check,
  CheckCircle2,
  Copy,
  Cpu,
  Database,
  GitMerge,
  Globe,
  Layers,
  Play,
  Plus,
  RefreshCw,
  ShieldCheck,
  Sliders,
  Sparkles,
  Target,
  Terminal,
  Trash2,
  Volume2,
  VolumeX,
  Zap,
} from "lucide-react";
import {
  CleaningSummary,
  ColumnProfile,
  CorrelationPair,
  DataRow,
  RexorLifecycleReport,
} from "../types/rexor";
import {
  buildProactivePushBriefing,
  DEFAULT_SEMANTIC_GLOSSARY,
  generateConnectorLiveDataset,
  LIVE_CONNECTORS_CATALOG,
  loadSemanticGlossary,
  runDeterministicSandboxQuery,
  runPreFlightSanityCheck,
  runRelationalAutoJoin,
  saveSemanticGlossary,
  SemanticGlossaryEntry,
  solveTargetGoalSeek,
} from "../utils/multiAgentEngine";

interface RexorMultiAgentCommandCenterProps {
  datasetName: string;
  domainContext: string;
  businessQuestion: string;
  rawRows: DataRow[];
  cleanedRows: DataRow[];
  cleaningSummary: CleaningSummary;
  columnProfiles: ColumnProfile[];
  correlations: CorrelationPair[];
  activeReport: RexorLifecycleReport;
  onIngestLiveConnectorData: (payload: {
    datasetName: string;
    domainContext: string;
    businessQuestion: string;
    rows: DataRow[];
  }) => void;
  onApplyIndustryLens: (lens: {
    domainContext: string;
    businessQuestion: string;
    semanticRule?: SemanticGlossaryEntry;
  }) => void;
  onJumpToCleaningStage: () => void;
}

type MultiAgentTab =
  | "preflight"
  | "sandbox"
  | "semantic"
  | "connectors"
  | "briefings"
  | "goalseek-join";

export const RexorMultiAgentCommandCenter: React.FC<
  RexorMultiAgentCommandCenterProps
> = ({
  datasetName,
  rawRows,
  cleanedRows,
  cleaningSummary,
  columnProfiles,
  correlations,
  activeReport,
  onIngestLiveConnectorData,
  onApplyIndustryLens,
  onJumpToCleaningStage,
}) => {
  const [activeTab, setActiveTab] = useState<MultiAgentTab>("sandbox");

  // 1. Semantic Memory state
  const [semanticGlossary, setSemanticGlossary] = useState<
    SemanticGlossaryEntry[]
  >(() => loadSemanticGlossary());
  const [newTerm, setNewTerm] = useState("");
  const [newCategory, setNewCategory] =
    useState<SemanticGlossaryEntry["category"]>("Metric Definition");
  const [newDefinition, setNewDefinition] = useState("");
  const [newFormula, setNewFormula] = useState("");

  // 2. Deterministic Sandbox state
  const [sandboxQuery, setSandboxQuery] = useState(
    "Calculate verified Net Revenue and mean Prep Time / Rating by cohort after enforcing Semantic Memory rules"
  );
  const [sandboxEngine, setSandboxEngine] = useState<
    "Python (pandas + Polars)" | "DuckDB SQL Engine"
  >("Python (pandas + Polars)");
  const [simulateSelfHealing, setSimulateSelfHealing] = useState<boolean>(true);
  const [sandboxRunCount, setSandboxRunCount] = useState<number>(1);
  const [copiedCode, setCopiedCode] = useState(false);

  // 3. Live Connectors state
  const [syncingConnectorId, setSyncingConnectorId] = useState<string | null>(
    null
  );
  const [lastSyncedConnector, setLastSyncedConnector] = useState<string | null>(
    "conn-gsheets"
  );

  // 4. Proactive Push Briefings state
  const [scheduleLabel, setScheduleLabel] = useState<string>(
    "Every Monday at 08:00 AM IST"
  );
  const [whatsappRecipient, setWhatsappRecipient] = useState<string>(
    "+91 98201-XXXXX (Founder Exec Alert)"
  );
  const [slackChannel, setSlackChannel] = useState<string>(
    "#exec-monday-briefings"
  );
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);
  const [copiedBriefType, setCopiedBriefType] = useState<string | null>(null);
  const [pushDispatchNotice, setPushDispatchNotice] = useState<string | null>(
    null
  );

  // 5. Goal-Seek & Auto-Join Studio state
  const [targetLiftPct, setTargetLiftPct] = useState<number>(20);
  const [customFormulaPrompt, setCustomFormulaPrompt] = useState<string>(
    "Net Profit Per Cover = Gross_Profit_INR / Pax"
  );

  // Computed Pre-Flight Sanity Report
  const preFlightReport = useMemo(
    () =>
      runPreFlightSanityCheck(
        rawRows,
        cleanedRows,
        cleaningSummary,
        columnProfiles
      ),
    [rawRows, cleanedRows, cleaningSummary, columnProfiles]
  );

  // Computed Deterministic Sandbox Trace
  const sandboxTrace = useMemo(
    () =>
      runDeterministicSandboxQuery(
        sandboxQuery,
        sandboxEngine,
        simulateSelfHealing,
        rawRows,
        cleanedRows,
        columnProfiles,
        correlations,
        semanticGlossary
      ),
    [
      sandboxQuery,
      sandboxEngine,
      simulateSelfHealing,
      rawRows,
      cleanedRows,
      columnProfiles,
      correlations,
      semanticGlossary,
      sandboxRunCount,
    ]
  );

  // Computed Proactive Push Briefing
  const briefingPayload = useMemo(
    () =>
      buildProactivePushBriefing(
        datasetName,
        cleanedRows,
        cleaningSummary,
        columnProfiles,
        correlations,
        activeReport,
        scheduleLabel
      ),
    [
      datasetName,
      cleanedRows,
      cleaningSummary,
      columnProfiles,
      correlations,
      activeReport,
      scheduleLabel,
    ]
  );

  // Computed Auto-Join Preview & Target Goal-Seek Solution
  const joinPreview = useMemo(
    () => runRelationalAutoJoin(cleanedRows, columnProfiles),
    [cleanedRows, columnProfiles]
  );

  const goalSeekSolution = useMemo(
    () => solveTargetGoalSeek(cleanedRows, columnProfiles, targetLiftPct),
    [cleanedRows, columnProfiles, targetLiftPct]
  );

  const handleAddSemanticEntry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTerm.trim() || !newDefinition.trim()) return;
    const entry: SemanticGlossaryEntry = {
      id: `sem-${Date.now()}`,
      term: newTerm.trim(),
      category: newCategory,
      definition: newDefinition.trim(),
      sqlOrPythonFormula:
        newFormula.trim() ||
        `# Enforced semantic definition for ${newTerm.trim()}`,
      updatedAt: new Date().toISOString().slice(0, 10),
    };
    const updated = [entry, ...semanticGlossary];
    setSemanticGlossary(updated);
    saveSemanticGlossary(updated);
    setNewTerm("");
    setNewDefinition("");
    setNewFormula("");
  };

  const handleDeleteSemanticEntry = (id: string) => {
    const updated = semanticGlossary.filter((item) => item.id !== id);
    setSemanticGlossary(updated);
    saveSemanticGlossary(updated);
  };

  const handleResetSemanticDefaults = () => {
    setSemanticGlossary(DEFAULT_SEMANTIC_GLOSSARY);
    saveSemanticGlossary(DEFAULT_SEMANTIC_GLOSSARY);
  };

  const handleAutoLearnSemanticRule = () => {
    const topCorr = correlations[0];
    const numCols = columnProfiles.filter((c) => c.type === "numeric");
    const catCols = columnProfiles.filter((c) => c.type !== "numeric");
    const primaryCol = topCorr?.colA || numCols[0]?.name || "Net_Revenue_INR";
    const secondaryCol = topCorr?.colB || numCols[1]?.name || "Customer_Rating";
    const cohortCol = catCols[0]?.name || "Outlet_Zone";
    const q3Val =
      columnProfiles.find((c) => c.name === primaryCol)?.q75 ?? 25;

    const entry: SemanticGlossaryEntry = {
      id: `sem-autolearn-${Date.now()}`,
      term: `Auto-Learned ${datasetName} Guardrail (${primaryCol} ↔ ${secondaryCol})`,
      category: "Metric Definition",
      definition: `Auto-learned from ${datasetName}: Cap ${primaryCol} outliers above Q3 (${q3Val}), group by canonical ${cohortCol}, and monitor Pearson r = ${
        topCorr?.r ?? "0.78"
      } against ${secondaryCol}.`,
      sqlOrPythonFormula: `df.groupby("${cohortCol}")["${primaryCol}"].apply(lambda s: s.clip(upper=${q3Val})).mean()`,
      updatedAt: new Date().toISOString().slice(0, 10),
    };
    const updated = [entry, ...semanticGlossary];
    setSemanticGlossary(updated);
    saveSemanticGlossary(updated);
  };

  const handleSyncLiveConnector = (connectorId: string) => {
    setSyncingConnectorId(connectorId);
    window.setTimeout(() => {
      const payload = generateConnectorLiveDataset(connectorId);
      onIngestLiveConnectorData(payload);
      setSyncingConnectorId(null);
      setLastSyncedConnector(connectorId);
    }, 350);
  };

  const handleToggleVoiceBriefing = () => {
    if (typeof window === "undefined" || !("speechSynthesis" in window)) {
      setPushDispatchNotice(
        "Voice transcript generated (Browser SpeechSynthesis unavailable in this tab)."
      );
      return;
    }
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(
      briefingPayload.voiceTranscript
    );
    utterance.rate = 1.02;
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);
    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleCopyText = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBriefType(label);
    window.setTimeout(() => setCopiedBriefType(null), 2000);
  };

  const INDUSTRY_PLAYBOOKS = [
    {
      id: "lens-bistro",
      title: "Hospitality & Bistro POS Audit",
      domainContext: "Multi-Outlet Restaurant & Bistro Operations (INR)",
      question:
        "Audit verified Net Revenue, ASPC, Prep Time vs Customer Rating correlation, and unauthorized post-11AM MORNING10 discounts.",
      badge: "ASPC · Prime Cost · Promo Leakage",
    },
    {
      id: "lens-ecom",
      title: "D2C E-Commerce & Shopify Margin",
      domainContext: "D2C E-Commerce Orders, Discounts & Returns",
      question:
        "Isolate Refunded/Failed orders and identify which SKU cohort and discount code yields the highest Net Contribution Margin.",
      badge: "AOV · Return Rate · Net ROAS",
    },
    {
      id: "lens-saas",
      title: "B2B SaaS Subscription & Churn",
      domainContext: "Enterprise B2B SaaS Telemetry & Net Dollar Retention",
      question:
        "Which account cohort has the highest churn risk and how does support latency correlate with NPS / Customer Rating?",
      badge: "NRR · Logo Churn · LTV:CAC",
    },
    {
      id: "lens-cfo",
      title: "CFO Tally / ERP GST Ledger Audit",
      domainContext: "Corporate Finance & Cost Center Variance Audit",
      question:
        "Deduplicate voucher logs, canonicalize branch names, and rank cost centers by Gross Profit Margin %.",
      badge: "EBITDA · Voucher Audit · COGS %",
    },
  ];

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 space-y-5 min-w-0 max-w-full overflow-x-hidden">
      {/* Top Banner: Pre-Flight 3-Second Sanity Interceptor */}
      <div className="p-4 rounded-xl bg-slate-50 border border-blue-600 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2 py-0.5 text-[11px] font-mono font-bold uppercase rounded bg-blue-600 text-white flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 shrink-0" />
              <span>Pre-Flight Sanity Gate ({preFlightReport.executionTimeMs}ms)</span>
            </span>
            <span className="text-xs font-mono text-blue-600 font-semibold">
              {cleaningSummary.duplicatesRemoved} Duplicates ·{" "}
              {cleaningSummary.missingValuesImputed} Nulls ·{" "}
              {cleaningSummary.outliersAdjusted} Outliers Neutralized
            </span>
          </div>
          <p className="text-xs sm:text-sm font-medium text-slate-900 leading-relaxed break-words">
            {preFlightReport.conversationalInterception}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab("preflight")}
            className="px-3 py-2 text-xs font-semibold bg-slate-100 text-slate-800 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
          >
            Inspect 4-Point Sanity Audit
          </button>
          <button
            type="button"
            onClick={onJumpToCleaningStage}
            className="px-3 py-2 text-xs font-semibold bg-blue-600 text-white hover:bg-blue-700 rounded-lg transition-colors cursor-pointer"
          >
            Configure Stage 3 Hygiene Rules →
          </button>
        </div>
      </div>

      {/* Header & 6 Multi-Agent Architecture Tabs */}
      <div className="flex flex-col gap-4 border-b border-slate-200 pb-4">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div>
            <div className="text-xs font-mono uppercase tracking-wider text-blue-600 font-semibold">
              MULTI-AGENT DETERMINISTIC INTELLIGENCE ARCHITECTURE
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900">
              Zero-Hallucination Sandbox, Semantic Memory, Live Connectors & Push Briefings
            </h2>
          </div>
          <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
            <Cpu className="w-4 h-4 text-blue-600 shrink-0" />
            <span>5 Autonomous Sub-Agents Online</span>
          </div>
        </div>

        {/* Navigation Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          {[
            {
              id: "sandbox",
              label: "1. Deterministic Sandbox (Zero LLM Math)",
              icon: Terminal,
            },
            {
              id: "semantic",
              label: `2. Semantic Memory (${semanticGlossary.length} Rules)`,
              icon: BookOpen,
            },
            {
              id: "preflight",
              label: "3. Pre-Flight Hygiene Gate",
              icon: ShieldCheck,
            },
            {
              id: "connectors",
              label: "4. Live Read-Only Connectors (6)",
              icon: Globe,
            },
            {
              id: "briefings",
              label: "5. Proactive 8AM Push Briefings",
              icon: Bell,
            },
            {
              id: "goalseek-join",
              label: "6. Auto-Join, Goal-Seek & Industry Lenses",
              icon: Target,
            },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => setActiveTab(tab.id as MultiAgentTab)}
                className={`px-3 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all cursor-pointer ${
                  isActive
                    ? "bg-blue-600 text-white"
                    : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* =====================================================================
          TAB 1: DETERMINISTIC SANDBOXED EXECUTION (ZERO MATH HALLUCINATIONS)
         ===================================================================== */}
      {activeTab === "sandbox" && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
            {/* Left 5 Cols: Query Controls & Self-Correction Toggle */}
            <div className="lg:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-mono font-bold text-blue-600 uppercase">
                  Isolated Execution Sandbox
                </span>
                <span className="px-2 py-0.5 text-[11px] font-mono rounded bg-emerald-50 text-emerald-600 border border-emerald-200">
                  0% LLM Mental Math
                </span>
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-900">
                  Analytical Question to Compile & Execute in Sandbox
                </label>
                <textarea
                  rows={2}
                  value={sandboxQuery}
                  onChange={(e) => setSandboxQuery(e.target.value)}
                  className="w-full p-2.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                {(
                  [
                    "Python (pandas + Polars)",
                    "DuckDB SQL Engine",
                  ] as const
                ).map((eng) => (
                  <button
                    key={eng}
                    type="button"
                    onClick={() => setSandboxEngine(eng)}
                    className={`px-3 py-2 text-xs font-mono rounded-lg border text-center cursor-pointer ${
                      sandboxEngine === eng
                        ? "bg-blue-600 text-white border-blue-500 font-bold"
                        : "bg-white text-slate-700 border-slate-300"
                    }`}
                  >
                    {eng}
                  </button>
                ))}
              </div>

              <label className="flex items-start gap-2.5 p-3 rounded-lg bg-white border border-slate-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={simulateSelfHealing}
                  onChange={(e) => setSimulateSelfHealing(e.target.checked)}
                  className="mt-0.5 rounded border-slate-300"
                />
                <div className="text-xs space-y-0.5">
                  <div className="font-semibold text-slate-900">
                    Show Self-Healing Traceback & Auto-Repair Loop
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Demonstrates how Rexor catches raw schema errors (like{" "}
                    <code>₹</code> strings or split outlet names), reads the
                    error log, rewrites the script using Semantic Memory, and
                    returns verified outputs.
                  </p>
                </div>
              </label>

              <button
                type="button"
                onClick={() => setSandboxRunCount((c) => c + 1)}
                className="w-full px-4 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5" />
                <span>
                  Compile & Execute Deterministic Sandbox ({sandboxTrace.executionMs}ms)
                </span>
              </button>

              <div className="pt-2 border-t border-slate-200 space-y-1.5">
                <div className="text-[11px] font-mono text-slate-500 uppercase">
                  Active Semantic Rules Injected into Sandbox:
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {sandboxTrace.semanticRulesApplied.map((r, i) => (
                    <span
                      key={i}
                      className="px-2 py-0.5 text-[11px] font-mono rounded bg-slate-100 border border-slate-300 text-slate-700"
                    >
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right 7 Cols: Self-Healing Trace, Verified Code & Deterministic Output Table */}
            <div className="lg:col-span-7 space-y-4 min-w-0">
              {sandboxTrace.simulateSelfHealingError &&
                sandboxTrace.attempt1ErrorTraceback && (
                  <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 space-y-2">
                    <div className="flex items-center justify-between text-xs font-mono font-bold text-amber-600">
                      <span>
                        ATTEMPT #1 INTERCEPTED · RAW STREAM TRACEBACK CAUGHT
                      </span>
                      <span>AUTO-REPAIRED IN ATTEMPT #2</span>
                    </div>
                    <pre className="p-2.5 rounded bg-slate-950 text-[11px] font-mono text-amber-300 overflow-x-auto whitespace-pre-wrap">
                      {sandboxTrace.attempt1ErrorTraceback}
                    </pre>
                    <p className="text-xs text-slate-700">
                      <strong>Self-Correction Agent:</strong>{" "}
                      {sandboxTrace.selfCorrectionReasoning}
                    </p>
                  </div>
                )}

              <div className="rounded-xl bg-slate-950 border border-slate-800 p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-mono text-blue-400 font-semibold">
                    {sandboxTrace.engineType} · Verified Execution Script
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(sandboxTrace.verifiedCode);
                      setCopiedCode(true);
                      window.setTimeout(() => setCopiedCode(false), 1800);
                    }}
                    className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-800 text-slate-200 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCode ? (
                      <>
                        <Check className="w-3 h-3" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Script</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="text-xs font-mono text-blue-100 overflow-x-auto whitespace-pre leading-relaxed">
                  {sandboxTrace.verifiedCode}
                </pre>
                <div className="pt-2 border-t border-slate-800 space-y-1">
                  {sandboxTrace.deterministicOutputLines.map((line, idx) => (
                    <div
                      key={idx}
                      className="text-[11px] font-mono text-emerald-400"
                    >
                      {line}
                    </div>
                  ))}
                </div>
              </div>

              {/* Verified Output Table */}
              {sandboxTrace.verifiedTable.length > 0 && (
                <div className="border border-slate-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">
                      Deterministic Sandbox Output Table (100% Array-Verified Math)
                    </span>
                    <span className="text-[11px] font-mono text-blue-600">
                      {sandboxTrace.verifiedTable.length} Cohorts
                    </span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b border-slate-200 font-mono text-[11px] text-slate-600">
                          {Object.keys(sandboxTrace.verifiedTable[0]).map(
                            (col) => (
                              <th key={col} className="py-2 px-3">
                                {col}
                              </th>
                            )
                          )}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 font-mono">
                        {sandboxTrace.verifiedTable.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-50">
                            {Object.values(row).map((val, cIdx) => (
                              <td key={cIdx} className="py-2 px-3">
                                {typeof val === "number"
                                  ? val.toLocaleString()
                                  : val}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 2: SEMANTIC MEMORY LAYER (PERSISTENT BUSINESS GLOSSARY)
         ===================================================================== */}
      {activeTab === "semantic" && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
          {/* Left 5 Cols: Teach Rexor a New Company Metric / Quirk */}
          <form
            onSubmit={handleAddSemanticEntry}
            className="lg:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3.5"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-blue-600 uppercase">
                Teach Semantic Memory
              </span>
              <button
                type="button"
                onClick={handleResetSemanticDefaults}
                className="text-[11px] font-mono text-slate-500 hover:underline cursor-pointer"
              >
                Restore Defaults
              </button>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Define your company&apos;s unique metric definitions, fiscal
              calendars, or messy column quirks once. Rexor remembers them
              across sessions and enforces them in every sandbox calculation.
            </p>

            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-900">
                Business Term or Metric Name
              </label>
              <input
                type="text"
                value={newTerm}
                onChange={(e) => setNewTerm(e.target.value)}
                placeholder="e.g., Active Repeat Customer / Prime Cost %"
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-900">
                Semantic Category
              </label>
              <select
                value={newCategory}
                onChange={(e) =>
                  setNewCategory(
                    e.target.value as SemanticGlossaryEntry["category"]
                  )
                }
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
              >
                <option value="Metric Definition">Metric Definition</option>
                <option value="Entity Rule">Entity Rule</option>
                <option value="Fiscal Calendar">Fiscal Calendar</option>
                <option value="Column Quirk">Column Quirk</option>
              </select>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-900">
                Company-Specific Business Logic Definition
              </label>
              <textarea
                rows={2}
                value={newDefinition}
                onChange={(e) => setNewDefinition(e.target.value)}
                placeholder="e.g., Exclude staff meal orders and only count Paid transactions with Pax >= 1..."
                className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-900">
                Deterministic SQL / Python Expression (Optional)
              </label>
              <input
                type="text"
                value={newFormula}
                onChange={(e) => setNewFormula(e.target.value)}
                placeholder="e.g., (COGS_INR + Labor_Cost) / Net_Revenue_INR * 100"
                className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg"
              />
            </div>

            <button
              type="submit"
              className="w-full px-4 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Save to Persistent Semantic Memory</span>
            </button>
          </form>

          {/* Right 7 Cols: Active Semantic Glossary Cards */}
          <div className="lg:col-span-7 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-sm font-bold text-slate-900">
                Active Company Semantic Glossary ({semanticGlossary.length} Rules)
              </h3>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAutoLearnSemanticRule}
                  className="px-3 py-1.5 text-xs font-bold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#39FF14]" />
                  <span>Auto-Learn Rule from {datasetName}</span>
                </button>
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3">
              {semanticGlossary.map((entry) => (
                <div
                  key={entry.id}
                  className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2"
                >
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-bold text-slate-900">
                        {entry.term}
                      </span>
                      <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-blue-50 text-blue-600 border border-blue-200">
                        {entry.category}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDeleteSemanticEntry(entry.id)}
                      className="text-xs text-slate-400 hover:text-red-600 cursor-pointer"
                      title="Remove rule from Semantic Memory"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {entry.definition}
                  </p>
                  <div className="p-2 rounded bg-slate-950 text-[11px] font-mono text-blue-300 overflow-x-auto">
                    {entry.sqlOrPythonFormula}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 3: PRE-FLIGHT DATA HYGIENE & SANITY CHECKS
         ===================================================================== */}
      {activeTab === "preflight" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {preFlightReport.checks.map((chk) => (
              <div
                key={chk.id}
                className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-sm font-bold text-slate-900">
                    {chk.label}
                  </span>
                  <span
                    className={`px-2 py-0.5 text-[11px] font-mono font-bold rounded ${
                      chk.status === "PASS"
                        ? "bg-emerald-50 text-emerald-600 border border-emerald-200"
                        : "bg-amber-50 text-amber-600 border border-amber-200"
                    }`}
                  >
                    {chk.metricBadge}
                  </span>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {chk.detail}
                </p>
                <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-[11px] font-mono text-blue-600">
                  <span>Guardrail: {chk.remediationAction}</span>
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 4: LIVE READ-ONLY CONNECTORS (BEYOND FILE UPLOADS)
         ===================================================================== */}
      {activeTab === "connectors" && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <p className="text-xs text-slate-600">
              Eliminate manual morning CSV exports. Connect read-only streams
              from Google Sheets, PostgreSQL, Shopify, Stripe, TallyPrime, or
              GA4 with automatic Pre-Flight Sanity validation.
            </p>
            <span className="text-xs font-mono text-blue-600 shrink-0">
              TLS 1.3 Read-Only Guardrails Active
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {LIVE_CONNECTORS_CATALOG.map((conn) => {
              const isSyncing = syncingConnectorId === conn.id;
              const isCurrent = lastSyncedConnector === conn.id;
              return (
                <div
                  key={conn.id}
                  className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-4 ${
                    isCurrent
                      ? "border-blue-600 bg-blue-50/20"
                      : "border-slate-200 bg-slate-50"
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] font-mono text-blue-600 font-semibold">
                        {conn.category}
                      </span>
                      <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-50 text-emerald-600 border border-emerald-200">
                        {conn.latencyMs}ms · {conn.status}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {conn.name}
                    </h3>
                    <p className="text-xs text-slate-600 leading-relaxed">
                      {conn.description}
                    </p>
                    <div className="p-2 rounded bg-slate-950 text-[10px] font-mono text-slate-300 truncate">
                      {conn.sampleEndpoint}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => handleSyncLiveConnector(conn.id)}
                    disabled={isSyncing}
                    className="w-full px-3 py-2 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isSyncing ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        <span>Syncing Live Read-Only Stream...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3.5 h-3.5" />
                        <span>1-Click Sync Live Stream ({conn.previewRowCount} rows)</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 5: PROACTIVE "PUSH" BRIEFINGS (NO-PROMPT ANALYTICS)
         ===================================================================== */}
      {activeTab === "briefings" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* Left 5 Cols: Schedule & Audio Voice Controls */}
            <div className="lg:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-blue-600 uppercase">
                  Autonomous Push Scheduler
                </span>
                <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-50 text-emerald-600 border border-emerald-200">
                  CRON ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Instead of waiting for a busy founder to log in and type a
                prompt, Rexor runs scheduled background checks and dispatches a
                verified WhatsApp or Slack voice/text brief with root-cause
                drivers and 2 recommended fixes.
              </p>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-900">
                  Background Check Schedule
                </label>
                <select
                  value={scheduleLabel}
                  onChange={(e) => setScheduleLabel(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg"
                >
                  <option value="Every Monday at 08:00 AM IST">
                    Every Monday at 08:00 AM IST (Weekly Executive Pulse)
                  </option>
                  <option value="Daily at 07:30 AM IST">
                    Daily at 07:30 AM IST (Morning Outlet Standup)
                  </option>
                  <option value="Real-Time on >10% Cohort Drop">
                    Real-Time Anomaly Push (Trigger on &gt;10% Drop)
                  </option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-900">
                  WhatsApp Executive Recipient
                </label>
                <input
                  type="text"
                  value={whatsappRecipient}
                  onChange={(e) => setWhatsappRecipient(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-900">
                  Slack Channel Target
                </label>
                <input
                  type="text"
                  value={slackChannel}
                  onChange={(e) => setSlackChannel(e.target.value)}
                  className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                />
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleToggleVoiceBriefing}
                  className="flex-1 px-3 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-4 h-4" />
                      <span>Stop Voice Note</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4" />
                      <span>Play 8:00 AM Voice Briefing</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setPushDispatchNotice(
                      `Dispatched verified morning briefing to ${whatsappRecipient} and ${slackChannel} (${scheduleLabel}).`
                    )
                  }
                  className="px-3 py-2.5 text-xs font-semibold bg-slate-200 text-slate-800 rounded-lg cursor-pointer"
                >
                  Simulate Push Now
                </button>
              </div>

              {pushDispatchNotice && (
                <div className="p-2.5 rounded-lg bg-emerald-50 border border-emerald-200 text-xs text-emerald-600">
                  {pushDispatchNotice}
                </div>
              )}
            </div>

            {/* Right 7 Cols: WhatsApp & Slack Live Preview Cards */}
            <div className="lg:col-span-7 space-y-4">
              {/* WhatsApp Brief Preview */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    WhatsApp Executive Briefing Preview ({whatsappRecipient})
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyText(
                        briefingPayload.whatsappMessage,
                        "whatsapp"
                      )
                    }
                    className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-200 text-slate-800 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedBriefType === "whatsapp" ? (
                      <>
                        <Check className="w-3 h-3" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy WhatsApp Brief</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-3 rounded-lg bg-slate-950 text-xs font-mono text-blue-100 whitespace-pre-wrap leading-relaxed">
                  {briefingPayload.whatsappMessage}
                </pre>
              </div>

              {/* Slack Block Kit Preview */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-900">
                    Slack Channel Alert Preview ({slackChannel})
                  </span>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyText(briefingPayload.slackBlocksText, "slack")
                    }
                    className="px-2.5 py-1 text-[11px] font-mono rounded bg-slate-200 text-slate-800 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedBriefType === "slack" ? (
                      <>
                        <Check className="w-3 h-3" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3 h-3" />
                        <span>Copy Slack Alert</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="p-3 rounded-lg bg-slate-950 text-xs font-mono text-blue-100 whitespace-pre-wrap leading-relaxed">
                  {briefingPayload.slackBlocksText}
                </pre>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =====================================================================
          TAB 6: AUTO-JOIN STUDIO, TARGET GOAL-SEEK & INDUSTRY PLAYBOOK LENSES
         ===================================================================== */}
      {activeTab === "goalseek-join" && (
        <div className="space-y-6">
          {/* Row 1: Target Goal-Seek Reverse ROI Solver */}
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <div className="text-xs font-mono text-blue-600 font-semibold uppercase">
                  REVERSE ROI & TARGET GOAL-SEEK SOLVER
                </div>
                <h3 className="text-base font-bold text-slate-900">
                  Reverse-Engineer Exact Cohort Targets to Hit Your Next Revenue / Profit Goal
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-slate-600">
                  Target Lift: +{targetLiftPct}%
                </span>
                <input
                  type="range"
                  min={5}
                  max={50}
                  step={5}
                  value={targetLiftPct}
                  onChange={(e) => setTargetLiftPct(Number(e.target.value))}
                  className="w-32 cursor-pointer"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
              <div className="p-3 rounded-lg bg-white border border-slate-200">
                <div className="text-[11px] font-mono text-slate-500">
                  Current Verified {goalSeekSolution.metricName}
                </div>
                <div className="text-lg font-bold font-mono text-slate-900">
                  {goalSeekSolution.currentBaseline.toLocaleString()}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-white border border-slate-200">
                <div className="text-[11px] font-mono text-slate-500">
                  Target Goal (+{goalSeekSolution.deltaPct}%)
                </div>
                <div className="text-lg font-bold font-mono text-blue-600">
                  {goalSeekSolution.targetGoal.toLocaleString()}
                </div>
              </div>
              <div className="p-3 rounded-lg bg-white border border-slate-200">
                <div className="text-[11px] font-mono text-slate-500">
                  Required Volume Lift
                </div>
                <div className="text-lg font-bold font-mono text-emerald-600">
                  +{goalSeekSolution.requiredVolumeLiftPct}% Covers/Orders
                </div>
              </div>
              <div className="p-3 rounded-lg bg-white border border-slate-200">
                <div className="text-[11px] font-mono text-slate-500">
                  Leakage & Margin Recovery
                </div>
                <div className="text-lg font-bold font-mono text-slate-900">
                  +{goalSeekSolution.requiredLeakageRecovery.toLocaleString()}
                </div>
              </div>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-lg">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 font-mono text-[11px] text-slate-600">
                    <th className="py-2 px-3">Cohort / Outlet</th>
                    <th className="py-2 px-3">Current Baseline</th>
                    <th className="py-2 px-3">Goal-Seek Target</th>
                    <th className="py-2 px-3">Gap to Close</th>
                    <th className="py-2 px-3">Required Operational Levers</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-mono">
                  {goalSeekSolution.cohortBreakdown.map((item, i) => (
                    <tr key={i}>
                      <td className="py-2 px-3 font-bold text-slate-900">
                        {item.cohort}
                      </td>
                      <td className="py-2 px-3">
                        {item.currentVal.toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-blue-600 font-bold">
                        {item.targetVal.toLocaleString()}
                      </td>
                      <td className="py-2 px-3 text-emerald-600">
                        +{item.gapToClose.toLocaleString()}
                      </td>
                      <td className="py-2 px-3 font-sans text-slate-600">
                        {item.actionLevers}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Row 2: Multi-Table Relational Auto-Join Studio + 1-Click Industry Lenses */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-start">
            {/* Auto-Join Studio (7 Cols) */}
            <div className="lg:col-span-7 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <GitMerge className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-bold text-slate-900">
                    Multi-Table Auto-Join & VLOOKUP Sanity Studio
                  </span>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-emerald-50 text-emerald-600 border border-emerald-200">
                  {joinPreview.explosionFactor.toFixed(1)}x Cardinality (Zero Row Explosion)
                </span>
              </div>
              <p className="text-xs text-slate-600">
                Joined active dataset ({joinPreview.leftRows} rows) with{" "}
                <code>{joinPreview.lookupTableName}</code> on canonical key{" "}
                <code>{joinPreview.joinKey}</code> ({joinPreview.matchedCount}{" "}
                matched, {joinPreview.orphanCount} orphans).
              </p>
              <div className="overflow-x-auto border border-slate-200 rounded-lg">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-200 font-mono text-[11px] text-slate-600">
                      <th className="py-2 px-2.5">{joinPreview.joinKey}</th>
                      <th className="py-2 px-2.5">Regional_Manager</th>
                      <th className="py-2 px-2.5">Tier_Classification</th>
                      <th className="py-2 px-2.5">Monthly_Target</th>
                      <th className="py-2 px-2.5">SLA_Prep_Cap</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-mono">
                    {joinPreview.sampleJoinedRows.map((r, idx) => (
                      <tr key={idx}>
                        <td className="py-1.5 px-2.5 font-bold">
                          {r[joinPreview.joinKey]}
                        </td>
                        <td className="py-1.5 px-2.5">{r.Regional_Manager}</td>
                        <td className="py-1.5 px-2.5">
                          {r.Tier_Classification}
                        </td>
                        <td className="py-1.5 px-2.5">
                          {Number(r.Monthly_Target_INR).toLocaleString()}
                        </td>
                        <td className="py-1.5 px-2.5">
                          {r.SLA_Prep_Cap_Mins} mins
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* 1-Click Industry Playbook Lenses (5 Cols) */}
            <div className="lg:col-span-5 p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="text-xs font-mono font-bold text-blue-600 uppercase">
                1-Click Industry Playbook Lenses
              </div>
              <div className="space-y-2">
                {INDUSTRY_PLAYBOOKS.map((lens) => (
                  <button
                    key={lens.id}
                    type="button"
                    onClick={() =>
                      onApplyIndustryLens({
                        domainContext: lens.domainContext,
                        businessQuestion: lens.question,
                      })
                    }
                    className="w-full text-left p-3 rounded-lg bg-white border border-slate-200 hover:border-blue-600 transition-colors cursor-pointer space-y-1"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-900">
                        {lens.title}
                      </span>
                      <span className="text-[10px] font-mono text-blue-600">
                        {lens.badge}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-600 line-clamp-2">
                      {lens.question}
                    </p>
                  </button>
                ))}
              </div>

              <div className="pt-2 border-t border-slate-200 space-y-1.5">
                <label className="block text-[11px] font-mono text-slate-500">
                  Natural-Language Formula Builder:
                </label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    value={customFormulaPrompt}
                    onChange={(e) => setCustomFormulaPrompt(e.target.value)}
                    className="flex-1 px-2.5 py-1.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const entry: SemanticGlossaryEntry = {
                        id: `sem-nl-${Date.now()}`,
                        term:
                          customFormulaPrompt.split("=")[0]?.trim() ||
                          "Custom Formula",
                        category: "Metric Definition",
                        definition: `Compiled from natural-language formula builder: ${customFormulaPrompt}`,
                        sqlOrPythonFormula: customFormulaPrompt,
                        updatedAt: new Date().toISOString().slice(0, 10),
                      };
                      const next = [entry, ...semanticGlossary];
                      setSemanticGlossary(next);
                      saveSemanticGlossary(next);
                      setActiveTab("semantic");
                    }}
                    className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                  >
                    Add Rule
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
