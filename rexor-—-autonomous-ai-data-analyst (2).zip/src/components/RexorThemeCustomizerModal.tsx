/**
 * Rexor — Full-Spectrum Chameleon Theme & Custom Color Studio Modal
 * Lets users pick from 18 Signature Themes or customize the exact color of
 * every UI layer (Buttons/Charts, Secondary Highlights, Headings, Body Text,
 * Main Background, Cards, Elevated Boxes, and Borders).
 *
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

import React, { useState } from "react";
import {
  Check,
  Palette,
  RotateCcw,
  Sliders,
  Sparkles,
  Wand2,
  X,
} from "lucide-react";
import {
  generateRandomCoolTheme,
  REXOR_SIGNATURE_THEMES,
  RexorThemeConfig,
} from "../utils/themeEngine";

interface RexorThemeCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTheme: RexorThemeConfig;
  onSelectTheme: (theme: RexorThemeConfig) => void;
}

const QUICK_SWATCHES = [
  "#2563EB",
  "#38BDF8",
  "#10B981",
  "#8B5CF6",
  "#EC4899",
  "#E11D48",
  "#F97316",
  "#F59E0B",
  "#84CC16",
  "#06B6D4",
  "#6366F1",
  "#F43F5E",
];

export const RexorThemeCustomizerModal: React.FC<
  RexorThemeCustomizerModalProps
> = ({ isOpen, onClose, activeTheme, onSelectTheme }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("ALL");

  if (!isOpen) return null;

  const categories = [
    "ALL",
    "Dark Metallic & Cyber",
    "Vibrant Neon & Multi-Color",
    "Luxury & Executive",
    "Crisp Daylight Boardroom",
  ];

  const filteredPresets =
    selectedCategory === "ALL"
      ? REXOR_SIGNATURE_THEMES
      : REXOR_SIGNATURE_THEMES.filter((t) => t.category === selectedCategory);

  const handleCustomColorChange = (
    field: keyof Pick<
      RexorThemeConfig,
      | "accentPrimary"
      | "accentSecondary"
      | "headingColor"
      | "bodyTextColor"
      | "bgMain"
      | "bgCard"
      | "bgElevated"
      | "borderColor"
    >,
    value: string
  ) => {
    onSelectTheme({
      ...activeTheme,
      id: "custom-user-theme",
      name: "Custom User Color Mix",
      badge: "Personalized Palette",
      [field]: value,
    });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-3 sm:px-6 py-6 overflow-y-auto"
      onClick={onClose}
    >
      <div
        className="bg-white border border-slate-200 rounded-2xl max-w-5xl w-full p-5 sm:p-6 space-y-6 max-h-[92vh] overflow-y-auto shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-blue-600" />
              <span className="text-xs font-mono uppercase tracking-wider text-blue-600 font-bold">
                REXOR CHAMELEON THEME & FULL-SPECTRUM COLOR STUDIO
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
              Customize Every Color of Rexor or Choose a Signature Theme
            </h2>
            <p className="text-xs text-slate-600">
              Change the color of buttons, charts, headings, tables, cards, and
              backgrounds to match your company brand or presentation mood.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onSelectTheme(generateRandomCoolTheme())}
              className="px-3 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center gap-1.5 cursor-pointer"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span>AI Randomize Cool Palette</span>
            </button>
            <button
              type="button"
              onClick={() => onSelectTheme(REXOR_SIGNATURE_THEMES[0])}
              className="px-3 py-2 text-xs font-medium bg-slate-100 text-slate-800 rounded-lg flex items-center gap-1.5 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Default</span>
            </button>
            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-500 hover:text-slate-900 rounded-lg bg-slate-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* =================================================================
            SECTION 1: FREESTYLE PER-ELEMENT COLOR MIXER (CUSTOMIZE ANYTHING)
           ================================================================= */}
        <div className="p-4 sm:p-5 rounded-xl bg-slate-50 border border-slate-200 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-blue-600" />
              <h3 className="text-sm font-bold text-slate-900">
                1. Freestyle Per-Element Color Mixer (Pick Any Color for Any Layer)
              </h3>
            </div>
            <span className="text-xs font-mono text-blue-600">
              Active Theme: {activeTheme.name} ({activeTheme.badge})
            </span>
          </div>

          {/* Quick 1-Click Primary Accent Swatches */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-mono text-slate-500">
              Instant Accent Color:
            </span>
            {QUICK_SWATCHES.map((hex) => (
              <button
                key={hex}
                type="button"
                onClick={() => {
                  onSelectTheme({
                    ...activeTheme,
                    id: "custom-swatch",
                    name: `Custom ${hex} Accent`,
                    accentPrimary: hex,
                    accentSecondary: hex,
                    headingColor: hex,
                    borderColor: hex,
                  });
                }}
                title={`Apply ${hex} accent`}
                className="w-6 h-6 rounded-full border-2 border-white shadow cursor-pointer transition-transform hover:scale-110"
                style={{ backgroundColor: hex }}
              />
            ))}
          </div>

          {/* 8 Individual Layer Color Pickers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              {
                key: "accentPrimary" as const,
                label: "Primary Buttons & Chart Bars",
                val: activeTheme.accentPrimary,
              },
              {
                key: "accentSecondary" as const,
                label: "Secondary Highlights & Badges",
                val: activeTheme.accentSecondary,
              },
              {
                key: "headingColor" as const,
                label: "Headings & Big KPI Numbers",
                val: activeTheme.headingColor,
              },
              {
                key: "bodyTextColor" as const,
                label: "Body Text & Data Tables",
                val: activeTheme.bodyTextColor,
              },
              {
                key: "bgMain" as const,
                label: "Main App Canvas Background",
                val: activeTheme.bgMain,
              },
              {
                key: "bgCard" as const,
                label: "Primary Cards & Panels",
                val: activeTheme.bgCard,
              },
              {
                key: "bgElevated" as const,
                label: "Inner Boxes & Inputs",
                val: activeTheme.bgElevated,
              },
              {
                key: "borderColor" as const,
                label: "Borders & Glow Outlines",
                val: activeTheme.borderColor,
              },
            ].map((item) => (
              <label
                key={item.key}
                className="p-3 rounded-xl bg-white border border-slate-200 flex items-center justify-between gap-2 cursor-pointer"
              >
                <div className="min-w-0">
                  <div className="text-xs font-bold text-slate-900 truncate">
                    {item.label}
                  </div>
                  <div className="text-[11px] font-mono text-slate-500">
                    {item.val.toUpperCase()}
                  </div>
                </div>
                <input
                  type="color"
                  value={item.val}
                  onChange={(e) =>
                    handleCustomColorChange(item.key, e.target.value)
                  }
                  className="w-9 h-9 rounded-lg border border-slate-300 cursor-pointer shrink-0 p-0.5 bg-transparent"
                />
              </label>
            ))}
          </div>
        </div>

        {/* =================================================================
            SECTION 2: 18 SIGNATURE DESIGNER & ENTERPRISE THEMES
           ================================================================= */}
        <div className="space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-sm font-bold text-slate-900">
              2. Or Choose from 18 Signature Full-Spectrum Themes
            </h3>
            <div className="flex flex-wrap items-center gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 text-xs font-mono rounded-lg cursor-pointer ${
                    selectedCategory === cat
                      ? "bg-blue-600 text-white font-bold"
                      : "bg-slate-100 text-slate-600"
                  }`}
                >
                  {cat === "ALL" ? "All 18 Themes" : cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {filteredPresets.map((theme) => {
              const isSelected = activeTheme.id === theme.id;
              return (
                <button
                  key={theme.id}
                  type="button"
                  onClick={() => onSelectTheme(theme)}
                  className={`text-left p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 cursor-pointer ${
                    isSelected
                      ? "border-blue-600 bg-blue-50/30"
                      : "border-slate-200 bg-slate-50 hover:border-blue-600"
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-mono text-slate-500">
                        {theme.category}
                      </span>
                      {isSelected && (
                        <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-blue-600 text-white flex items-center gap-1">
                          <Check className="w-3 h-3" />
                          <span>ACTIVE</span>
                        </span>
                      )}
                    </div>
                    <div className="text-sm font-bold text-slate-900">
                      {theme.name}
                    </div>
                    <div className="text-xs text-slate-500">{theme.badge}</div>
                  </div>

                  {/* Multi-Color Swatch Strip Preview */}
                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      {[
                        theme.bgMain,
                        theme.bgCard,
                        theme.accentPrimary,
                        theme.accentSecondary,
                        theme.headingColor,
                      ].map((hex, i) => (
                        <span
                          key={i}
                          className="w-5 h-5 rounded-full border border-white/40 shadow-sm"
                          style={{ backgroundColor: hex }}
                          title={hex}
                        />
                      ))}
                    </div>
                    <span className="text-xs font-semibold text-blue-600">
                      Apply Theme →
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Your custom theme and colors are automatically saved to your browser.
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
          >
            Done & Apply Colors
          </button>
        </div>
      </div>
    </div>
  );
};
