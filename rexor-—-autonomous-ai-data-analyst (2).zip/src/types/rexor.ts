export type DataRow = Record<string, any>;

export type ColumnType = "numeric" | "categorical" | "date" | "boolean";

export interface ColumnProfile {
  name: string;
  type: ColumnType;
  rawCount: number;
  missingCount: number;
  missingPct: number;
  uniqueCount: number;
  sum?: number;
  mean?: number;
  median?: number;
  stdDev?: number;
  min?: number;
  max?: number;
  q25?: number;
  q75?: number;
  iqr?: number;
  outlierCount?: number;
  topCategories?: { value: string; count: number; pct: number }[];
  sampleValues: string[];
}

export interface CleaningOptions {
  removeDuplicates: boolean;
  imputeMissingNumeric: "median" | "mean" | "zero" | "drop";
  imputeMissingCategorical: "mode" | "unknown";
  normalizeFormats: boolean;
  capOutliers: boolean;
}

export interface RemediationLogEntry {
  id: string;
  rowIndex: number;
  column: string;
  issueType:
    | "Missing Value"
    | "Duplicate Row"
    | "Format Normalization"
    | "Outlier Capped"
    | "Status Isolation";
  originalValue: string;
  cleanedValue: string;
  ruleApplied: string;
}

export interface CleaningSummary {
  rawRowCount: number;
  cleanedRowCount: number;
  duplicatesRemoved: number;
  invalidStatusIsolated?: number;
  missingValuesImputed: number;
  formatsNormalized: number;
  outliersAdjusted: number;
  dataHealthBefore: number;
  dataHealthAfter: number;
  logs: RemediationLogEntry[];
}

export interface CorrelationPair {
  colA: string;
  colB: string;
  r: number;
  strength: "Strong Positive" | "Moderate Positive" | "Weak" | "Moderate Negative" | "Strong Negative";
}

export interface RexorLifecycleReport {
  stage1ProblemFraming: {
    refinedQuestion: string;
    decisionStakeholders: string;
    primaryObjectiveMetric: string;
    hypotheses: {
      id: string;
      statement: string;
      rationale: string;
      validationStatus: string;
      evidenceMetric: string;
    }[];
  };
  stage3CleaningAssessment: {
    dataReliabilityScore: number;
    structuralRisksResolved: string;
    schemaRecommendations: string[];
  };
  stage4AnalyticalFindings: {
    executiveSummary: string;
    keyInsights: {
      title: string;
      category: string;
      quantifiedFinding: string;
      businessImplication: string;
    }[];
    sqlQueries: {
      title: string;
      purpose: string;
      sql: string;
      expectedOutputSummary: string;
    }[];
    pythonSnippet: string;
  };
  stage5VisualNarrative: {
    dashboardHeadline: string;
    storylineTakeaways: string[];
    recommendedChartConfigs: {
      chartTitle: string;
      chartType: string;
      xColumn: string;
      yColumn: string;
      insightAnnotation: string;
    }[];
  };
  stage6ActionPlan: {
    recommendations: {
      priority: string;
      actionTitle: string;
      targetSegmentOrVariable: string;
      concreteMechanism: string;
      quantifiedExpectedImpact: string;
      effortLevel: string;
      measurementKpi: string;
    }[];
    measurementFramework: {
      kpiName: string;
      baselineValue: string;
      target30Day: string;
      target90Day: string;
      trackingCadence: string;
    }[];
  };
}

export interface SampleDatasetPreset {
  id: string;
  name: string;
  sourceType: "PostgreSQL Dump" | "Excel Workbook" | "REST API Stream" | "CRM Export" | "CSV Upload";
  domainContext: string;
  defaultBusinessQuestion: string;
  description: string;
  rawCsv: string;
}

export interface AskRexorResponse {
  question: string;
  timestamp: string;
  directAnswer: string;
  sqlQuery: string;
  pythonCode: string;
  recommendedAction: string;
}

export type ValidationIssueType =
  | "EMPTY_FILE"
  | "MISSING_HEADER_ROW"
  | "MALFORMED_DELIMITERS";

export type DelimiterChoice = "auto" | "," | "\t" | ";" | "|";

export interface ValidationIssue {
  type: ValidationIssueType;
  severity: "critical" | "warning";
  title: string;
  description: string;
  diagnosticDetail: string;
  suggestedAction: string;
  affectedLines?: number[];
  sampleOffendingValues?: string[];
}

export interface FileValidationResult {
  fileName: string;
  fileSizeBytes: number;
  fileFormat: "csv" | "tsv" | "json" | "excel" | "text";
  isValidToAutoIngest: boolean;
  canRecoverAndIngest: boolean;
  detectedDelimiter: "," | "\t" | ";" | "|";
  rawText?: string;
  rawMatrix?: string[][];
  issues: ValidationIssue[];
  parsedRows: DataRow[];
  previewHeaders: string[];
}

