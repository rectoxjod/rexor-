/**
 * Rexor — Autonomous AI Data Analyst Suite
 * @author Rushi Chavan
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowRight,
  Check,
  Copy,
  Database,
  Download,
  FileSpreadsheet,
  Filter,
  Globe,
  HelpCircle,
  Keyboard,
  Lock,
  MessageSquare,
  Palette,
  Play,
  RefreshCw,
  RotateCcw,
  Search,
  ShieldCheck,
  Sliders,
  Sparkles,
  Terminal,
  Upload,
} from "lucide-react";
import { RexorSideChat } from "./components/RexorSideChat";
import {
  RexorShortcutsModal,
  ShortcutCommandItem,
} from "./components/RexorShortcutsModal";
import { SAMPLE_DATASETS } from "./data/sampleDatasets";
import {
  AskRexorResponse,
  CleaningOptions,
  ColumnType,
  DataRow,
  DelimiterChoice,
  FileValidationResult,
  RexorLifecycleReport,
} from "./types/rexor";
import {
  buildDataGroundedLifecycleReport,
  cleanAndPrepareDataset,
  computeColumnProfiles,
  computeCorrelations,
  executeDeterministicTaskAgainstDataset,
  executeGroupByAggregation,
  parseDelimitedText,
  parseUploadedFile,
  validateRawDatasetInput,
  validateUploadedDatasetFile,
} from "./utils/dataEngine";
import {
  InteractiveBarChart,
  InteractiveHistogram,
  InteractiveScatterPlot,
} from "./components/InteractiveCharts";
import { AdvancedAnalyticsSuite } from "./components/AdvancedAnalyticsSuite";
import { RexorPythonStudio } from "./components/RexorPythonStudio";
import {
  RexorEnterpriseCommandSuite,
  WorkspaceSnapshot,
} from "./components/RexorEnterpriseCommandSuite";
import { PreIngestionValidationModal } from "./components/PreIngestionValidationModal";
import { DatasetExportModal } from "./components/DatasetExportModal";
import { RexorAdaptiveKnowledgeHub } from "./components/RexorAdaptiveKnowledgeHub";
import { RexorMultiAgentCommandCenter } from "./components/RexorMultiAgentCommandCenter";
import { RexorBiTemplateStudio } from "./components/RexorBiTemplateStudio";
import { RexorThemeCustomizerModal } from "./components/RexorThemeCustomizerModal";
import { RexorUniversalTaskSolverBar } from "./components/RexorUniversalTaskSolverBar";
import { RexorIndustryAssignmentStudio } from "./components/RexorIndustryAssignmentStudio";
import {
  applyThemeToDocument,
  loadSavedThemeConfig,
  RexorThemeConfig,
  saveThemeConfig,
} from "./utils/themeEngine";
import { SOVEREIGN_SECURITY_MANIFEST } from "./utils/biTemplatesCatalog";
import {
  generateConnectorLiveDataset,
  LIVE_CONNECTORS_CATALOG,
} from "./utils/multiAgentEngine";
import {
  AdaptiveUserRequirement,
  compileUserRequirementToRule,
  EcosystemAnalystKnowledge,
  executeAdaptiveRulesOnRows,
  loadEcosystemKnowledge,
  loadSavedUserRequirements,
  saveEcosystemKnowledge,
  saveUserRequirements,
} from "./utils/adaptiveEngine";
import { downloadExecutiveBoardDeckPdf } from "./utils/pdfExporter";

type ActiveView =
  | "overview"
  | "problem-data"
  | "cleaning"
  | "analysis"
  | "visuals-actions"
  | "bi-studio"
  | "high-friction-agents"
  | "industry-assignment";

type IngestionSourceTab = "presets" | "upload" | "paste" | "api";

export default function App() {
  // Fresh-start state: On every refresh or restart, start on the Upload / Select Dataset Launchpad
  const [hasActiveDataset, setHasActiveDataset] = useState<boolean>(false);

  // Active navigation view & AI Guide Side Chat state
  const [activeView, setActiveView] = useState<ActiveView>("overview");
  const [isSideChatOpen, setIsSideChatOpen] = useState<boolean>(true);
  const [newbieGuideMode, setNewbieGuideMode] = useState<boolean>(true);
  const [newbieStep, setNewbieStep] = useState<number>(0);
  const [showLicenseModal, setShowLicenseModal] = useState<boolean>(false);
  const [showDataModal, setShowDataModal] = useState<boolean>(false);
  const [showExportModal, setShowExportModal] = useState<boolean>(false);
  const [showShortcutsModal, setShowShortcutsModal] = useState<boolean>(false);
  const [showThemeModal, setShowThemeModal] = useState<boolean>(false);
  const [activeTheme, setActiveTheme] = useState<RexorThemeConfig>(() =>
    loadSavedThemeConfig()
  );
  const [shortcutToast, setShortcutToast] = useState<string | null>(null);

  useEffect(() => {
    applyThemeToDocument(activeTheme);
    saveThemeConfig(activeTheme);
  }, [activeTheme]);

  // Stage 1 & 2 state: Dataset & Business Problem
  const [selectedPresetId, setSelectedPresetId] = useState<string>("");
  const [datasetName, setDatasetName] = useState<string>(
    SAMPLE_DATASETS[0].name
  );
  const [domainContext, setDomainContext] = useState<string>(
    SAMPLE_DATASETS[0].domainContext
  );
  const [businessQuestion, setBusinessQuestion] = useState<string>(
    SAMPLE_DATASETS[0].defaultBusinessQuestion
  );
  const [rawRows, setRawRows] = useState<DataRow[]>(() =>
    parseDelimitedText(SAMPLE_DATASETS[0].rawCsv)
  );

  // Clear any stale cached session on fresh load so refresh always prompts for Upload / Dataset selection
  useEffect(() => {
    try {
      localStorage.removeItem("rexor_active_session_v2");
    } catch {
      // ignore
    }
  }, []);

  // Reset Everything handler — Wipes active dataset, custom rules, filters, and returns to Upload / Select Dataset Launchpad
  const handleResetEverything = () => {
    try {
      localStorage.removeItem("rexor_active_session_v2");
      localStorage.removeItem("rexor_user_requirements_v1");
    } catch {
      // ignore
    }
    setHasActiveDataset(false);
    setSelectedPresetId("");
    setUserRequirements([]);
    setAiReport(null);
    setQaHistory([]);
    setPasteInput("");
    setTableSearch("");
    setRemediationFilter("ALL");
    setActiveView("overview");
    setIngestionError(null);
    setPendingValidationResult(null);
    setPendingUploadedFile(null);
    setPendingRawSourceText(null);
    setCleaningOptions({
      removeDuplicates: true,
      imputeMissingNumeric: "median",
      imputeMissingCategorical: "mode",
      normalizeFormats: true,
      capOutliers: true,
    });
    setAutopilotNotice(null);
  };

  const handleRestoreSnapshot = (snap: WorkspaceSnapshot) => {
    setDatasetName(snap.datasetName);
    setBusinessQuestion(snap.businessQuestion);
    setDomainContext(snap.domainContext);
    setRawRows(snap.rawRows);
    setSelectedPresetId("");
    setAiReport(null);
    setHasActiveDataset(true);
    setAutopilotNotice(
      `Restored workspace checkpoint "${snap.name}" (${snap.rowCount} records).`
    );
  };

  // Ingestion source controls & Pre-Ingestion Validation Gate state
  const [sourceTab, setSourceTab] = useState<IngestionSourceTab>("presets");
  const [pasteInput, setPasteInput] = useState<string>("");
  const [apiUrl, setApiUrl] = useState<string>(
    "https://jsonplaceholder.typicode.com/users"
  );
  const [ingestionError, setIngestionError] = useState<string | null>(null);
  const [isFetchingUrl, setIsFetchingUrl] = useState<boolean>(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const biStudioSectionRef = useRef<HTMLDivElement | null>(null);

  const [pendingValidationResult, setPendingValidationResult] =
    useState<FileValidationResult | null>(null);
  const [pendingUploadedFile, setPendingUploadedFile] = useState<File | null>(
    null
  );
  const [pendingRawSourceText, setPendingRawSourceText] = useState<
    string | null
  >(null);
  const [validationDelimiterOverride, setValidationDelimiterOverride] =
    useState<DelimiterChoice>("auto");
  const [validationTreatFirstRowAsData, setValidationTreatFirstRowAsData] =
    useState<boolean>(false);

  // Stage 3 state: Data Cleaning & Preparation options
  const [cleaningOptions, setCleaningOptions] = useState<CleaningOptions>({
    removeDuplicates: true,
    imputeMissingNumeric: "median",
    imputeMissingCategorical: "mode",
    normalizeFormats: true,
    capOutliers: true,
  });
  const [tableMode, setTableMode] = useState<"cleaned" | "raw">("cleaned");
  const [tableSearch, setTableSearch] = useState<string>("");
  const [remediationFilter, setRemediationFilter] = useState<string>("ALL");

  // User-Defined Adaptive Requirements & Senior Analyst Ecosystem Knowledge Vault
  const [userRequirements, setUserRequirements] = useState<
    AdaptiveUserRequirement[]
  >(() => loadSavedUserRequirements());
  const [ecosystemKnowledge, setEcosystemKnowledge] = useState<
    EcosystemAnalystKnowledge[]
  >(() => loadEcosystemKnowledge());

  useEffect(() => {
    saveUserRequirements(userRequirements);
  }, [userRequirements]);

  useEffect(() => {
    saveEcosystemKnowledge(ecosystemKnowledge);
  }, [ecosystemKnowledge]);

  // Execute deterministic Stage 3 pipeline + User Adaptive Requirements Engine
  const {
    cleanedRows: baseCleanedRows,
    summary: baseCleaningSummary,
    columnTypes: baseColumnTypes,
  } = useMemo(
    () => cleanAndPrepareDataset(rawRows, cleaningOptions),
    [rawRows, cleaningOptions]
  );

  const ruleExecutionSummary = useMemo(
    () => executeAdaptiveRulesOnRows(baseCleanedRows, userRequirements),
    [baseCleanedRows, userRequirements]
  );

  const cleanedRows = ruleExecutionSummary.transformedRows;

  const columnTypes = useMemo(() => {
    const merged: Record<string, ColumnType> = {
      ...baseColumnTypes,
    };
    for (const newCol of ruleExecutionSummary.newColumnsCreated) {
      const sampleVal = cleanedRows.find(
        (r) => r[newCol] !== null && r[newCol] !== undefined && r[newCol] !== ""
      )?.[newCol];
      if (typeof sampleVal === "number" || !Number.isNaN(Number(sampleVal))) {
        merged[newCol] = "numeric";
      } else {
        merged[newCol] = "categorical";
      }
    }
    return merged;
  }, [baseColumnTypes, ruleExecutionSummary.newColumnsCreated, cleanedRows]);

  const cleaningSummary = useMemo(() => {
    const activeRulesCount = userRequirements.filter((r) => r.enabled).length;
    if (activeRulesCount === 0) return baseCleaningSummary;
    const rowsFilteredByUser = Math.max(
      0,
      ruleExecutionSummary.totalRowsBefore - ruleExecutionSummary.totalRowsAfter
    );
    return {
      ...baseCleaningSummary,
      cleanedRowCount: cleanedRows.length,
      formatsNormalized:
        baseCleaningSummary.formatsNormalized +
        ruleExecutionSummary.totalCellsModified,
      outliersAdjusted:
        baseCleaningSummary.outliersAdjusted + rowsFilteredByUser,
    };
  }, [
    baseCleaningSummary,
    userRequirements,
    ruleExecutionSummary,
    cleanedRows.length,
  ]);

  const columnProfiles = useMemo(
    () => computeColumnProfiles(rawRows, cleanedRows, columnTypes),
    [rawRows, cleanedRows, columnTypes]
  );

  const correlations = useMemo(
    () => computeCorrelations(cleanedRows, columnProfiles),
    [cleanedRows, columnProfiles]
  );

  // Initial deterministic report + AI-enriched report state
  const baselineReport = useMemo(
    () =>
      buildDataGroundedLifecycleReport(
        datasetName,
        businessQuestion,
        domainContext,
        cleaningSummary,
        columnProfiles,
        correlations,
        cleanedRows
      ),
    [
      datasetName,
      businessQuestion,
      domainContext,
      cleaningSummary,
      columnProfiles,
      correlations,
      cleanedRows,
    ]
  );

  const [aiReport, setAiReport] = useState<RexorLifecycleReport | null>(null);
  const [isRunningAutopilot, setIsRunningAutopilot] = useState<boolean>(false);
  const [autopilotStep, setAutopilotStep] = useState<number>(6);
  const [autopilotNotice, setAutopilotNotice] = useState<string | null>(null);

  const activeReport: RexorLifecycleReport = aiReport || baselineReport;

  // Stage 4 interactive SQL workbench state
  const numericCols = useMemo(
    () => columnProfiles.filter((c) => c.type === "numeric").map((c) => c.name),
    [columnProfiles]
  );
  const categoricalCols = useMemo(
    () =>
      columnProfiles
        .filter((c) => c.type === "categorical" || c.type === "date")
        .map((c) => c.name),
    [columnProfiles]
  );

  const [sqlGroupCol, setSqlGroupCol] = useState<string>("");
  const [sqlMetricCol, setSqlMetricCol] = useState<string>("");
  const [sqlAggFn, setSqlAggFn] = useState<"AVG" | "SUM" | "COUNT" | "MEDIAN">(
    "AVG"
  );
  const [copiedCodeId, setCopiedCodeId] = useState<string | null>(null);

  // Stage 4 Ask Rexor custom analyst Q&A state
  const [customQuestion, setCustomQuestion] = useState<string>("");
  const [isAskingRexor, setIsAskingRexor] = useState<boolean>(false);
  const [qaHistory, setQaHistory] = useState<AskRexorResponse[]>([]);

  // Stage 5 Interactive Chart Explorer state
  const [chartXCol, setChartXCol] = useState<string>("");
  const [chartYCol, setChartYCol] = useState<string>("");
  const [scatterXCol, setScatterXCol] = useState<string>("");
  const [scatterYCol, setScatterYCol] = useState<string>("");
  const [histCol, setHistCol] = useState<string>("");

  // Stage 6 Interactive ROI / Action Impact Simulator state
  const [simImprovementPct, setSimImprovementPct] = useState<number>(18);
  const [simAdoptionPct, setSimAdoptionPct] = useState<number>(75);
  const [completedActions, setCompletedActions] = useState<Record<number, boolean>>({
    0: false,
    1: false,
    2: false,
  });

  // Sync default selected columns whenever dataset schema changes
  useEffect(() => {
    const firstCat =
      categoricalCols.find((c) =>
        /^(outlet_zone|segment|carrier_tier|channel|region|funnel_stage)$/i.test(
          c
        )
      ) ||
      categoricalCols.find(
        (c) =>
          !c.toLowerCase().includes("id") &&
          !c.toLowerCase().includes("timestamp") &&
          !c.toLowerCase().includes("date") &&
          !c.toLowerCase().includes("name")
      ) ||
      categoricalCols[0] ||
      "";
    const firstNum = numericCols[0] || "";
    const preferredOutcomeNum =
      numericCols.find((n) =>
        /^(net_revenue_inr|mrr_usd|profit_contribution_usd|on_time_pct|customer_rating)$/i.test(
          n
        )
      ) ||
      numericCols[numericCols.length - 1] ||
      firstNum;

    setSqlGroupCol(firstCat);
    setSqlMetricCol(preferredOutcomeNum);
    setChartXCol(firstCat);
    setChartYCol(preferredOutcomeNum);

    if (correlations.length > 0) {
      setScatterXCol(correlations[0].colA);
      setScatterYCol(correlations[0].colB);
    } else {
      setScatterXCol(firstNum);
      setScatterYCol(preferredOutcomeNum);
    }
    setHistCol(preferredOutcomeNum);
  }, [categoricalCols, numericCols, correlations]);

  // Trigger Rexor Full 6-Stage Autopilot via Server-Side Gemini API
  const runRexorAutopilot = async () => {
    if (cleanedRows.length === 0) return;
    setIsRunningAutopilot(true);
    setAutopilotNotice(null);
    setAutopilotStep(1);

    const stepTimer = setInterval(() => {
      setAutopilotStep((prev) => (prev < 5 ? prev + 1 : prev));
    }, 650);

    try {
      const response = await fetch("/api/rexor/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          datasetName,
          businessQuestion,
          domainContext,
          rowCount: rawRows.length,
          cleanedRowCount: cleanedRows.length,
          cleaningSummary: {
            duplicatesRemoved: cleaningSummary.duplicatesRemoved,
            missingValuesImputed: cleaningSummary.missingValuesImputed,
            formatsNormalized: cleaningSummary.formatsNormalized,
            outliersAdjusted: cleaningSummary.outliersAdjusted,
            dataHealthBefore: cleaningSummary.dataHealthBefore,
            dataHealthAfter: cleaningSummary.dataHealthAfter,
          },
          columns: columnProfiles.map((c) => ({
            name: c.name,
            type: c.type,
            missingPct: c.missingPct,
            uniqueCount: c.uniqueCount,
            mean: c.mean,
            median: c.median,
            stdDev: c.stdDev,
            min: c.min,
            max: c.max,
            topCategories: c.topCategories?.slice(0, 3),
          })),
          topCorrelations: correlations.slice(0, 6),
          sampleRows: cleanedRows.slice(0, 8),
          activeUserRequirements: userRequirements
            .filter((r) => r.enabled)
            .map((r) => `${r.rawInstruction} (${r.title})`),
          ecosystemKnowledge: ecosystemKnowledge
            .slice(0, 5)
            .map((k) => `${k.title} by ${k.analystName}: ${k.expertHeuristic}`),
        }),
      });

      clearInterval(stepTimer);
      setAutopilotStep(6);

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || "Synthesis completed using deterministic statistical engine.");
      }

      const data = await response.json();
      if (data?.report) {
        setAiReport(data.report);
        setAutopilotNotice("Rexor completed all 6 lifecycle stages with deep AI synthesis.");
      }
    } catch (err: any) {
      clearInterval(stepTimer);
      setAutopilotStep(6);
      setAiReport(null);
      setAutopilotNotice(
        "Rexor statistical engine computed all 6 stages locally from your dataset."
      );
    } finally {
      setIsRunningAutopilot(false);
    }
  };

  // Load a sample preset dataset
  const handleSelectPreset = (presetId: string) => {
    const found = SAMPLE_DATASETS.find((d) => d.id === presetId);
    if (!found) return;
    const parsedRows = parseDelimitedText(found.rawCsv);
    setSelectedPresetId(found.id);
    setDatasetName(found.name);
    setDomainContext(found.domainContext);
    setBusinessQuestion(found.defaultBusinessQuestion);
    setRawRows(parsedRows);
    setUserRequirements([]);
    setAiReport(null);
    setIngestionError(null);
    setShowDataModal(false);
    setHasActiveDataset(true);
    setAutopilotNotice(
      `Loaded dataset "${found.name}" (${parsedRows.length} raw records ingested and cleaned automatically).`
    );
  };

  // Commit validated dataset into the 6-stage pipeline
  const commitValidatedDataset = (
    finalRows: DataRow[],
    sourceFileName: string
  ) => {
    const cleanTitle = sourceFileName.replace(/\.[^/.]+$/, "");
    setDatasetName(cleanTitle);
    setDomainContext(`Validated Upload (${sourceFileName})`);
    setBusinessQuestion(
      `Analyze ${sourceFileName} to uncover primary performance drivers, data quality risks, and high-impact business recommendations.`
    );
    setRawRows(finalRows);
    setUserRequirements([]);
    setAiReport(null);
    setSelectedPresetId("");
    setShowDataModal(false);
    setPendingValidationResult(null);
    setPendingUploadedFile(null);
    setPendingRawSourceText(null);
    setHasActiveDataset(true);
    setAutopilotNotice(
      `Pre-Ingestion Validation complete: Ingested "${sourceFileName}" (${finalRows.length} validated rows across ${
        Object.keys(finalRows[0] || {}).length
      } columns).`
    );
  };

  // Re-run Pre-Ingestion Validation when user changes Delimiter Override or Header Recovery options
  const handleUpdateValidationOptions = async (newOptions: {
    delimiterOverride: DelimiterChoice;
    treatFirstRowAsData: boolean;
  }) => {
    setValidationDelimiterOverride(newOptions.delimiterOverride);
    setValidationTreatFirstRowAsData(newOptions.treatFirstRowAsData);

    if (pendingUploadedFile) {
      const updated = await validateUploadedDatasetFile(
        pendingUploadedFile,
        newOptions
      );
      setPendingValidationResult(updated);
    } else if (pendingRawSourceText !== null && pendingValidationResult) {
      const updated = validateRawDatasetInput(
        pendingRawSourceText,
        pendingValidationResult.fileName,
        pendingValidationResult.fileSizeBytes,
        newOptions
      );
      setPendingValidationResult(updated);
    }
  };

  // Trigger simulated pre-ingestion validation scenarios (Empty File, Missing Header, Malformed Delimiters)
  const handleSimulateValidationScenario = (
    scenario: "empty" | "missing-header" | "malformed-delimiter"
  ) => {
    setIngestionError(null);
    setValidationDelimiterOverride("auto");
    setValidationTreatFirstRowAsData(false);
    setPendingUploadedFile(null);

    if (scenario === "empty") {
      const raw = "";
      setPendingRawSourceText(raw);
      setPendingValidationResult(
        validateRawDatasetInput(raw, "empty_quarterly_export.csv", 0)
      );
    } else if (scenario === "missing-header") {
      const raw = `North America,Enterprise,$18400,1.8,94,2026-01-15
EMEA,Mid-Market,$9600,4.5,72,2026-01-18
APAC,Enterprise,$15900,2.1,89,2026-01-22
LATAM,SMB,$4200,7.4,61,2026-01-29`;
      setPendingRawSourceText(raw);
      setPendingValidationResult(
        validateRawDatasetInput(
          raw,
          "headerless_crm_accounts.csv",
          raw.length
        )
      );
    } else {
      const raw = `region,account_tier,monthly_revenue,churn_pct,csat_score
North America,Enterprise,18400,1.8,94
EMEA,Mid-Market,9600,4.5,72,EXTRA_UNESCAPED_COLUMN,999
APAC,Enterprise,15900
LATAM,SMB,"4200,7.4,61`;
      setPendingRawSourceText(raw);
      setPendingValidationResult(
        validateRawDatasetInput(
          raw,
          "malformed_delimiters_export.csv",
          raw.length
        )
      );
    }
  };

  // Shared helper to process a local File (from native file picker or drag-and-drop)
  const processUploadedFileObject = async (file: File) => {
    setIngestionError(null);
    setValidationDelimiterOverride("auto");
    setValidationTreatFirstRowAsData(false);

    try {
      const validation = await validateUploadedDatasetFile(file, {
        delimiterOverride: "auto",
        treatFirstRowAsData: false,
      });

      const hasCriticalError = validation.issues.some(
        (i) => i.severity === "critical"
      );

      // If the file has valid parsedRows and no critical error, ingest immediately so the user sees their data right away!
      if (validation.parsedRows.length > 0 && !hasCriticalError) {
        commitValidatedDataset(validation.parsedRows, file.name);
        return;
      }

      // Otherwise open the Pre-Ingestion Recovery Modal for empty or critically broken files
      setPendingUploadedFile(file);
      setPendingRawSourceText(validation.rawText ?? null);
      setPendingValidationResult(validation);
    } catch (err: any) {
      setIngestionError(err?.message || "Failed to validate uploaded file.");
    }
  };

  // Handle Excel / CSV / JSON file upload
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processUploadedFileObject(file);
    e.target.value = "";
  };

  // Handle Paste Raw Data with Pre-Ingestion Validation Step
  const handleIngestPastedData = () => {
    setIngestionError(null);
    setValidationDelimiterOverride("auto");
    setValidationTreatFirstRowAsData(false);

    const validation = validateRawDatasetInput(
      pasteInput,
      "Pasted_Clipboard_Dataset.csv",
      pasteInput.length,
      {
        delimiterOverride: "auto",
        treatFirstRowAsData: false,
      }
    );

    if (!validation.isValidToAutoIngest || validation.issues.length > 0) {
      setPendingUploadedFile(null);
      setPendingRawSourceText(pasteInput);
      setPendingValidationResult(validation);
      return;
    }

    commitValidatedDataset(validation.parsedRows, "Custom Pasted Dataset");
  };

  // Handle Live REST API Fetch
  const handleFetchApiData = async () => {
    if (!apiUrl.trim()) return;
    setIsFetchingUrl(true);
    setIngestionError(null);
    try {
      const res = await fetch("/api/rexor/fetch-url", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url: apiUrl.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to fetch remote URL.");
      }
      const parsed = parseDelimitedText(data.rawText || "");
      if (parsed.length === 0) {
        throw new Error("Remote endpoint did not return a tabular JSON array or CSV dataset.");
      }
      // Flatten nested objects if needed (e.g. jsonplaceholder users)
      const flattened = parsed.map((row) => {
        const flat: DataRow = {};
        Object.entries(row).forEach(([k, v]) => {
          if (v && typeof v === "object" && !Array.isArray(v)) {
            Object.entries(v).forEach(([subK, subV]) => {
              if (typeof subV !== "object") {
                flat[`${k}_${subK}`] = subV;
              }
            });
          } else if (Array.isArray(v)) {
            flat[k] = v.length;
          } else {
            flat[k] = v;
          }
        });
        return flat;
      });

      const hostTitle = new URL(apiUrl).hostname + " API Dataset";
      setDatasetName(hostTitle);
      setDomainContext(`REST API Stream (${apiUrl})`);
      setRawRows(flattened);
      setAiReport(null);
      setSelectedPresetId("");
      setShowDataModal(false);
      setHasActiveDataset(true);
      setAutopilotNotice(
        `Connected live API "${hostTitle}" (${flattened.length} records fetched and cleaned).`
      );
    } catch (err: any) {
      setIngestionError(err?.message || "Failed to ingest from API URL.");
    } finally {
      setIsFetchingUrl(false);
    }
  };

  // Handle Ask Rexor Follow-Up Question (Backed by 100% Deterministic Full-Dataset Execution)
  const handleAskRexor = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuestion.trim() || isAskingRexor) return;
    const qText = customQuestion.trim();
    setIsAskingRexor(true);

    // 1. Pre-compute 100% deterministic answer, SQL, and Python across ALL cleanedRows
    const deterministicExecution = executeDeterministicTaskAgainstDataset({
      rows: cleanedRows,
      columnProfiles,
      correlations,
      datasetName,
      taskPrompt: qText,
    });

    try {
      const res = await fetch("/api/rexor/ask", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question: qText,
          datasetName,
          businessQuestion,
          columns: columnProfiles.map((c) => ({
            name: c.name,
            type: c.type,
            mean: c.mean,
            median: c.median,
            min: c.min,
            max: c.max,
          })),
          topCorrelations: correlations.slice(0, 5),
          sampleRows: cleanedRows.slice(0, 6),
          activeUserRequirements: userRequirements
            .filter((r) => r.enabled)
            .map((r) => `${r.rawInstruction} (${r.title})`),
          ecosystemKnowledge: ecosystemKnowledge
            .slice(0, 4)
            .map((k) => `${k.title} (${k.analystName}): ${k.expertHeuristic}`),
          deterministicResult: deterministicExecution,
        }),
      });

      if (!res.ok) {
        throw new Error("Fallback to local analytical engine");
      }
      const ans = await res.json();
      setQaHistory((prev) => [
        {
          question: qText,
          timestamp: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
          directAnswer: ans.directAnswer || deterministicExecution.directAnswer,
          sqlQuery: ans.sqlQuery || deterministicExecution.sqlQuery,
          pythonCode: ans.pythonCode || deterministicExecution.pythonCode,
          recommendedAction:
            ans.recommendedAction ||
            `Focus operational intervention on cohorts highlighted in the deterministic table (${deterministicExecution.taskTitle}).`,
        },
        ...prev,
      ]);
      setCustomQuestion("");
    } catch {
      // 100% Deterministic full-dataset analytical answer if offline/error
      const primaryNum = columnProfiles.find((c) => c.type === "numeric");
      setQaHistory((prev) => [
        {
          question: qText,
          timestamp: new Date().toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit",
          }),
          directAnswer: deterministicExecution.directAnswer,
          sqlQuery: deterministicExecution.sqlQuery,
          pythonCode: deterministicExecution.pythonCode,
          recommendedAction: `Focus operational intervention on cohorts where ${
            sqlMetricCol || primaryNum?.name || "performance"
          } deviates beyond 1 sample standard deviation (${primaryNum?.stdDev ?? 0}).`,
        },
        ...prev,
      ]);
      setCustomQuestion("");
    } finally {
      setIsAskingRexor(false);
    }
  };

  // Export Cleaned CSV
  const handleDownloadCleanedCsv = () => {
    if (cleanedRows.length === 0) return;
    const headers = Object.keys(cleanedRows[0]);
    const csvLines = [
      headers.join(","),
      ...cleanedRows.map((row) =>
        headers
          .map((h) => {
            const val = String(row[h] ?? "");
            return val.includes(",") || val.includes('"')
              ? `"${val.replace(/"/g, '""')}"`
              : val;
          })
          .join(",")
      ),
    ];
    const blob = new Blob([csvLines.join("\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${datasetName.toLowerCase().replace(/[^a-z0-9]+/g, "_")}_rexor_cleaned.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Export Executive Markdown Report
  const handleDownloadReport = () => {
    const md = `# Rexor Autonomous Data Analytics Report: ${datasetName}
Author & License Holder: Rushi Chavan (Copyright © 2026 Rushi Chavan. All Rights Reserved.)
Generated: ${new Date().toISOString().split("T")[0]}
Domain Context: ${domainContext}

## 1. Business Problem & Hypotheses
- **Refined Question**: ${activeReport.stage1ProblemFraming.refinedQuestion}
- **Decision Stakeholders**: ${activeReport.stage1ProblemFraming.decisionStakeholders}
- **Objective Metric**: ${activeReport.stage1ProblemFraming.primaryObjectiveMetric}

### Tested Hypotheses
${activeReport.stage1ProblemFraming.hypotheses
  .map(
    (h) =>
      `- **${h.id} (${h.validationStatus})**: ${h.statement} — *Evidence*: ${h.evidenceMetric}`
  )
  .join("\n")}

## 2 & 3. Data Collection, Cleaning & Preparation
- **Raw Records**: ${cleaningSummary.rawRowCount} | **Cleaned Records**: ${cleaningSummary.cleanedRowCount}
- **Duplicates Removed**: ${cleaningSummary.duplicatesRemoved}
- **Missing Values Imputed**: ${cleaningSummary.missingValuesImputed}
- **Formats Normalized**: ${cleaningSummary.formatsNormalized}
- **Outliers Capped**: ${cleaningSummary.outliersAdjusted}
- **Structural Summary**: ${activeReport.stage3CleaningAssessment.structuralRisksResolved}

## 4. Statistical & SQL Analysis
${activeReport.stage4AnalyticalFindings.executiveSummary}

${activeReport.stage4AnalyticalFindings.keyInsights
  .map(
    (ins) =>
      `### ${ins.title} (${ins.category})\n- **Finding**: ${ins.quantifiedFinding}\n- **Implication**: ${ins.businessImplication}`
  )
  .join("\n\n")}

## 5. Executive Visual Takeaways
${activeReport.stage5VisualNarrative.storylineTakeaways.map((t) => `- ${t}`).join("\n")}

## 6. Recommended Actions & KPI Measurement Plan
${activeReport.stage6ActionPlan.recommendations
  .map(
    (r) =>
      `### [${r.priority}] ${r.actionTitle}\n- **Target**: ${r.targetSegmentOrVariable}\n- **Mechanism**: ${r.concreteMechanism}\n- **Expected Impact**: ${r.quantifiedExpectedImpact}\n- **KPI**: ${r.measurementKpi}`
  )
  .join("\n\n")}
`;
    const blob = new Blob([md], { type: "text/markdown;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${datasetName.toLowerCase().replace(/[^a-z0-9]+/g, "_")}_executive_report.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleCopyCode = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCodeId(id);
    setTimeout(() => setCopiedCodeId(null), 1800);
  };

  // Filtered rows for data table explorer
  const activeTableRows = tableMode === "cleaned" ? cleanedRows : rawRows;
  const filteredTableRows = useMemo(() => {
    if (!tableSearch.trim()) return activeTableRows;
    const q = tableSearch.toLowerCase();
    return activeTableRows.filter((row) =>
      Object.values(row).some((v) => String(v ?? "").toLowerCase().includes(q))
    );
  }, [activeTableRows, tableSearch]);

  const filteredRemediationLogs = useMemo(() => {
    if (remediationFilter === "ALL") return cleaningSummary.logs;
    return cleaningSummary.logs.filter((l) => l.issueType === remediationFilter);
  }, [cleaningSummary.logs, remediationFilter]);

  const liveSqlResult = useMemo(
    () =>
      executeGroupByAggregation(
        cleanedRows,
        sqlGroupCol,
        sqlMetricCol,
        sqlAggFn
      ),
    [cleanedRows, sqlGroupCol, sqlMetricCol, sqlAggFn]
  );

  // Stage 6 ROI simulation math
  const primaryNumericProfile =
    columnProfiles.find((p) => p.name === sqlMetricCol) ||
    columnProfiles.find((p) => p.type === "numeric");
  const baselineTotalSum = useMemo(() => {
    if (!primaryNumericProfile) return 100000;
    return cleanedRows.reduce(
      (acc, r) => acc + (Number(r[primaryNumericProfile.name]) || 0),
      0
    );
  }, [cleanedRows, primaryNumericProfile]);

  const simulatedNetLift = useMemo(() => {
    const effectiveRate = (simImprovementPct / 100) * (simAdoptionPct / 100);
    return Math.round(baselineTotalSum * effectiveRate);
  }, [baselineTotalSum, simImprovementPct, simAdoptionPct]);

  const LIFECYCLE_STAGES = [
    {
      num: "01",
      title: "Understand Problem",
      metric: `${activeReport.stage1ProblemFraming.hypotheses.length} Hypotheses`,
      targetView: "problem-data" as ActiveView,
    },
    {
      num: "02",
      title: "Collect & Access",
      metric: `${cleaningSummary.rawRowCount} Raw Rows`,
      targetView: "problem-data" as ActiveView,
    },
    {
      num: "03",
      title: "Clean & Prepare",
      metric: `${cleaningSummary.logs.length} Fixes Applied`,
      targetView: "cleaning" as ActiveView,
    },
    {
      num: "04",
      title: "Analyze Data",
      metric: `${columnProfiles.length} Columns Profiled`,
      targetView: "analysis" as ActiveView,
    },
    {
      num: "05",
      title: "Visualize Insights",
      metric: `3 Interactive Views`,
      targetView: "visuals-actions" as ActiveView,
    },
    {
      num: "06",
      title: "Recommend & Measure",
      metric: `${activeReport.stage6ActionPlan.recommendations.length} Action Playbooks`,
      targetView: "visuals-actions" as ActiveView,
    },
  ];

  const triggerShortcutToast = (label: string) => {
    setShortcutToast(label);
  };

  useEffect(() => {
    if (!shortcutToast) return;
    const timer = window.setTimeout(() => setShortcutToast(null), 2600);
    return () => window.clearTimeout(timer);
  }, [shortcutToast]);

  const shortcutCommands: ShortcutCommandItem[] = [
    {
      id: "run-autopilot",
      label: "Run Autopilot",
      description:
        "Execute all 6 autonomous data hygiene, SQL, statistical & ROI simulation stages",
      keys: ["Ctrl", "Space"],
      category: "Core Actions",
      action: () => {
        if (!hasActiveDataset) {
          handleSelectPreset(SAMPLE_DATASETS[0].id);
        }
        runRexorAutopilot();
        triggerShortcutToast("Shortcut Triggered: Run Autopilot (Ctrl + Space)");
      },
    },
    {
      id: "toggle-sidebar",
      label: "Toggle Sidebar (AI Copilot)",
      description:
        "Show or hide the interactive Rexor AI Onboarding & Analytics Copilot panel",
      keys: ["Ctrl", "B"],
      category: "Core Actions",
      action: () => {
        setIsSideChatOpen((prev) => {
          const next = !prev;
          triggerShortcutToast(
            `Shortcut Triggered: ${next ? "Opened" : "Hidden"} AI Sidebar (Ctrl + B)`
          );
          return next;
        });
      },
    },
    {
      id: "reset-everything",
      label: "Reset Everything",
      description:
        "Clear active dataset & return to the Fresh-Start Upload / Select Dataset Launchpad",
      keys: ["Ctrl", "R"],
      category: "Core Actions",
      action: () => {
        handleResetEverything();
        triggerShortcutToast(
          "Shortcut Triggered: Reset Everything to Launchpad (Ctrl + R)"
        );
      },
    },
    {
      id: "toggle-shortcuts-modal",
      label: "Open Keyboard Shortcuts & Command Palette",
      description:
        "Search and trigger any Rexor power-user command or inspect keybindings",
      keys: ["Ctrl", "K"],
      category: "Core Actions",
      action: () => {
        setShowShortcutsModal((prev) => !prev);
      },
    },
    {
      id: "toggle-newbie-guide",
      label: "Toggle Newbie Starter Coach",
      description:
        "Turn the interactive 5-step beginner guided walkthrough on or off",
      keys: ["Ctrl", "G"],
      category: "Core Actions",
      action: () => {
        setNewbieGuideMode((prev) => {
          const next = !prev;
          triggerShortcutToast(
            `Shortcut Triggered: Newbie Guide ${next ? "ON" : "OFF"} (Ctrl + G)`
          );
          return next;
        });
      },
    },
    {
      id: "nav-overview",
      label: "Go to Lifecycle Overview",
      description:
        "Jump to the complete 6-stage executive overview and adaptive engine",
      keys: ["Alt", "1"],
      category: "Stage Navigation",
      action: () => {
        setActiveView("overview");
        triggerShortcutToast("Navigated to: Lifecycle Overview (Alt + 1)");
      },
    },
    {
      id: "nav-problem-data",
      label: "Go to Stage 1–2: Problem & Data",
      description:
        "Frame hypotheses, inspect schema, or ingest new files / REST API streams",
      keys: ["Alt", "2"],
      category: "Stage Navigation",
      action: () => {
        setActiveView("problem-data");
        triggerShortcutToast("Navigated to: Stage 1–2 Problem & Data (Alt + 2)");
      },
    },
    {
      id: "nav-cleaning",
      label: "Go to Stage 3: Clean & Prepare",
      description:
        "Configure deduplication, median/mean imputation, IQR outlier capping & audit logs",
      keys: ["Alt", "3"],
      category: "Stage Navigation",
      action: () => {
        setActiveView("cleaning");
        triggerShortcutToast("Navigated to: Stage 3 Clean & Prepare (Alt + 3)");
      },
    },
    {
      id: "nav-analysis",
      label: "Go to Stage 4: SQL, Python & Statistics",
      description:
        "Run live SQL GROUP BY queries, Pearson r matrices, and verified Python scripts",
      keys: ["Alt", "4"],
      category: "Stage Navigation",
      action: () => {
        setActiveView("analysis");
        triggerShortcutToast("Navigated to: Stage 4 SQL & Statistics (Alt + 4)");
      },
    },
    {
      id: "nav-visuals-actions",
      label: "Go to Stage 5–6: Visuals & Action ROI",
      description:
        "Explore interactive charts, ROI sensitivity sliders, and P1–P3 action playbooks",
      keys: ["Alt", "5"],
      category: "Stage Navigation",
      action: () => {
        setActiveView("visuals-actions");
        triggerShortcutToast(
          "Navigated to: Stage 5–6 Visuals & Actions (Alt + 5)"
        );
      },
    },
    {
      id: "nav-bi-studio",
      label: "Open 108 Power BI & Tableau Presentation Studio",
      description:
        "Launch all 108 Power BI & Tableau templates, AI Template Advisor, and DAX/LOD exports",
      keys: ["Alt", "6"],
      category: "Stage Navigation",
      action: () => {
        handleOpenBiStudio();
      },
    },
    {
      id: "upload-switch-data",
      label: "Upload or Switch Dataset",
      description:
        "Open the Dataset Ingestion & Preset Switcher modal from anywhere",
      keys: ["Ctrl", "U"],
      category: "Data & Exports",
      action: () => {
        if (!hasActiveDataset) {
          fileInputRef.current?.click();
        } else {
          setIngestionError(null);
          setShowDataModal(true);
        }
        triggerShortcutToast("Shortcut Triggered: Upload / Switch Data (Ctrl + U)");
      },
    },
    {
      id: "export-dataset-modal",
      label: "Export Cleaned Dataset (.xlsx / .csv / .json)",
      description:
        "Open the Custom Dataset Export Studio with column and date filters",
      keys: ["Ctrl", "E"],
      category: "Data & Exports",
      action: () => {
        setShowExportModal(true);
        triggerShortcutToast("Shortcut Triggered: Export Dataset Studio (Ctrl + E)");
      },
    },
    {
      id: "save-board-deck-pdf",
      label: "Save Executive Board Deck (.pdf)",
      description:
        "Generate and download the multi-page Executive PDF report immediately",
      keys: ["Ctrl", "P"],
      category: "Data & Exports",
      action: () => {
        downloadExecutiveBoardDeckPdf({
          datasetName,
          domainContext,
          businessQuestion,
          cleaningSummary,
          columnProfiles,
          correlations,
          activeReport,
        });
        triggerShortcutToast(
          "Shortcut Triggered: Save Executive PDF Report (Ctrl + P)"
        );
      },
    },
  ];

  // Dedicated launcher for 108 Power BI & Tableau Presentation Studio (works from Launchpad, Header, Command Bar, or Copilot)
  const handleOpenBiStudio = () => {
    if (!hasActiveDataset) {
      const preset = SAMPLE_DATASETS[0];
      setSelectedPresetId(preset.id);
      setDatasetName(preset.name);
      setDomainContext(preset.domainContext);
      setBusinessQuestion(preset.defaultBusinessQuestion);
      setRawRows(parseDelimitedText(preset.rawCsv));
      setHasActiveDataset(true);
    }
    setActiveView("bi-studio");
    triggerShortcutToast(
      "Opened 108 Power BI & Tableau Presentation Studio (54 Power BI + 54 Tableau Templates)"
    );
    window.setTimeout(() => {
      if (biStudioSectionRef.current) {
        biStudioSectionRef.current.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      } else {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
    }, 60);
  };

  // Global Power-User Keyboard Shortcuts Listener
  useEffect(() => {
    const handleGlobalKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const isEditable =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable);

      const mod = e.ctrlKey || e.metaKey;
      const keyLower = e.key.toLowerCase();

      // Escape closes active modals
      if (e.key === "Escape") {
        if (showShortcutsModal) {
          e.preventDefault();
          setShowShortcutsModal(false);
          return;
        }
      }

      // Ctrl + K -> Open/Close Keyboard Shortcuts & Command Palette (works even in inputs)
      if (mod && keyLower === "k") {
        e.preventDefault();
        setShowShortcutsModal((prev) => !prev);
        return;
      }

      // Ctrl + Space -> Run Autopilot
      if ((e.ctrlKey || e.metaKey) && (e.code === "Space" || e.key === " ")) {
        e.preventDefault();
        if (!hasActiveDataset) {
          handleSelectPreset(SAMPLE_DATASETS[0].id);
        }
        runRexorAutopilot();
        triggerShortcutToast("Shortcut Triggered: Run Autopilot (Ctrl + Space)");
        return;
      }

      // Ctrl + B -> Toggle Sidebar
      if (mod && keyLower === "b") {
        e.preventDefault();
        setIsSideChatOpen((prev) => {
          const next = !prev;
          triggerShortcutToast(
            `Shortcut Triggered: ${next ? "Opened" : "Hidden"} AI Sidebar (Ctrl + B)`
          );
          return next;
        });
        return;
      }

      // Ctrl + R -> Reset Everything (intercepts default reload to reset Rexor workspace cleanly)
      if (mod && !e.shiftKey && keyLower === "r") {
        e.preventDefault();
        handleResetEverything();
        triggerShortcutToast(
          "Shortcut Triggered: Reset Everything to Launchpad (Ctrl + R)"
        );
        return;
      }

      // Skip remaining shortcuts if user is typing inside an input/textarea
      if (isEditable) return;

      // '?' -> Open Shortcuts Modal
      if (e.key === "?" && !mod && !e.altKey) {
        e.preventDefault();
        setShowShortcutsModal(true);
        return;
      }

      // Ctrl + U -> Upload / Switch Data
      if (mod && keyLower === "u") {
        e.preventDefault();
        if (!hasActiveDataset) {
          fileInputRef.current?.click();
        } else {
          setIngestionError(null);
          setShowDataModal(true);
        }
        triggerShortcutToast("Shortcut Triggered: Upload / Switch Data (Ctrl + U)");
        return;
      }

      // Ctrl + E -> Export Dataset Studio
      if (mod && keyLower === "e") {
        e.preventDefault();
        setShowExportModal(true);
        triggerShortcutToast("Shortcut Triggered: Export Dataset Studio (Ctrl + E)");
        return;
      }

      // Ctrl + P -> Save Executive PDF
      if (mod && keyLower === "p") {
        e.preventDefault();
        downloadExecutiveBoardDeckPdf({
          datasetName,
          domainContext,
          businessQuestion,
          cleaningSummary,
          columnProfiles,
          correlations,
          activeReport,
        });
        triggerShortcutToast(
          "Shortcut Triggered: Save Executive PDF Report (Ctrl + P)"
        );
        return;
      }

      // Ctrl + G -> Toggle Newbie Guide
      if (mod && keyLower === "g") {
        e.preventDefault();
        setNewbieGuideMode((prev) => {
          const next = !prev;
          triggerShortcutToast(
            `Shortcut Triggered: Newbie Guide ${next ? "ON" : "OFF"} (Ctrl + G)`
          );
          return next;
        });
        return;
      }

      // Alt + 1..5 -> Stage Navigation
      if (e.altKey && !mod) {
        if (e.key === "1") {
          e.preventDefault();
          setActiveView("overview");
          triggerShortcutToast("Navigated to: Lifecycle Overview (Alt + 1)");
        } else if (e.key === "2") {
          e.preventDefault();
          setActiveView("problem-data");
          triggerShortcutToast("Navigated to: Stage 1–2 Problem & Data (Alt + 2)");
        } else if (e.key === "3") {
          e.preventDefault();
          setActiveView("cleaning");
          triggerShortcutToast("Navigated to: Stage 3 Clean & Prepare (Alt + 3)");
        } else if (e.key === "4") {
          e.preventDefault();
          setActiveView("analysis");
          triggerShortcutToast("Navigated to: Stage 4 SQL & Statistics (Alt + 4)");
        } else if (e.key === "5") {
          e.preventDefault();
          setActiveView("visuals-actions");
          triggerShortcutToast(
            "Navigated to: Stage 5–6 Visuals & Actions (Alt + 5)"
          );
        } else if (e.key === "6") {
          e.preventDefault();
          handleOpenBiStudio();
        }
      }
    };

    window.addEventListener("keydown", handleGlobalKeyDown);
    return () => window.removeEventListener("keydown", handleGlobalKeyDown);
  }, [
    hasActiveDataset,
    showShortcutsModal,
    datasetName,
    domainContext,
    businessQuestion,
    cleaningSummary,
    columnProfiles,
    correlations,
    activeReport,
  ]);

  return (
    <div className="theme-metallic-root min-h-screen flex flex-col bg-[#050811] text-[#60A5FA]">
      {/* Global Always-Mounted File Input for Instant Excel / CSV / JSON Upload */}
      <input
        id="rexor-global-file-input"
        ref={fileInputRef}
        type="file"
        accept=".csv,.tsv,.json,.xlsx,.xls,.txt"
        onChange={handleFileUpload}
        className="sr-only"
      />
      {/* Top Bar Contract: Zero-Overlap 2-Tier Responsive Header across Mobile, Tablet, Laptop, PC, and 4K TV */}
      <header className="sticky top-0 z-30 flex flex-col bg-white border-b border-slate-200 w-full max-w-full overflow-x-hidden px-3 sm:px-6 lg:px-8 py-2.5 gap-2">
        {/* Tier 1: Brand Wordmark + Global Action Buttons (Zero Collision) */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 w-full min-w-0">
          <div className="flex items-center gap-3 min-w-0">
            <a
              href="#overview"
              onClick={(e) => {
                e.preventDefault();
                setActiveView("overview");
              }}
              className="text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 font-display"
            >
              Rexor
            </a>
            <span className="hidden md:inline-block text-xs text-slate-500 truncate max-w-[340px] lg:max-w-[480px]">
              {hasActiveDataset
                ? `Active: ${datasetName} (${cleaningSummary.cleanedRowCount} Verified Rows)`
                : "Autonomous 6-Stage Data Analytics Suite · Upload or Select a Dataset"}
            </span>
          </div>

          {/* Primary Global Actions (Theme & Colors / Shortcuts / 108 BI Studio / Reset / Autopilot) */}
          <div className="flex items-center gap-2 shrink-0 flex-wrap justify-end">
            <button
              onClick={() => setShowThemeModal(true)}
              title="Customize Rexor Theme & Colors (Choose from 18 Themes or Freestyle Color Mixer)"
              className="px-2.5 sm:px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
            >
              <Palette className="w-3.5 h-3.5 shrink-0" />
              <span>Theme & Colors</span>
              <span
                className="w-3 h-3 rounded-full border border-white/60 shrink-0"
                style={{ backgroundColor: activeTheme.accentPrimary }}
              />
            </button>
            <button
              onClick={() => setShowShortcutsModal(true)}
              title="Open Power-User Keyboard Shortcuts & Command Palette (Ctrl+K)"
              className="px-2.5 sm:px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
            >
              <Keyboard className="w-3.5 h-3.5 shrink-0" />
              <span className="hidden sm:inline">Shortcuts</span>
              <kbd className="px-1.5 py-0.5 text-[10px] font-mono rounded bg-slate-200 text-slate-800">
                Ctrl+K
              </kbd>
            </button>
            {hasActiveDataset ? (
              <>
                <button
                  onClick={handleResetEverything}
                  title="Reset everything and return to the Upload / Select Dataset screen (Ctrl+R)"
                  className="px-2.5 sm:px-3 py-1.5 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                  <span>Reset Everything</span>
                  <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-mono rounded bg-slate-200 text-slate-800">
                    Ctrl+R
                  </kbd>
                </button>
                <button
                  onClick={runRexorAutopilot}
                  disabled={isRunningAutopilot}
                  title="Run 6-Stage Autonomous Autopilot (Ctrl+Space)"
                  className="px-3 sm:px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 disabled:opacity-60 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
                >
                  {isRunningAutopilot ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin shrink-0" />
                      <span>Stage {autopilotStep}/6...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-3.5 h-3.5 shrink-0" />
                      <span>Run Full Autopilot</span>
                      <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] font-mono rounded bg-blue-800/80 text-blue-100">
                        Ctrl+Space
                      </kbd>
                    </>
                  )}
                </button>
              </>
            ) : (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleOpenBiStudio}
                  title="Open 108 Power BI & Tableau Presentation Studio"
                  className="px-3 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 shrink-0" />
                  <span>108 Power BI & Tableau Studio</span>
                </button>
                <label
                  htmlFor="rexor-global-file-input"
                  title="Upload Dataset (Ctrl+U)"
                  className="px-3.5 py-1.5 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 shrink-0" />
                  <span>Upload Dataset (.xlsx / .csv / .json)</span>
                </label>
              </div>
            )}
          </div>
        </div>

        {/* Tier 2: Dedicated Full-Width Navigation Row (Never Collides with Action Buttons) */}
        {hasActiveDataset && (
          <nav className="flex flex-wrap items-center gap-1.5 sm:gap-2 pt-2 border-t border-slate-200 w-full min-w-0">
            {[
              { id: "overview", label: "Lifecycle Overview" },
              {
                id: "industry-assignment",
                label: "📋 5-Task Industry Deliverable",
              },
              { id: "problem-data", label: "1–2. Problem & Data" },
              { id: "cleaning", label: "3. Clean & Prepare" },
              { id: "analysis", label: "4. SQL & Statistics" },
              { id: "visuals-actions", label: "5–6. Visuals & Actions" },
              { id: "bi-studio", label: "★ 108 Power BI & Tableau Studio" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() =>
                  tab.id === "bi-studio"
                    ? handleOpenBiStudio()
                    : setActiveView(tab.id as ActiveView)
                }
                className={`px-2.5 sm:px-3 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap cursor-pointer ${
                  activeView === tab.id
                    ? "bg-blue-600 text-white font-semibold"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </nav>
        )}
      </header>

      {/* =====================================================================
          FRESH-START LAUNCHPAD: SHOWN ON EVERY REFRESH / RESTART OR AFTER RESET
         ===================================================================== */}
      {!hasActiveDataset ? (
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12 space-y-8">
          {/* Hero Upload & Dataset Selection Card */}
          <section className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-6">
            <div className="space-y-2 max-w-3xl">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                <span>Rexor Autonomous AI Data Analyst Suite</span>
                <span>·</span>
                <span>Created & Licensed by Rushi Chavan</span>
                <span>·</span>
                <span>Ready for Data Ingestion</span>
              </div>
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-slate-900 tracking-tight">
                Upload Your Data or Select a Dataset to Begin
              </h1>
              <p className="text-sm text-slate-600 leading-relaxed">
                Start fresh by uploading an Excel (`.xlsx`), CSV, TSV, or JSON
                file—or pick one of the built-in enterprise datasets below to
                launch Rexor&apos;s 6-Stage Data Hygiene, SQL & Statistical
                Analysis, Python Studio, and Executive Board Deck pipeline.
              </p>
            </div>

            {ingestionError && (
              <div className="p-3.5 bg-red-50 border border-red-200 rounded-lg text-xs text-red-600">
                {ingestionError}
              </div>
            )}

            {/* Primary Upload Dropzone + Paste / API Quick Tabs */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Left 7 Cols: Upload Local File */}
              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                }}
                onDrop={(e) => {
                  e.preventDefault();
                  e.stopPropagation();
                  const droppedFile = e.dataTransfer?.files?.[0];
                  if (droppedFile) {
                    processUploadedFileObject(droppedFile);
                  }
                }}
                className="lg:col-span-7 p-6 border-2 border-dashed border-blue-600 rounded-xl bg-blue-50/30 flex flex-col justify-between gap-5"
              >
                <div className="space-y-2">
                  <div className="text-xs font-mono text-blue-600 font-semibold">
                    OPTION 1 · UPLOAD LOCAL FILE (.XLSX, .CSV, .TSV, .JSON)
                  </div>
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900">
                    Upload Your Spreadsheet or Dataset File
                  </h2>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Click the button below or drag &amp; drop any Excel, CSV, TSV,
                    or JSON file to immediately load, clean, and display your
                    spreadsheet.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  <label
                    htmlFor="rexor-global-file-input"
                    className="px-5 py-3 text-xs sm:text-sm font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-4 h-4 shrink-0" />
                    <span>Browse & Upload File (.xlsx / .csv / .json)</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      handleSelectPreset("industry-business-assessment");
                      setActiveView("industry-assignment");
                    }}
                    className="px-4 py-3 text-xs sm:text-sm font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg flex items-center gap-2 cursor-pointer"
                  >
                    <Check className="w-4 h-4 shrink-0" />
                    <span>Launch 5-Task Industry Assignment (Tasks 1–5)</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleOpenBiStudio}
                    className="px-4 py-3 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 border border-blue-600 rounded-lg flex items-center gap-2 cursor-pointer"
                  >
                    <Sparkles className="w-4 h-4 shrink-0 text-blue-600" />
                    <span>Open 108 Power BI & Tableau Studio</span>
                  </button>
                </div>

                <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                  <span className="text-slate-500">
                    Test Pre-Ingestion Diagnostic Gate:
                  </span>
                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleSimulateValidationScenario("empty")}
                      className="px-2.5 py-1 font-mono rounded border border-slate-300 bg-slate-100 text-slate-700 cursor-pointer"
                    >
                      Simulate Empty File
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        handleSimulateValidationScenario("missing-header")
                      }
                      className="px-2.5 py-1 font-mono rounded border border-slate-300 bg-slate-100 text-slate-700 cursor-pointer"
                    >
                      Simulate Missing Header
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        handleSimulateValidationScenario("malformed-delimiter")
                      }
                      className="px-2.5 py-1 font-mono rounded border border-slate-300 bg-slate-100 text-slate-700 cursor-pointer"
                    >
                      Simulate Malformed Delimiter
                    </button>
                  </div>
                </div>
              </div>

              {/* Right 5 Cols: Paste Raw CSV/JSON or Connect Live API */}
              <div className="lg:col-span-5 p-5 border border-slate-200 rounded-xl bg-slate-50 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono text-slate-500 font-semibold">
                      OPTION 2 · PASTE OR REST API
                    </span>
                    <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg text-xs">
                      <button
                        type="button"
                        onClick={() => setSourceTab("paste")}
                        className={`px-2.5 py-1 rounded cursor-pointer ${
                          sourceTab === "paste"
                            ? "bg-blue-600 text-white font-semibold"
                            : "text-slate-600"
                        }`}
                      >
                        Paste CSV/JSON
                      </button>
                      <button
                        type="button"
                        onClick={() => setSourceTab("api")}
                        className={`px-2.5 py-1 rounded cursor-pointer ${
                          sourceTab === "api"
                            ? "bg-blue-600 text-white font-semibold"
                            : "text-slate-600"
                        }`}
                      >
                        REST API
                      </button>
                    </div>
                  </div>

                  {sourceTab === "api" ? (
                    <div className="space-y-2.5">
                      <label className="block text-xs font-semibold text-slate-900">
                        Connect Live JSON / CSV Endpoint URL
                      </label>
                      <input
                        type="url"
                        value={apiUrl}
                        onChange={(e) => setApiUrl(e.target.value)}
                        placeholder="https://api.example.com/data.json"
                        className="w-full px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={handleFetchApiData}
                        disabled={isFetchingUrl}
                        className="w-full px-4 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <Globe className="w-3.5 h-3.5" />
                        <span>
                          {isFetchingUrl
                            ? "Fetching API Stream..."
                            : "Fetch & Ingest API Data"}
                        </span>
                      </button>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-semibold text-slate-900">
                          Paste Raw CSV, TSV, or JSON Rows
                        </label>
                        <button
                          type="button"
                          onClick={() =>
                            setPasteInput(SAMPLE_DATASETS[0].rawCsv)
                          }
                          className="text-[11px] font-mono text-blue-600 hover:underline cursor-pointer"
                        >
                          Fill Sample CSV
                        </button>
                      </div>
                      <textarea
                        rows={4}
                        value={pasteInput}
                        onChange={(e) => setPasteInput(e.target.value)}
                        placeholder="Paste comma/tab-separated rows or JSON array here..."
                        className="w-full p-2.5 text-xs font-mono bg-white border border-slate-300 rounded-lg"
                      />
                      <button
                        type="button"
                        onClick={handleIngestPastedData}
                        className="w-full px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                      >
                        Validate & Load Pasted Data
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Option 3: Select a Built-In Enterprise Dataset */}
            <div className="space-y-3 pt-2">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="text-xs font-mono text-blue-600 font-semibold">
                    OPTION 3 · SELECT A BUILT-IN ENTERPRISE DATASET
                  </div>
                  <h2 className="text-lg font-bold text-slate-900">
                    Or Choose a Sample Dataset to Launch Immediately
                  </h2>
                </div>
                <span className="text-xs text-slate-500">
                  Includes raw anomalies (duplicates, missing values, outliers)
                  to demonstrate Stage 3–6
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {SAMPLE_DATASETS.map((preset) => (
                  <button
                    key={preset.id}
                    type="button"
                    onClick={() => handleSelectPreset(preset.id)}
                    className="text-left p-5 rounded-xl border border-slate-200 hover:border-blue-600 bg-slate-50 hover:bg-blue-50/30 transition-all flex flex-col justify-between gap-4 cursor-pointer group"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-mono text-slate-500">
                          {preset.domainContext}
                        </span>
                        <span className="text-xs font-semibold text-blue-600 flex items-center gap-1">
                          <span>Load Dataset</span>
                          <ArrowRight className="w-3.5 h-3.5" />
                        </span>
                      </div>
                      <h3 className="text-base font-bold text-slate-900">
                        {preset.name}
                      </h3>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {preset.description}
                      </p>
                    </div>
                    <div className="pt-2.5 border-t border-slate-200 text-[11px] text-slate-500 font-mono truncate">
                      Goal: {preset.defaultBusinessQuestion}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Option 4: 1-Click Read-Only Live Connectors (Beyond Manual CSV Uploads) */}
            <div className="space-y-3 pt-3 border-t border-slate-200">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <div className="text-xs font-mono text-blue-600 font-semibold">
                    OPTION 4 · 1-CLICK READ-ONLY LIVE CONNECTORS (NO MANUAL CSV EXPORT NEEDED)
                  </div>
                  <h2 className="text-lg font-bold text-slate-900">
                    Connect Google Sheets, PostgreSQL, Shopify, Stripe, TallyPrime, or GA4
                  </h2>
                </div>
                <span className="text-xs font-mono text-emerald-600">
                  Pre-Flight Sanity Gate & Semantic Memory Active
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {LIVE_CONNECTORS_CATALOG.map((conn) => (
                  <button
                    key={conn.id}
                    type="button"
                    onClick={() => {
                      const payload = generateConnectorLiveDataset(conn.id);
                      setDatasetName(payload.datasetName);
                      setDomainContext(payload.domainContext);
                      setBusinessQuestion(payload.businessQuestion);
                      setRawRows(payload.rows);
                      setSelectedPresetId("");
                      setAiReport(null);
                      setHasActiveDataset(true);
                      setAutopilotNotice(
                        `1-Click Read-Only Connector Synced: ${conn.name} (${payload.rows.length} raw records ingested; Pre-Flight Sanity & Semantic Memory active).`
                      );
                    }}
                    className="text-left p-4 rounded-xl border border-slate-200 hover:border-blue-600 bg-slate-50 transition-all flex flex-col justify-between gap-3 cursor-pointer"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[11px] font-mono">
                        <span className="text-blue-600 font-semibold">
                          {conn.category}
                        </span>
                        <span className="text-emerald-600">
                          {conn.latencyMs}ms · Read-Only
                        </span>
                      </div>
                      <div className="text-sm font-bold text-slate-900">
                        {conn.name}
                      </div>
                      <p className="text-xs text-slate-600 line-clamp-2">
                        {conn.description}
                      </p>
                    </div>
                    <div className="pt-2 border-t border-slate-200 flex items-center justify-between text-xs font-semibold text-blue-600">
                      <span>1-Click Sync Stream ({conn.previewRowCount} rows)</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </section>
        </main>
      ) : (
      /* =====================================================================
         ACTIVE 6-STAGE ANALYTICS WORKSPACE (STRICT CSS GRID — ZERO CLIPPING)
         ===================================================================== */
      <div
        className={`flex-1 grid grid-cols-1 ${
          isSideChatOpen
            ? "lg:grid-cols-[minmax(0,1fr)_330px] xl:grid-cols-[minmax(0,1fr)_360px]"
            : "lg:grid-cols-1"
        } items-start max-w-[2400px] w-full mx-auto overflow-x-hidden`}
      >
      {/* Main Content Container */}
      <main className="min-w-0 w-full max-w-full overflow-x-hidden px-3 sm:px-6 lg:px-8 py-5 sm:py-8 space-y-6 sm:space-y-8">
        {/* Workspace Context Header & 6-Stage Pipeline Bar */}
        <section className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 min-w-0 max-w-full overflow-x-hidden">
          <div className="flex flex-col gap-4 pb-5 border-b border-slate-200 min-w-0">
            <div className="min-w-0 w-full">
              <div className="flex items-center gap-x-2 gap-y-1 text-xs text-slate-500 mb-1.5 flex-wrap">
                <span className="font-semibold text-blue-600 flex items-center gap-1">
                  <Lock className="w-3 h-3 shrink-0" />
                  <span>
                    Exclusive Owner: Rushi Chavan (rushichavan69@gmail.com)
                  </span>
                </span>
                <span aria-hidden="true">·</span>
                <span className="break-words">Active Dataset: {datasetName}</span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">
                  {cleaningSummary.cleanedRowCount} Verified Rows
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-slate-900 tracking-tight break-words">
                {activeReport.stage5VisualNarrative.dashboardHeadline}
              </h1>
              <p className="text-xs sm:text-sm text-slate-600 mt-1.5 max-w-4xl break-words leading-relaxed">
                {activeReport.stage1ProblemFraming.refinedQuestion}
              </p>
            </div>

            {/* Responsive Action Command Bar — Wraps cleanly on Mobile, Tablet, Laptop/PC (even with AI Sidebar open), and 4K TV */}
            <div className="flex flex-wrap items-center gap-2 w-full pt-1 min-w-0">
              <button
                onClick={() => {
                  setIngestionError(null);
                  setShowDataModal(true);
                }}
                className="px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5 shrink-0" />
                <span>Switch / Upload Data</span>
              </button>
              <button
                onClick={handleResetEverything}
                title="Clear active dataset and return to the Upload / Select Dataset screen"
                className="px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5 shrink-0" />
                <span>Reset Everything</span>
              </button>
              <button
                onClick={() => setNewbieGuideMode((prev) => !prev)}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer border ${
                  newbieGuideMode
                    ? "bg-blue-600 text-white border-blue-500"
                    : "border-slate-300 text-slate-700 bg-slate-100 hover:bg-slate-200"
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {newbieGuideMode ? "Newbie Guide: ON" : "Newbie Guide: OFF"}
                </span>
              </button>
              <button
                onClick={() => setIsSideChatOpen((prev) => !prev)}
                className={`px-3 py-2 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  isSideChatOpen
                    ? "bg-slate-900 text-white hover:bg-slate-800"
                    : "text-slate-700 bg-slate-100 hover:bg-slate-200"
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5 shrink-0" />
                <span>{isSideChatOpen ? "Hide AI Guide" : "Open AI Guide"}</span>
              </button>
              <button
                onClick={() => setShowExportModal(true)}
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5 shrink-0" />
                <span>Export Dataset (.xlsx / .csv / .json)</span>
              </button>
              <button
                onClick={handleDownloadReport}
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>Export Report (.md)</span>
              </button>
              <button
                onClick={() =>
                  downloadExecutiveBoardDeckPdf({
                    datasetName,
                    domainContext,
                    businessQuestion,
                    cleaningSummary,
                    columnProfiles,
                    correlations,
                    activeReport,
                  })
                }
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>Save Executive PDF (.pdf)</span>
              </button>
              <button
                onClick={handleOpenBiStudio}
                className={`px-3 py-2 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer ${
                  activeView === "bi-studio"
                    ? "bg-emerald-600 text-white"
                    : "text-white bg-blue-600 hover:bg-blue-700"
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 shrink-0" />
                <span>
                  {activeView === "bi-studio"
                    ? "✓ 108 Power BI & Tableau Studio Active"
                    : "108 Power BI & Tableau Studio"}
                </span>
              </button>
              <button
                onClick={() => setShowThemeModal(true)}
                className="px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Palette className="w-3.5 h-3.5 shrink-0" />
                <span>Customize Theme & Colors</span>
              </button>
              <button
                onClick={() => setShowShortcutsModal(true)}
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <Keyboard className="w-3.5 h-3.5 shrink-0" />
                <span>Shortcuts (Ctrl+K)</span>
              </button>
              <button
                onClick={() => setShowLicenseModal(true)}
                className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
              >
                <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-blue-600" />
                <span>Security & Owner Lock</span>
              </button>
            </div>
          </div>

          {autopilotNotice && (
            <div className="mt-4 px-4 py-2.5 bg-blue-50 border border-blue-200 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs text-blue-900">
              <span className="break-words">{autopilotNotice}</span>
              <button
                onClick={() => setAutopilotNotice(null)}
                className="text-blue-700 hover:underline font-medium whitespace-nowrap cursor-pointer"
              >
                Dismiss
              </button>
            </div>
          )}

          {/* Interactive Newbie Guided Walkthrough Coach */}
          {newbieGuideMode && (
            <div className="mt-5 p-3.5 sm:p-4 rounded-xl bg-slate-50 border border-blue-600 space-y-3 min-w-0">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-2.5 border-b border-slate-200">
                <div className="flex items-center gap-2 min-w-0">
                  <HelpCircle className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-900 break-words">
                    Newbie Guided Assistant · Step-by-Step Starter Coach
                  </span>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {[
                    { idx: 0, label: "1. Pick Data" },
                    { idx: 1, label: "2. Clean Errors" },
                    { idx: 2, label: "3. Auto-Python & Stats" },
                    { idx: 3, label: "4. Read Charts" },
                    { idx: 4, label: "5. Simulate ROI" },
                  ].map((s) => (
                    <button
                      key={s.idx}
                      onClick={() => setNewbieStep(s.idx)}
                      className={`px-2.5 py-1 text-[11px] font-mono rounded transition-colors cursor-pointer ${
                        newbieStep === s.idx
                          ? "bg-blue-600 text-white font-bold"
                          : "bg-slate-100 text-slate-600 border border-slate-200 hover:border-blue-600"
                      }`}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>

              {newbieStep === 0 && (
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="text-sm font-bold text-slate-900">
                      Step 1 for Beginners: Where do I start? (Choose or Upload Your Data)
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                      You don&apos;t need to know coding or formulas. Rexor loaded{" "}
                      <span className="font-mono text-blue-600">{datasetName}</span> for you!
                      Want to analyze a different Excel (`.xlsx`), CSV, or JSON file? Click{" "}
                      <strong>&quot;Switch / Upload Data&quot;</strong> or <strong>&quot;Reset Everything&quot;</strong> anytime.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setShowDataModal(true)}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      Upload / Switch Dataset
                    </button>
                    <button
                      onClick={() => setNewbieStep(1)}
                      className="px-3 py-1.5 text-xs font-mono border border-slate-200 text-slate-700 rounded-lg cursor-pointer"
                    >
                      Next Step →
                    </button>
                  </div>
                </div>
              )}

              {newbieStep === 1 && (
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="text-sm font-bold text-slate-900">
                      Step 2 for Beginners: What is Data Cleaning? (Stage 3)
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                      Real-world spreadsheets have duplicate rows, blank cells, and extreme typos that ruin averages.
                      Rexor automatically found and repaired{" "}
                      <span className="font-mono text-blue-600">
                        {cleaningSummary.logs.length} issues
                      </span>{" "}
                      (raising data health from {cleaningSummary.dataHealthBefore}% to{" "}
                      {cleaningSummary.dataHealthAfter}%). Click below to inspect every cell Rexor fixed.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setActiveView("cleaning")}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      Inspect Cleaned Cells
                    </button>
                    <button
                      onClick={() => setNewbieStep(2)}
                      className="px-3 py-1.5 text-xs font-mono border border-slate-200 text-slate-700 rounded-lg cursor-pointer"
                    >
                      Next Step →
                    </button>
                  </div>
                </div>
              )}

              {newbieStep === 2 && (
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="text-sm font-bold text-slate-900">
                      Step 3 for Beginners: Autonomous Python & Statistical Playbooks (Stage 4)
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                      You never have to guess which Python playbook or statistical test to run.
                      Rexor scans your columns, correlations, and business goal to{" "}
                      <strong>auto-select and run the best Python Data Science Playbook by itself</strong>, or you can type any task in plain English!
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setActiveView("analysis")}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      Open Auto-Python & SQL Lab
                    </button>
                    <button
                      onClick={() => setNewbieStep(3)}
                      className="px-3 py-1.5 text-xs font-mono border border-slate-200 text-slate-700 rounded-lg cursor-pointer"
                    >
                      Next Step →
                    </button>
                  </div>
                </div>
              )}

              {newbieStep === 3 && (
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="text-sm font-bold text-slate-900">
                      Step 4 for Beginners: How to Read the Charts (Stage 5)
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                      Use the Bar Chart to compare categories (e.g., which region makes the most revenue),
                      the Scatter Plot to see if two numbers move together, and the Histogram to see typical vs. extreme values.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setActiveView("visuals-actions")}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      Explore Visual Charts
                    </button>
                    <button
                      onClick={() => setNewbieStep(4)}
                      className="px-3 py-1.5 text-xs font-mono border border-slate-200 text-slate-700 rounded-lg cursor-pointer"
                    >
                      Next Step →
                    </button>
                  </div>
                </div>
              )}

              {newbieStep === 4 && (
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-1 min-w-0">
                    <div className="text-sm font-bold text-slate-900">
                      Step 5 for Beginners: Take Action & Export Your Report (Stage 6)
                    </div>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-3xl break-words">
                      Data analysis only matters when it drives decisions. Check Stage 6 for prioritized P0/P1/P2 recommendations,
                      drag the ROI Simulator sliders to forecast financial impact, and click{" "}
                      <strong>&quot;Export Report (.md)&quot;</strong> to share your findings.
                    </p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <button
                      onClick={() => setActiveView("visuals-actions")}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                    >
                      Go to Action Plan & ROI
                    </button>
                    <button
                      onClick={() => setNewbieStep(0)}
                      className="px-3 py-1.5 text-xs font-mono border border-slate-200 text-slate-700 rounded-lg cursor-pointer"
                    >
                      Restart Tour
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* 6-Stage Data Analytics Lifecycle Stepper */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3 pt-5">
            {LIFECYCLE_STAGES.map((st, idx) => {
              const isStepActive =
                isRunningAutopilot && autopilotStep === idx + 1;
              return (
                <button
                  key={st.num}
                  onClick={() => setActiveView(st.targetView)}
                  className={`text-left p-3.5 rounded-lg border transition-colors cursor-pointer min-w-0 ${
                    isStepActive
                      ? "border-blue-600 bg-blue-50/50"
                      : "border-slate-200 hover:border-slate-300 bg-slate-50/60 hover:bg-slate-100/70"
                  }`}
                >
                  <div className="flex items-center justify-between text-xs text-slate-500 mb-1">
                    <span className="font-mono font-semibold text-blue-600 tabular-nums">
                      Stage {st.num}
                    </span>
                    <span className="text-[11px] text-emerald-700 font-medium">
                      Ready
                    </span>
                  </div>
                  <div className="text-sm font-semibold text-slate-900 truncate">
                    {st.title}
                  </div>
                  <div className="text-xs text-slate-500 font-mono tabular-nums mt-1 truncate">
                    {st.metric}
                  </div>
                </button>
              );
            })}
          </div>
        </section>

        {/* Universal Simple AI Data Editor & Every-Stage Task Problem Solver Bar */}
        <RexorUniversalTaskSolverBar
          activeView={activeView}
          datasetName={datasetName}
          businessQuestion={businessQuestion}
          rawRows={rawRows}
          cleanedRows={cleanedRows}
          cleaningSummary={cleaningSummary}
          columnProfiles={columnProfiles}
          correlations={correlations}
          userRequirements={userRequirements}
          adaptiveExecutionSummary={ruleExecutionSummary}
          onApplyInstruction={(instructionText) => {
            const compiled = compileUserRequirementToRule(
              instructionText,
              columnProfiles,
              "Direct User Edit"
            );
            setUserRequirements((prev) => [compiled, ...prev]);
            setAiReport(null);
            setAutopilotNotice(
              `✅ Applied Change to ${datasetName}: ${compiled.title}`
            );
            return compiled;
          }}
          onUndoLastRequirement={() => {
            setUserRequirements((prev) => prev.slice(1));
            setAiReport(null);
            setAutopilotNotice("↩ Undid last custom data change.");
          }}
          onClearAllRequirements={() => {
            setUserRequirements([]);
            setAiReport(null);
            setAutopilotNotice("Reset all custom data edits.");
          }}
          onDownloadCleanedCsv={handleDownloadCleanedCsv}
          onNavigateView={(view) => setActiveView(view)}
        />

        {/* ===================================================================
            DEDICATED VIEW: 5-TASK INDUSTRY BUSINESS DATA ANALYST DELIVERABLE STUDIO
           =================================================================== */}
        {activeView === "industry-assignment" && (
          <RexorIndustryAssignmentStudio
            datasetName={datasetName}
            rawRows={rawRows}
            cleanedRows={cleanedRows}
            cleaningSummary={cleaningSummary}
            columnProfiles={columnProfiles}
            onLoadIndustryPreset={() =>
              handleSelectPreset("industry-business-assessment")
            }
            onOpenExportModal={() => setShowExportModal(true)}
          />
        )}

        {/* ===================================================================
            DEDICATED VIEW: 108 POWER BI & TABLEAU PRESENTATION STUDIO
           =================================================================== */}
        {activeView === "bi-studio" && (
          <div ref={biStudioSectionRef} className="space-y-6">
            <div className="p-4 rounded-xl bg-white border border-blue-600 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-0.5">
                <div className="text-xs font-mono text-blue-600 font-bold uppercase">
                  DEDICATED BI PRESENTATION & VISUALIZATION WORKSPACE
                </div>
                <div className="text-sm font-bold text-slate-900">
                  108 Power BI & Tableau Templates + AI Target Advisor ({datasetName})
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setActiveView("overview")}
                  className="px-3 py-1.5 text-xs font-semibold bg-slate-100 text-slate-800 rounded-lg cursor-pointer"
                >
                  ← Back to Lifecycle Overview
                </button>
                <button
                  onClick={() => setActiveView("visuals-actions")}
                  className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                >
                  Open Stage 5–6 Charts & ROI Simulator →
                </button>
              </div>
            </div>

            <RexorBiTemplateStudio
              datasetName={datasetName}
              cleanedRows={cleanedRows}
              cleaningSummary={cleaningSummary}
              columnProfiles={columnProfiles}
              correlations={correlations}
            />
          </div>
        )}

        {/* ===================================================================
            VIEW 1: END-TO-END LIFECYCLE EXECUTIVE OVERVIEW
           =================================================================== */}
        {activeView === "overview" && (
          <div className="space-y-8">
            {/* Multi-Agent System: Deterministic Sandbox, Semantic Memory, Pre-Flight Sanity, Live Connectors & 8AM Push Briefings */}
            <RexorMultiAgentCommandCenter
              datasetName={datasetName}
              domainContext={domainContext}
              businessQuestion={businessQuestion}
              rawRows={rawRows}
              cleanedRows={cleanedRows}
              cleaningSummary={cleaningSummary}
              columnProfiles={columnProfiles}
              correlations={correlations}
              activeReport={activeReport}
              onIngestLiveConnectorData={(payload) => {
                setDatasetName(payload.datasetName);
                setDomainContext(payload.domainContext);
                setBusinessQuestion(payload.businessQuestion);
                setRawRows(payload.rows);
                setSelectedPresetId("");
                setAiReport(null);
                setAutopilotNotice(
                  `Live Read-Only Stream Synced: ${payload.datasetName} (${payload.rows.length} raw records ingested and verified).`
                );
              }}
              onApplyIndustryLens={(lens) => {
                setDomainContext(lens.domainContext);
                setBusinessQuestion(lens.businessQuestion);
                setAutopilotNotice(
                  `Applied Industry Playbook Lens: ${lens.domainContext}`
                );
              }}
              onJumpToCleaningStage={() => setActiveView("cleaning")}
            />

            {/* Key Lifecycle Telemetry Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="text-xs text-slate-500">
                  Stage 2 · Ingestion Volume
                </div>
                <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">
                  {cleaningSummary.rawRowCount} → {cleaningSummary.cleanedRowCount}
                </div>
                <div className="text-xs text-slate-600 mt-1">
                  {columnProfiles.length} columns · {numericCols.length} numeric ·{" "}
                  {categoricalCols.length} categorical
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="text-xs text-slate-500">
                  Stage 3 · Data Quality Remediation
                </div>
                <div className="text-2xl font-bold text-emerald-700 font-mono tabular-nums mt-1">
                  {cleaningSummary.dataHealthBefore}% →{" "}
                  {cleaningSummary.dataHealthAfter}%
                </div>
                <div className="text-xs text-slate-600 mt-1 font-mono tabular-nums">
                  {cleaningSummary.duplicatesRemoved} dupes ·{" "}
                  {cleaningSummary.missingValuesImputed} nulls ·{" "}
                  {cleaningSummary.formatsNormalized} formats fixed
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="text-xs text-slate-500">
                  Stage 4 · Top Statistical Correlation
                </div>
                <div className="text-2xl font-bold text-slate-900 font-mono tabular-nums mt-1">
                  {correlations[0] ? `r = ${correlations[0].r}` : "N/A"}
                </div>
                <div className="text-xs text-slate-600 mt-1 truncate">
                  {correlations[0]
                    ? `${correlations[0].colA} ↔ ${correlations[0].colB}`
                    : "Select numeric variables"}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-5">
                <div className="text-xs text-slate-500">
                  Stage 6 · Projected Action Impact
                </div>
                <div className="text-2xl font-bold text-blue-600 font-mono tabular-nums mt-1">
                  +{simImprovementPct}% Target Lift
                </div>
                <div className="text-xs text-slate-600 mt-1">
                  {activeReport.stage6ActionPlan.recommendations.length} prioritized
                  interventions ready
                </div>
              </div>
            </div>

            {/* Stage 1 & Stage 3 Summary Split */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Stage 1: Business Problem & Tested Hypotheses */}
              <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                    <div>
                      <div className="text-xs text-slate-500">
                        Stage 01 · Understand the Business Problem
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                        Problem Framing & Hypothesis Verification
                      </h2>
                    </div>
                    <button
                      onClick={() => setActiveView("problem-data")}
                      className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <span>Edit Problem & Data</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="py-4 border-b border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-slate-500 block">
                        Decision Stakeholders
                      </span>
                      <span className="font-medium text-slate-900 mt-0.5 block">
                        {activeReport.stage1ProblemFraming.decisionStakeholders}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">
                        North Star Objective Metric
                      </span>
                      <span className="font-mono tabular-nums font-medium text-slate-900 mt-0.5 block">
                        {activeReport.stage1ProblemFraming.primaryObjectiveMetric}
                      </span>
                    </div>
                  </div>

                  <div className="divide-y divide-slate-100 mt-2">
                    {activeReport.stage1ProblemFraming.hypotheses.map((hyp) => (
                      <div key={hyp.id} className="py-3.5">
                        <div className="flex items-center justify-between text-xs mb-1">
                          <span className="font-mono font-semibold text-slate-900">
                            Hypothesis {hyp.id} · {hyp.validationStatus}
                          </span>
                          <span className="font-mono tabular-nums text-slate-500">
                            {hyp.evidenceMetric}
                          </span>
                        </div>
                        <p className="text-sm font-medium text-slate-900">
                          {hyp.statement}
                        </p>
                        <p className="text-xs text-slate-600 mt-0.5">
                          {hyp.rationale}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Stage 3: Automated Data Cleaning Summary */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-4 border-b border-slate-200">
                    <div>
                      <div className="text-xs text-slate-500">
                        Stage 03 · Clean & Prepare Data
                      </div>
                      <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                        Automated Remediation Audit
                      </h2>
                    </div>
                    <button
                      onClick={() => setActiveView("cleaning")}
                      className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                    >
                      <span>Inspect {cleaningSummary.logs.length} Fixes</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <p className="text-xs text-slate-600 mt-4 leading-relaxed">
                    {activeReport.stage3CleaningAssessment.structuralRisksResolved}
                  </p>

                  <div className="mt-4 divide-y divide-slate-100 border-t border-b border-slate-100">
                    {cleaningSummary.logs.slice(0, 5).map((log) => (
                      <div
                        key={log.id}
                        className="py-2.5 flex items-center justify-between text-xs gap-2"
                      >
                        <div className="truncate">
                          <span className="font-mono text-slate-500 tabular-nums">
                            Row {log.rowIndex}
                          </span>
                          <span className="mx-1.5 text-slate-300">·</span>
                          <span className="font-medium text-slate-800">
                            {log.column}
                          </span>
                          <span className="mx-1.5 text-slate-300">·</span>
                          <span className="text-slate-500">{log.issueType}</span>
                        </div>
                        <div className="font-mono tabular-nums shrink-0 text-right">
                          <span className="line-through text-red-600 mr-1.5">
                            {log.originalValue}
                          </span>
                          <span className="text-emerald-700 font-medium">
                            → {log.cleanedValue}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-4 pt-3 flex items-center justify-between text-xs text-slate-500">
                  <span>
                    Post-Cleaning Reliability:{" "}
                    <strong className="font-mono tabular-nums text-slate-900">
                      {activeReport.stage3CleaningAssessment.dataReliabilityScore}%
                    </strong>
                  </span>
                  <button
                    onClick={handleDownloadCleanedCsv}
                    className="text-blue-600 hover:underline font-medium cursor-pointer"
                  >
                    Export Cleaned Table →
                  </button>
                </div>
              </div>
            </div>

            {/* 100% Mathematical Accuracy & Cross-Stage Reconciliation Ledger */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-slate-200">
                <div>
                  <div className="text-xs font-mono text-emerald-700 font-bold">
                    ZERO-ERROR MATHEMATICAL AUDIT · 100% PANDAS / SCIPY / SQL PARITY
                  </div>
                  <h3 className="text-base font-bold text-slate-900 mt-0.5">
                    Cross-Stage Mathematical & Statistical Reconciliation Ledger
                  </h3>
                </div>
                <span className="text-xs font-mono text-slate-600">
                  Verified: {cleaningSummary.rawRowCount} Raw −{" "}
                  {cleaningSummary.duplicatesRemoved} Removed ={" "}
                  {cleaningSummary.cleanedRowCount} Valid Rows (100.0% Match)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <div className="font-mono text-[11px] text-slate-500">
                    1. ROW & ENTITY RECONCILIATION
                  </div>
                  <div className="font-bold text-slate-900 font-mono">
                    {cleaningSummary.rawRowCount} → {cleaningSummary.cleanedRowCount} Rows
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Composite subset deduplication + unpaid/refunded isolation
                    verified before revenue aggregation.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <div className="font-mono text-[11px] text-slate-500">
                    2. BESSEL SAMPLE STDDEV & 1.5×IQR
                  </div>
                  <div className="font-bold text-slate-900 font-mono">
                    ddof = 1 (N − 1) · Q3 + 1.5×IQR
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Exact linear-interpolated quartiles and sample variance
                    matching pandas.DataFrame.describe().
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <div className="font-mono text-[11px] text-slate-500">
                    3. UNBIASED COHORT MEAN PRESERVATION
                  </div>
                  <div className="font-bold text-slate-900 font-mono">
                    0.00% Median Distortion
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Missing ratings/scores use cohort-preserving group means so
                    Outlet/Segment averages remain 100% exact.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg space-y-1">
                  <div className="font-mono text-[11px] text-slate-500">
                    4. TAUTOLOGY-FREE DRIVER RANKING
                  </div>
                  <div className="font-bold text-slate-900 font-mono">
                    {correlations[0]
                      ? `${correlations[0].colA} ↔ ${correlations[0].colB} (r = ${correlations[0].r})`
                      : "Verified Operational Drivers"}
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Separates accounting identities (Gross vs Net) to rank true
                    operational cause-and-effect drivers #1.
                  </p>
                </div>
              </div>
            </div>

            {/* Adaptive User Requirements & Senior Analyst Ecosystem Knowledge Vault */}
            <RexorAdaptiveKnowledgeHub
              datasetName={datasetName}
              domainContext={domainContext}
              businessQuestion={businessQuestion}
              sampleRows={cleanedRows}
              cleanedRows={cleanedRows}
              columnProfiles={columnProfiles}
              correlations={correlations}
              userRequirements={userRequirements}
              onUpdateRequirements={(next) => {
                setUserRequirements(next);
                setAiReport(null);
              }}
              ruleExecutionSummary={ruleExecutionSummary}
              ecosystemKnowledge={ecosystemKnowledge}
              onUpdateEcosystemKnowledge={setEcosystemKnowledge}
              onTriggerNotice={(msg) => setAutopilotNotice(msg)}
            />

            {/* 108 Power BI & Tableau Presentation & Multi-Layout Visualization Studio */}
            <RexorBiTemplateStudio
              datasetName={datasetName}
              cleanedRows={cleanedRows}
              cleaningSummary={cleaningSummary}
              columnProfiles={columnProfiles}
              correlations={correlations}
            />

            {/* Stage 4 & Stage 5: Visual Exploration + Key Statistical Insights */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-5">
                  <div>
                    <div className="text-xs text-slate-500">
                      Stage 05 · Visualize & Communicate
                    </div>
                    <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                      Cohort Performance Breakdown ({chartYCol} by {chartXCol})
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveView("visuals-actions")}
                    className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                  >
                    <span>Full Chart Studio</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <InteractiveBarChart
                  rows={cleanedRows}
                  xCol={chartXCol}
                  yCol={chartYCol}
                  aggFn="AVG"
                />
              </div>

              <div className="lg:col-span-6 bg-white border border-slate-200 rounded-xl p-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-5">
                  <div>
                    <div className="text-xs text-slate-500">
                      Stage 04 · Statistical Driver Regression
                    </div>
                    <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                      Bivariate Relationship ({scatterXCol} vs {scatterYCol})
                    </h2>
                  </div>
                  <button
                    onClick={() => setActiveView("analysis")}
                    className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                  >
                    <span>SQL & Python Code</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                <InteractiveScatterPlot
                  rows={cleanedRows}
                  xCol={scatterXCol}
                  yCol={scatterYCol}
                  colorCol={chartXCol}
                />
              </div>
            </div>

            {/* Advanced Statistical & Predictive Suite (Pivot, Hypothesis t-Test, Forecasting, Z-Score Anomalies) */}
            <AdvancedAnalyticsSuite
              rows={cleanedRows}
              columnProfiles={columnProfiles}
              datasetName={datasetName}
            />

            {/* Universal Python Data Science & N-Task Runner */}
            <RexorPythonStudio
              rows={cleanedRows}
              columnProfiles={columnProfiles}
              correlations={correlations}
              datasetName={datasetName}
              businessQuestion={businessQuestion}
              newbieGuideMode={newbieGuideMode}
              onToggleNewbieGuide={() => setNewbieGuideMode((prev) => !prev)}
              onAddDerivedColumn={(_colName, updatedRows) => {
                setRawRows(updatedRows);
              }}
            />

            {/* Enterprise Command Suite: Multi-Table SQL JOIN, Target Goal-Seek, Snapshots & Board Deck */}
            <RexorEnterpriseCommandSuite
              cleanedRows={cleanedRows}
              rawRows={rawRows}
              columnProfiles={columnProfiles}
              correlations={correlations}
              cleaningSummary={cleaningSummary}
              datasetName={datasetName}
              businessQuestion={businessQuestion}
              domainContext={domainContext}
              activeReport={activeReport}
              newbieGuideMode={newbieGuideMode}
              onCommitMergedDataset={(merged, mergedTitle, notice) => {
                setRawRows(merged);
                setDatasetName(mergedTitle);
                setSelectedPresetId("");
                setAiReport(null);
                setAutopilotNotice(notice);
              }}
              onRestoreSnapshot={handleRestoreSnapshot}
            />

            {/* Stage 6: Recommended Actions & KPI Measurement Table */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-4 border-b border-slate-200">
                <div>
                  <div className="text-xs text-slate-500">
                    Stage 06 · Recommend Action & Measure Results
                  </div>
                  <h2 className="text-lg font-bold text-slate-900 mt-0.5">
                    Executive Action Playbook & KPI Tracking Matrix
                  </h2>
                </div>
                <button
                  onClick={() => setActiveView("visuals-actions")}
                  className="text-xs font-medium text-blue-600 hover:text-blue-800 flex items-center gap-1 whitespace-nowrap cursor-pointer"
                >
                  <span>Open ROI Impact Simulator</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 pt-5">
                {activeReport.stage6ActionPlan.recommendations.map(
                  (rec, index) => (
                    <div
                      key={index}
                      className="border border-slate-200 rounded-lg p-4 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                          <span className="font-mono font-semibold text-blue-600">
                            {rec.priority}
                          </span>
                          <span>Effort: {rec.effortLevel}</span>
                        </div>
                        <h3 className="text-base font-bold text-slate-900">
                          {rec.actionTitle}
                        </h3>
                        <div className="text-xs text-slate-500 mt-1">
                          Target: {rec.targetSegmentOrVariable}
                        </div>
                        <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                          {rec.concreteMechanism}
                        </p>
                      </div>

                      <div className="mt-4 pt-3 border-t border-slate-100 text-xs space-y-1">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Expected Impact:</span>
                          <span className="font-mono font-semibold text-emerald-700 tabular-nums">
                            {rec.quantifiedExpectedImpact}
                          </span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-slate-500">Tracking KPI:</span>
                          <span className="font-medium text-slate-900">
                            {rec.measurementKpi}
                          </span>
                        </div>
                      </div>
                    </div>
                  )
                )}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            VIEW 2: STAGE 1 (PROBLEM FRAMING) & STAGE 2 (COLLECT & ACCESS DATA)
           =================================================================== */}
        {activeView === "problem-data" && (
          <div className="space-y-8">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Stage 1: Business Problem Definition */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-slate-500">
                    Stage 01 · Understand the Business Problem
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                    Define Analytical Question & Scope
                  </h2>
                  <p className="text-xs text-slate-600 mt-1">
                    Tell Rexor what business decision or operational bottleneck
                    needs to be solved. Rexor formulates testable statistical
                    hypotheses automatically.
                  </p>

                  <div className="space-y-4 mt-5">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Dataset Title
                      </label>
                      <input
                        type="text"
                        value={datasetName}
                        onChange={(e) => setDatasetName(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Industry / Operational Domain
                      </label>
                      <input
                        type="text"
                        value={domainContext}
                        onChange={(e) => setDomainContext(e.target.value)}
                        className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        Core Business Question to Answer
                      </label>
                      <textarea
                        rows={4}
                        value={businessQuestion}
                        onChange={(e) => setBusinessQuestion(e.target.value)}
                        placeholder="e.g., Why is customer churn increasing in Mid-Market accounts, and which levers will improve net retention?"
                        className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-5 mt-5 border-t border-slate-200 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    {activeReport.stage1ProblemFraming.hypotheses.length} Active
                    Hypotheses
                  </span>
                  <button
                    onClick={runRexorAutopilot}
                    disabled={isRunningAutopilot}
                    className="px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
                  >
                    Re-Synthesize Hypotheses
                  </button>
                </div>
              </div>

              {/* Stage 2: Collect & Access Data Connectors */}
              <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-4 sm:p-6 min-w-0">
                <div className="flex flex-col gap-3 pb-4 border-b border-slate-200 min-w-0">
                  <div>
                    <div className="text-xs text-slate-500">
                      Stage 02 · Collect & Access Data
                    </div>
                    <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                      Multi-Source Data Ingestion Hub
                    </h2>
                  </div>

                  {/* Interactive Source Selector Tabs */}
                  <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 rounded-lg w-full">
                    {[
                      { id: "presets", label: "Enterprise Presets" },
                      { id: "upload", label: "Excel / CSV Upload" },
                      { id: "paste", label: "Paste Raw Data" },
                      { id: "api", label: "REST API" },
                    ].map((t) => (
                      <button
                        key={t.id}
                        onClick={() => {
                          setSourceTab(t.id as IngestionSourceTab);
                          setIngestionError(null);
                        }}
                        className={`px-2.5 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                          sourceTab === t.id
                            ? "bg-white text-slate-900 shadow-xs"
                            : "text-slate-600 hover:text-slate-900"
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                {ingestionError && (
                  <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
                    {ingestionError}
                  </div>
                )}

                {/* Connector 1: Enterprise Sample Datasets */}
                {sourceTab === "presets" && (
                  <div className="mt-5 space-y-3">
                    <p className="text-xs text-slate-600">
                      Select a production-grade dataset containing real-world
                      data anomalies (duplicates, missing cells, unformatted
                      currencies, and outliers) to test Rexor’s full lifecycle:
                    </p>
                    {SAMPLE_DATASETS.map((preset) => {
                      const isSelected = selectedPresetId === preset.id;
                      return (
                        <div
                          key={preset.id}
                          onClick={() => handleSelectPreset(preset.id)}
                          className={`p-4 rounded-lg border transition-colors cursor-pointer ${
                            isSelected
                              ? "border-blue-600 bg-blue-50/30"
                              : "border-slate-200 hover:border-slate-300 bg-white"
                          }`}
                        >
                          <div className="flex items-center justify-between">
                            <div className="font-semibold text-sm text-slate-900">
                              {preset.name}
                            </div>
                            <span className="text-xs text-slate-500">
                              {preset.sourceType} · {preset.domainContext.split(",")[0]}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 mt-1">
                            {preset.description}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Connector 2: Upload Excel (.xlsx), CSV, TSV, JSON */}
                {sourceTab === "upload" && (
                  <div className="mt-5 space-y-4">
                    <label
                      htmlFor="rexor-global-file-input"
                      onDragOver={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                      }}
                      onDrop={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        const droppedFile = e.dataTransfer?.files?.[0];
                        if (droppedFile) {
                          processUploadedFileObject(droppedFile);
                        }
                      }}
                      className="block border-2 border-dashed border-blue-600 hover:bg-blue-50/40 rounded-xl p-8 text-center cursor-pointer transition-colors bg-slate-50/50"
                    >
                      <FileSpreadsheet className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                      <div className="text-sm font-semibold text-slate-900">
                        Click or Drag & Drop Excel (.xlsx, .xls), CSV, TSV, or JSON file
                      </div>
                      <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                        Automatically validates, cleans, and displays your uploaded spreadsheet rows below.
                      </p>
                      <span className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 rounded-lg hover:bg-blue-700 cursor-pointer">
                        <Upload className="w-3.5 h-3.5" />
                        <span>Select Local File (.xlsx / .csv / .json)</span>
                      </span>
                    </label>

                    {/* Diagnostic Simulator Bar to Test All 3 Pre-Ingestion Validation Warnings */}
                    <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                      <div className="text-xs text-slate-600">
                        <strong className="text-slate-900">
                          Test Pre-Ingestion Validator:
                        </strong>{" "}
                        Simulate broken uploads to inspect the warning & recovery UI:
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            handleSimulateValidationScenario("empty")
                          }
                          className="px-2.5 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white hover:border-slate-400 text-slate-700 cursor-pointer"
                        >
                          1. Empty File (0B)
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleSimulateValidationScenario("missing-header")
                          }
                          className="px-2.5 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white hover:border-slate-400 text-slate-700 cursor-pointer"
                        >
                          2. Missing Header Row
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            handleSimulateValidationScenario(
                              "malformed-delimiter"
                            )
                          }
                          className="px-2.5 py-1 text-[11px] font-mono rounded border border-slate-300 bg-white hover:border-slate-400 text-slate-700 cursor-pointer"
                        >
                          3. Malformed Delimiters
                        </button>
                      </div>
                    </div>
                  </div>
                )}

                {/* Connector 3: Paste Raw CSV / TSV / JSON */}
                {sourceTab === "paste" && (
                  <div className="mt-5 space-y-3">
                    <label className="block text-xs font-medium text-slate-700">
                      Paste Raw CSV, TSV (from Excel/Sheets), or JSON Array
                    </label>
                    <textarea
                      rows={7}
                      value={pasteInput}
                      onChange={(e) => setPasteInput(e.target.value)}
                      placeholder={`region,monthly_revenue,churn_pct,support_tickets\nNorth America,"$14,200",2.1,3\nEMEA,"$9,800",4.8,11\nAPAC,,1.9,2`}
                      className="w-full p-3 text-xs font-mono bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                    <div className="flex justify-end">
                      <button
                        onClick={handleIngestPastedData}
                        className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg cursor-pointer"
                      >
                        Ingest & Clean Pasted Dataset
                      </button>
                    </div>
                  </div>
                )}

                {/* Connector 4: Live REST API Stream */}
                {sourceTab === "api" && (
                  <div className="mt-5 space-y-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-700 mb-1">
                        REST API Endpoint URL (JSON Array or CSV Stream)
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="url"
                          value={apiUrl}
                          onChange={(e) => setApiUrl(e.target.value)}
                          placeholder="https://api.example.com/v1/metrics"
                          className="flex-1 px-3 py-2 text-xs font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                        />
                        <button
                          onClick={handleFetchApiData}
                          disabled={isFetchingUrl}
                          className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg whitespace-nowrap shrink-0 flex items-center gap-1.5 cursor-pointer"
                        >
                          <Globe className="w-3.5 h-3.5" />
                          <span>{isFetchingUrl ? "Fetching..." : "Connect API"}</span>
                        </button>
                      </div>
                    </div>
                    <p className="text-xs text-slate-500">
                      Rexor proxies the request through its backend connector,
                      flattens nested JSON objects into tabular columns, and
                      pipes the records directly into Stage 3 cleaning.
                    </p>
                  </div>
                )}

                {/* Live Active Dataset Verification Banner inside Multi-Source Data Ingestion Hub */}
                {cleanedRows.length > 0 && (
                  <div className="mt-5 p-4 rounded-xl bg-emerald-50/70 border border-emerald-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-bold text-slate-900">
                        ✅ Active Dataset Loaded: {datasetName}
                      </div>
                      <div className="text-[11px] font-mono text-slate-600 mt-0.5">
                        {cleaningSummary.rawRowCount} Raw Rows →{" "}
                        <strong>{cleaningSummary.cleanedRowCount} Cleaned Rows</strong> ·{" "}
                        {columnProfiles.length} Columns ({numericCols.length} Numeric,{" "}
                        {categoricalCols.length} Categorical)
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => setActiveView("cleaning")}
                        className="px-3 py-1.5 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
                      >
                        Stage 3: Clean & Edit →
                      </button>
                      <button
                        type="button"
                        onClick={() => setActiveView("analysis")}
                        className="px-3 py-1.5 text-xs font-semibold bg-white border border-slate-300 text-slate-800 rounded-lg cursor-pointer"
                      >
                        Stage 4: Analyze →
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Live Ingested Data Table Preview directly inside Stage 1-2 (Multi-Source Ingestion Hub) */}
            {filteredTableRows.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-200">
                  <div>
                    <div className="text-xs font-mono text-blue-600 font-semibold uppercase">
                      STAGE 02 OUTPUT · LIVE INGESTED SPREADSHEET PREVIEW
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                      Loaded Data Table: {datasetName} ({filteredTableRows.length}{" "}
                      {tableMode === "cleaned" ? "Cleaned" : "Raw"} Rows)
                    </h3>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="inline-flex rounded-lg border border-slate-200 p-0.5 bg-slate-100">
                      <button
                        type="button"
                        onClick={() => setTableMode("cleaned")}
                        className={`px-2.5 py-1 text-xs font-medium rounded-md cursor-pointer ${
                          tableMode === "cleaned"
                            ? "bg-white text-slate-900 shadow-xs"
                            : "text-slate-600"
                        }`}
                      >
                        Cleaned ({cleanedRows.length})
                      </button>
                      <button
                        type="button"
                        onClick={() => setTableMode("raw")}
                        className={`px-2.5 py-1 text-xs font-medium rounded-md cursor-pointer ${
                          tableMode === "raw"
                            ? "bg-white text-slate-900 shadow-xs"
                            : "text-slate-600"
                        }`}
                      >
                        Raw ({rawRows.length})
                      </button>
                    </div>
                    <input
                      type="text"
                      value={tableSearch}
                      onChange={(e) => setTableSearch(e.target.value)}
                      placeholder="Search loaded rows..."
                      className="px-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                  </div>
                </div>

                <div className="overflow-x-auto max-h-80 overflow-y-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead className="sticky top-0 bg-slate-50 border-b border-slate-200">
                      <tr className="text-slate-600">
                        <th className="py-2 px-3 font-mono">#</th>
                        {Object.keys(filteredTableRows[0]).map((col) => (
                          <th
                            key={col}
                            className={`py-2 px-3 font-semibold whitespace-nowrap ${
                              columnTypes[col] === "numeric"
                                ? "text-right"
                                : "text-left"
                            }`}
                          >
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredTableRows.slice(0, 50).map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-slate-50">
                          <td className="py-1.5 px-3 font-mono text-slate-400">
                            {rIdx + 1}
                          </td>
                          {Object.keys(filteredTableRows[0]).map((col) => (
                            <td
                              key={col}
                              className={`py-1.5 px-3 whitespace-nowrap ${
                                columnTypes[col] === "numeric"
                                  ? "text-right font-mono tabular-nums text-slate-900"
                                  : "text-left text-slate-700"
                              }`}
                            >
                              {String(row[col] ?? "")}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* Stage 1 Tested Hypotheses Detail Grid */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="text-xs text-slate-500">
                Stage 01 Output · Automated Hypothesis Matrix
              </div>
              <h3 className="text-lg font-bold text-slate-900 mt-0.5 mb-4">
                Structured Business Hypotheses & Empirical Validation
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {activeReport.stage1ProblemFraming.hypotheses.map((h) => (
                  <div
                    key={h.id}
                    className="p-4 border border-slate-200 rounded-lg flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-500 mb-2">
                        <span className="font-mono font-semibold text-slate-900">
                          {h.id}
                        </span>
                        <span className="font-medium text-emerald-700">
                          {h.validationStatus}
                        </span>
                      </div>
                      <div className="text-sm font-semibold text-slate-900">
                        {h.statement}
                      </div>
                      <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                        {h.rationale}
                      </p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 text-xs font-mono tabular-nums text-slate-700">
                      Evidence: {h.evidenceMetric}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Adaptive User Requirements & Senior Analyst Ecosystem Knowledge Vault */}
            <RexorAdaptiveKnowledgeHub
              datasetName={datasetName}
              domainContext={domainContext}
              businessQuestion={businessQuestion}
              sampleRows={cleanedRows}
              cleanedRows={cleanedRows}
              columnProfiles={columnProfiles}
              correlations={correlations}
              userRequirements={userRequirements}
              onUpdateRequirements={(next) => {
                setUserRequirements(next);
                setAiReport(null);
              }}
              ruleExecutionSummary={ruleExecutionSummary}
              ecosystemKnowledge={ecosystemKnowledge}
              onUpdateEcosystemKnowledge={setEcosystemKnowledge}
              onTriggerNotice={(msg) => setAutopilotNotice(msg)}
            />
          </div>
        )}

        {/* ===================================================================
            VIEW 3: STAGE 3 — CLEAN & PREPARE DATA
           =================================================================== */}
        {activeView === "cleaning" && (
          <div className="space-y-8">
            {/* Cleaning Pipeline Configuration Controls */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-5 border-b border-slate-200">
                <div>
                  <div className="text-xs text-slate-500">
                    Stage 03 · Clean & Prepare Data
                  </div>
                  <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                    Automated Data Hygiene & Transformation Rules
                  </h2>
                </div>

                <div className="flex items-center gap-4 text-xs font-mono tabular-nums">
                  <span>
                    Raw Health:{" "}
                    <strong className="text-amber-700">
                      {cleaningSummary.dataHealthBefore}%
                    </strong>
                  </span>
                  <span>→</span>
                  <span>
                    Cleaned Health:{" "}
                    <strong className="text-emerald-700">
                      {cleaningSummary.dataHealthAfter}%
                    </strong>
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 pt-5">
                {/* Rule 1: Deduplication */}
                <label className="p-3.5 border border-slate-200 rounded-lg flex items-start gap-3 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={cleaningOptions.removeDuplicates}
                    onChange={(e) =>
                      setCleaningOptions((prev) => ({
                        ...prev,
                        removeDuplicates: e.target.checked,
                      }))
                    }
                    className="mt-0.5 rounded border-slate-300 text-blue-600"
                  />
                  <div>
                    <div className="text-xs font-semibold text-slate-900">
                      Remove Duplicate Rows
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono tabular-nums mt-0.5">
                      {cleaningSummary.duplicatesRemoved} exact duplicates removed
                    </div>
                  </div>
                </label>

                {/* Rule 2: Format Normalization */}
                <label className="p-3.5 border border-slate-200 rounded-lg flex items-start gap-3 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={cleaningOptions.normalizeFormats}
                    onChange={(e) =>
                      setCleaningOptions((prev) => ({
                        ...prev,
                        normalizeFormats: e.target.checked,
                      }))
                    }
                    className="mt-0.5 rounded border-slate-300 text-blue-600"
                  />
                  <div>
                    <div className="text-xs font-semibold text-slate-900">
                      Normalize Formats
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono tabular-nums mt-0.5">
                      {cleaningSummary.formatsNormalized} currency/date strings fixed
                    </div>
                  </div>
                </label>

                {/* Rule 3: Outlier Winsorization */}
                <label className="p-3.5 border border-slate-200 rounded-lg flex items-start gap-3 cursor-pointer hover:bg-slate-50">
                  <input
                    type="checkbox"
                    checked={cleaningOptions.capOutliers}
                    onChange={(e) =>
                      setCleaningOptions((prev) => ({
                        ...prev,
                        capOutliers: e.target.checked,
                      }))
                    }
                    className="mt-0.5 rounded border-slate-300 text-blue-600"
                  />
                  <div>
                    <div className="text-xs font-semibold text-slate-900">
                      Cap Extreme Outliers
                    </div>
                    <div className="text-[11px] text-slate-500 font-mono tabular-nums mt-0.5">
                      {cleaningSummary.outliersAdjusted} IQR extremes capped
                    </div>
                  </div>
                </label>

                {/* Rule 4: Numeric Missing Imputation */}
                <div className="p-3.5 border border-slate-200 rounded-lg">
                  <label className="block text-xs font-semibold text-slate-900 mb-1">
                    Numeric Missing Strategy
                  </label>
                  <select
                    value={cleaningOptions.imputeMissingNumeric}
                    onChange={(e) =>
                      setCleaningOptions((prev) => ({
                        ...prev,
                        imputeMissingNumeric: e.target.value as any,
                      }))
                    }
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded px-2 py-1"
                  >
                    <option value="median">Impute Median (Robust)</option>
                    <option value="mean">Impute Mean</option>
                    <option value="zero">Fill with 0</option>
                    <option value="drop">Drop Incomplete Rows</option>
                  </select>
                </div>

                {/* Rule 5: Categorical Missing Imputation */}
                <div className="p-3.5 border border-slate-200 rounded-lg">
                  <label className="block text-xs font-semibold text-slate-900 mb-1">
                    Categorical Missing Strategy
                  </label>
                  <select
                    value={cleaningOptions.imputeMissingCategorical}
                    onChange={(e) =>
                      setCleaningOptions((prev) => ({
                        ...prev,
                        imputeMissingCategorical: e.target.value as any,
                      }))
                    }
                    className="w-full text-xs bg-slate-50 border border-slate-300 rounded px-2 py-1"
                  >
                    <option value="mode">Impute Mode (Most Frequent)</option>
                    <option value="unknown">Label as Unspecified</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Cell-Level Remediation Audit Log */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 min-w-0">
              <div className="flex flex-col gap-3 pb-4 border-b border-slate-200 min-w-0">
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    Cell-Level Remediation Audit Log ({filteredRemediationLogs.length}{" "}
                    Modifications)
                  </h3>
                  <p className="text-xs text-slate-500">
                    Every anomaly repaired by Rexor is logged with its exact row
                    index, original raw value, and cleaned output.
                  </p>
                </div>

                <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-slate-100 rounded-lg w-full">
                  {[
                    "ALL",
                    "Duplicate Row",
                    "Missing Value",
                    "Format Normalization",
                    "Outlier Capped",
                  ].map((type) => (
                    <button
                      key={type}
                      onClick={() => setRemediationFilter(type)}
                      className={`px-2.5 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                        remediationFilter === type
                          ? "bg-white text-slate-900 shadow-xs"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      {type === "ALL" ? "All Fixes" : type}
                    </button>
                  ))}
                </div>
              </div>

              <div className="overflow-x-auto max-h-72 overflow-y-auto mt-3">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500">
                      <th className="py-2.5 px-3 font-medium">Row #</th>
                      <th className="py-2.5 px-3 font-medium">Column</th>
                      <th className="py-2.5 px-3 font-medium">Issue Detected</th>
                      <th className="py-2.5 px-3 font-medium">Raw Value</th>
                      <th className="py-2.5 px-3 font-medium">Cleaned Value</th>
                      <th className="py-2.5 px-3 font-medium">Rule Applied</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {filteredRemediationLogs.length === 0 ? (
                      <tr>
                        <td
                          colSpan={6}
                          className="py-8 text-center text-slate-500"
                        >
                          No modifications match the selected filter.
                        </td>
                      </tr>
                    ) : (
                      filteredRemediationLogs.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-mono tabular-nums text-slate-500">
                            #{item.rowIndex}
                          </td>
                          <td className="py-2.5 px-3 font-mono font-medium text-slate-900">
                            {item.column}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700">
                            {item.issueType}
                          </td>
                          <td className="py-2.5 px-3 font-mono tabular-nums text-red-600 line-through">
                            {item.originalValue}
                          </td>
                          <td className="py-2.5 px-3 font-mono tabular-nums font-semibold text-emerald-700">
                            {item.cleanedValue}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500">
                            {item.ruleApplied}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Interactive Data Grid: Compare Cleaned vs Raw Dataset */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 min-w-0">
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-3 pb-4 border-b border-slate-200 min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg">
                    <button
                      onClick={() => setTableMode("cleaned")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                        tableMode === "cleaned"
                          ? "bg-white text-slate-900 shadow-xs"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      Cleaned Dataset ({cleanedRows.length} rows)
                    </button>
                    <button
                      onClick={() => setTableMode("raw")}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
                        tableMode === "raw"
                          ? "bg-white text-slate-900 shadow-xs"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      Raw Uncleaned Input ({rawRows.length} rows)
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <div className="relative flex-1 sm:flex-initial min-w-[180px]">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={tableSearch}
                      onChange={(e) => setTableSearch(e.target.value)}
                      placeholder="Filter records..."
                      className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:border-blue-600"
                    />
                  </div>
                  <button
                    onClick={() => setShowExportModal(true)}
                    className="px-3 py-1.5 text-xs font-medium text-white bg-slate-900 hover:bg-slate-800 rounded-lg cursor-pointer"
                  >
                    Export Dataset (.xlsx / .parquet / .json)
                  </button>
                </div>
              </div>

              <div className="overflow-x-auto max-h-96 overflow-y-auto mt-3">
                {filteredTableRows.length === 0 ? (
                  <div className="py-12 text-center text-sm text-slate-500">
                    No records match your search filter.
                  </div>
                ) : (
                  <table className="w-full text-left border-collapse">
                    <thead className="sticky top-0 bg-slate-50 border-b border-slate-200">
                      <tr className="text-xs text-slate-600">
                        <th className="py-2.5 px-3 font-mono font-medium">#</th>
                        {Object.keys(filteredTableRows[0]).map((col) => (
                          <th
                            key={col}
                            className={`py-2.5 px-3 font-medium whitespace-nowrap ${
                              columnTypes[col] === "numeric" ? "text-right" : "text-left"
                            }`}
                          >
                            {col}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {filteredTableRows.slice(0, 60).map((row, rIdx) => (
                        <tr key={rIdx} className="hover:bg-slate-50/80">
                          <td className="py-2 px-3 font-mono tabular-nums text-slate-400">
                            {rIdx + 1}
                          </td>
                          {Object.keys(filteredTableRows[0]).map((col) => {
                            const val = row[col];
                            const isNum = columnTypes[col] === "numeric";
                            const isEmpty =
                              val === "" || val === null || val === undefined;
                            return (
                              <td
                                key={col}
                                className={`py-2 px-3 whitespace-nowrap ${
                                  isNum
                                    ? "text-right font-mono tabular-nums text-slate-900"
                                    : "text-left text-slate-700"
                                } ${isEmpty ? "bg-red-50 text-red-600 font-mono" : ""}`}
                              >
                                {isEmpty ? "NULL" : String(val)}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            VIEW 4: STAGE 4 — ANALYZE THE DATA (SQL, PYTHON, STATISTICS)
           =================================================================== */}
        {activeView === "analysis" && (
          <div className="space-y-8">
            {/* Ask Rexor Interactive Natural-Language Analyst Bar */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="text-xs text-slate-500">
                Stage 04 · Interactive AI Data Analyst Query Engine
              </div>
              <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                Ask Rexor Any Analytical Question About {datasetName}
              </h2>
              <form onSubmit={handleAskRexor} className="mt-3 flex gap-2">
                <input
                  type="text"
                  value={customQuestion}
                  onChange={(e) => setCustomQuestion(e.target.value)}
                  placeholder="e.g., Which segment has the worst churn risk and what SQL query isolates the top 5 outliers?"
                  className="flex-1 px-4 py-2.5 text-sm bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:bg-white focus:border-blue-600"
                />
                <button
                  type="submit"
                  disabled={isAskingRexor}
                  className="px-5 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 rounded-lg whitespace-nowrap shrink-0 cursor-pointer"
                >
                  {isAskingRexor ? "Analyzing..." : "Run Query"}
                </button>
              </form>

              {qaHistory.length > 0 && (
                <div className="mt-5 space-y-4 divide-y divide-slate-200 border-t border-slate-200 pt-4">
                  {qaHistory.map((item, idx) => (
                    <div key={idx} className="pt-4 first:pt-0 space-y-3">
                      <div className="flex items-center justify-between text-xs text-slate-500">
                        <span className="font-semibold text-slate-900">
                          Q: {item.question}
                        </span>
                        <span className="font-mono tabular-nums">
                          {item.timestamp}
                        </span>
                      </div>
                      <p className="text-sm text-slate-800 leading-relaxed">
                        {item.directAnswer}
                      </p>
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                        <div className="bg-slate-900 text-slate-100 p-3.5 rounded-lg text-xs font-mono overflow-x-auto">
                          <div className="text-slate-400 text-[11px] mb-1">
                            Generated SQL Verification
                          </div>
                          <pre>{item.sqlQuery}</pre>
                        </div>
                        <div className="bg-slate-900 text-slate-100 p-3.5 rounded-lg text-xs font-mono overflow-x-auto">
                          <div className="text-slate-400 text-[11px] mb-1">
                            Pandas / Python Expression
                          </div>
                          <pre>{item.pythonCode}</pre>
                        </div>
                      </div>
                      <div className="text-xs text-emerald-800 bg-emerald-50 border border-emerald-200 rounded px-3 py-2">
                        <strong>Recommended Action:</strong>{" "}
                        {item.recommendedAction}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Universal Python Data Science & N-Task Runner */}
            <RexorPythonStudio
              rows={cleanedRows}
              rawRows={rawRows}
              columnProfiles={columnProfiles}
              correlations={correlations}
              datasetName={datasetName}
              businessQuestion={businessQuestion}
              newbieGuideMode={newbieGuideMode}
              onToggleNewbieGuide={() => setNewbieGuideMode((prev) => !prev)}
              onAddDerivedColumn={(_colName, updatedRows) => {
                setRawRows(updatedRows);
              }}
            />

            {/* Advanced Statistical & Predictive Suite */}
            <AdvancedAnalyticsSuite
              rows={cleanedRows}
              columnProfiles={columnProfiles}
              datasetName={datasetName}
            />

            {/* Statistical Column Profiler Table */}
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="pb-4 border-b border-slate-200">
                <div className="text-xs text-slate-500">
                  Stage 04 · Descriptive Statistics & Distribution Summary
                </div>
                <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                  Column-Level Statistical Profile ({columnProfiles.length} Variables)
                </h3>
              </div>

              <div className="overflow-x-auto mt-3">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 text-xs text-slate-500">
                      <th className="py-2.5 px-3 font-medium">Column Name</th>
                      <th className="py-2.5 px-3 font-medium">Data Type</th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        Raw Missing %
                      </th>
                      <th className="py-2.5 px-3 font-medium text-right">Unique</th>
                      <th className="py-2.5 px-3 font-medium text-right">Mean</th>
                      <th className="py-2.5 px-3 font-medium text-right">Median</th>
                      <th className="py-2.5 px-3 font-medium text-right">Std Dev</th>
                      <th className="py-2.5 px-3 font-medium text-right">
                        Min – Max
                      </th>
                      <th className="py-2.5 px-3 font-medium">
                        Distribution / Top Modes
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-xs">
                    {columnProfiles.map((col) => (
                      <tr key={col.name} className="hover:bg-slate-50">
                        <td className="py-2.5 px-3 font-mono font-semibold text-slate-900">
                          {col.name}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600">
                          {col.type}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          {col.missingPct}%
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          {col.uniqueCount}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-900">
                          {col.mean !== undefined ? col.mean.toLocaleString() : "—"}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-900">
                          {col.median !== undefined
                            ? col.median.toLocaleString()
                            : "—"}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                          {col.stdDev !== undefined
                            ? col.stdDev.toLocaleString()
                            : "—"}
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono tabular-nums text-slate-600">
                          {col.min !== undefined && col.max !== undefined
                            ? `${col.min.toLocaleString()} – ${col.max.toLocaleString()}`
                            : "—"}
                        </td>
                        <td className="py-2.5 px-3 text-slate-600 truncate max-w-xs">
                          {col.type === "numeric"
                            ? `IQR: ${col.iqr} · Outliers: ${col.outlierCount}`
                            : col.topCategories
                                ?.map((c) => `${c.value} (${c.pct}%)`)
                                .join(" · ")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Interactive SQL Execution Workbench & Correlation Matrix */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Interactive SQL GroupBy Sandbox */}
              <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
                <div className="pb-4 border-b border-slate-200">
                  <div className="text-xs text-slate-500">
                    Stage 04 · Live In-Browser SQL Aggregation Engine
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                    Interactive SQL Cohort Query Builder
                  </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
                  <div>
                    <label className="block text-xs text-slate-600 mb-1">
                      GROUP BY Dimension
                    </label>
                    <select
                      value={sqlGroupCol}
                      onChange={(e) => setSqlGroupCol(e.target.value)}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    >
                      {columnProfiles.map((c) => (
                        <option key={c.name} value={c.name}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-600 mb-1">
                      Target Metric Column
                    </label>
                    <select
                      value={sqlMetricCol}
                      onChange={(e) => setSqlMetricCol(e.target.value)}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    >
                      {numericCols.map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-600 mb-1">
                      Aggregation Function
                    </label>
                    <select
                      value={sqlAggFn}
                      onChange={(e) => setSqlAggFn(e.target.value as any)}
                      className="w-full text-xs bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-2"
                    >
                      <option value="AVG">AVG (Mean)</option>
                      <option value="SUM">SUM (Total)</option>
                      <option value="MEDIAN">MEDIAN (50th Pct)</option>
                      <option value="COUNT">COUNT (Volume)</option>
                    </select>
                  </div>
                </div>

                <div className="bg-slate-900 text-slate-100 p-3.5 rounded-lg text-xs font-mono mb-4 overflow-x-auto">
                  {`SELECT ${sqlGroupCol}, COUNT(*) AS record_count, ${sqlAggFn}(${sqlMetricCol}) AS ${sqlAggFn.toLowerCase()}_${sqlMetricCol}\nFROM cleaned_dataset\nGROUP BY ${sqlGroupCol}\nORDER BY ${sqlAggFn.toLowerCase()}_${sqlMetricCol} DESC;`}
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-xs text-slate-500">
                        <th className="py-2 px-3 font-medium">{sqlGroupCol}</th>
                        <th className="py-2 px-3 font-medium text-right">
                          Record Count
                        </th>
                        <th className="py-2 px-3 font-medium text-right">
                          {sqlAggFn}({sqlMetricCol})
                        </th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs font-mono tabular-nums">
                      {liveSqlResult.slice(0, 8).map((row) => (
                        <tr key={row.group} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-sans font-medium text-slate-900">
                            {row.group}
                          </td>
                          <td className="py-2 px-3 text-right text-slate-600">
                            {row.count}
                          </td>
                          <td className="py-2 px-3 text-right font-semibold text-blue-600">
                            {row.value.toLocaleString()}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Pearson Correlation Matrix */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6">
                <div className="pb-4 border-b border-slate-200">
                  <div className="text-xs text-slate-500">
                    Stage 04 · Bivariate Feature Relationships
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                    Pearson Correlation Ranking (r)
                  </h3>
                </div>

                <div className="divide-y divide-slate-100 mt-3">
                  {correlations.slice(0, 8).map((pair, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setScatterXCol(pair.colA);
                        setScatterYCol(pair.colB);
                      }}
                      className="py-3 flex items-center justify-between text-xs hover:bg-slate-50 px-2 rounded cursor-pointer"
                    >
                      <div>
                        <div className="font-mono font-medium text-slate-900">
                          {pair.colA} ↔ {pair.colB}
                        </div>
                        <div className="text-slate-500 mt-0.5">
                          {pair.strength}
                        </div>
                      </div>
                      <div
                        className={`font-mono tabular-nums font-bold text-sm ${
                          pair.r > 0 ? "text-blue-600" : "text-amber-700"
                        }`}
                      >
                        r = {pair.r > 0 ? `+${pair.r}` : pair.r}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Generated Production SQL & Python Scripts */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
                  <div>
                    <div className="text-xs text-slate-500">
                      Warehouse Verification Queries
                    </div>
                    <h3 className="text-base font-bold text-slate-900">
                      Rexor Generated SQL Scripts
                    </h3>
                  </div>
                </div>
                <div className="space-y-4">
                  {activeReport.stage4AnalyticalFindings.sqlQueries.map(
                    (q, idx) => (
                      <div key={idx} className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-900">
                            {q.title}
                          </span>
                          <button
                            onClick={() => handleCopyCode(`sql-${idx}`, q.sql)}
                            className="text-slate-500 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                          >
                            {copiedCodeId === `sql-${idx}` ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-600" />
                                <span>Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>Copy SQL</span>
                              </>
                            )}
                          </button>
                        </div>
                        <p className="text-xs text-slate-500">{q.purpose}</p>
                        <pre className="bg-slate-900 text-slate-100 p-3.5 rounded-lg text-xs font-mono overflow-x-auto">
                          {q.sql}
                        </pre>
                      </div>
                    )
                  )}
                </div>
              </div>

              <div className="bg-white border border-slate-200 rounded-xl p-6">
                <div className="flex items-center justify-between pb-4 border-b border-slate-200 mb-4">
                  <div>
                    <div className="text-xs text-slate-500">
                      Reproducible Data Science Notebook
                    </div>
                    <h3 className="text-base font-bold text-slate-900">
                      Python (pandas & scipy.stats) Pipeline
                    </h3>
                  </div>
                  <button
                    onClick={() =>
                      handleCopyCode(
                        "py-snippet",
                        activeReport.stage4AnalyticalFindings.pythonSnippet
                      )
                    }
                    className="text-xs text-slate-600 hover:text-slate-900 flex items-center gap-1 cursor-pointer"
                  >
                    {copiedCodeId === "py-snippet" ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Python</span>
                      </>
                    )}
                  </button>
                </div>
                <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg text-xs font-mono overflow-x-auto leading-relaxed">
                  {activeReport.stage4AnalyticalFindings.pythonSnippet}
                </pre>
              </div>
            </div>
          </div>
        )}

        {/* ===================================================================
            VIEW 5: STAGE 5 (VISUALIZE) & STAGE 6 (RECOMMEND & MEASURE RESULTS)
           =================================================================== */}
        {activeView === "visuals-actions" && (
          <div className="space-y-8">
            {/* 108 Power BI & Tableau Presentation & Multi-Layout Visualization Studio + AI Template Advisor */}
            <RexorBiTemplateStudio
              datasetName={datasetName}
              cleanedRows={cleanedRows}
              cleaningSummary={cleaningSummary}
              columnProfiles={columnProfiles}
              correlations={correlations}
            />

            {/* Stage 5 Interactive Visual Chart Studio */}
            <div className="bg-white border border-slate-200 rounded-xl p-4 sm:p-6 min-w-0">
              <div className="pb-4 border-b border-slate-200">
                <div className="text-xs text-slate-500">
                  Stage 05 · Visualize & Communicate Insights
                </div>
                <h2 className="text-xl font-bold text-slate-900 mt-0.5">
                  Interactive Visual Analytics Studio
                </h2>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 pt-6">
                {/* Chart 1: Cohort Comparison */}
                <div className="border border-slate-200 rounded-lg p-4 min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-semibold text-slate-900">
                      1. Cohort Comparison (Bar)
                    </span>
                    <div className="flex flex-wrap items-center gap-1.5 max-w-full">
                      <select
                        value={chartXCol}
                        onChange={(e) => setChartXCol(e.target.value)}
                        className="text-[11px] bg-slate-50 border border-slate-300 rounded px-1.5 py-1 max-w-[140px] truncate"
                      >
                        {columnProfiles.map((c) => (
                          <option key={c.name} value={c.name}>
                            {c.name}
                          </option>
                        ))}
                      </select>
                      <select
                        value={chartYCol}
                        onChange={(e) => setChartYCol(e.target.value)}
                        className="text-[11px] bg-slate-50 border border-slate-300 rounded px-1.5 py-1 max-w-[140px] truncate"
                      >
                        {numericCols.map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <InteractiveBarChart
                    rows={cleanedRows}
                    xCol={chartXCol}
                    yCol={chartYCol}
                    aggFn="AVG"
                  />
                </div>

                {/* Chart 2: Bivariate Regression Scatter */}
                <div className="border border-slate-200 rounded-lg p-4 min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-semibold text-slate-900">
                      2. Linear Regression (Scatter)
                    </span>
                    <div className="flex flex-wrap items-center gap-1.5 max-w-full">
                      <select
                        value={scatterXCol}
                        onChange={(e) => setScatterXCol(e.target.value)}
                        className="text-[11px] bg-slate-50 border border-slate-300 rounded px-1.5 py-1 max-w-[140px] truncate"
                      >
                        {numericCols.map((n) => (
                          <option key={n} value={n}>
                            X: {n}
                          </option>
                        ))}
                      </select>
                      <select
                        value={scatterYCol}
                        onChange={(e) => setScatterYCol(e.target.value)}
                        className="text-[11px] bg-slate-50 border border-slate-300 rounded px-1.5 py-1 max-w-[140px] truncate"
                      >
                        {numericCols.map((n) => (
                          <option key={n} value={n}>
                            Y: {n}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                  <InteractiveScatterPlot
                    rows={cleanedRows}
                    xCol={scatterXCol}
                    yCol={scatterYCol}
                    colorCol={chartXCol}
                  />
                </div>

                {/* Chart 3: Variable Distribution Histogram */}
                <div className="border border-slate-200 rounded-lg p-4 min-w-0">
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                    <span className="text-xs font-semibold text-slate-900">
                      3. Frequency Distribution
                    </span>
                    <select
                      value={histCol}
                      onChange={(e) => setHistCol(e.target.value)}
                      className="text-[11px] bg-slate-50 border border-slate-300 rounded px-2 py-1 max-w-[160px] truncate"
                    >
                      {numericCols.map((n) => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </div>
                  <InteractiveHistogram rows={cleanedRows} col={histCol} />
                </div>
              </div>
            </div>

            {/* Stage 6: Interactive What-If ROI & Impact Simulator + KPI Tracking */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
              {/* Interactive What-If Simulator */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between">
                <div>
                  <div className="text-xs text-slate-500">
                    Stage 06 · Decision Impact & Scenario Modeling
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                    What-If Action ROI Simulator
                  </h3>
                  <p className="text-xs text-slate-600 mt-1">
                    Simulate how operational improvements on{" "}
                    <strong>{primaryNumericProfile?.name || "target KPI"}</strong>{" "}
                    compound across your cleaned cohort baseline.
                  </p>

                  <div className="space-y-5 mt-6">
                    <div>
                      <div className="flex justify-between text-xs mb-1.5">
                        <span className="font-medium text-slate-700">
                          Target Metric Improvement Rate
                        </span>
                        <span className="font-mono font-semibold text-blue-600 tabular-nums">
                          +{simImprovementPct}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={2}
                        max={45}
                        value={simImprovementPct}
                        onChange={(e) =>
                          setSimImprovementPct(Number(e.target.value))
                        }
                        className="w-full accent-blue-600 cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-xs mb-1.5">
                        <span className="font-medium text-slate-700">
                          Cohort Rollout & Adoption Coverage
                        </span>
                        <span className="font-mono font-semibold text-blue-600 tabular-nums">
                          {simAdoptionPct}%
                        </span>
                      </div>
                      <input
                        type="range"
                        min={15}
                        max={100}
                        value={simAdoptionPct}
                        onChange={(e) =>
                          setSimAdoptionPct(Number(e.target.value))
                        }
                        className="w-full accent-blue-600 cursor-pointer"
                      />
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-5 border-t border-slate-200 grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-xs text-slate-500">
                      Current Cohort Sum ({primaryNumericProfile?.name})
                    </div>
                    <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-0.5">
                      {Math.round(baselineTotalSum).toLocaleString()}
                    </div>
                  </div>
                  <div>
                    <div className="text-xs text-slate-500">
                      Projected Net Lift (90-Day)
                    </div>
                    <div className="text-xl font-bold font-mono tabular-nums text-emerald-700 mt-0.5">
                      +{simulatedNetLift.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* Stage 6: KPI Measurement Matrix */}
              <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6">
                <div className="pb-4 border-b border-slate-200">
                  <div className="text-xs text-slate-500">
                    Stage 06 · Post-Implementation Governance
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mt-0.5">
                    30 / 90-Day KPI Measurement & Tracking Framework
                  </h3>
                </div>

                <div className="overflow-x-auto mt-3">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 text-xs text-slate-500">
                        <th className="py-2.5 px-3 font-medium">KPI Metric</th>
                        <th className="py-2.5 px-3 font-medium">
                          Current Baseline
                        </th>
                        <th className="py-2.5 px-3 font-medium">30-Day Target</th>
                        <th className="py-2.5 px-3 font-medium">90-Day Target</th>
                        <th className="py-2.5 px-3 font-medium">Cadence</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 text-xs">
                      {activeReport.stage6ActionPlan.measurementFramework.map(
                        (kpi, i) => (
                          <tr key={i} className="hover:bg-slate-50">
                            <td className="py-3 px-3 font-semibold text-slate-900">
                              {kpi.kpiName}
                            </td>
                            <td className="py-3 px-3 font-mono tabular-nums text-slate-600">
                              {kpi.baselineValue}
                            </td>
                            <td className="py-3 px-3 font-mono tabular-nums font-medium text-blue-600">
                              {kpi.target30Day}
                            </td>
                            <td className="py-3 px-3 font-mono tabular-nums font-semibold text-emerald-700">
                              {kpi.target90Day}
                            </td>
                            <td className="py-3 px-3 text-slate-500">
                              {kpi.trackingCadence}
                            </td>
                          </tr>
                        )
                      )}
                    </tbody>
                  </table>
                </div>

                {/* Action Execution Checklist */}
                <div className="mt-6 pt-4 border-t border-slate-200 space-y-2.5">
                  <div className="text-xs font-semibold text-slate-800">
                    Action Implementation Tracker
                  </div>
                  {activeReport.stage6ActionPlan.recommendations.map(
                    (rec, idx) => {
                      const done = !!completedActions[idx];
                      return (
                        <label
                          key={idx}
                          className="flex items-center justify-between p-2.5 border border-slate-200 rounded-lg cursor-pointer hover:bg-slate-50 text-xs"
                        >
                          <div className="flex items-center gap-2.5">
                            <input
                              type="checkbox"
                              checked={done}
                              onChange={() =>
                                setCompletedActions((prev) => ({
                                  ...prev,
                                  [idx]: !prev[idx],
                                }))
                              }
                              className="rounded border-slate-300 text-blue-600"
                            />
                            <span
                              className={
                                done
                                  ? "line-through text-slate-400"
                                  : "font-medium text-slate-900"
                              }
                            >
                              [{rec.priority}] {rec.actionTitle}
                            </span>
                          </div>
                          <span className="font-mono tabular-nums text-emerald-700">
                            {rec.quantifiedExpectedImpact}
                          </span>
                        </label>
                      );
                    }
                  )}
                </div>
              </div>
            </div>

            {/* Enterprise Command Suite: Multi-Table SQL JOIN, Target Goal-Seek, Snapshots & Printable Board Deck */}
            <RexorEnterpriseCommandSuite
              cleanedRows={cleanedRows}
              rawRows={rawRows}
              columnProfiles={columnProfiles}
              correlations={correlations}
              cleaningSummary={cleaningSummary}
              datasetName={datasetName}
              businessQuestion={businessQuestion}
              domainContext={domainContext}
              activeReport={activeReport}
              newbieGuideMode={newbieGuideMode}
              onCommitMergedDataset={(merged, mergedTitle, notice) => {
                setRawRows(merged);
                setDatasetName(mergedTitle);
                setSelectedPresetId("");
                setAiReport(null);
                setAutopilotNotice(notice);
              }}
              onRestoreSnapshot={handleRestoreSnapshot}
            />
          </div>
        )}
      </main>

      {/* Docked Side AI Assistant & Onboarding Guide */}
      <RexorSideChat
        isOpen={isSideChatOpen}
        onClose={() => setIsSideChatOpen((prev) => !prev)}
        activeView={activeView}
        onNavigateView={(view) => setActiveView(view)}
        onRunAutopilot={runRexorAutopilot}
        isRunningAutopilot={isRunningAutopilot}
        datasetName={datasetName}
        businessQuestion={businessQuestion}
        cleaningSummary={cleaningSummary}
        columnProfiles={columnProfiles}
        correlations={correlations}
        cleanedRows={cleanedRows}
        newbieGuideMode={newbieGuideMode}
        onToggleNewbieGuide={() => setNewbieGuideMode((prev) => !prev)}
        onApplyChatRequirement={(promptText) => {
          const compiled = compileUserRequirementToRule(
            promptText,
            columnProfiles,
            "User Directive (Side Chat)"
          );
          setUserRequirements((prev) => [compiled, ...prev]);
          setAiReport(null);
          setAutopilotNotice(
            `Adaptive Rule Applied via Side Chat: ${compiled.title}`
          );
          return compiled.title;
        }}
      />
      </div>
      )}

      {/* Clean Minimal Footer with Rushi Chavan Ownership & License */}
      <footer className="border-t border-slate-200 bg-white px-4 sm:px-6 lg:px-8 py-4 mt-12 w-full max-w-full overflow-x-hidden">
        <div className="max-w-[2400px] mx-auto flex flex-col lg:flex-row items-start lg:items-center justify-between text-xs text-slate-500 gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-slate-900">
              Rexor Autonomous Data Analytics Suite
            </span>
            <span>·</span>
            <span>
              Exclusive Owner & Architect: Rushi Chavan (rushichavan69@gmail.com)
            </span>
            <span>·</span>
            <span className="font-mono tabular-nums">
              Copyright © 2026 Rushi Chavan. All Rights Reserved.
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5">
            <button
              onClick={() => setShowLicenseModal(true)}
              className="hover:text-slate-900 transition-colors cursor-pointer font-medium flex items-center gap-1"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-blue-600" />
              <span>Sovereign Security & Ownership (rushichavan69@gmail.com)</span>
            </button>
            <span>·</span>
            <button
              onClick={() => setShowExportModal(true)}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Export Dataset (.xlsx / .json / .parquet)
            </button>
            <span>·</span>
            <button
              onClick={handleDownloadReport}
              className="hover:text-slate-900 transition-colors cursor-pointer"
            >
              Export Executive Markdown Report
            </button>
            <span>·</span>
            <button
              onClick={() =>
                downloadExecutiveBoardDeckPdf({
                  datasetName,
                  domainContext,
                  businessQuestion,
                  cleaningSummary,
                  columnProfiles,
                  correlations,
                  activeReport,
                })
              }
              className="hover:text-slate-900 transition-colors cursor-pointer font-medium"
            >
              Save Executive PDF (.pdf)
            </button>
          </div>
        </div>
      </footer>

      {/* Sovereign Security Boundary & Exclusive Ownership Vault Modal */}
      {showLicenseModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 py-6 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div>
                <div className="text-xs font-mono text-blue-600 font-semibold">
                  SOVEREIGN SECURITY FIREWALL & CRYPTOGRAPHIC OWNERSHIP LOCK
                </div>
                <h3 className="text-lg font-bold text-slate-900">
                  Exclusive Ownership & Root Access: Rushi Chavan (rushichavan69@gmail.com)
                </h3>
              </div>
              <button
                onClick={() => setShowLicenseModal(false)}
                className="text-xs font-medium text-slate-500 hover:text-slate-900 px-2 py-1 rounded cursor-pointer"
              >
                Close
              </button>
            </div>

            <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono leading-relaxed space-y-2 text-blue-100">
              <div className="font-bold text-blue-400">
                REXOR AUTONOMOUS AI DATA ANALYTICS SUITE — ROOT SOVEREIGNTY CERTIFICATE
              </div>
              <div>
                • Master Owner & Sole Architect: {SOVEREIGN_SECURITY_MANIFEST.ownerName}
              </div>
              <div>
                • Authorized Master Email: {SOVEREIGN_SECURITY_MANIFEST.ownerEmail}
              </div>
              <div>
                • Cryptographic Fingerprint: {SOVEREIGN_SECURITY_MANIFEST.licenseFingerprint}
              </div>
              <div>
                • Security Status: {SOVEREIGN_SECURITY_MANIFEST.integrityStatus}
              </div>
              <div className="pt-2 text-slate-300">
                Zero external loopholes, ownership overrides, or unauthorized
                system-prompt extractions are permitted. All administrative
                rights and intellectual property belong exclusively to Rushi
                Chavan (rushichavan69@gmail.com).
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {SOVEREIGN_SECURITY_MANIFEST.activeFirewalls.map((fw) => (
                <div
                  key={fw.id}
                  className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">
                      {fw.name}
                    </span>
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-50 text-emerald-600 border border-emerald-200">
                      {fw.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {fw.description}
                  </p>
                </div>
              ))}
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => setShowLicenseModal(false)}
                className="px-4 py-2 text-xs font-semibold bg-blue-600 text-white rounded-lg cursor-pointer"
              >
                Verified & Locked
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Instant Switch / Upload Data Modal */}
      {showDataModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 px-4 py-6 overflow-y-auto">
          <div className="bg-white border border-slate-200 rounded-xl max-w-2xl w-full p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-slate-200 pb-4">
              <div>
                <div className="text-xs text-slate-500">
                  Stage 02 · Collect & Access Data Hub
                </div>
                <h3 className="text-lg font-bold text-slate-900">
                  Switch Dataset or Upload Local File (.xlsx, .csv, .json)
                </h3>
              </div>
              <button
                onClick={() => setShowDataModal(false)}
                className="px-3 py-1 text-xs font-medium text-slate-500 hover:text-slate-900 border border-slate-200 rounded-lg cursor-pointer"
              >
                Close
              </button>
            </div>

            {ingestionError && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-600">
                {ingestionError}
              </div>
            )}

            {/* Quick Local File Upload Callout */}
            <div className="p-5 border-2 border-dashed border-slate-300 rounded-xl space-y-3 bg-slate-50">
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <div className="text-sm font-bold text-slate-900">
                    Upload Your Own Excel, CSV, TSV, or JSON File
                  </div>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Runs pre-ingestion validation for empty files, missing
                    header rows, and malformed delimiters before loading.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-4 py-2.5 text-xs font-semibold bg-blue-600 text-white rounded-lg whitespace-nowrap shrink-0 flex items-center gap-2 cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>Browse Local File...</span>
                </button>
              </div>

              <div className="pt-2.5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-[11px]">
                <span className="text-slate-500">
                  Simulate Pre-Ingestion Validation Gate:
                </span>
                <div className="flex flex-wrap items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => handleSimulateValidationScenario("empty")}
                    className="px-2 py-1 font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    Test Empty File
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleSimulateValidationScenario("missing-header")
                    }
                    className="px-2 py-1 font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    Test Missing Header
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleSimulateValidationScenario("malformed-delimiter")
                    }
                    className="px-2 py-1 font-mono rounded border border-slate-300 bg-white text-slate-700 cursor-pointer"
                  >
                    Test Malformed Delimiter
                  </button>
                </div>
              </div>
            </div>

            {/* Switch Between Enterprise Sample Datasets */}
            <div className="space-y-2.5">
              <div className="text-xs font-semibold text-slate-700">
                Or Switch to a Built-In Enterprise Dataset (Click to Load):
              </div>
              <div className="grid grid-cols-1 gap-2.5">
                {SAMPLE_DATASETS.map((preset) => {
                  const isCurrent = selectedPresetId === preset.id;
                  return (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() => handleSelectPreset(preset.id)}
                      className={`text-left p-3.5 rounded-lg border transition-colors cursor-pointer ${
                        isCurrent
                          ? "border-blue-600 bg-blue-50"
                          : "border-slate-200 hover:border-slate-300 bg-slate-50"
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-bold text-slate-900">
                          {preset.name}
                        </span>
                        <span className="text-xs font-mono text-slate-500">
                          {isCurrent ? "ACTIVE DATASET" : "Click to Load →"}
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 mt-1">
                        {preset.description}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Paste Raw CSV or Connect API Footer Link */}
            <div className="pt-3 border-t border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Need to paste raw CSV/JSON text or connect a live REST API URL?
              </span>
              <button
                type="button"
                onClick={() => {
                  setShowDataModal(false);
                  setActiveView("problem-data");
                  setSourceTab("paste");
                }}
                className="font-semibold text-blue-600 hover:underline cursor-pointer"
              >
                Open Paste / API Connectors →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Pre-Ingestion Data Validation Warning & Interactive Recovery Modal */}
      {pendingValidationResult && (
        <PreIngestionValidationModal
          validationResult={pendingValidationResult}
          delimiterOverride={validationDelimiterOverride}
          treatFirstRowAsData={validationTreatFirstRowAsData}
          onChangeOptions={handleUpdateValidationOptions}
          onConfirmIngest={commitValidatedDataset}
          onCancel={() => {
            setPendingValidationResult(null);
            setPendingUploadedFile(null);
            setPendingRawSourceText(null);
          }}
          onBrowseAnotherFile={() => {
            setPendingValidationResult(null);
            setPendingUploadedFile(null);
            setPendingRawSourceText(null);
            fileInputRef.current?.click();
          }}
        />
      )}

      {/* Custom Dataset Export Studio Modal (Column Selection, Date Ranges & Multi-Format Export) */}
      <DatasetExportModal
        isOpen={showExportModal}
        onClose={() => setShowExportModal(false)}
        datasetName={datasetName}
        cleanedRows={cleanedRows}
        rawRows={rawRows}
        columnProfiles={columnProfiles}
      />

      {/* Power-User Keyboard Shortcuts & Command Palette Modal */}
      <RexorShortcutsModal
        isOpen={showShortcutsModal}
        onClose={() => setShowShortcutsModal(false)}
        commands={shortcutCommands}
        isSideChatOpen={isSideChatOpen}
        hasActiveDataset={hasActiveDataset}
      />

      {/* Full-Spectrum Chameleon Theme & Custom Color Mixer Modal */}
      <RexorThemeCustomizerModal
        isOpen={showThemeModal}
        onClose={() => setShowThemeModal(false)}
        activeTheme={activeTheme}
        onSelectTheme={(nextTheme) => {
          setActiveTheme(nextTheme);
          triggerShortcutToast(
            `Applied Theme: ${nextTheme.name} (${nextTheme.badge})`
          );
        }}
      />

      {/* Live Keyboard Shortcut Execution HUD Toast */}
      {shortcutToast && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-slate-900 border border-blue-500 text-xs font-mono text-blue-100 shadow-xl flex items-center gap-2.5">
          <Keyboard className="w-4 h-4 text-blue-400 shrink-0" />
          <span>{shortcutToast}</span>
        </div>
      )}
    </div>
  );
}
