/**
 * Rexor — 108 Power BI & Tableau Visualization & Presentation Templates Catalog,
 * AI Template Recommendation Advisor, and Sovereign Security Boundary Engine
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved. Exclusive Ownership Lock Active.
 */

import {
  CleaningSummary,
  ColumnProfile,
  CorrelationPair,
} from "../types/rexor";

export type BiPlatform = "Power BI" | "Tableau";

export type BiDomainCategory =
  | "Executive Boardroom"
  | "Sales & Revenue Waterfall"
  | "Hospitality & POS Ops"
  | "CFO P&L & Variance"
  | "Marketing & Retention"
  | "Supply Chain & SLA"
  | "SaaS & Recurring Revenue"
  | "Workforce & HR"
  | "Statistical Data Science";

export type VisualCanvasLayoutId =
  | "exec-ribbon-combo-decomp"
  | "waterfall-pareto-bridge"
  | "small-multiples-treemap"
  | "scatter-quadrant-regression"
  | "marimekko-heatmap-matrix"
  | "bullet-gauge-sla-tracker"
  | "sankey-funnel-conversion"
  | "boxplot-iqr-distribution"
  | "radar-spider-benchmark"
  | "dual-axis-velocity-trend"
  | "pivot-crosstab-databars"
  | "anomaly-control-chart";

export interface BiTemplateItem {
  id: string;
  code: string;
  platform: BiPlatform;
  domain: BiDomainCategory;
  title: string;
  subtitle: string;
  targetAudience: string;
  layoutId: VisualCanvasLayoutId;
  layoutName: string;
  visualsIncluded: string[];
  whenToChoose: string;
  formulaLabel: string;
  formulaCode: string;
  presentationSlideCount: number;
  complexityLevel: "Executive Ready" | "Analyst Pro" | "Data Science Deep-Dive";
}

export interface BiAdvisorRecommendation {
  template: BiTemplateItem;
  matchScorePct: number;
  aiWhyChooseThis: string;
  mappedColumnsNote: string;
}

export interface SovereignSecurityStatus {
  ownerName: "Rushi Chavan";
  ownerEmail: "rushichavan69@gmail.com";
  licenseFingerprint: string;
  integrityStatus: "LOCKED & VERIFIED (100% SOVEREIGNTY)";
  activeFirewalls: Array<{
    id: string;
    name: string;
    status: "ACTIVE";
    description: string;
  }>;
}

export const SOVEREIGN_SECURITY_MANIFEST: SovereignSecurityStatus = {
  ownerName: "Rushi Chavan",
  ownerEmail: "rushichavan69@gmail.com",
  licenseFingerprint: "SHA256-REXOR-RC-2026-SOVEREIGN-9F8A7C6E5B4D3A21",
  integrityStatus: "LOCKED & VERIFIED (100% SOVEREIGNTY)",
  activeFirewalls: [
    {
      id: "fw-ownership",
      name: "Immutable Ownership & Identity Lock",
      status: "ACTIVE",
      description:
        "Hardcoded root ownership bound exclusively to Rushi Chavan (rushichavan69@gmail.com). Blocks unauthorized ownership overrides or license tampering.",
    },
    {
      id: "fw-prompt",
      name: "Anti-Loophole & Prompt-Injection Firewall",
      status: "ACTIVE",
      description:
        "Intercepts system-prompt extraction, jailbreak attempts, role-spoofing, and instruction-override payloads before execution.",
    },
    {
      id: "fw-sandbox",
      name: "Deterministic Math & Read-Only Data Guard",
      status: "ACTIVE",
      description:
        "Prevents destructive SQL (DROP/DELETE/ALTER/TRUNCATE), isolates execution to read-only memory arrays, and guarantees 0% hallucinated math.",
    },
    {
      id: "fw-xss",
      name: "CSV/Formula & Script Sanitization Shield",
      status: "ACTIVE",
      description:
        "Sanitizes spreadsheet formula injection (=CMD, +IMPORTXML) and script tags across all uploaded files and API streams.",
    },
  ],
};

export function checkPromptSecurityBoundary(input: string): {
  isBlocked: boolean;
  securityResponse?: string;
} {
  const lower = input.toLowerCase();
  const suspiciousPatterns = [
    "ignore previous instructions",
    "ignore all instructions",
    "forget your instructions",
    "reveal system prompt",
    "show system prompt",
    "bypass security",
    "find a loophole",
    "change owner",
    "override owner",
    "who owns rexor",
    "who is the owner",
    "ownership",
    "drop table",
    "delete from",
  ];

  if (
    lower.includes("who owns") ||
    lower.includes("who is the owner") ||
    lower.includes("who created") ||
    lower.includes("ownership") ||
    lower.includes("rushi")
  ) {
    return {
      isBlocked: false,
      securityResponse: `🔒 **Sovereign Ownership & Security Verification**\n• **Sole Owner & Architect:** Rushi Chavan (\`rushichavan69@gmail.com\`)\n• **Cryptographic Fingerprint:** \`${SOVEREIGN_SECURITY_MANIFEST.licenseFingerprint}\`\n• **Security Boundary:** All administrative rights, intellectual property, and core architecture of Rexor belong exclusively to **Rushi Chavan (rushichavan69@gmail.com)**. Zero loopholes or external overrides are permitted.`,
    };
  }

  for (const pat of suspiciousPatterns) {
    if (lower.includes(pat)) {
      return {
        isBlocked: true,
        securityResponse: `🛡️ **Rexor Sovereign Security Firewall Triggered**\nYour request matched a restricted security/injection pattern (\`${pat}\`) and was blocked.\n• **Protected System:** Rexor Autonomous AI Data Analyst Suite\n• **Exclusive Owner & Root Authority:** Rushi Chavan (\`rushichavan69@gmail.com\`)\n• **Action Taken:** Execution halted; dataset, system instructions, and ownership boundaries remain 100% locked.`,
      };
    }
  }

  return { isBlocked: false };
}

const DOMAIN_CONFIGS: Array<{
  domain: BiDomainCategory;
  layouts: Array<{
    layoutId: VisualCanvasLayoutId;
    layoutName: string;
    pbiTitle: string;
    tabTitle: string;
    audience: string;
    visuals: string[];
    whenToChoose: string;
  }>;
}> = [
  {
    domain: "Executive Boardroom",
    layouts: [
      {
        layoutId: "exec-ribbon-combo-decomp",
        layoutName: "Executive KPI Ribbon + Combo Dual-Axis + Decomposition Tree",
        pbiTitle: "Power BI C-Suite Boardroom Command Deck",
        tabTitle: "Tableau Executive Pulse & KPI Storyboard",
        audience: "CEO, Founder, Board of Directors",
        visuals: [
          "6-Card KPI Scorecards with MoM Sparklines",
          "Dual-Axis Revenue vs Margin % Combo Chart",
          "AI Decomposition Tree (Root-Cause Drilldown)",
          "Top/Bottom Cohort Ranking Matrix",
          "Executive Action ROI Tracker",
        ],
        whenToChoose:
          "Best when presenting a complete high-level company overview to executives who want headline KPIs plus immediate drill-down into what drove performance.",
      },
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "Executive Revenue Bridge + 80/20 Pareto Concentration",
        pbiTitle: "Power BI Boardroom Growth & Concentration Deck",
        tabTitle: "Tableau Executive Pareto & Variance Story",
        audience: "Board Members, Investors, VP Strategy",
        visuals: [
          "Gross-to-Net Revenue Waterfall Bridge",
          "80/20 Cumulative Pareto Concentration Curve",
          "Cohort Contribution Bar Matrix",
          "Data Health & Audit Badge Strip",
        ],
        whenToChoose:
          "Best when showing which 20% of outlets/products generate 80% of net profit and where revenue drops off between gross and net.",
      },
      {
        layoutId: "bullet-gauge-sla-tracker",
        layoutName: "Target vs Actual Bullet Matrix + OKR Gauges",
        pbiTitle: "Power BI OKR & Quarterly Target Attainment View",
        tabTitle: "Tableau Stephen Few Bullet Graph Executive Scorecard",
        audience: "COO, Business Unit Heads, Regional Directors",
        visuals: [
          "Stephen Few Bullet Graphs (Actual vs Target vs Threshold)",
          "Radial Goal Attainment Gauges",
          "Variance Gap Leaderboard",
          "P0/P1 Action Playbook Cards",
        ],
        whenToChoose:
          "Best when tracking quarterly goals, outlet quotas, or SLA targets against actual verified performance.",
      },
      {
        layoutId: "small-multiples-treemap",
        layoutName: "Small Multiples Cohort Grid + Hierarchical Treemap",
        pbiTitle: "Power BI Multi-Region Executive Comparison Grid",
        tabTitle: "Tableau Trellis Small Multiples & Hierarchy Map",
        audience: "Multi-Region VPs, Franchise Owners",
        visuals: [
          "Synchronized Small Multiples Grid by Cohort",
          "Nested Hierarchical Revenue & Margin Treemap",
          "Cross-Filtered Outlier Strip",
          "Cohort Summary Table with Data Bars",
        ],
        whenToChoose:
          "Best when comparing 4 to 20+ outlets, regions, or product lines side-by-side without cluttered overlapping lines.",
      },
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "4-Quadrant Strategic Matrix + OLS Regression Trend",
        pbiTitle: "Power BI Strategic Magic Quadrant & Driver View",
        tabTitle: "Tableau 4-Quadrant Scatter & Parameter Reference Lines",
        audience: "Chief Strategy Officer, Product & Ops Leaders",
        visuals: [
          "4-Quadrant Scatter Plot (High Volume / High Margin)",
          "OLS Linear Regression Line with Confidence Band",
          "Pearson r Correlation Heatmap Matrix",
          "Outlier Spotlight Callout Table",
        ],
        whenToChoose:
          "Best when proving a statistical cause-and-effect relationship (like Prep Time vs Customer Rating) to leadership.",
      },
      {
        layoutId: "pivot-crosstab-databars",
        layoutName: "Conditional Formatting Pivot Matrix + Variance Sparklines",
        pbiTitle: "Power BI Matrix Visual with Conditional Data Bars & Icons",
        tabTitle: "Tableau Highlight Table & Stepped Color Crosstab",
        audience: "Operations Directors, Finance & Audit Committees",
        visuals: [
          "Multi-Level Expandable Matrix Crosstab",
          "In-Cell Conditional Data Bars & Traffic Light Icons",
          "Row-Level Anomaly Audit Log",
          "Summary Percentile Footer",
        ],
        whenToChoose:
          "Best when stakeholders want to inspect exact tabular numbers alongside visual heatmap cues.",
      },
    ],
  },
  {
    domain: "Sales & Revenue Waterfall",
    layouts: [
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "Gross-to-Net Revenue Waterfall + Discount Leakage Audit",
        pbiTitle: "Power BI Sales Revenue & Promo Leakage Waterfall",
        tabTitle: "Tableau Gantt-Bar Revenue & Discount Bridge",
        audience: "VP Sales, CRO, Revenue Operations",
        visuals: [
          "Gross Sales -> Discounts -> Refunds -> Net Revenue Waterfall",
          "Unauthorized Promo Code Audit Bar Chart",
          "Top Performing SKU/Item Pareto Curve",
          "Server/Rep Leaderboard",
        ],
        whenToChoose:
          "Best when diagnosing how discounts, refunds, or unauthorized promo codes erode top-line gross sales.",
      },
      {
        layoutId: "sankey-funnel-conversion",
        layoutName: "Multi-Stage Pipeline Funnel + Segment Flow Matrix",
        pbiTitle: "Power BI Revenue Conversion Funnel & Ribbon Chart",
        tabTitle: "Tableau Multi-Stage Sankey & Conversion Flow",
        audience: "Sales Directors, Growth Teams",
        visuals: [
          "Stage-by-Stage Conversion Funnel",
          "Cohort-to-Payment-Status Flow Breakdown",
          "Win-Rate & Paid-Order Velocity Chart",
          "Deal/Order Size Histogram",
        ],
        whenToChoose:
          "Best when analyzing drop-offs from raw orders/leads to verified paid revenue.",
      },
      {
        layoutId: "marimekko-heatmap-matrix",
        layoutName: "Marimekko Market Share + Hour-by-Zone Intensity Heatmap",
        pbiTitle: "Power BI Territory Share & Peak-Hour Revenue Matrix",
        tabTitle: "Tableau Marimekko Mosaic & Calendar Heatmap",
        audience: "Commercial Heads, Territory Managers",
        visuals: [
          "Variable-Width Marimekko Share Chart",
          "Order Hour × Outlet Zone Revenue Heatmap",
          "Average Spend Per Cover (ASPC) Ranking",
          "Top Cross-Sell Item Table",
        ],
        whenToChoose:
          "Best when visualizing both cohort size (width) and margin/ASPC (height) simultaneously.",
      },
      {
        layoutId: "dual-axis-velocity-trend",
        layoutName: "Dual-Axis Volume vs Price Realization + Moving Average",
        pbiTitle: "Power BI Price-Volume Mix & Rolling Trend Studio",
        tabTitle: "Tableau Dual-AxisSynchronized Rolling Average View",
        audience: "Pricing Analysts, Sales Ops",
        visuals: [
          "Order Volume Bars + Unit Price Line Dual-Axis",
          "Cumulative Revenue Run-Rate Area Chart",
          "Price Elasticity Scatter Plot",
          "Discount Tier Breakdown",
        ],
        whenToChoose:
          "Best when checking whether revenue growth comes from higher order volume or higher ticket prices.",
      },
      {
        layoutId: "exec-ribbon-combo-decomp",
        layoutName: "AI Revenue Decomposition Tree + Quota Scorecard",
        pbiTitle: "Power BI AI Decomposition Tree for Revenue Root Cause",
        tabTitle: "Tableau Set-Action Drilldown Revenue Explorer",
        audience: "CRO, Regional Sales Managers",
        visuals: [
          "Interactive Root-Cause Decomposition Tree",
          "Quota Attainment KPI Ribbon",
          "Territory Variance Bar Chart",
          "Rep-Level Performance Table",
        ],
        whenToChoose:
          "Best when drilling down interactively from Total Net Revenue -> Outlet Zone -> Item Name -> Discount Code.",
      },
      {
        layoutId: "radar-spider-benchmark",
        layoutName: "Multi-Metric Territory Radar + Percentile Ranking",
        pbiTitle: "Power BI Territory 360° Radar & Scorecard",
        tabTitle: "Tableau Polygon Radar & Percentile Benchmark",
        audience: "Sales Enablement, Regional VPs",
        visuals: [
          "5-Axis Territory Radar (Revenue, Margin, Rating, Speed, Volume)",
          "Percentile Distribution Strip",
          "Top vs Bottom Performer Delta Cards",
          "Coaching Action Matrix",
        ],
        whenToChoose:
          "Best when benchmarking outlets or sales reps across multiple balanced scorecard dimensions at once.",
      },
    ],
  },
  {
    domain: "Hospitality & POS Ops",
    layouts: [
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "Kitchen Prep Time vs Guest Rating Correlation + IQR Cap",
        pbiTitle: "Power BI Restaurant POS & Kitchen Bottleneck Suite",
        tabTitle: "Tableau Hospitality Turnaround & Guest CSAT Cockpit",
        audience: "Restaurant Owners, F&B Directors, Kitchen Managers",
        visuals: [
          "Prep Time (Winsorized) vs Customer Rating Scatter + Regression",
          "Outlet Zone ASPC (Avg Spend Per Cover) Bar Chart",
          "Post-11AM Unauthorized MORNING10 Promo Leakage Table",
          "POS Duplicate & Refund Isolation Audit Strip",
        ],
        whenToChoose:
          "Best for restaurants, bistros, and cloud kitchens auditing POS logs, kitchen ticket delays, and guest ratings.",
      },
      {
        layoutId: "marimekko-heatmap-matrix",
        layoutName: "Daypart Order-Hour Heatmap + Menu Engineering Matrix",
        pbiTitle: "Power BI Menu Engineering (Stars/Plowhorses) & Daypart View",
        tabTitle: "Tableau Kasavana-Smith Menu Matrix & Hourly Rush Heatmap",
        audience: "Executive Chefs, Restaurant GMs, Menu Planners",
        visuals: [
          "Menu Engineering 4-Box (Popularity Qty vs Gross Margin %)",
          "Hourly Daypart Order & Prep Load Heatmap",
          "Item-Level COGS vs Net Revenue Breakdown",
          "Server Table-Turn Efficiency Leaderboard",
        ],
        whenToChoose:
          "Best when optimizing menu pricing, identifying high-margin Star dishes, and staffing for peak kitchen hours.",
      },
      {
        layoutId: "boxplot-iqr-distribution",
        layoutName: "Kitchen Ticket Prep-Time Boxplot + 1.5×IQR Outlier Fence",
        pbiTitle: "Power BI Kitchen SLA & Winsorized Outlier Diagnostic",
        tabTitle: "Tableau Box-and-Whisker Ticket Latency Distribution",
        audience: "Operations Heads, Quality Assurance",
        visuals: [
          "Cohort Box-and-Whisker Plot (Q1, Median, Q3, 1.5×IQR Fence)",
          "Capped vs Uncapped Prep Time Histogram",
          "SLA Breach Ticket Log (>20 Mins)",
          "Rating Drop Impact Simulator",
        ],
        whenToChoose:
          "Best when isolating stuck POS timers (e.g., 145-min bugs) from genuine kitchen slowdowns.",
      },
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "POS Gross-to-Net Leakage Bridge + Server Promo Audit",
        pbiTitle: "Power BI POS Revenue Leakage & Fraud Audit Deck",
        tabTitle: "Tableau POS Discount & Refund Forensic Waterfall",
        audience: "Hospitality CFOs, Internal Auditors, Franchise Owners",
        visuals: [
          "Gross Bill -> Promo Discounts -> Refunds -> Net Verified Cash",
          "Unauthorized Promo Code by Server ID & Hour",
          "Duplicate POS Order_ID Interception Log",
          "Outlet Net Profit Margin % Comparison",
        ],
        whenToChoose:
          "Best when stopping revenue leakage from duplicate POS prints, refunded bills, and abused morning promo codes.",
      },
      {
        layoutId: "small-multiples-treemap",
        layoutName: "Multi-Outlet Scorecard Grid + Category Margin Treemap",
        pbiTitle: "Power BI Multi-Outlet Franchise Performance Grid",
        tabTitle: "Tableau Outlet Zone Small Multiples & Cover Tracker",
        audience: "Regional Area Managers, Operations VPs",
        visuals: [
          "Outlet Zone Small Multiples (Net Rev, Covers, Prep Mins, Rating)",
          "Item Category Gross Profit Treemap",
          "Cover Size (Pax) Distribution Chart",
          "Outlet Action Playbook Matrix",
        ],
        whenToChoose:
          "Best when managing 3+ restaurant locations (e.g., College Rd, Bandra, Indiranagar) on a single screen.",
      },
      {
        layoutId: "bullet-gauge-sla-tracker",
        layoutName: "Outlet SLA Target Bullet Graphs + Prime Cost Gauges",
        pbiTitle: "Power BI Restaurant Prime Cost & SLA Command Center",
        tabTitle: "Tableau F&B COGS & Service Speed Bullet Dashboard",
        audience: "Store Managers, Shift Supervisors",
        visuals: [
          "Outlet Net Revenue vs Monthly Target Bullet Graphs",
          "COGS % & Gross Margin % Target Gauges",
          "Mean Guest Rating vs 4.5★ Benchmark",
          "Shift-Level Action Checklist",
        ],
        whenToChoose:
          "Best for daily store standups tracking whether each outlet is hitting its margin, speed, and rating targets.",
      },
    ],
  },
  {
    domain: "CFO P&L & Variance",
    layouts: [
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "CFO P&L Gross-to-Net Profit Bridge + COGS Variance",
        pbiTitle: "Power BI CFO Income Statement & EBITDA Waterfall",
        tabTitle: "Tableau Financial P&L Bridge & Cost Center Variance",
        audience: "CFO, VP Finance, Controllers, Auditors",
        visuals: [
          "Gross Revenue -> Discounts -> Net Revenue -> COGS -> Gross Profit Bridge",
          "Cohort Gross Margin % Variance Bar Chart",
          "Cost-to-Revenue Ratio Scatter",
          "Audited Ledger Summary Table",
        ],
        whenToChoose:
          "Best for board financial reviews requiring reconcilable Gross Revenue, Discount, COGS, and Gross Profit math.",
      },
      {
        layoutId: "pivot-crosstab-databars",
        layoutName: "Cost-Center General Ledger Matrix + Margin Data Bars",
        pbiTitle: "Power BI Financial Matrix with Budget vs Actual Variance",
        tabTitle: "Tableau CFO Ledger Crosstab & Conditional Alerts",
        audience: "FP&A Teams, Chartered Accountants, CFO",
        visuals: [
          "Cost Center P&L Crosstab (Gross, Discount, Net, COGS, Profit, Margin %)",
          "In-Cell Margin % Data Bars",
          "Exception & Leakage Audit Table",
          "Quarterly Run-Rate Projection",
        ],
        whenToChoose:
          "Best when finance teams want an Excel/Tally-grade structured P&L table inside Power BI or Tableau.",
      },
      {
        layoutId: "anomaly-control-chart",
        layoutName: "Statistical 3-Sigma Control Chart + Forensic Audit Log",
        pbiTitle: "Power BI Forensic Internal Audit & Benford/IQR Anomaly View",
        tabTitle: "Tableau Bollinger/3-Sigma Financial Control Chart",
        audience: "Internal Audit, Risk & Compliance Officers",
        visuals: [
          "Mean ± 2σ Statistical Control Chart for Transaction Amounts",
          "Unauthorized Discount & Refund Spike Detector",
          "Duplicate Voucher / Order Interception Table",
          "Data Hygiene Remediation Certificate",
        ],
        whenToChoose:
          "Best when auditing transactions for billing errors, unauthorized discounts, or abnormal cost spikes.",
      },
      {
        layoutId: "bullet-gauge-sla-tracker",
        layoutName: "Budget vs Actual Bullet Scorecard + Working Capital Gauges",
        pbiTitle: "Power BI FP&A Budget Variance & Margin Target Suite",
        tabTitle: "Tableau Budget vs Actual Bullet & Variance Bridge",
        audience: "FP&A Directors, Department Budget Owners",
        visuals: [
          "Department Budget vs Actual Bullet Graphs",
          "Gross Margin % vs Target Threshold Gauges",
          "Top Cost Drivers Pareto Chart",
          "Savings Opportunity Calculator",
        ],
        whenToChoose:
          "Best for monthly budget-vs-actual variance reviews across business units.",
      },
      {
        layoutId: "dual-axis-velocity-trend",
        layoutName: "Unit Economics (Price vs Unit Cost) + Contribution Margin",
        pbiTitle: "Power BI Unit Economics & Contribution Margin Studio",
        tabTitle: "Tableau Unit Price vs COGS Spread & Margin Velocity",
        audience: "CFO, Pricing Committee, Strategy Heads",
        visuals: [
          "Unit Price vs Unit Cost Dual-Axis Spread",
          "Gross Margin % Distribution Histogram",
          "Cohort Profitability Quadrant",
          "Break-Even Volume Sensitivity Table",
        ],
        whenToChoose:
          "Best when analyzing SKU/item-level unit economics and gross margin spreads.",
      },
      {
        layoutId: "exec-ribbon-combo-decomp",
        layoutName: "CFO Profit Decomposition Tree + Cash Leakage Ribbon",
        pbiTitle: "Power BI AI Profit Margin Decomposition & Leakage Deck",
        tabTitle: "Tableau Hierarchical Profit Drilldown & Margin Story",
        audience: "CFO, Private Equity Operating Partners",
        visuals: [
          "Gross Profit AI Decomposition Tree",
          "6-Card Financial Health Ribbon",
          "Leakage Recovery ROI Simulator",
          "Audited Cohort P&L Table",
        ],
        whenToChoose:
          "Best when explaining exact drivers of profit margin expansion or compression to investors.",
      },
    ],
  },
  {
    domain: "Marketing & Retention",
    layouts: [
      {
        layoutId: "sankey-funnel-conversion",
        layoutName: "Full-Funnel Acquisition to Repeat Order Conversion",
        pbiTitle: "Power BI Growth Marketing Funnel & Promo ROAS Suite",
        tabTitle: "Tableau Multi-Touch Attribution & Promo Conversion Flow",
        audience: "CMO, Growth Marketing Managers, Performance Marketers",
        visuals: [
          "Promo Code to Verified Paid Order Funnel",
          "Net Revenue Lift vs Discount Cost by Promo Code",
          "Customer Rating Distribution by Campaign",
          "Promo ROI Efficiency Table",
        ],
        whenToChoose:
          "Best when evaluating whether promo codes (like VIP20, WEEKEND15, MORNING10) generate profitable net revenue or just give away margin.",
      },
      {
        layoutId: "marimekko-heatmap-matrix",
        layoutName: "Cohort Retention Heatmap + Segment Spend Mosaic",
        pbiTitle: "Power BI Customer Cohort Retention & LTV Heatmap",
        tabTitle: "Tableau Triangle Cohort Retention & Spend Matrix",
        audience: "CRM Managers, Lifecycle Marketers, Product Growth",
        visuals: [
          "Cohort × Time Period Intensity Heatmap",
          "Segment Share Marimekko Chart",
          "Repeat Frequency Histogram",
          "High-Value VIP Cohort Table",
        ],
        whenToChoose:
          "Best when tracking customer retention, repeat purchase behavior, and cohort lifetime value.",
      },
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "CSAT/Rating vs Spend Elasticity + NPS Driver Matrix",
        pbiTitle: "Power BI Customer Experience (CX) & Spend Driver Studio",
        tabTitle: "Tableau CSAT vs Revenue Elasticity Quadrant",
        audience: "VP Customer Experience, Brand Directors",
        visuals: [
          "Customer Rating vs Net Spend Scatter & Regression",
          "Rating Tier Breakdown (Promoters vs Detractors)",
          "Operational Speed Impact on Rating Chart",
          "At-Risk Cohort Recovery Playbook",
        ],
        whenToChoose:
          "Best when quantifying how customer satisfaction ratings directly impact repeat revenue.",
      },
      {
        layoutId: "small-multiples-treemap",
        layoutName: "Channel & Promo Small Multiples + Category Share Treemap",
        pbiTitle: "Power BI Campaign & Category Performance Grid",
        tabTitle: "Tableau Channel Small Multiples & Product Treemap",
        audience: "Brand Managers, Category Heads",
        visuals: [
          "Promo / Channel Small Multiples Grid",
          "Product Category Revenue Treemap",
          "Discount Depth vs Volume Bar Chart",
          "Campaign ROI Leaderboard",
        ],
        whenToChoose:
          "Best when comparing multiple marketing promotions and product categories side by side.",
      },
      {
        layoutId: "radar-spider-benchmark",
        layoutName: "Brand Health 360° Radar + Cohort Sentiment Profile",
        pbiTitle: "Power BI Brand Equity & Outlet Sentiment Radar",
        tabTitle: "Tableau Multi-Dimension Customer Sentiment Spider",
        audience: "CMO, Customer Insights Team",
        visuals: [
          "5-Axis Brand & Outlet Sentiment Radar",
          "Customer Rating Histogram with Median Marker",
          "Cohort Net Promoter Proxy Scorecard",
          "Actionable CX Fixes Table",
        ],
        whenToChoose:
          "Best when presenting customer sentiment and brand perception across locations.",
      },
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "Promo Spend Efficiency Bridge + Top 20% VIP Concentration",
        pbiTitle: "Power BI Promotional Trade Spend & VIP Pareto Deck",
        tabTitle: "Tableau Trade Spend Waterfall & Customer Pareto",
        audience: "Trade Marketing, Revenue Growth Management (RGM)",
        visuals: [
          "Gross Sales -> Authorized Promos -> Unauthorized Leakage -> Net Sales",
          "80/20 Pareto Curve of Revenue by Item/Segment",
          "Promo Code Margin Erosion Chart",
          "Guardrail Recommendations",
        ],
        whenToChoose:
          "Best when optimizing promotional trade spend and cutting unprofitable discount codes.",
      },
    ],
  },
  {
    domain: "Supply Chain & SLA",
    layouts: [
      {
        layoutId: "boxplot-iqr-distribution",
        layoutName: "Lead-Time / Prep-Time IQR Boxplot + Outlier Winsorization",
        pbiTitle: "Power BI Supply Chain & Fulfilment SLA Boxplot Suite",
        tabTitle: "Tableau Fulfilment Latency Box-and-Whisker & IQR Fence",
        audience: "VP Supply Chain, Logistics Directors, Operations",
        visuals: [
          "Cohort Latency Box-and-Whisker Plot (Median & IQR)",
          "Extreme Outlier Capping Audit (Winsorized vs Raw)",
          "Turnaround Time vs Rating Correlation",
          "Bottleneck Remediation Table",
        ],
        whenToChoose:
          "Best when analyzing fulfilment, delivery, or prep lead times and removing extreme sensor/logging glitches.",
      },
      {
        layoutId: "anomaly-control-chart",
        layoutName: "Six-Sigma Process Control Chart + SLA Breach Tracker",
        pbiTitle: "Power BI Six-Sigma Process Control & Quality Cockpit",
        tabTitle: "Tableau SPC Control Chart (UCL / Mean / LCL)",
        audience: "Quality Engineers, Lean Six Sigma Black Belts, COO",
        visuals: [
          "Upper/Lower Control Limit (UCL/LCL) Process Chart",
          "Defect / Outlier Frequency Pareto",
          "Process Capability & Health Gauge",
          "Root-Cause Corrective Action Table",
        ],
        whenToChoose:
          "Best for Six-Sigma quality control and spotting when operational turnaround crosses upper control limits.",
      },
      {
        layoutId: "bullet-gauge-sla-tracker",
        layoutName: "On-Time In-Full (OTIF) Bullet Matrix + SLA Gauges",
        pbiTitle: "Power BI OTIF & Warehouse SLA Scorecard",
        tabTitle: "Tableau Logistics SLA Bullet & Throughput View",
        audience: "Warehouse Managers, Fulfilment Leads",
        visuals: [
          "Cohort SLA Turnaround Bullet Graphs",
          "On-Time Fulfilment Rate Gauges",
          "Unit Cost vs Volume Efficiency Bar Chart",
          "Daily Dispatch Audit Log",
        ],
        whenToChoose:
          "Best when monitoring strict service-level agreements (SLAs) across hubs or kitchens.",
      },
      {
        layoutId: "sankey-funnel-conversion",
        layoutName: "Order-to-Fulfilment Flow + Exception Drop-Off Funnel",
        pbiTitle: "Power BI Order Fulfilment & Exception Flow Studio",
        tabTitle: "Tableau Supply Chain Node-to-Node Sankey",
        audience: "Supply Chain Planners, Inventory Controllers",
        visuals: [
          "Source-to-Zone Fulfilment Flow Chart",
          "Order Status Funnel (Paid vs Failed vs Refunded)",
          "SKU Volume Velocity Chart",
          "Inventory Cost Matrix",
        ],
        whenToChoose:
          "Best when tracking order flow from placement through kitchen/warehouse prep to completed delivery.",
      },
      {
        layoutId: "small-multiples-treemap",
        layoutName: "SKU Inventory Cost Treemap + Hub Throughput Grid",
        pbiTitle: "Power BI SKU COGS Treemap & Hub Comparison Grid",
        tabTitle: "Tableau Inventory Value Treemap & Hub Small Multiples",
        audience: "Procurement Heads, Inventory Planners",
        visuals: [
          "Item COGS & Volume Hierarchical Treemap",
          "Hub/Zone Small Multiples Throughput Grid",
          "Unit Cost vs Unit Price Margin Spread",
          "Reorder & Cost Optimization Table",
        ],
        whenToChoose:
          "Best when controlling COGS, raw material costs, and SKU-level throughput across hubs.",
      },
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "Order Complexity (Qty/Pax) vs Turnaround Time Regression",
        pbiTitle: "Power BI Capacity Load vs Turnaround Regression View",
        tabTitle: "Tableau Load vs Latency Scatter & Capacity Planner",
        audience: "Capacity Planners, Industrial Engineers",
        visuals: [
          "Order Size (Qty/Pax) vs Prep Time Scatter + Trendline",
          "Peak Load Capacity Utilization Chart",
          "Cohort Bottleneck Ranking",
          "Staffing & Batching Recommendations",
        ],
        whenToChoose:
          "Best when testing whether large group orders or specific items cause kitchen/warehouse bottlenecks.",
      },
    ],
  },
  {
    domain: "SaaS & Recurring Revenue",
    layouts: [
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "SaaS MRR Expansion/Contraction Waterfall + Churn Audit",
        pbiTitle: "Power BI SaaS Net Dollar Retention (NDR) & MRR Bridge",
        tabTitle: "Tableau SaaS ARR Waterfall & Cohort Churn Story",
        audience: "SaaS Founders, CEO, VP Customer Success, VC Investors",
        visuals: [
          "Beginning MRR -> New -> Expansion -> Churn -> Net MRR Bridge",
          "Enterprise vs Mid-Market vs SMB Pareto Curve",
          "Churn Risk vs CSAT Correlation Chart",
          "Account Expansion Playbook",
        ],
        whenToChoose:
          "Best for SaaS and subscription businesses presenting ARR/MRR bridges and churn drivers to boards.",
      },
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "Account Health (CSAT vs Latency/Usage) Churn Quadrant",
        pbiTitle: "Power BI Customer Success Churn Prediction Quadrant",
        tabTitle: "Tableau Account Health Risk Quadrant & Regression",
        audience: "VP Customer Success, Account Executives, Product Managers",
        visuals: [
          "Support Latency / Usage vs CSAT Risk Quadrant",
          "MRR at Risk by Account Tier Bar Chart",
          "Pearson r Churn Driver Matrix",
          "At-Risk Account Save List",
        ],
        whenToChoose:
          "Best when identifying high-value accounts at risk of churning due to support delays or low satisfaction.",
      },
      {
        layoutId: "marimekko-heatmap-matrix",
        layoutName: "Logo & Net Dollar Retention Cohort Heatmap",
        pbiTitle: "Power BI SaaS Vintage Cohort Retention Matrix",
        tabTitle: "Tableau NRR Layer Cake & Vintage Heatmap",
        audience: "Growth PMs, SaaS CFOs, Investors",
        visuals: [
          "Cohort Retention & Expansion Heatmap",
          "Tier Revenue Share Marimekko",
          "LTV to CAC Ratio Scorecard",
          "Cohort Economics Table",
        ],
        whenToChoose:
          "Best for Series A–D fundraising decks and board reviews focused on cohort retention.",
      },
      {
        layoutId: "exec-ribbon-combo-decomp",
        layoutName: "Rule-of-40 Executive Ribbon + ARR Decomposition Tree",
        pbiTitle: "Power BI SaaS Rule-of-40 & ARR Decomposition Suite",
        tabTitle: "Tableau SaaS Executive North-Star & Drilldown Cockpit",
        audience: "SaaS CEO, CFO, Board of Directors",
        visuals: [
          "ARR, NRR %, Gross Margin %, CAC Payback KPI Ribbon",
          "Interactive ARR AI Decomposition Tree",
          "Growth vs Profitability Combo Chart",
          "Board Action Plan",
        ],
        whenToChoose:
          "Best when presenting overall SaaS company health and Rule-of-40 metrics.",
      },
      {
        layoutId: "dual-axis-velocity-trend",
        layoutName: "Seat Expansion vs ARPU Velocity + Pipeline Trend",
        pbiTitle: "Power BI Product-Led Growth (PLG) & ARPU Velocity",
        tabTitle: "Tableau PLG Seat Expansion & ARPU Dual-Axis View",
        audience: "VP Product, Growth Leads, RevOps",
        visuals: [
          "Active Seats/Units vs ARPU Dual-Axis Chart",
          "Discount Impact on Net Realized Price",
          "Tier Upgrade Distribution",
          "Monetization Experiment Table",
        ],
        whenToChoose:
          "Best when analyzing seat expansion, pricing tiers, and discounting impact on ARPU.",
      },
      {
        layoutId: "bullet-gauge-sla-tracker",
        layoutName: "Quota & NRR Target Bullet Matrix + Support SLA Gauges",
        pbiTitle: "Power BI RevOps & Customer Success SLA Scorecard",
        tabTitle: "Tableau SaaS Quota & Support SLA Bullet Dashboard",
        audience: "RevOps, Customer Support Directors",
        visuals: [
          "Regional ARR vs Quota Bullet Graphs",
          "First-Response & Resolution SLA Gauges",
          "CSAT Score by Support Tier",
          "Escalation Reduction Playbook",
        ],
        whenToChoose:
          "Best when aligning sales quota attainment with customer support SLA compliance.",
      },
    ],
  },
  {
    domain: "Workforce & HR",
    layouts: [
      {
        layoutId: "radar-spider-benchmark",
        layoutName: "Staff / Server Productivity 360° Radar + Quality Index",
        pbiTitle: "Power BI Workforce Productivity & Service Scorecard",
        tabTitle: "Tableau Employee / Server 360° Performance Radar",
        audience: "CHRO, Operations Managers, Store Directors",
        visuals: [
          "Multi-Axis Staff Performance Radar (Volume, Revenue, Speed, Rating)",
          "Employee / Server Revenue & Rating Leaderboard",
          "Workload Distribution Histogram",
          "Coaching & Incentive Matrix",
        ],
        whenToChoose:
          "Best when evaluating staff, servers, or account reps across both revenue output and customer satisfaction.",
      },
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "Workload Volume vs Service Speed/Rating Quadrant",
        pbiTitle: "Power BI Staff Burnout & Capacity Utilization Matrix",
        tabTitle: "Tableau Workload vs Quality Quadrant & Trend",
        audience: "HR Analytics, Shift Planners, Ops Leaders",
        visuals: [
          "Orders/Covers Handled vs Customer Rating Scatter",
          "Shift Hour Load Bar Chart",
          "Unauthorized Discount Compliance Audit by Staff ID",
          "Shift Rebalancing Recommendations",
        ],
        whenToChoose:
          "Best when checking if overloaded shifts cause slower service and lower customer ratings.",
      },
      {
        layoutId: "small-multiples-treemap",
        layoutName: "Department / Outlet Staffing Grid + Compensation Treemap",
        pbiTitle: "Power BI Headcount & Productivity Small Multiples",
        tabTitle: "Tableau Org Unit Small Multiples & Cost Treemap",
        audience: "VP HR, Finance Partners, Regional Heads",
        visuals: [
          "Location/Team Small Multiples Productivity Grid",
          "Revenue-per-Employee / Cover Treemap",
          "Tenure vs Performance Chart",
          "Roster Optimization Table",
        ],
        whenToChoose:
          "Best when comparing workforce output across multiple branches or departments.",
      },
      {
        layoutId: "boxplot-iqr-distribution",
        layoutName: "Performance & Turnaround Dispersion Boxplot by Team",
        pbiTitle: "Power BI Team Consistency & Variance Boxplot Studio",
        tabTitle: "Tableau Staff Turnaround & Rating Box-and-Whisker",
        audience: "People Analytics, L&D Directors",
        visuals: [
          "Team Turnaround / Output Box-and-Whisker Plot",
          "Top vs Bottom Quartile Gap Analysis",
          "Training ROI Impact Simulator",
          "Standard Operating Procedure (SOP) Playbook",
        ],
        whenToChoose:
          "Best when measuring consistency across staff and identifying who needs SOP coaching.",
      },
      {
        layoutId: "bullet-gauge-sla-tracker",
        layoutName: "KPI Target Attainment Bullets + Compliance Gauges",
        pbiTitle: "Power BI Incentive & Bonus Attainment Scorecard",
        tabTitle: "Tableau Staff KPI Bullet & Compliance Tracker",
        audience: "Store Managers, Sales & Ops Directors",
        visuals: [
          "Staff Actual vs Target Revenue Bullet Graphs",
          "Policy & Promo Compliance Gauges",
          "Customer Rating Leaderboard",
          "Monthly Bonus Qualification Table",
        ],
        whenToChoose:
          "Best for transparent monthly staff incentive and compliance reviews.",
      },
      {
        layoutId: "pivot-crosstab-databars",
        layoutName: "Shift & Roster Performance Crosstab with Data Bars",
        pbiTitle: "Power BI Roster & Shift Audit Matrix",
        tabTitle: "Tableau Staff × Outlet Highlight Crosstab",
        audience: "Operations Managers, HR Business Partners",
        visuals: [
          "Staff × Outlet Zone Performance Crosstab",
          "In-Cell Revenue & Rating Conditional Data Bars",
          "Policy Exception Log",
          "Shift Allocation Summary",
        ],
        whenToChoose:
          "Best when reviewing granular staff performance across locations and shifts.",
      },
    ],
  },
  {
    domain: "Statistical Data Science",
    layouts: [
      {
        layoutId: "scatter-quadrant-regression",
        layoutName: "Pearson r Correlation Matrix + OLS Regression & Residual Audit",
        pbiTitle: "Power BI Data Science Correlation & Regression Workbench",
        tabTitle: "Tableau Statistical Regression, R² & p-Value Studio",
        audience: "Lead Data Scientists, Principal Analysts, Econometricians",
        visuals: [
          "Bivariate Scatter with OLS Regression Line & Slope Equation",
          "Full Pairwise Pearson r Correlation Matrix",
          "Parametric (Mean/SD) vs Non-Parametric (Median/IQR) Table",
          "Hypothesis Test Proof Cards",
        ],
        whenToChoose:
          "Best when presenting rigorous statistical proof, correlation coefficients (r), and regression slopes.",
      },
      {
        layoutId: "boxplot-iqr-distribution",
        layoutName: "Tukey 1.5×IQR Winsorization + Skewness & Kurtosis Studio",
        pbiTitle: "Power BI Outlier Winsorization & Distribution Diagnostics",
        tabTitle: "Tableau Tukey Boxplot & Parametric vs Non-Parametric View",
        audience: "Data Scientists, Quantitative Analysts, Data Engineers",
        visuals: [
          "Tukey 1.5×IQR Fence Boxplot across Cohorts",
          "Frequency Distribution Histogram with Mean vs Median Split",
          "Winsorized Outlier Remediation Log",
          "Column Normality & Skewness Profile Table",
        ],
        whenToChoose:
          "Best when demonstrating why skewed distributions require Median/IQR and Winsorization before modeling.",
      },
      {
        layoutId: "anomaly-control-chart",
        layoutName: "Z-Score (±2σ / ±3σ) Anomaly Detection & Pipeline Hygiene",
        pbiTitle: "Power BI Z-Score Anomaly & Data Hygiene Diagnostic",
        tabTitle: "Tableau Z-Score Band & Pipeline Sanity Monitor",
        audience: "Analytics Engineers, Data Quality Leads",
        visuals: [
          "Z-Score Anomaly Control Chart (±2σ Bands)",
          "Pre-Flight Hygiene Scorecard (Duplicates, Nulls, Formats, Outliers)",
          "Before vs After Cleaning Health Comparison",
          "Cell-Level Remediation Audit Trail",
        ],
        whenToChoose:
          "Best when proving data pipeline hygiene and anomaly isolation before executive reporting.",
      },
      {
        layoutId: "waterfall-pareto-bridge",
        layoutName: "Lorenz / Pareto Cumulative Inequality & Variance Decomposition",
        pbiTitle: "Power BI Pareto 80/20 & Variance Decomposition Studio",
        tabTitle: "Tableau Lorenz Concentration Curve & Cohort Contribution",
        audience: "Quantitative Strategists, Operations Research",
        visuals: [
          "Cumulative Pareto 80/20 Concentration Curve",
          "Cohort Variance Contribution Waterfall",
          "Coefficient of Variation (CV = SD/Mean) Bar Chart",
          "High-Leverage Intervention Matrix",
        ],
        whenToChoose:
          "Best when mathematically isolating the exact cohorts responsible for 80% of variance.",
      },
      {
        layoutId: "marimekko-heatmap-matrix",
        layoutName: "Multivariate Cross-Entropy & Contingency Heatmap",
        pbiTitle: "Power BI Multivariate Cohort × Metric Intensity Matrix",
        tabTitle: "Tableau Contingency Heatmap & Normalized Z-Matrix",
        audience: "Data Scientists, Marketing Scientists",
        visuals: [
          "Normalized Multi-Metric Cohort Heatmap",
          "Two-Dimensional Marimekko Proportion Chart",
          "Cluster Centroid Summary Table",
          "Feature Importance Ranking",
        ],
        whenToChoose:
          "Best when exploring interactions between two categorical dimensions and multiple numeric KPIs.",
      },
      {
        layoutId: "radar-spider-benchmark",
        layoutName: "Multi-Dimensional Z-Normalized Cohort Cluster Profiles",
        pbiTitle: "Power BI Cluster Profile Radar & Benchmark Suite",
        tabTitle: "Tableau Normalized Parallel Coordinates & Spider Plot",
        audience: "Machine Learning Engineers, Strategic Analysts",
        visuals: [
          "Z-Normalized Multi-Axis Cohort Radar",
          "Cohort Distance from Global Mean Bar Chart",
          "Statistical Significance Summary",
          "Prescriptive Optimization Playbook",
        ],
        whenToChoose:
          "Best when comparing cohorts across metrics with different units (e.g., INR, Minutes, 1–5 Stars, Pax).",
      },
    ],
  },
];

/**
 * Generates the complete 108-Template Library (54 Power BI + 54 Tableau)
 * dynamically hydrated with formulas referencing the active dataset's columns.
 */
export function buildBiTemplatesCatalog(
  columnProfiles: ColumnProfile[]
): BiTemplateItem[] {
  const numCols = columnProfiles.filter((c) => c.type === "numeric");
  const catCols = columnProfiles.filter((c) => c.type === "categorical");

  const primaryNum =
    numCols.find((c) => /rev|sales|amount|price|profit|mrr/i.test(c.name))
      ?.name ||
    numCols[0]?.name ||
    "Net_Revenue_INR";
  const secondaryNum =
    numCols.find(
      (c) =>
        c.name !== primaryNum &&
        /prep|time|rating|cost|qty|pax|churn/i.test(c.name)
    )?.name ||
    numCols[1]?.name ||
    "Prep_Time_Mins";
  const primaryCat =
    catCols.find((c) =>
      /outlet|zone|region|category|segment|channel/i.test(c.name)
    )?.name ||
    catCols[0]?.name ||
    "Outlet_Zone";

  const templates: BiTemplateItem[] = [];
  let pbiCounter = 1;
  let tabCounter = 55;

  for (const domGroup of DOMAIN_CONFIGS) {
    for (const item of domGroup.layouts) {
      // 1. Power BI Template Entry
      const pbiCode = `PBI-${String(pbiCounter).padStart(3, "0")}`;
      templates.push({
        id: `tpl-pbi-${pbiCounter}`,
        code: pbiCode,
        platform: "Power BI",
        domain: domGroup.domain,
        title: item.pbiTitle,
        subtitle: `${domGroup.domain} · ${item.layoutName}`,
        targetAudience: item.audience,
        layoutId: item.layoutId,
        layoutName: item.layoutName,
        visualsIncluded: item.visuals,
        whenToChoose: item.whenToChoose,
        formulaLabel: "Verified Power BI DAX Measure",
        formulaCode: `Verified_${primaryNum} = \nCALCULATE(\n    SUM('VerifiedData'[${primaryNum}]),\n    FILTER('VerifiedData', 'VerifiedData'[Is_Duplicate] = FALSE())\n)\n// Cohort Avg ${secondaryNum} by ${primaryCat}\nCohort_Mean_${secondaryNum} = AVERAGE('VerifiedData'[${secondaryNum}])`,
        presentationSlideCount: 6,
        complexityLevel:
          domGroup.domain === "Statistical Data Science"
            ? "Data Science Deep-Dive"
            : domGroup.domain === "Executive Boardroom"
            ? "Executive Ready"
            : "Analyst Pro",
      });
      pbiCounter++;

      // 2. Tableau Template Entry
      const tabCode = `TAB-${String(tabCounter).padStart(3, "0")}`;
      templates.push({
        id: `tpl-tab-${tabCounter}`,
        code: tabCode,
        platform: "Tableau",
        domain: domGroup.domain,
        title: item.tabTitle,
        subtitle: `${domGroup.domain} · ${item.layoutName}`,
        targetAudience: item.audience,
        layoutId: item.layoutId,
        layoutName: item.layoutName,
        visualsIncluded: item.visuals,
        whenToChoose: item.whenToChoose,
        formulaLabel: "Verified Tableau LOD Calculation",
        formulaCode: `// Tableau Fixed LOD by [${primaryCat}]\n{ FIXED [${primaryCat}] : SUM([${primaryNum}]) }\n\n// Winsorized / Clean Cohort Benchmark\n{ FIXED [${primaryCat}] : AVG([${secondaryNum}]) }`,
        presentationSlideCount: 6,
        complexityLevel:
          domGroup.domain === "Statistical Data Science"
            ? "Data Science Deep-Dive"
            : domGroup.domain === "Executive Boardroom"
            ? "Executive Ready"
            : "Analyst Pro",
      });
      tabCounter++;
    }
  }

  return templates;
}

/**
 * AI Template Advisor: Scores & recommends the best Power BI and Tableau templates
 * based on the user's stated presentation goal, target audience, and active dataset schema.
 */
export function recommendBiTemplatesForGoal(
  userGoalPrompt: string,
  platformFilter: "ALL" | BiPlatform,
  allTemplates: BiTemplateItem[],
  datasetName: string,
  columnProfiles: ColumnProfile[],
  correlations: CorrelationPair[],
  cleaningSummary: CleaningSummary
): BiAdvisorRecommendation[] {
  const q = userGoalPrompt.toLowerCase();
  const colNames = columnProfiles.map((c) => c.name.toLowerCase()).join(" ");
  const topCorr = correlations[0];

  const scored = allTemplates
    .filter((t) => platformFilter === "ALL" || t.platform === platformFilter)
    .map((tpl) => {
      let score = 78;
      const blob =
        `${tpl.title} ${tpl.subtitle} ${tpl.domain} ${tpl.targetAudience} ${tpl.whenToChoose} ${tpl.layoutName}`.toLowerCase();

      // Match keywords from user prompt
      const tokens = q
        .split(/\s+/)
        .map((w) => w.replace(/[^a-z0-9]/g, ""))
        .filter((w) => w.length > 2);

      for (const tok of tokens) {
        if (blob.includes(tok)) score += 5;
      }

      // Domain & dataset context boosts
      if (
        (q.includes("pos") ||
          q.includes("outlet") ||
          q.includes("bistro") ||
          q.includes("restaurant") ||
          q.includes("prep") ||
          colNames.includes("outlet") ||
          colNames.includes("prep_time")) &&
        tpl.domain === "Hospitality & POS Ops"
      ) {
        score += 14;
      }
      if (
        (q.includes("ceo") ||
          q.includes("board") ||
          q.includes("executive") ||
          q.includes("presentation") ||
          q.includes("summary")) &&
        tpl.domain === "Executive Boardroom"
      ) {
        score += 13;
      }
      if (
        (q.includes("cfo") ||
          q.includes("profit") ||
          q.includes("margin") ||
          q.includes("cost") ||
          q.includes("cogs") ||
          q.includes("leakage") ||
          q.includes("discount")) &&
        (tpl.domain === "CFO P&L & Variance" ||
          tpl.domain === "Sales & Revenue Waterfall")
      ) {
        score += 12;
      }
      if (
        (q.includes("correlation") ||
          q.includes("outlier") ||
          q.includes("stat") ||
          q.includes("regression") ||
          q.includes("iqr")) &&
        tpl.domain === "Statistical Data Science"
      ) {
        score += 14;
      }
      if (
        (q.includes("churn") ||
          q.includes("saas") ||
          q.includes("mrr") ||
          q.includes("retention")) &&
        tpl.domain === "SaaS & Recurring Revenue"
      ) {
        score += 14;
      }

      const cappedScore = Math.min(99, score);

      const numCol =
        columnProfiles.find((c) => c.type === "numeric")?.name || "Net_Revenue";
      const catCol =
        columnProfiles.find((c) => c.type === "categorical")?.name ||
        "Outlet_Zone";

      const aiWhyChooseThis = `${tpl.whenToChoose} For "${datasetName}" (${cleaningSummary.cleanedRowCount} verified rows), this ${tpl.platform} template automatically binds [${catCol}] and [${numCol}]${
        topCorr
          ? ` while highlighting your top statistical driver (${topCorr.colA} ↔ ${topCorr.colB}, r = ${topCorr.r})`
          : ""
      }.`;

      return {
        template: tpl,
        matchScorePct: cappedScore,
        aiWhyChooseThis,
        mappedColumnsNote: `Auto-Mapped: Cohort [${catCol}] · Metric [${numCol}]${
          topCorr ? ` · Driver [${topCorr.colA} vs ${topCorr.colB}]` : ""
        }`,
      };
    })
    .sort((a, b) => b.matchScorePct - a.matchScorePct);

  return scored.slice(0, 6);
}
