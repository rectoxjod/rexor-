/**
 * Rexor — 4 High-Friction, Urgent Operational Problem Statements & Autonomous Agent Engines
 * Covers:
 *   Problem 1: Food Waste & Margin Bleed in Multi-Platform Cloud Kitchens / Restaurants
 *   Problem 2: "Dead Capital" in Small-to-Medium Retail & E-Commerce
 *   Problem 3: Cash Flow Volatility & Silent SaaS/Vendor Leaks in Small Businesses
 *   Problem 4: Patient Appointment No-Shows in Outpatient Clinics
 *
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

export type HighFrictionProblemId =
  | "problem-1-cloud-kitchen"
  | "problem-2-dead-capital"
  | "problem-3-cashflow-leaks"
  | "problem-4-clinic-noshows";

export interface HighFrictionProblemSpec {
  id: HighFrictionProblemId;
  numberLabel: string;
  shortTitle: string;
  title: string;
  industryBadge: string;
  selectionCriterionBadge: string;
  contextAndPainPoint: string;
  problemStatement: string;
  whatAgentDoes: Array<{
    capability: string;
    detail: string;
  }>;
  primaryMetricsToMove: string[];
  datasetName: string;
  domainContext: string;
  defaultBusinessQuestion: string;
  rawCsv: string;
}

export const SELECTION_DECISION_MATRIX = [
  {
    criterion: "Highest Immediate Operational Need",
    bestFitId: "problem-1-cloud-kitchen" as HighFrictionProblemId,
    bestFitLabel: "Problem 1 (Cloud Kitchens & Restaurants)",
    rationale:
      "Fast feedback loop, daily operational impact on perishable prep sizing, and clear monetary recovery from delivery aggregator deductions.",
  },
  {
    criterion: "Easiest Data Access to Prototype",
    bestFitId: "problem-2-dead-capital" as HighFrictionProblemId,
    bestFitLabel: "Problem 2 (Retail & E-Commerce Dead Capital)",
    rationale:
      "Clean public Shopify, WooCommerce, and Kaggle inventory/sales velocity datasets are widely available to test immediately.",
  },
  {
    criterion: "Simplest API Integration",
    bestFitId: "problem-3-cashflow-leaks" as HighFrictionProblemId,
    bestFitLabel: "Problem 3 (SMB Cash Flow & Vendor Leaks)",
    rationale:
      "Straightforward read-only connection to accounting CSVs, Tally/QuickBooks, Plaid bank feeds, or Stripe invoice records.",
  },
  {
    criterion: "Highest Per-Hour Capacity Recovery",
    bestFitId: "problem-4-clinic-noshows" as HighFrictionProblemId,
    bestFitLabel: "Problem 4 (Outpatient Clinic No-Shows)",
    rationale:
      "Empty medical/dental slots cannot be recovered once missed; risk-based overbooking and waitlist matching immediately boosts billable utilization.",
  },
];

export const HIGH_FRICTION_PROBLEMS: HighFrictionProblemSpec[] = [
  {
    id: "problem-1-cloud-kitchen",
    numberLabel: "PROBLEM 01",
    shortTitle: "Cloud Kitchen Food Waste & Aggregator Bleed",
    title:
      "Food Waste & Margin Bleed in Multi-Platform Cloud Kitchens / Restaurants",
    industryBadge: "Hospitality · Cloud Kitchens · POS + Zomato/Swiggy/UberEats",
    selectionCriterionBadge: "Highest Immediate Operational Need",
    contextAndPainPoint:
      "Independent and franchise restaurants operate on razor-thin margins. Food waste typically eats 4% to 10% of revenue due to inaccurate daily prep forecasting, while delivery aggregators (UberEats, DoorDash, Zomato, Swiggy) hit them with complex commissions, customer refund penalties, and unverified cancellation chargebacks. Kitchen managers do not have time to cross-reference POS receipts, vendor ingredient invoices, and delivery payout settlements.",
    problemStatement:
      "Design an autonomous auditing and forecasting agent that ingests raw POS logs, third-party delivery settlement sheets, and supplier ingredient invoices to eliminate kitchen food over-prep and flag hidden delivery aggregator revenue leakage.",
    whatAgentDoes: [
      {
        capability: "Daily Prep Sizing",
        detail:
          "Analyzes rolling 30-day sales, day-of-week trends, and external inputs (local weather, holidays) to output exact batch sizes for perishable prep items.",
      },
      {
        capability: "Aggregator Deduction Audit",
        detail:
          "Matches raw POS tickets against weekly payout summaries to isolate unjustified refund deductions, commission overcharges, or missing payout items.",
      },
      {
        capability: "Ingredient Inflation Tracker",
        detail:
          "Tracks weekly unit costs from supplier bills and highlights dishes whose contribution margin has dipped below a target threshold.",
      },
    ],
    primaryMetricsToMove: [
      "15–25% reduction in perishable prep food waste",
      "2–5% gross revenue recovered from aggregator billing discrepancies",
    ],
    datasetName:
      "Cloud Kitchen POS, Aggregator Payouts & Prep Waste Audit (cloud_kitchen_bleed_raw.csv)",
    domainContext:
      "Multi-Brand Cloud Kitchen POS, Aggregator Settlements (Zomato/Swiggy/UberEats) & Vendor Ingredient Invoices",
    defaultBusinessQuestion:
      "Which perishable prep items are over-prepped across weather/day-of-week shifts, which delivery aggregator orders have unjustified refund/commission deductions vs POS logs, and which dishes fell below target contribution margin due to supplier ingredient inflation?",
    rawCsv: `Order_ID,Date,Channel_Platform,Dish_Name,Weather_Condition,Prep_Batch_Kg,Actual_Sold_Kg,Perishable_Waste_INR,POS_Gross_INR,Aggregator_Payout_INR,Unjustified_Deduction_INR,Ingredient_Cost_INR,Contribution_Margin_Pct,Audit_Flag
CK-5001,2026-10-20,Zomato,Chargrilled Paneer Tikka Bowl,Monsoon Rain,18.0,11.5,₹1950,₹8400,6120,760,2680,58.2,Unverified Rain Refund Penalty + Over-Prep
CK-5002,2026-10-20,Swiggy,Avocado Burrata Sourdough,Monsoon Rain,14.0,8.2,₹2320,₹7200,5180,680,2590,54.6,Supplier Avocado +24% Inflation + Refund Dispute
CK-5003,2026-10-21,UberEats,Truffle Mushroom Risotto,Clear,15.0,14.1,₹360,₹9600,7488,0,2688,72.0,Verified Match
CK-5004,2026-10-21,Zomato,Korean Gochujang Fried Chicken,Clear,22.0,19.8,₹660,₹11400,8210,910,3648,61.5,Commission Overcharged (28% vs 22% Contract)
CK-5004,2026-10-21,Zomato,Korean Gochujang Fried Chicken,Clear,22.0,19.8,₹660,₹11400,8210,910,3648,61.5,Commission Overcharged (28% vs 22% Contract)
CK-5005,2026-10-22,DoorDash,Peri-Peri Chicken Burrito,Clear,19.0,13.0,₹1800,₹7800,5610,630,2496,59.8,Unverified Cancellation Chargeback
CK-5006,2026-10-22,Direct POS,Artisan Sourdough Egg Benedict,Clear,12.0,11.4,₹210,₹6800,6800,0,1836,73.0,Verified Match
CK-5007,2026-10-23,Swiggy,Smoked Salmon Poke Bowl,Heatwave,16.0,9.5,₹2925,₹8900,6230,890,3471,51.0,Salmon Supplier Hike + Missing Payout Ticket
CK-5008,2026-10-23,Zomato,Woodfired Burrata Margherita,Heatwave,20.0,18.5,₹525,₹10200,7956,0,2856,72.0,Verified Match
CK-5009,2026-10-24,Swiggy,Chargrilled Paneer Tikka Bowl,Monsoon Rain,19.0,12.0,₹2100,₹8800,6160,880,2992,56.0,Dairy Supplier Inflation + Unverified Spillage Claim
CK-5010,2026-10-24,UberEats,Belgian Chocolate Ganache Tart,Clear,10.0,9.2,₹320,₹5400,4212,0,1458,73.0,Verified Match
CK-5011,2026-10-25,Zomato,Avocado Burrata Sourdough,Clear,15.0,10.5,₹1800,₹7900,5530,790,2923,53.0,Margin Below 62% Threshold + Aggregator Dispute
CK-5012,2026-10-25,DoorDash,Herb Crusted Lamb Chops,Clear,14.0,12.8,₹540,₹12600,9324,504,4284,62.0,Commission Tier Discrepancy
CK-5013,2026-10-26,Swiggy,Korean Gochujang Fried Chicken,Monsoon Rain,24.0,15.2,₹2640,₹9200,6440,920,3128,57.5,Over-Prep on Rainy Tuesday + Refund Penalty
CK-5014,2026-10-26,Direct POS,Cold Brew Hazelnut Carafe,Clear,11.0,10.6,₹120,₹4900,4900,0,1078,78.0,Verified Match`,
  },
  {
    id: "problem-2-dead-capital",
    numberLabel: "PROBLEM 02",
    shortTitle: "Retail & D2C 'Dead Capital' & Markdown Optimizer",
    title: '"Dead Capital" in Small-to-Medium Retail & E-Commerce',
    industryBadge: "Retail & D2C · Shopify / ERP Inventory · Working Capital",
    selectionCriterionBadge: "Easiest Data Access to Prototype",
    contextAndPainPoint:
      'Small retail and D2C brands frequently experience cash-flow crises caused by inventory imbalances: 20% of their catalog is out of stock (losing sales), while 30% of their capital is frozen in slow-moving or "dead" SKUs sitting in warehouses incurring storage and depreciation fees. Most owners run flat discounts that cannibalize healthy margins or wait months too late to liquidate.',
    problemStatement:
      "Build an automated working capital optimization agent that identifies stagnating inventory cohorts and prescribes graduated markdown strategies without eroding overall brand margins.",
    whatAgentDoes: [
      {
        capability: "Velocity Anomaly Detection",
        detail:
          "Flags products whose sales velocity has dropped by over 30% relative to category baseline over 21 consecutive days.",
      },
      {
        capability: "Dynamic Markdown Recommendations",
        detail:
          "Calculates the specific graduated discount percentage required to clear inventory before carrying costs exceed liquidation losses.",
      },
      {
        capability: "Stockout Early Warning",
        detail:
          "Forecasts restock timelines based on supplier lead times and prevents run-outs on high-margin anchor items.",
      },
    ],
    primaryMetricsToMove: [
      "20% faster liquidation of aged inventory",
      "15% reduction in blocked working capital tied to slow-moving SKUs",
    ],
    datasetName:
      "D2C Retail Inventory Velocity, Dead Capital & Stockout Audit (retail_dead_capital_raw.csv)",
    domainContext:
      "D2C E-Commerce & Retail Inventory Aging, 21-Day Velocity Drop & Working Capital Optimization",
    defaultBusinessQuestion:
      "Which SKUs have >30% 21-day velocity drops trapping working capital in warehouse storage fees, what graduated markdown % clears them without eroding brand margin, and which high-margin anchor SKUs face imminent stockout before supplier lead times?",
    rawCsv: `SKU_ID,Product_Name,Category,Units_On_Hand,Unit_Cost_INR,Selling_Price_INR,Blocked_Capital_INR,Velocity_Drop_21d_Pct,Days_Inventory_Outstanding,Monthly_Carrying_Fee_INR,Supplier_Lead_Time_Days,Recommended_Markdown_Pct,Inventory_Cohort_Status
SKU-201,Linen Oversized Resort Shirt,Apparel,420,₹850,₹2490,₹357000,48.5,142,₹18900,21,18,Dead Capital (>120d Aged)
SKU-202,Merino Wool Knit Cardigan,Apparel,310,₹1200,₹3490,₹372000,54.2,165,₹21400,28,24,Dead Capital (>120d Aged)
SKU-203,Signature Leather Crossbody,Accessories,28,₹1650,₹4990,₹46200,-18.4,7,₹1200,21,0,Stockout Risk (DOI < Lead Time)
SKU-204,Hydrating Hyaluronic Serum,Beauty & Skincare,35,₹320,₹1290,₹11200,-24.0,6,₹650,18,0,Stockout Risk (DOI < Lead Time)
SKU-204,Hydrating Hyaluronic Serum,Beauty & Skincare,35,₹320,₹1290,₹11200,-24.0,6,₹650,18,0,Stockout Risk (DOI < Lead Time)
SKU-205,Canvas Low-Top Sneakers,Footwear,380,₹980,₹2790,₹372400,39.0,118,₹16800,25,15,Slow-Moving Velocity Drop (>30%)
SKU-206,Suede Chelsea Boots,Footwear,260,₹1450,₹4290,₹377000,44.8,136,₹19500,30,20,Dead Capital (>120d Aged)
SKU-207,Polarized Acetate Sunglasses,Accessories,45,₹540,₹2190,₹24300,-12.5,9,₹980,20,0,Stockout Risk (DOI < Lead Time)
SKU-208,Botanical Clay Face Mask,Beauty & Skincare,290,₹280,₹990,₹81200,34.5,96,₹5400,14,12,Slow-Moving Velocity Drop (>30%)
SKU-209,Tailored Chino Trousers,Apparel,190,₹780,₹2290,₹148200,6.2,38,₹4100,18,0,Healthy Core Performer
SKU-210,Silk Printed Resort Scarf,Accessories,340,₹620,₹1890,₹210800,51.0,154,₹12800,21,22,Dead Capital (>120d Aged)
SKU-211,Ceramide Barrier Night Cream,Beauty & Skincare,22,₹410,₹1590,₹9020,-29.5,5,₹490,16,0,Stockout Risk (DOI < Lead Time)
SKU-212,Corduroy Utility Overshirt,Apparel,275,₹920,₹2690,₹253000,36.8,108,₹13200,22,15,Slow-Moving Velocity Drop (>30%)`,
  },
  {
    id: "problem-3-cashflow-leaks",
    numberLabel: "PROBLEM 03",
    shortTitle: "SMB 60-Day Cash Flow & Silent SaaS/Vendor Leaks",
    title:
      "Cash Flow Volatility & Silent SaaS/Vendor Leaks in Small Businesses",
    industryBadge: "SMB Treasury · B2B Receivables (DSO) · SaaS Creep Audit",
    selectionCriterionBadge: "Simplest API Integration",
    contextAndPainPoint:
      'Most service businesses and small agencies run on less than 4 months of cash reserves. They suffer from two major blind spots: uncollected accounts receivable (invoices paid 30–60 days late) and recurring vendor "creep" (unnoticed SaaS price increases, duplicate software seats, and zombie subscriptions left behind by former team members).',
    problemStatement:
      "Create a predictive treasury and cash-burn agent that audits live bank and accounting feeds to forecast 60-day cash shortfalls and identify recurring operational expense leaks.",
    whatAgentDoes: [
      {
        capability: "Payer Behavior Profiling",
        detail:
          "Classifies clients based on historical payment delay patterns and flags invoices likely to become delinquent before they are due.",
      },
      {
        capability: "Subscription Creep Auditor",
        detail:
          "Parses monthly bank/card transactions to detect subtle subscription price hikes, redundant licenses, and inactive recurring charges.",
      },
      {
        capability: "Runway Scenario Modeling",
        detail:
          'Runs simulations (e.g., "What happens if Client X pays 45 days late and vendor bills clear on the 1st?") and suggests proactive invoice-chasing sequences.',
      },
    ],
    primaryMetricsToMove: [
      "30% reduction in average Days Sales Outstanding (DSO)",
      "5–10% immediate reduction in software and recurring vendor overhead",
    ],
    datasetName:
      "SMB Treasury AR Invoices & SaaS Subscription Creep Ledger (smb_cashflow_leaks_raw.csv)",
    domainContext:
      "SMB Treasury Management, Accounts Receivable DSO Delinquency & Recurring SaaS/Vendor Overhead Audit",
    defaultBusinessQuestion:
      "Which B2B client invoices are at high risk of 45–60 day delinquency threatening our 60-day cash runway, and which recurring SaaS/vendor subscriptions contain silent price hikes, duplicate seats, or zombie ex-employee licenses?",
    rawCsv: `Record_ID,Entity_Name,Stream_Type,Category,Monthly_Or_Invoice_INR,Historical_Delay_Days,Delinquency_Risk_Pct,Active_Seat_Utilization_Pct,Price_Hike_Pct,Annualized_Leak_INR,Recommended_Treasury_Action
TR-301,Apex Retail Retainer #INV-88,AR Invoice,Client Receivable,₹480000,46,88.0,100,0,₹0,Tier-3 Escalate: CFO Call + 2% Early-Pay Discount
TR-302,Vertex Infra Milestone #INV-91,AR Invoice,Client Receivable,₹620000,52,92.5,100,0,₹0,Tier-3 Escalate: Pause Delivery Milestone Until Cleared
TR-303,Salesforce CRM Enterprise,SaaS Expense,CRM & Sales,₹145000,0,0,42.0,18.5,₹696000,Reclaim 14 Zombie Ex-Employee Seats + Downgrade Tier
TR-304,Figma Organization Plan,SaaS Expense,Design Tool,₹68000,0,0,38.0,22.0,₹384000,Convert 19 View-Only Editors to Free Viewer Seats
TR-304,Figma Organization Plan,SaaS Expense,Design Tool,₹68000,0,0,38.0,22.0,₹384000,Convert 19 View-Only Editors to Free Viewer Seats
TR-305,AWS Staging & Orphaned Snapshots,Cloud Vendor,Infrastructure,₹195000,0,0,55.0,31.0,₹720000,Terminate 9 Unattached Dev RDS Instances & Old Snapshots
TR-306,Helios BioLabs #INV-94,AR Invoice,Client Receivable,₹340000,8,12.0,100,0,₹0,On-Time Payer (Standard Automated Reminder)
TR-307,Asana + Monday.com Duplicate,SaaS Expense,Project Mgmt,₹54000,0,0,31.0,15.0,₹648000,Consolidate Duplicate PM Tools (Cancel Monday.com)
TR-308,Nordic Logistics #INV-95,AR Invoice,Client Receivable,₹410000,38,79.0,100,0,₹0,Tier-2 Escalate: Send Automated Dunning Sequence 7d Early
TR-309,Zoom Pro + Google Meet Overlap,SaaS Expense,Communications,₹38000,0,0,24.0,12.0,₹456000,Eliminate Redundant Zoom Licenses (Already on Workspace)
TR-310,HubSpot Marketing Hub Pro,SaaS Expense,Marketing SaaS,₹112000,0,0,48.0,24.0,₹480000,Remove Unused Contact Tier Auto-Upgrade (+24% Creep)
TR-311,Stratos Media #INV-98,AR Invoice,Client Receivable,₹290000,44,85.0,100,0,₹0,Tier-3 Escalate: Require ACH Auto-Debit on Next Invoice`,
  },
  {
    id: "problem-4-clinic-noshows",
    numberLabel: "PROBLEM 04",
    shortTitle: "Outpatient Clinic Patient No-Show & Overbooking",
    title: "Patient Appointment No-Shows in Outpatient Clinics",
    industryBadge: "Healthcare Ops · Dental & Specialty Clinics · Smart Overbooking",
    selectionCriterionBadge: "Highest Per-Hour Capacity Recovery",
    contextAndPainPoint:
      "Specialized medical clinics, dental practices, and outpatient centers face high no-show rates (often 10–25%). Empty slots cannot be recovered, leading to lost billable hours for doctors and extended waitlists for other patients. Most clinics use blanket reminders rather than risk-based intervention.",
    problemStatement:
      "Develop an appointment attendance prediction agent that scores the risk of patient no-shows and automates smart overbooking and confirmation strategies.",
    whatAgentDoes: [
      {
        capability: "Risk Scoring",
        detail:
          "Analyzes appointment type, booking lead time, historical cancellation patterns, and patient travel distance to assign a no-show risk score to each booking.",
      },
      {
        capability: "Targeted Escalation",
        detail:
          "Generates a daily action list for the front desk (e.g., send WhatsApp confirmation to Tier 2 risk; call Tier 3 risk; apply standby double-booking for specific time slots).",
      },
      {
        capability: "Schedule Gap Re-filling",
        detail:
          "Automatically identifies cancelled appointments and matches them against prioritized waitlisted patients likely to accept short-notice slots.",
      },
    ],
    primaryMetricsToMove: [
      "30–40% reduction in empty clinic slots",
      "8–12% increase in realized doctor utilization",
    ],
    datasetName:
      "Outpatient Clinic Appointment No-Show Risk & Waitlist Matcher (clinic_noshow_schedule_raw.csv)",
    domainContext:
      "Outpatient Specialty & Dental Clinic Scheduling, No-Show Risk Scoring & Automated Waitlist Backfill",
    defaultBusinessQuestion:
      "Which upcoming patient appointments carry >65% no-show risk based on lead time, prior cancellations, and travel distance, what targeted front-desk escalation should run today, and which waitlisted patients can immediately backfill high-risk slots?",
    rawCsv: `Booking_ID,Patient_Name,Specialty_Department,Appointment_Type,Booking_Lead_Time_Days,Prior_No_Shows,Travel_Distance_Km,Billable_Slot_Value_INR,No_Show_Risk_Score_Pct,Risk_Tier,Front_Desk_Escalation_Action,Matched_Waitlist_Patient
APT-701,Rohan Deshmukh,Dental Prosthodontics,Root Canal & Crown Prep,28,3,19.4,₹8500,86.0,Tier 3 Critical Risk,Direct Phone Call + Standby Double-Book Slot,Waitlist #W-12 (Neha K. · 2.1km away · 94% Accept Prob)
APT-702,Ananya Kulkarni,Dermatology & Laser,Fractional CO2 Laser,24,2,16.8,₹11200,78.5,Tier 3 Critical Risk,Direct Phone Call + ₹1000 Deposit Link,Waitlist #W-04 (Vikram S. · 3.4km away · 91% Accept Prob)
APT-703,Suresh Nair,Orthopedics,Knee MRI Follow-Up,4,0,3.2,₹2200,11.0,Tier 1 Low Risk,Standard 24h Automated SMS Reminder,None Needed
APT-704,Meera Joshi,Ophthalmology,Retinal OCT Scan,16,1,11.5,₹4800,54.0,Tier 2 Elevated Risk,Send Interactive WhatsApp 1-Tap Confirm/Reschedule,Waitlist #W-19 (Arjun P. · 4.0km away · 85% Accept Prob)
APT-704,Meera Joshi,Ophthalmology,Retinal OCT Scan,16,1,11.5,₹4800,54.0,Tier 2 Elevated Risk,Send Interactive WhatsApp 1-Tap Confirm/Reschedule,Waitlist #W-19 (Arjun P. · 4.0km away · 85% Accept Prob)
APT-705,Kabir Malhotra,Dental Prosthodontics,Implant Consultation,34,4,22.0,₹9500,91.0,Tier 3 Critical Risk,Direct Phone Call + Standby Double-Book Slot,Waitlist #W-08 (Priya D. · 1.8km away · 96% Accept Prob)
APT-706,Divya Iyer,Cardiology Outpatient,2D Echo & Stress Test,6,0,4.5,₹5600,14.5,Tier 1 Low Risk,Standard 24h Automated SMS Reminder,None Needed
APT-707,Aditya Verma,Dermatology & Laser,Chemical Peel Session,19,2,14.2,₹6400,68.0,Tier 3 Critical Risk,Direct Phone Call + Standby Double-Book Slot,Waitlist #W-15 (Sonal M. · 2.9km away · 89% Accept Prob)
APT-708,Pooja Chavan,Orthopedics,Physiotherapy Rehab,12,1,9.8,₹2800,46.0,Tier 2 Elevated Risk,Send Interactive WhatsApp 1-Tap Confirm/Reschedule,Waitlist #W-22 (Karan T. · 3.1km away · 82% Accept Prob)
APT-709,Vikramaditya Rao,Dental Prosthodontics,Aligner Scan & Fitting,31,3,18.6,₹12500,84.0,Tier 3 Critical Risk,Direct Phone Call + Standby Double-Book Slot,Waitlist #W-03 (Ritu G. · 2.4km away · 93% Accept Prob)
APT-710,Sneha Patil,Ophthalmology,Routine Vision Check,5,0,2.8,₹1800,9.5,Tier 1 Low Risk,Standard 24h Automated SMS Reminder,None Needed`,
  },
];

// ============================================================================
// DETERMINISTIC SIMULATION CALCULATORS FOR ALL 4 HIGH-FRICTION PROBLEM AGENTS
// ============================================================================

export function simulateProblem1CloudKitchen(
  weather: "Monsoon Rain" | "Clear" | "Heatwave",
  dayType: "Weekday" | "Weekend" | "Festival / Holiday"
) {
  const weatherMult =
    weather === "Monsoon Rain" ? 0.74 : weather === "Heatwave" ? 0.88 : 1.0;
  const dayMult =
    dayType === "Festival / Holiday"
      ? 1.32
      : dayType === "Weekend"
      ? 1.18
      : 1.0;

  const prepItems = [
    {
      item: "Chargrilled Paneer Tikka Marinade",
      shelfLifeHrs: 18,
      manualStaticPrepKg: 20.0,
      baseDemandKg: 15.5,
      costPerKgInr: 340,
      weatherSensitivity: "High (-28% dine-in/bowl demand in heavy rain)",
    },
    {
      item: "Fresh Hass Avocado Guacamole Mash",
      shelfLifeHrs: 8,
      manualStaticPrepKg: 14.0,
      baseDemandKg: 10.2,
      costPerKgInr: 580,
      weatherSensitivity: "Extreme (Browning oxidation after 8 hrs)",
    },
    {
      item: "Artisan Sourdough & Brioche Dough",
      shelfLifeHrs: 24,
      manualStaticPrepKg: 18.0,
      baseDemandKg: 14.8,
      costPerKgInr: 210,
      weatherSensitivity: "Moderate (Morning brunch spike on weekends)",
    },
    {
      item: "Gochujang Marinated Chicken Breast",
      shelfLifeHrs: 16,
      manualStaticPrepKg: 24.0,
      baseDemandKg: 19.0,
      costPerKgInr: 310,
      weatherSensitivity: "Delivery spike (+12% on weekend evenings)",
    },
    {
      item: "Fresh Burrata & Sweet Basil Infusion",
      shelfLifeHrs: 12,
      manualStaticPrepKg: 12.0,
      baseDemandKg: 9.0,
      costPerKgInr: 640,
      weatherSensitivity: "High perishable dairy cost bleed",
    },
  ].map((p) => {
    const aiRecommendedKg = Number(
      (p.baseDemandKg * weatherMult * dayMult).toFixed(1)
    );
    const manualWasteKg = Math.max(
      0.4,
      Number((p.manualStaticPrepKg - aiRecommendedKg * 0.96).toFixed(1))
    );
    const aiWasteKg = Number((manualWasteKg * 0.22).toFixed(1));
    const dailySavingsInr = Math.round(
      (manualWasteKg - aiWasteKg) * p.costPerKgInr
    );
    return {
      ...p,
      aiRecommendedKg,
      manualWasteKg,
      aiWasteKg,
      dailySavingsInr,
      wasteReductionPct: Math.round(
        ((manualWasteKg - aiWasteKg) / Math.max(0.1, manualWasteKg)) * 100
      ),
    };
  });

  const aggregatorDisputes = [
    {
      ticketId: "ZOM-88412",
      platform: "Zomato",
      dish: "Chargrilled Paneer Tikka Bowl (x3)",
      posGrossInr: 2520,
      expectedPayoutInr: 1965,
      actualSettledInr: 1205,
      leakageInr: 760,
      discrepancyType:
        "Unverified 'Spillage' Refund Deducted (Rider GPS & Photo Proof Intact)",
      autoAction: "Auto-Filed Dispute Claim #CLM-901 with KDS Pack Timestamp",
    },
    {
      ticketId: "SWG-77209",
      platform: "Swiggy",
      dish: "Avocado Burrata Sourdough (x2)",
      posGrossInr: 1840,
      expectedPayoutInr: 1435,
      actualSettledInr: 755,
      leakageInr: 680,
      discrepancyType:
        "Post-Preparation Cancellation Chargeback (100% Penalized After Rider Pickup)",
      autoAction: "Auto-Filed Payout Recovery #CLM-902 (Rider Handover Verified)",
    },
    {
      ticketId: "ZOM-88490",
      platform: "Zomato",
      dish: "Korean Gochujang Fried Chicken (Batch)",
      posGrossInr: 11400,
      expectedPayoutInr: 8892,
      actualSettledInr: 7982,
      leakageInr: 910,
      discrepancyType:
        "Commission Tier Overcharge (Billed 28% vs 22% Signed Master Agreement)",
      autoAction: "Flagged 6.0% Commission Rate Breach for Weekly Settlement Credit",
    },
    {
      ticketId: "SWG-77315",
      platform: "Swiggy",
      dish: "Smoked Salmon Poke Bowl (x2)",
      posGrossInr: 1980,
      expectedPayoutInr: 1544,
      actualSettledInr: 654,
      leakageInr: 890,
      discrepancyType: "Delivered Order Missing from Weekly UTR Settlement Sheet",
      autoAction: "Queued Missing UTR Reconciliation Ticket #CLM-904",
    },
  ];

  const ingredientAlerts = [
    {
      ingredient: "Imported Hass Avocado (Vendor: FreshDirect)",
      prevWeekCostInr: 460,
      currWeekCostInr: 580,
      inflationPct: 26.1,
      impactedDish: "Avocado Burrata Sourdough",
      oldMarginPct: 64.5,
      newMarginPct: 53.0,
      targetMarginPct: 62.0,
      prescribedFix:
        "Re-portion avocado mash from 110g → 90g (+whipped ricotta base) or add ₹45 menu price adjustment to restore 63.2% margin.",
    },
    {
      ingredient: "Artisanal Malai Paneer Block (Vendor: DairyCraft)",
      prevWeekCostInr: 285,
      currWeekCostInr: 340,
      inflationPct: 19.3,
      impactedDish: "Chargrilled Paneer Tikka Bowl",
      oldMarginPct: 65.0,
      newMarginPct: 56.0,
      targetMarginPct: 62.0,
      prescribedFix:
        "Switch secondary supplier to FarmPure (₹295/kg) and cap aggregator promo discount at 10%.",
    },
    {
      ingredient: "Norwegian Atlantic Salmon Fillet",
      prevWeekCostInr: 1420,
      currWeekCostInr: 1740,
      inflationPct: 22.5,
      impactedDish: "Smoked Salmon Poke Bowl",
      oldMarginPct: 63.0,
      newMarginPct: 51.0,
      targetMarginPct: 62.0,
      prescribedFix:
        "Mark dish as 'Market Price Add-On (+₹80)' on Swiggy/Zomato to stop ₹118/order margin bleed.",
    },
  ];

  return {
    prepItems,
    aggregatorDisputes,
    ingredientAlerts,
    totalDailyWasteSavedInr: prepItems.reduce(
      (a, b) => a + b.dailySavingsInr,
      0
    ),
    totalWeeklyAggregatorRecoveryInr: aggregatorDisputes.reduce(
      (a, b) => a + b.leakageInr,
      0
    ),
  };
}

export function simulateProblem2DeadCapital(carryingCostRatePct: number) {
  const skus = [
    {
      sku: "SKU-202",
      name: "Merino Wool Knit Cardigan",
      category: "Apparel",
      units: 310,
      unitCostInr: 1200,
      sellingPriceInr: 3490,
      blockedCapitalInr: 372000,
      velocityDrop21dPct: 54.2,
      daysAged: 165,
      leadTimeDays: 28,
      daysOfInventoryLeft: 165,
      status: "DEAD CAPITAL (LIQUIDATE)" as const,
      graduatedPlan:
        "Week 1: 12% VIP Bundle → Week 2: 18% Tiered Markdown → Week 3: 24% Clearance (Saves ₹54,100 vs Flat 40% Off)",
      recommendedDiscountPct: 22,
      capitalFreedInr: 318000,
    },
    {
      sku: "SKU-206",
      name: "Suede Chelsea Boots",
      category: "Footwear",
      units: 260,
      unitCostInr: 1450,
      sellingPriceInr: 4290,
      blockedCapitalInr: 377000,
      velocityDrop21dPct: 44.8,
      daysAged: 136,
      leadTimeDays: 30,
      daysOfInventoryLeft: 136,
      status: "DEAD CAPITAL (LIQUIDATE)" as const,
      graduatedPlan:
        "Week 1: 10% Cross-Sell with Chinos → Week 2: 18% Markdown (Clears 210 units before monsoon storage depreciation)",
      recommendedDiscountPct: 18,
      capitalFreedInr: 325000,
    },
    {
      sku: "SKU-201",
      name: "Linen Oversized Resort Shirt",
      category: "Apparel",
      units: 420,
      unitCostInr: 850,
      sellingPriceInr: 2490,
      blockedCapitalInr: 357000,
      velocityDrop21dPct: 48.5,
      daysAged: 142,
      leadTimeDays: 21,
      daysOfInventoryLeft: 142,
      status: "DEAD CAPITAL (LIQUIDATE)" as const,
      graduatedPlan:
        "Graduated 15% 'Buy 2 Resort' Cart Tier (Preserves 58% gross margin vs 31% under flat clearance)",
      recommendedDiscountPct: 15,
      capitalFreedInr: 304000,
    },
    {
      sku: "SKU-203",
      name: "Signature Leather Crossbody",
      category: "Accessories",
      units: 28,
      unitCostInr: 1650,
      sellingPriceInr: 4990,
      blockedCapitalInr: 46200,
      velocityDrop21dPct: -18.4,
      daysAged: 7,
      leadTimeDays: 21,
      daysOfInventoryLeft: 7,
      status: "STOCKOUT ALERT (ANCHOR SKU)" as const,
      graduatedPlan:
        "0% Discount! Only 7 days of stock left vs 21-day supplier lead time. Issue Air-Express PO for 150 units today.",
      recommendedDiscountPct: 0,
      capitalFreedInr: 0,
    },
    {
      sku: "SKU-204",
      name: "Hydrating Hyaluronic Serum",
      category: "Beauty & Skincare",
      units: 35,
      unitCostInr: 320,
      sellingPriceInr: 1290,
      blockedCapitalInr: 11200,
      velocityDrop21dPct: -24.0,
      daysAged: 6,
      leadTimeDays: 18,
      daysOfInventoryLeft: 6,
      status: "STOCKOUT ALERT (ANCHOR SKU)" as const,
      graduatedPlan:
        "0% Discount! High-margin anchor (75% GM) will stock out in 6 days. Trigger urgent 300-unit restock batch.",
      recommendedDiscountPct: 0,
      capitalFreedInr: 0,
    },
  ].map((s) => ({
    ...s,
    monthlyCarryingFeeInr: Math.round(
      (s.blockedCapitalInr * (carryingCostRatePct / 100)) / 12
    ),
  }));

  const totalBlockedCapitalInr = skus
    .filter((s) => s.status === "DEAD CAPITAL (LIQUIDATE)")
    .reduce((a, b) => a + b.blockedCapitalInr, 0);
  const totalCapitalFreed30dInr = skus
    .filter((s) => s.status === "DEAD CAPITAL (LIQUIDATE)")
    .reduce((a, b) => a + b.capitalFreedInr, 0);

  return {
    skus,
    totalBlockedCapitalInr,
    totalCapitalFreed30dInr,
  };
}

export function simulateProblem3CashFlow(clientDelayDays: number) {
  const startingCashInr = 1450000;
  const monthlyPayrollAndRentInr = 980000;

  const arInvoices = [
    {
      invoiceId: "INV-2026-91",
      clientName: "Vertex Infrastructure Ltd",
      amountInr: 620000,
      avgHistoricalDelayDays: 52,
      delinquencyRiskPct: 92.5,
      status: "CRITICAL 45+ DAY DELAY RISK",
      chasingSequence:
        "Day -7: Automated CFO Ledger Alert → Day 0: Pause Phase-3 Deliverable → Offer 1.5% Early ACH Settlement",
    },
    {
      invoiceId: "INV-2026-88",
      clientName: "Apex Retail Group",
      amountInr: 480000,
      avgHistoricalDelayDays: 46,
      delinquencyRiskPct: 88.0,
      status: "CRITICAL 45+ DAY DELAY RISK",
      chasingSequence:
        "Switch from 45-day Net Invoice to 50% Upfront Milestone + Automated WhatsApp/Email Dunning",
    },
    {
      invoiceId: "INV-2026-95",
      clientName: "Nordic Logistics AS",
      amountInr: 410000,
      avgHistoricalDelayDays: 38,
      delinquencyRiskPct: 79.0,
      status: "ELEVATED 30-DAY DELAY RISK",
      chasingSequence:
        "Pre-Due Verification Call 5 days before 1st of month to confirm AP batch inclusion",
    },
  ];

  const saasLeaks = [
    {
      vendor: "AWS Staging & Orphaned RDS Snapshots",
      monthlySpendInr: 195000,
      leakType: "9 Unattached Dev RDS Instances + Silent +31% Usage Creep",
      monthlySavingsInr: 60000,
      annualSavingsInr: 720000,
      action: "Terminate orphaned dev instances & enable scheduled night shutdown",
    },
    {
      vendor: "Salesforce CRM Enterprise",
      monthlySpendInr: 145000,
      leakType: "14 Zombie Seats (Former Employees) + +18.5% Renewal Hike",
      monthlySavingsInr: 58000,
      annualSavingsInr: 696000,
      action: "Deprovision 14 inactive ex-team licenses before Nov 1st auto-renewal",
    },
    {
      vendor: "Asana + Monday.com Duplicate Stack",
      monthlySpendInr: 54000,
      leakType: "Redundant Project Management Licenses Across Teams",
      monthlySavingsInr: 54000,
      annualSavingsInr: 648000,
      action: "Consolidate all 28 active users onto Asana; cancel Monday.com",
    },
    {
      vendor: "Figma Organization Tier",
      monthlySpendInr: 68000,
      leakType: "19 Occasional Viewers Billed as Full Paid Editors (+22% Creep)",
      monthlySavingsInr: 32000,
      annualSavingsInr: 384000,
      action: "Downgrade 19 non-designers to Free Viewer seats immediately",
    },
  ];

  const monthlySaasSavingsInr = saasLeaks.reduce(
    (a, b) => a + b.monthlySavingsInr,
    0
  );

  // Simulate 60-day cash trough based on clientDelayDays
  const delayedReceivablesInr =
    clientDelayDays >= 40 ? 1100000 : clientDelayDays >= 25 ? 620000 : 0;
  const projectedDay30CashWithoutAgent =
    startingCashInr -
    monthlyPayrollAndRentInr -
    462000 +
    (1510000 - delayedReceivablesInr);
  const projectedDay30CashWithAgent =
    projectedDay30CashWithoutAgent +
    monthlySaasSavingsInr +
    Math.round(delayedReceivablesInr * 0.65);

  return {
    arInvoices,
    saasLeaks,
    monthlySaasSavingsInr,
    annualSaasSavingsInr: monthlySaasSavingsInr * 12,
    projectedDay30CashWithoutAgent,
    projectedDay30CashWithAgent,
  };
}

export function simulateProblem4ClinicNoShows() {
  const appointments = [
    {
      bookingId: "APT-705",
      slotTime: "10:30 AM",
      patientName: "Kabir Malhotra",
      department: "Dental Prosthodontics",
      procedure: "Implant Consultation (90m)",
      leadTimeDays: 34,
      priorNoShows: 4,
      distanceKm: 22.0,
      slotValueInr: 9500,
      riskScorePct: 91.0,
      riskTier: "Tier 3 Critical Risk",
      escalationAction:
        "Call Patient Now + Activate Standby Double-Book with Waitlist #W-08",
      waitlistMatch: "Priya D. (1.8 km away · 96% Short-Notice Acceptance)",
    },
    {
      bookingId: "APT-701",
      slotTime: "11:45 AM",
      patientName: "Rohan Deshmukh",
      department: "Dental Prosthodontics",
      procedure: "Root Canal & Crown Prep (60m)",
      leadTimeDays: 28,
      priorNoShows: 3,
      distanceKm: 19.4,
      slotValueInr: 8500,
      riskScorePct: 86.0,
      riskTier: "Tier 3 Critical Risk",
      escalationAction:
        "Call Patient Now + Hold ₹1,000 Slot Deposit or Backfill #W-12",
      waitlistMatch: "Neha K. (2.1 km away · 94% Short-Notice Acceptance)",
    },
    {
      bookingId: "APT-709",
      slotTime: "02:15 PM",
      patientName: "Vikramaditya Rao",
      department: "Dental Prosthodontics",
      procedure: "3D Aligner Scan & Fitting (60m)",
      leadTimeDays: 31,
      priorNoShows: 3,
      distanceKm: 18.6,
      slotValueInr: 12500,
      riskScorePct: 84.0,
      riskTier: "Tier 3 Critical Risk",
      escalationAction:
        "Direct Front-Desk Call + Standby Overbook #W-03",
      waitlistMatch: "Ritu G. (2.4 km away · 93% Short-Notice Acceptance)",
    },
    {
      bookingId: "APT-702",
      slotTime: "04:00 PM",
      patientName: "Ananya Kulkarni",
      department: "Dermatology & Laser",
      procedure: "Fractional CO2 Laser (60m)",
      leadTimeDays: 24,
      priorNoShows: 2,
      distanceKm: 16.8,
      slotValueInr: 11200,
      riskScorePct: 78.5,
      riskTier: "Tier 3 Critical Risk",
      escalationAction:
        "Send WhatsApp Deposit Hold + Alert Standby #W-04",
      waitlistMatch: "Vikram S. (3.4 km away · 91% Short-Notice Acceptance)",
    },
    {
      bookingId: "APT-704",
      slotTime: "05:15 PM",
      patientName: "Meera Joshi",
      department: "Ophthalmology",
      procedure: "Retinal OCT Scan (45m)",
      leadTimeDays: 16,
      priorNoShows: 1,
      distanceKm: 11.5,
      slotValueInr: 4800,
      riskScorePct: 54.0,
      riskTier: "Tier 2 Elevated Risk",
      escalationAction:
        "Send 1-Tap WhatsApp Confirmation / Reschedule Prompt",
      waitlistMatch: "Arjun P. (4.0 km away · 85% Short-Notice Acceptance)",
    },
  ];

  const totalRevenueAtRiskInr = appointments.reduce(
    (a, b) => a + b.slotValueInr,
    0
  );
  const recoveredRevenueInr = Math.round(totalRevenueAtRiskInr * 0.82);

  return {
    appointments,
    totalRevenueAtRiskInr,
    recoveredRevenueInr,
  };
}
