/**
 * Rexor — Full-Spectrum Chameleon Theme & Custom Color Engine
 * Allows users and companies to customize the color of every UI layer
 * (Primary Accent, Secondary Accent, Headings, Body Text, Background Canvas,
 * Card Surfaces, and Borders/Glows) or pick from 18 Signature Themes.
 *
 * @author Rushi Chavan (rushichavan69@gmail.com)
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */

export interface RexorThemeConfig {
  id: string;
  name: string;
  badge: string;
  category:
    | "Dark Metallic & Cyber"
    | "Vibrant Neon & Multi-Color"
    | "Luxury & Executive"
    | "Crisp Daylight Boardroom";
  accentPrimary: string;
  accentSecondary: string;
  headingColor: string;
  bodyTextColor: string;
  bgMain: string;
  bgCard: string;
  bgElevated: string;
  borderColor: string;
}

const THEME_STORAGE_KEY = "rexor_custom_theme_config_v1";

export const REXOR_SIGNATURE_THEMES: RexorThemeConfig[] = [
  {
    id: "sapphire-cobalt",
    name: "Sapphire Cobalt Metallic",
    badge: "Default Shiny Dark Blue",
    category: "Dark Metallic & Cyber",
    accentPrimary: "#2563EB",
    accentSecondary: "#38BDF8",
    headingColor: "#60A5FA",
    bodyTextColor: "#BFDBFE",
    bgMain: "#050811",
    bgCard: "#0B1325",
    bgElevated: "#111D38",
    borderColor: "#1E3A8A",
  },
  {
    id: "emerald-matrix",
    name: "Emerald Cyber Matrix",
    badge: "Hyper Emerald & Obsidian",
    category: "Dark Metallic & Cyber",
    accentPrimary: "#10B981",
    accentSecondary: "#34D399",
    headingColor: "#6EE7B7",
    bodyTextColor: "#D1FAE5",
    bgMain: "#040D0A",
    bgCard: "#081C15",
    bgElevated: "#0F291E",
    borderColor: "#065F46",
  },
  {
    id: "amethyst-ultraviolet",
    name: "Royal Amethyst & Ultraviolet",
    badge: "Electric Violet & Cyber Plum",
    category: "Vibrant Neon & Multi-Color",
    accentPrimary: "#8B5CF6",
    accentSecondary: "#EC4899",
    headingColor: "#C4B5FD",
    bodyTextColor: "#EDE9FE",
    bgMain: "#090514",
    bgCard: "#130B29",
    bgElevated: "#1E123D",
    borderColor: "#5B21B6",
  },
  {
    id: "crimson-ferrari",
    name: "Crimson Velocity & Ruby Gold",
    badge: "Executive Crimson & Carbon",
    category: "Luxury & Executive",
    accentPrimary: "#E11D48",
    accentSecondary: "#FB923C",
    headingColor: "#FDA4AF",
    bodyTextColor: "#FFE4E6",
    bgMain: "#0F0507",
    bgCard: "#1F0A10",
    bgElevated: "#2E1018",
    borderColor: "#9F1239",
  },
  {
    id: "imperial-gold",
    name: "Imperial 24K Gold & Obsidian",
    badge: "Wall Street Luxury Gold",
    category: "Luxury & Executive",
    accentPrimary: "#D97706",
    accentSecondary: "#FBBF24",
    headingColor: "#FDE68A",
    bodyTextColor: "#FEF3C7",
    bgMain: "#0C0904",
    bgCard: "#1A1408",
    bgElevated: "#261E0C",
    borderColor: "#92400E",
  },
  {
    id: "cyan-tron",
    name: "Cyan Tron & Electric Aqua",
    badge: "Futuristic Sci-Fi Cyan",
    category: "Dark Metallic & Cyber",
    accentPrimary: "#0891B2",
    accentSecondary: "#22D3EE",
    headingColor: "#67E8F9",
    bodyTextColor: "#CFFAFE",
    bgMain: "#030B10",
    bgCard: "#071824",
    bgElevated: "#0C2536",
    borderColor: "#155E75",
  },
  {
    id: "sunset-magenta",
    name: "Sunset Coral & Magenta Pulse",
    badge: "Synthwave Rose & Coral",
    category: "Vibrant Neon & Multi-Color",
    accentPrimary: "#DB2777",
    accentSecondary: "#F97316",
    headingColor: "#F472B6",
    bodyTextColor: "#FCE7F3",
    bgMain: "#0F050D",
    bgCard: "#210B1C",
    bgElevated: "#30112A",
    borderColor: "#9D174D",
  },
  {
    id: "bloomberg-terminal",
    name: "Bloomberg Terminal Amber",
    badge: "Quantitative Trading Desk",
    category: "Luxury & Executive",
    accentPrimary: "#EA580C",
    accentSecondary: "#F59E0B",
    headingColor: "#FDBA74",
    bodyTextColor: "#FFEDD5",
    bgMain: "#080604",
    bgCard: "#140E08",
    bgElevated: "#21170D",
    borderColor: "#9A3412",
  },
  {
    id: "lime-volt",
    name: "Lime Volt & Stealth Carbon",
    badge: "High-Voltage Neon Lime",
    category: "Vibrant Neon & Multi-Color",
    accentPrimary: "#65A30D",
    accentSecondary: "#A3E635",
    headingColor: "#BEF264",
    bodyTextColor: "#ECFCCB",
    bgMain: "#070B04",
    bgCard: "#111A08",
    bgElevated: "#1A290D",
    borderColor: "#3F6212",
  },
  {
    id: "tiffany-mint",
    name: "Tiffany Mint & Arctic Teal",
    badge: "Cool Mint & Deep Lagoon",
    category: "Dark Metallic & Cyber",
    accentPrimary: "#0D9488",
    accentSecondary: "#2DD4BF",
    headingColor: "#5EEAD4",
    bodyTextColor: "#CCFBF1",
    bgMain: "#040D0C",
    bgCard: "#081C1B",
    bgElevated: "#0F2928",
    borderColor: "#115E59",
  },
  {
    id: "indigo-starlight",
    name: "Indigo Starlight & Periwinkle",
    badge: "Deep Space Indigo",
    category: "Dark Metallic & Cyber",
    accentPrimary: "#4F46E5",
    accentSecondary: "#818CF8",
    headingColor: "#A5B4FC",
    bodyTextColor: "#E0E7FF",
    bgMain: "#060614",
    bgCard: "#0E0F29",
    bgElevated: "#16183D",
    borderColor: "#3730A3",
  },
  {
    id: "copper-espresso",
    name: "Warm Copper & Roast Espresso",
    badge: "Hospitality & Bistro Signature",
    category: "Luxury & Executive",
    accentPrimary: "#C2410C",
    accentSecondary: "#FB923C",
    headingColor: "#FDBA74",
    bodyTextColor: "#FFEDD5",
    bgMain: "#0C0705",
    bgCard: "#1C100B",
    bgElevated: "#291811",
    borderColor: "#7C2D12",
  },
  {
    id: "chameleon-aurora",
    name: "Chameleon Aurora Borealis",
    badge: "Multi-Color Electric Fusion",
    category: "Vibrant Neon & Multi-Color",
    accentPrimary: "#7C3AED",
    accentSecondary: "#06B6D4",
    headingColor: "#38BDF8",
    bodyTextColor: "#E0F2FE",
    bgMain: "#060814",
    bgCard: "#0F1429",
    bgElevated: "#171F3D",
    borderColor: "#4F46E5",
  },
  {
    id: "neon-cyberpunk",
    name: "Cyberpunk 2099 Yellow & Cyan",
    badge: "High-Contrast Dual Neon",
    category: "Vibrant Neon & Multi-Color",
    accentPrimary: "#0284C7",
    accentSecondary: "#EAB308",
    headingColor: "#FACC15",
    bodyTextColor: "#E0F2FE",
    bgMain: "#070913",
    bgCard: "#101529",
    bgElevated: "#18203D",
    borderColor: "#0369A1",
  },
  {
    id: "daylight-royal",
    name: "Daylight Boardroom — Royal Blue",
    badge: "Crisp White & Royal Blue",
    category: "Crisp Daylight Boardroom",
    accentPrimary: "#2563EB",
    accentSecondary: "#0284C7",
    headingColor: "#0F172A",
    bodyTextColor: "#334155",
    bgMain: "#F1F5F9",
    bgCard: "#FFFFFF",
    bgElevated: "#F8FAFC",
    borderColor: "#CBD5E1",
  },
  {
    id: "daylight-emerald",
    name: "Daylight Boardroom — Forest Emerald",
    badge: "Crisp White & CFO Emerald",
    category: "Crisp Daylight Boardroom",
    accentPrimary: "#059669",
    accentSecondary: "#0D9488",
    headingColor: "#064E3B",
    bodyTextColor: "#1E293B",
    bgMain: "#ECFDF5",
    bgCard: "#FFFFFF",
    bgElevated: "#F0FDF4",
    borderColor: "#A7F3D0",
  },
  {
    id: "daylight-amethyst",
    name: "Daylight Boardroom — Iris Purple",
    badge: "Crisp White & SaaS Violet",
    category: "Crisp Daylight Boardroom",
    accentPrimary: "#7C3AED",
    accentSecondary: "#DB2777",
    headingColor: "#1E1B4B",
    bodyTextColor: "#334155",
    bgMain: "#F5F3FF",
    bgCard: "#FFFFFF",
    bgElevated: "#FAF5FF",
    borderColor: "#DDD6FE",
  },
  {
    id: "daylight-crimson",
    name: "Daylight Boardroom — Executive Ruby",
    badge: "Crisp White & Crimson",
    category: "Crisp Daylight Boardroom",
    accentPrimary: "#E11D48",
    accentSecondary: "#D97706",
    headingColor: "#4C0519",
    bodyTextColor: "#334155",
    bgMain: "#FFF1F2",
    bgCard: "#FFFFFF",
    bgElevated: "#FFF5F5",
    borderColor: "#FECDD3",
  },
];

export function loadSavedThemeConfig(): RexorThemeConfig {
  try {
    const raw = localStorage.getItem(THEME_STORAGE_KEY);
    if (!raw) return REXOR_SIGNATURE_THEMES[0];
    const parsed = JSON.parse(raw);
    if (parsed && parsed.accentPrimary && parsed.bgMain) {
      return parsed;
    }
    return REXOR_SIGNATURE_THEMES[0];
  } catch {
    return REXOR_SIGNATURE_THEMES[0];
  }
}

export function saveThemeConfig(theme: RexorThemeConfig): void {
  try {
    localStorage.setItem(THEME_STORAGE_KEY, JSON.stringify(theme));
  } catch {
    // Ignore storage quota errors
  }
}

export function applyThemeToDocument(theme: RexorThemeConfig): void {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.style.setProperty("--rexor-accent", theme.accentPrimary);
  root.style.setProperty("--rexor-accent-secondary", theme.accentSecondary);
  root.style.setProperty("--rexor-heading", theme.headingColor);
  root.style.setProperty("--rexor-body-text", theme.bodyTextColor);
  root.style.setProperty("--rexor-bg-main", theme.bgMain);
  root.style.setProperty("--rexor-bg-card", theme.bgCard);
  root.style.setProperty("--rexor-bg-elevated", theme.bgElevated);
  root.style.setProperty("--rexor-border", theme.borderColor);
}

export function generateRandomCoolTheme(): RexorThemeConfig {
  const palettes: Array<Omit<RexorThemeConfig, "id" | "name" | "badge" | "category">> = [
    {
      accentPrimary: "#FF2E93",
      accentSecondary: "#00F0FF",
      headingColor: "#00F0FF",
      bodyTextColor: "#FCE7F3",
      bgMain: "#080411",
      bgCard: "#140926",
      bgElevated: "#1F1038",
      borderColor: "#9D174D",
    },
    {
      accentPrimary: "#00E5A3",
      accentSecondary: "#6366F1",
      headingColor: "#5EEAD4",
      bodyTextColor: "#E0E7FF",
      bgMain: "#040B14",
      bgCard: "#0A1829",
      bgElevated: "#11243D",
      borderColor: "#0D9488",
    },
    {
      accentPrimary: "#F97316",
      accentSecondary: "#A855F7",
      headingColor: "#FDBA74",
      bodyTextColor: "#F3E8FF",
      bgMain: "#0E0612",
      bgCard: "#1C0D24",
      bgElevated: "#291436",
      borderColor: "#7E22CE",
    },
    {
      accentPrimary: "#3B82F6",
      accentSecondary: "#10B981",
      headingColor: "#6EE7B7",
      bodyTextColor: "#DBEAFE",
      bgMain: "#040A12",
      bgCard: "#0A1626",
      bgElevated: "#102238",
      borderColor: "#1D4ED8",
    },
  ];
  const pick = palettes[Math.floor(Math.random() * palettes.length)];
  return {
    id: `custom-ai-${Date.now()}`,
    name: "AI Generated Spectrum Mix",
    badge: "Custom Freestyle Palette",
    category: "Vibrant Neon & Multi-Color",
    ...pick,
  };
}
