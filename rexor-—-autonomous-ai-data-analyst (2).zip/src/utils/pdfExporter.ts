/**
 * Rexor — Direct Multi-Page Vector PDF Executive Report & Board Deck Exporter
 * Uses jsPDF to generate and download a real .pdf file directly in the browser
 * (working reliably inside sandboxed preview iframes where window.print() is blocked).
 *
 * @author Rushi Chavan
 * @license Copyright (c) 2026 Rushi Chavan. All Rights Reserved.
 */
import { jsPDF } from "jspdf";
import {
  CleaningSummary,
  ColumnProfile,
  CorrelationPair,
  RexorLifecycleReport,
} from "../types/rexor";

interface ExportExecutivePdfParams {
  datasetName: string;
  domainContext: string;
  businessQuestion: string;
  cleaningSummary: CleaningSummary;
  columnProfiles: ColumnProfile[];
  correlations: CorrelationPair[];
  activeReport: RexorLifecycleReport;
}

export function downloadExecutiveBoardDeckPdf({
  datasetName,
  domainContext,
  businessQuestion,
  cleaningSummary,
  columnProfiles,
  correlations,
  activeReport,
}: ExportExecutivePdfParams): void {
  const doc = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 14;
  const contentWidth = pageWidth - margin * 2;
  let y = 16;

  const ensureSpace = (neededMm: number) => {
    if (y + neededMm > pageHeight - 18) {
      drawFooter();
      doc.addPage();
      y = 18;
    }
  };

  const drawFooter = () => {
    const pageNum = doc.getNumberOfPages();
    doc.setDrawColor(43, 52, 65);
    doc.line(margin, pageHeight - 12, pageWidth - margin, pageHeight - 12);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(110, 125, 145);
    doc.text(
      "Rexor Autonomous AI Data Analyst Suite | Created & Licensed to Rushi Chavan (Copyright (c) 2026 Rushi Chavan)",
      margin,
      pageHeight - 7.5
    );
    doc.text(`Page ${pageNum}`, pageWidth - margin - 14, pageHeight - 7.5);
  };

  // =========================================================================
  // HEADER BANNER (Metallic Black + Neon Green Accent)
  // =========================================================================
  doc.setFillColor(11, 14, 19);
  doc.roundedRect(margin, y, contentWidth, 32, 3, 3, "F");

  doc.setFont("courier", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(57, 255, 20);
  doc.text(
    "REXOR EXECUTIVE BOARD BRIEFING  |  LICENSED TO RUSHI CHAVAN",
    margin + 5,
    y + 7.5
  );

  doc.setFont("helvetica", "bold");
  doc.setFontSize(13);
  doc.setTextColor(255, 255, 255);
  const headlineLines = doc.splitTextToSize(
    activeReport.stage5VisualNarrative.dashboardHeadline ||
      `Executive Analytics Report: ${datasetName}`,
    contentWidth - 10
  );
  doc.text(headlineLines.slice(0, 2), margin + 5, y + 15);

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(180, 194, 208);
  doc.text(
    `Dataset: ${datasetName} (${cleaningSummary.cleanedRowCount} verified rows)  |  Domain: ${domainContext}  |  Date: ${
      new Date().toISOString().split("T")[0]
    }`,
    margin + 5,
    y + 27.5
  );

  y += 38;

  // =========================================================================
  // 4-CARD KPI TELEMETRY STRIP
  // =========================================================================
  const cardGap = 3;
  const cardWidth = (contentWidth - cardGap * 3) / 4;
  const kpiCards = [
    {
      label: "STAGE 2: VERIFIED ROWS",
      val: `${cleaningSummary.rawRowCount} -> ${cleaningSummary.cleanedRowCount}`,
      sub: `${columnProfiles.length} profiled columns`,
    },
    {
      label: "STAGE 3: DATA HEALTH",
      val: `${cleaningSummary.dataHealthBefore}% -> ${cleaningSummary.dataHealthAfter}%`,
      sub: `${cleaningSummary.logs.length} cells auto-repaired`,
    },
    {
      label: "STAGE 4: TOP CORRELATION",
      val: correlations[0] ? `r = ${correlations[0].r}` : "N/A",
      sub: correlations[0]
        ? `${correlations[0].colA} vs ${correlations[0].colB}`
        : "Numeric driver",
    },
    {
      label: "STAGE 6: NORTH STAR KPI",
      val: (
        activeReport.stage1ProblemFraming.primaryObjectiveMetric || "Primary KPI"
      ).slice(0, 18),
      sub: `${activeReport.stage6ActionPlan.recommendations.length} Action Playbooks`,
    },
  ];

  kpiCards.forEach((card, idx) => {
    const cx = margin + idx * (cardWidth + cardGap);
    doc.setFillColor(18, 23, 30);
    doc.setDrawColor(43, 52, 65);
    doc.roundedRect(cx, y, cardWidth, 20, 2, 2, "FD");

    doc.setFont("courier", "bold");
    doc.setFontSize(6.5);
    doc.setTextColor(142, 155, 174);
    doc.text(card.label, cx + 3, y + 5.5);

    doc.setFont("courier", "bold");
    doc.setFontSize(9.5);
    doc.setTextColor(57, 255, 20);
    doc.text(card.val, cx + 3, y + 12);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(7);
    doc.setTextColor(212, 220, 230);
    doc.text(card.sub.slice(0, 24), cx + 3, y + 17.2);
  });

  y += 26;

  // =========================================================================
  // STAGE 1: BUSINESS PROBLEM FRAMING & TESTED HYPOTHESES
  // =========================================================================
  ensureSpace(45);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10.5);
  doc.setTextColor(18, 23, 30);
  doc.text("1. STAGE 01: BUSINESS PROBLEM & EMPIRICAL HYPOTHESES", margin, y);
  y += 4.5;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(60, 70, 85);
  const qLines = doc.splitTextToSize(
    `Refined Question: ${
      activeReport.stage1ProblemFraming.refinedQuestion || businessQuestion
    }`,
    contentWidth
  );
  doc.text(qLines, margin, y);
  y += qLines.length * 4 + 2;

  activeReport.stage1ProblemFraming.hypotheses.forEach((h) => {
    ensureSpace(16);
    doc.setFillColor(245, 247, 250);
    doc.setDrawColor(210, 218, 226);
    const stmtLines = doc.splitTextToSize(
      `[${h.id} - ${h.validationStatus}] ${h.statement} (Evidence: ${h.evidenceMetric})`,
      contentWidth - 6
    );
    const boxH = stmtLines.length * 4 + 4;
    doc.roundedRect(margin, y, contentWidth, boxH, 1.5, 1.5, "FD");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(8);
    doc.setTextColor(20, 30, 45);
    doc.text(stmtLines, margin + 3, y + 4.5);
    y += boxH + 2.5;
  });

  y += 3;

  // =========================================================================
  // STAGE 3: DATA CLEANING & REMEDIATION AUDIT
  // =========================================================================
  ensureSpace(26);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10.5);
  doc.setTextColor(18, 23, 30);
  doc.text("2. STAGE 03: AUTOMATED DATA HYGIENE & REMEDIATION SUMMARY", margin, y);
  y += 5;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(50, 60, 75);
  const cleanSummaryText = `Duplicates Removed: ${cleaningSummary.duplicatesRemoved}  |  Missing Values Imputed: ${cleaningSummary.missingValuesImputed}  |  Formats Normalized: ${cleaningSummary.formatsNormalized}  |  Outliers Capped: ${cleaningSummary.outliersAdjusted}`;
  doc.text(cleanSummaryText, margin, y);
  y += 4.5;

  const riskLines = doc.splitTextToSize(
    activeReport.stage3CleaningAssessment.structuralRisksResolved,
    contentWidth
  );
  doc.text(riskLines, margin, y);
  y += riskLines.length * 4 + 4;

  // =========================================================================
  // STAGE 4: KEY STATISTICAL FINDINGS & CORRELATIONS
  // =========================================================================
  ensureSpace(40);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10.5);
  doc.setTextColor(18, 23, 30);
  doc.text("3. STAGE 04: QUANTIFIED STATISTICAL & ANALYTICAL FINDINGS", margin, y);
  y += 5;

  doc.setFont("helvetica", "normal");
  doc.setFontSize(8.5);
  doc.setTextColor(50, 60, 75);
  const execLines = doc.splitTextToSize(
    activeReport.stage4AnalyticalFindings.executiveSummary,
    contentWidth
  );
  doc.text(execLines, margin, y);
  y += execLines.length * 4 + 3;

  activeReport.stage4AnalyticalFindings.keyInsights.forEach((ins) => {
    ensureSpace(18);
    const insLines = doc.splitTextToSize(
      `• ${ins.title} (${ins.category}): ${ins.quantifiedFinding} -> ${ins.businessImplication}`,
      contentWidth - 4
    );
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.2);
    doc.setTextColor(25, 35, 50);
    doc.text(insLines, margin + 2, y);
    y += insLines.length * 4 + 2;
  });

  y += 3;

  // =========================================================================
  // STAGE 6: PRIORITIZED EXECUTIVE ACTION ROADMAP (P0 / P1 / P2)
  // =========================================================================
  ensureSpace(45);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10.5);
  doc.setTextColor(18, 23, 30);
  doc.text(
    "4. STAGE 06: PRIORITIZED ACTION PLAYBOOK & KPI GOVERNANCE",
    margin,
    y
  );
  y += 5;

  activeReport.stage6ActionPlan.recommendations.forEach((rec) => {
    ensureSpace(22);
    doc.setFillColor(18, 23, 30);
    doc.setDrawColor(43, 52, 65);
    const mechLines = doc.splitTextToSize(
      `Mechanism: ${rec.concreteMechanism}  |  Target: ${rec.targetSegmentOrVariable}  |  KPI: ${rec.measurementKpi}`,
      contentWidth - 8
    );
    const cardH = mechLines.length * 4 + 11;
    doc.roundedRect(margin, y, contentWidth, cardH, 2, 2, "FD");

    doc.setFont("courier", "bold");
    doc.setFontSize(8.5);
    doc.setTextColor(57, 255, 20);
    doc.text(
      `[${rec.priority}] ${rec.actionTitle}  —  Expected Impact: ${rec.quantifiedExpectedImpact}`,
      margin + 4,
      y + 5.5
    );

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(212, 220, 230);
    doc.text(mechLines, margin + 4, y + 10.5);

    y += cardH + 3;
  });

  drawFooter();

  const cleanSlug = datasetName
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_|_$/g, "");
  doc.save(`${cleanSlug || "rexor"}_executive_board_deck.pdf`);
}
