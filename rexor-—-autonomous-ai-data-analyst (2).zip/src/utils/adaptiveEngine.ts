import { ColumnProfile, CorrelationPair, DataRow } from "../types/rexor";

export type AdaptiveRuleType =
  | "FILTER_KEEP"
  | "FILTER_EXCLUDE"
  | "CAP_MAX"
  | "FLOOR_MIN"
  | "DERIVE_FORMULA"
  | "CONDITIONAL_FLAG"
  | "CONDITIONAL_DISCOUNT_AUDIT"
  | "CANONICALIZE_TEXT"
  | "COHORT_MEAN_IMPUTE"
  | "TEXT_REPLACE"
  | "ADJUST_IN_PLACE"
  | "DROP_COLUMN";

export interface AdaptiveUserRequirement {
  id: string;
  title: string;
  rawInstruction: string;
  ruleType: AdaptiveRuleType;
  targetColumn: string;
  secondaryColumn?: string;
  operator?: "==" | "!=" | ">" | ">=" | "<" | "<=" | "CONTAINS";
  compareValue?: string | number;
  replaceWithValue?: string | number;
  numericParameter?: number;
  formulaExpression?:
    | "SUB"
    | "ADD"
    | "MUL"
    | "DIV"
    | "PCT_MARGIN"
    | "SCALE_FACTOR"
    | "PCT_CHANGE";
  outputColumnName?: string;
  flagLabelTrue?: string;
  flagLabelFalse?: string;
  pythonEquivalent: string;
  sqlEquivalent: string;
  enabled: boolean;
  createdAt: string;
  sourceAuthor: string;
}

export interface EcosystemAnalystKnowledge {
  id: string;
  analystName: string;
  analystRole: string;
  domain: string;
  experienceYears: number;
  title: string;
  problemPattern: string;
  expertHeuristic: string;
  statisticalRationale: string;
  executablePrompt: string;
  pythonTemplate: string;
  upvotes: number;
  verifiedParity: boolean;
  createdAt: string;
  isUserContributed?: boolean;
}

export interface CellDiffRecord {
  rowNumber: number;
  column: string;
  beforeValue: string;
  afterValue: string;
  ruleTitle: string;
}

export interface RuleExecutionSummary {
  transformedRows: DataRow[];
  totalRowsBefore: number;
  totalRowsAfter: number;
  totalCellsModified: number;
  newColumnsCreated: string[];
  cellDiffs: CellDiffRecord[];
  perRuleImpact: Record<
    string,
    {
      rowsAffected: number;
      description: string;
    }
  >;
}

const STORAGE_KEY_REQUIREMENTS = "rexor_adaptive_user_requirements_v1";
const STORAGE_KEY_KNOWLEDGE = "rexor_ecosystem_analyst_knowledge_v1";

export const INITIAL_ECOSYSTEM_ANALYST_KNOWLEDGE: EcosystemAnalystKnowledge[] = [
  {
    id: "eco-pos-bistro-audit",
    analystName: "Rushi Chavan",
    analystRole: "Creator & Principal Autonomous Analytics Architect",
    domain: "Hospitality POS & Unit Economics",
    experienceYears: 12,
    title: "POS Composite Deduplication, Unpaid Isolation & Time-Window Promo Audit",
    problemPattern:
      "POS terminal retries create duplicate rows with different auto-incremented Order_IDs, while unpaid/refunded orders and after-hours promo codes (MORNING10 >= 11:00 AM) distort Net Revenue.",
    expertHeuristic:
      "Always deduplicate on [Timestamp_Clean, Outlet_Zone, Server_ID, Item_Name, Pax, Qty] ignoring Order_ID, isolate Payment_Status == 'Paid' before revenue aggregation, Winsorize Prep_Time_Mins at Q3 + 1.5*IQR, and audit MORNING10 applied at or after 11:00 AM.",
    statisticalRationale:
      "Prevents double-counting POS retry logs, eliminates cancelled-order revenue inflation, and protects OLS correlation (Prep_Time vs Rating) from single-ticket 145-min kitchen timer bugs.",
    executablePrompt:
      "Audit unauthorized MORNING10 discounts applied at or after 11:00 AM and isolate Paid orders with Qty > 0",
    pythonTemplate: `df_dedup = df.drop_duplicates(subset=["Timestamp_Clean", "Outlet_Zone", "Server_ID", "Item_Name", "Pax", "Qty"])
df_valid = df_dedup[(df_dedup["Payment_Status"] == "Paid") & (df_dedup["Qty"] > 0)].copy()
df_valid["Unauthorized_Discount_INR"] = np.where((df_valid["Discount_Code"] == "MORNING10") & (df_valid["Order_Hour"] >= 11), df_valid["Discount_Amount_INR"], 0.0)`,
    upvotes: 148,
    verifiedParity: true,
    createdAt: "2026-10-20",
  },
  {
    id: "eco-stat-bessel-null",
    analystName: "Dr. Priya Nair",
    analystRole: "Chief Statistical Methodology Advisor",
    domain: "Biostatistics & Econometric Rigor",
    experienceYears: 15,
    title: "Cohort-Preserving Group Mean Imputation & Tautology-Free Driver Ranking",
    problemPattern:
      "Global median imputation distorts subgroup averages (e.g., Outlet_Zone Mean_Rating), while correlating Gross_Revenue with Net_Revenue produces trivial r = 0.99 accounting tautologies.",
    expertHeuristic:
      "Impute missing ratings using the exact subgroup mean of the record's primary cohort (df.groupby(cohort)[col].transform('mean')) so cohort means suffer 0.00% distortion, and exclude accounting identities when ranking operational drivers.",
    statisticalRationale:
      "Preserves exact conditional expectations E[Y | Cohort] matching pandas groupby(.mean()) while surfacing true operational cause-and-effect drivers #1.",
    executablePrompt:
      "Impute missing numeric ratings using cohort group mean so segment averages have 0% distortion",
    pythonTemplate: `df["Customer_Rating"] = df["Customer_Rating"].fillna(df.groupby("Outlet_Zone")["Customer_Rating"].transform("mean"))`,
    upvotes: 132,
    verifiedParity: true,
    createdAt: "2026-10-18",
  },
  {
    id: "eco-saas-churn-guardrail",
    analystName: "Elena Rostova",
    analystRole: "Staff SaaS RevOps & Retention Scientist",
    domain: "B2B SaaS & Subscription Analytics",
    experienceYears: 14,
    title: "Support Ticket Friction & SLA Escalation Risk Flagging",
    problemPattern:
      "B2B churn spikes non-linearly once support ticket volume or kitchen/service wait time crosses the 75th percentile threshold.",
    expertHeuristic:
      "Flag any record where support tickets, prep time, or churn risk exceeds the upper quartile threshold so operations teams can intervene before customer defection.",
    statisticalRationale:
      "Segmented hazard analysis shows 3.2x higher churn velocity in the top quartile of operational friction.",
    executablePrompt:
      "Flag records where Prep_Time_Mins > 25 or support_tickets > 6 as High_Operational_Risk",
    pythonTemplate: `df["Operational_Risk_Flag"] = np.where(df[friction_col] > threshold, "High_Risk_Intervention", "Normal_SLA")`,
    upvotes: 96,
    verifiedParity: true,
    createdAt: "2026-10-15",
  },
  {
    id: "eco-fintech-unit-econ",
    analystName: "Vikram Mehta",
    analystRole: "Principal FinTech & Unit Economics Strategist",
    domain: "Financial Audit & Margin Optimization",
    experienceYears: 11,
    title: "Net Contribution Margin & Post-Tax Profit Engineering",
    problemPattern:
      "Teams optimize top-line Gross Revenue while ignoring promo discount leakage, COGS, and variable tax/gateway overhead.",
    expertHeuristic:
      "Always engineer a net contribution or post-overhead profit column (82% of Gross Profit or Net Revenue minus COGS) to rank cohorts by true bottom-line cash generation.",
    statisticalRationale:
      "Top-line volume leaders frequently rank in the bottom tercile of net contribution margin when promo leakage exceeds 12%.",
    executablePrompt:
      "Create derived column Net_Contribution_INR = Gross_Profit_INR * 0.85",
    pythonTemplate: `df["Net_Contribution_INR"] = (df["Gross_Profit_INR"] * 0.85).round(2)`,
    upvotes: 89,
    verifiedParity: true,
    createdAt: "2026-10-12",
  },
];

export function loadSavedUserRequirements(): AdaptiveUserRequirement[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_REQUIREMENTS);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveUserRequirements(reqs: AdaptiveUserRequirement[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_REQUIREMENTS, JSON.stringify(reqs));
  } catch {
    // ignore storage quota errors
  }
}

export function loadEcosystemKnowledge(): EcosystemAnalystKnowledge[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY_KNOWLEDGE);
    if (!raw) return INITIAL_ECOSYSTEM_ANALYST_KNOWLEDGE;
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return INITIAL_ECOSYSTEM_ANALYST_KNOWLEDGE;
  } catch {
    return INITIAL_ECOSYSTEM_ANALYST_KNOWLEDGE;
  }
}

export function saveEcosystemKnowledge(items: EcosystemAnalystKnowledge[]): void {
  try {
    localStorage.setItem(STORAGE_KEY_KNOWLEDGE, JSON.stringify(items));
  } catch {
    // ignore storage quota errors
  }
}

function toFiniteNum(val: unknown): number | null {
  if (val === null || val === undefined || val === "") return null;
  if (typeof val === "number") return Number.isFinite(val) ? val : null;
  const cleaned = String(val)
    .trim()
    .replace(/^[₹$€£¥]\s*/, "")
    .replace(/,/g, "")
    .replace(/%$/, "");
  if (!cleaned) return null;
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

/**
 * Fuzzy column matcher: matches exact column names, space-separated human names
 * (e.g. "prep time" -> "Prep_Time_Mins"), or partial tokens ("revenue" -> "Net_Revenue_INR").
 */
function findMatchingColumns(
  instruction: string,
  columnProfiles: ColumnProfile[]
): string[] {
  const lower = instruction.toLowerCase();
  const normalizedInstruction = lower.replace(/[_-]+/g, " ");
  const allCols = columnProfiles.map((c) => c.name);
  const scored: Array<{ col: string; score: number }> = [];

  for (const col of allCols) {
    const colLower = col.toLowerCase();
    const colSpaced = colLower.replace(/[_-]+/g, " ");
    const tokens = colSpaced
      .split(/\s+/)
      .filter((t) => t.length >= 3 && !["inr", "usd", "mins", "pct", "num", "col"].includes(t));

    if (lower.includes(colLower) || normalizedInstruction.includes(colSpaced)) {
      scored.push({ col, score: 100 + col.length });
      continue;
    }

    let matchedTokens = 0;
    for (const tk of tokens) {
      if (normalizedInstruction.includes(tk)) {
        matchedTokens++;
      }
    }
    if (matchedTokens > 0) {
      scored.push({ col, score: matchedTokens * 25 + tokens.length });
    }
  }

  return scored.sort((a, b) => b.score - a.score).map((s) => s.col);
}

/**
 * Checks if the user instruction mentions a specific category value present in columnProfiles
 * (e.g. "Bandra West", "Refunded", "Pending", "Cyber Hub").
 */
function findMentionedCategoryValue(
  instruction: string,
  columnProfiles: ColumnProfile[]
): { column: string; value: string } | null {
  const lower = instruction.toLowerCase();
  for (const prof of columnProfiles) {
    const candidates = [
      ...(prof.topCategories?.map((tc) => tc.value) || []),
      ...(prof.sampleValues || []),
    ];
    for (const val of candidates) {
      const cleanVal = String(val || "").trim();
      if (cleanVal.length >= 2 && lower.includes(cleanVal.toLowerCase())) {
        return { column: prof.name, value: cleanVal };
      }
    }
  }
  return null;
}

/**
 * Deterministic Natural-Language Requirement Compiler:
 * Translates any plain-English user instruction into an executable AdaptiveUserRequirement
 * bound to the actual columns and values of the active dataset.
 */
export function compileUserRequirementToRule(
  instruction: string,
  columnProfiles: ColumnProfile[],
  authorName: string = "User Requirement"
): AdaptiveUserRequirement {
  const cleanText = instruction.trim();
  const lower = cleanText.toLowerCase();
  const allCols = columnProfiles.map((c) => c.name);
  const numCols = columnProfiles
    .filter((c) => c.type === "numeric")
    .map((c) => c.name);
  const catCols = columnProfiles
    .filter((c) => c.type !== "numeric")
    .map((c) => c.name);

  const mentionedCols = findMatchingColumns(cleanText, columnProfiles);
  const mentionedCat = findMentionedCategoryValue(cleanText, columnProfiles);

  const primaryCol =
    mentionedCols[0] ||
    mentionedCat?.column ||
    numCols.find((c) => /prep|price|revenue|profit|rating|qty|score/i.test(c)) ||
    numCols[0] ||
    allCols[0] ||
    "Value";

  const secondaryCol =
    mentionedCols[1] ||
    numCols.find((c) => c !== primaryCol) ||
    catCols[0] ||
    primaryCol;

  // Extract numbers in instruction if present
  const numMatch = cleanText.match(/[+-]?\d+(\.\d+)?/);
  const extractedNum = numMatch ? Number(numMatch[0]) : undefined;

  // 0A. Check for Replace / Change value A to B ("replace Pending with Paid", "change Bandra to Andheri")
  const replaceMatch = cleanText.match(
    /(?:replace|change|swap|convert|set)\s+['"]?([^'"]+?)['"]?\s+(?:to|with|into|as)\s+['"]?([^'"]+?)['"]?(?:\s+in\s+([a-zA-Z0-9_ ]+))?$/i
  );
  if (replaceMatch && !lower.includes("increase") && !lower.includes("decrease")) {
    const rawFrom = replaceMatch[1].trim();
    const rawTo = replaceMatch[2].trim();
    const targetCol =
      mentionedCols[0] ||
      mentionedCat?.column ||
      catCols[0] ||
      primaryCol;
    return {
      id: `req-${Date.now()}`,
      title: `Replace "${rawFrom}" → "${rawTo}" in ${targetCol}`,
      rawInstruction: cleanText,
      ruleType: "TEXT_REPLACE",
      targetColumn: targetCol,
      compareValue: rawFrom,
      replaceWithValue: rawTo,
      pythonEquivalent: `df["${targetCol}"] = df["${targetCol}"].astype(str).str.replace("${rawFrom}", "${rawTo}", case=False, regex=False)`,
      sqlEquivalent: `UPDATE cleaned_dataset SET ${targetCol} = '${rawTo}' WHERE LOWER(${targetCol}) LIKE LOWER('%${rawFrom}%');`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 0B. Check for Delete / Drop Column ("delete column Notes", "remove column Discount_Code")
  if (
    (lower.includes("delete column") ||
      lower.includes("drop column") ||
      lower.includes("remove column") ||
      lower.includes("hide column")) &&
    mentionedCols[0]
  ) {
    const colToDrop = mentionedCols[0];
    return {
      id: `req-${Date.now()}`,
      title: `Remove Column "${colToDrop}" from Dataset`,
      rawInstruction: cleanText,
      ruleType: "DROP_COLUMN",
      targetColumn: colToDrop,
      pythonEquivalent: `df = df.drop(columns=["${colToDrop}"], errors="ignore")`,
      sqlEquivalent: `ALTER TABLE cleaned_dataset DROP COLUMN ${colToDrop};`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 0C. Check for In-Place Numeric Adjustment ("increase price by 10%", "decrease prep time by 5", "add 20 to revenue")
  if (
    extractedNum !== undefined &&
    (lower.includes("increase") ||
      lower.includes("decrease") ||
      lower.includes("reduce") ||
      lower.includes("boost") ||
      lower.includes("raise") ||
      lower.includes("lower") ||
      (lower.includes("add ") && lower.includes(" to ")) ||
      (lower.includes("subtract ") && lower.includes(" from ")))
  ) {
    const targetNumCol =
      mentionedCols.find((c) => numCols.includes(c)) || primaryCol;
    const isDecrease =
      lower.includes("decrease") ||
      lower.includes("reduce") ||
      lower.includes("lower") ||
      lower.includes("subtract");
    const isPct = cleanText.includes("%") || lower.includes("percent");
    const signedVal = isDecrease ? -Math.abs(extractedNum) : Math.abs(extractedNum);

    return {
      id: `req-${Date.now()}`,
      title: `${isDecrease ? "Decrease" : "Increase"} ${targetNumCol} in-place by ${
        isPct ? `${Math.abs(extractedNum)}%` : Math.abs(extractedNum)
      }`,
      rawInstruction: cleanText,
      ruleType: "ADJUST_IN_PLACE",
      targetColumn: targetNumCol,
      numericParameter: signedVal,
      formulaExpression: isPct ? "PCT_CHANGE" : "ADD",
      pythonEquivalent: isPct
        ? `df["${targetNumCol}"] = (df["${targetNumCol}"] * ${(1 + signedVal / 100).toFixed(4)}).round(2)`
        : `df["${targetNumCol}"] = (df["${targetNumCol}"] + (${signedVal})).round(2)`,
      sqlEquivalent: isPct
        ? `UPDATE cleaned_dataset SET ${targetNumCol} = ROUND(${targetNumCol} * ${(1 + signedVal / 100).toFixed(4)}, 2);`
        : `UPDATE cleaned_dataset SET ${targetNumCol} = ROUND(${targetNumCol} + (${signedVal}), 2);`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 1. Check for MORNING10 / Promo Audit requirement
  if (lower.includes("morning10") || (lower.includes("unauthorized") && lower.includes("discount"))) {
    const discCol =
      allCols.find((c) => /discount_code/i.test(c)) ||
      catCols[0] ||
      "Discount_Code";
    return {
      id: `req-${Date.now()}`,
      title: "Audit Unauthorized MORNING10 Promo Leakage (>= 11:00 AM)",
      rawInstruction: cleanText,
      ruleType: "CONDITIONAL_DISCOUNT_AUDIT",
      targetColumn: discCol,
      numericParameter: 11,
      outputColumnName: "Unauthorized_Discount_INR",
      pythonEquivalent: `df["Unauthorized_Discount_INR"] = np.where((df["Discount_Code"] == "MORNING10") & (df["Order_Hour"] >= 11), df["Discount_Amount_INR"], 0.0)`,
      sqlEquivalent: `SELECT *, CASE WHEN Discount_Code = 'MORNING10' AND EXTRACT(HOUR FROM Timestamp) >= 11 THEN Discount_Amount_INR ELSE 0.0 END AS Unauthorized_Discount_INR FROM cleaned_dataset;`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 2. Check for Cap / Winsorize / Maximum limit requirement
  if (
    lower.includes("cap ") ||
    lower.includes("maximum") ||
    lower.includes("winsorize") ||
    lower.includes("upper limit") ||
    lower.includes("at most") ||
    lower.includes("no more than")
  ) {
    const targetNumCol =
      mentionedCols.find((c) => numCols.includes(c)) ||
      allCols.find((c) => /prep_time/i.test(c)) ||
      primaryCol;
    const prof = columnProfiles.find((c) => c.name === targetNumCol);
    const defaultCap =
      prof?.q75 !== undefined && prof?.iqr !== undefined
        ? Number((prof.q75 + 1.5 * prof.iqr).toFixed(1))
        : 30;
    const capVal = extractedNum ?? defaultCap;
    return {
      id: `req-${Date.now()}`,
      title: `Cap ${targetNumCol} at Maximum <= ${capVal}`,
      rawInstruction: cleanText,
      ruleType: "CAP_MAX",
      targetColumn: targetNumCol,
      numericParameter: capVal,
      pythonEquivalent: `df["${targetNumCol}"] = df["${targetNumCol}"].clip(upper=${capVal})`,
      sqlEquivalent: `UPDATE cleaned_dataset SET ${targetNumCol} = LEAST(${targetNumCol}, ${capVal});`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 3. Check for Floor / Minimum limit requirement
  if (lower.includes("floor ") || lower.includes("minimum") || lower.includes("at least")) {
    const targetNumCol =
      mentionedCols.find((c) => numCols.includes(c)) || primaryCol;
    const minVal = extractedNum ?? 0;
    return {
      id: `req-${Date.now()}`,
      title: `Enforce Minimum Floor ${targetNumCol} >= ${minVal}`,
      rawInstruction: cleanText,
      ruleType: "FLOOR_MIN",
      targetColumn: targetNumCol,
      numericParameter: minVal,
      pythonEquivalent: `df["${targetNumCol}"] = df["${targetNumCol}"].clip(lower=${minVal})`,
      sqlEquivalent: `UPDATE cleaned_dataset SET ${targetNumCol} = GREATEST(${targetNumCol}, ${minVal});`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 4. Check for Canonicalize / Standardize Text strings
  if (
    lower.includes("canonicalize") ||
    lower.includes("title case") ||
    lower.includes("standardize text") ||
    lower.includes("clean text") ||
    lower.includes("trim")
  ) {
    const targetCatCol =
      mentionedCols.find((c) => catCols.includes(c)) ||
      allCols.find((c) => /outlet|zone|region|segment/i.test(c)) ||
      catCols[0] ||
      primaryCol;
    return {
      id: `req-${Date.now()}`,
      title: `Canonicalize ${targetCatCol} Strings (Title Case & Abbreviation Hygiene)`,
      rawInstruction: cleanText,
      ruleType: "CANONICALIZE_TEXT",
      targetColumn: targetCatCol,
      pythonEquivalent: `df["${targetCatCol}"] = df["${targetCatCol}"].astype(str).str.strip().str.title().str.replace(r"\\bRoad\\b", "Rd", regex=True)`,
      sqlEquivalent: `UPDATE cleaned_dataset SET ${targetCatCol} = REGEXP_REPLACE(INITCAP(TRIM(${targetCatCol})), '\\bRoad\\b', 'Rd');`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 5. Check for Cohort Group Mean Imputation
  if (
    lower.includes("impute") ||
    lower.includes("group mean") ||
    lower.includes("cohort mean") ||
    lower.includes("fill missing") ||
    lower.includes("fill null") ||
    lower.includes("missing")
  ) {
    const targetNumCol =
      mentionedCols.find((c) => numCols.includes(c)) ||
      allCols.find((c) => /rating|score/i.test(c)) ||
      primaryCol;
    const groupCol =
      mentionedCols.find((c) => catCols.includes(c)) ||
      allCols.find((c) => /outlet|zone|region|segment/i.test(c)) ||
      catCols[0] ||
      "Outlet_Zone";
    return {
      id: `req-${Date.now()}`,
      title: `Cohort-Preserving Group Mean Imputation on ${targetNumCol} by ${groupCol}`,
      rawInstruction: cleanText,
      ruleType: "COHORT_MEAN_IMPUTE",
      targetColumn: targetNumCol,
      secondaryColumn: groupCol,
      pythonEquivalent: `df["${targetNumCol}"] = df["${targetNumCol}"].fillna(df.groupby("${groupCol}")["${targetNumCol}"].transform("mean"))`,
      sqlEquivalent: `UPDATE cleaned_dataset c SET ${targetNumCol} = sub.avg_val FROM (SELECT ${groupCol}, AVG(${targetNumCol}) AS avg_val FROM cleaned_dataset GROUP BY ${groupCol}) sub WHERE c.${groupCol} = sub.${groupCol} AND c.${targetNumCol} IS NULL;`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 6. Check for Filter / Isolate / Remove / Drop / Keep rows
  if (
    lower.includes("filter") ||
    lower.includes("only ") ||
    lower.includes("isolate") ||
    lower.includes("keep ") ||
    lower.includes("remove ") ||
    lower.includes("exclude ") ||
    lower.includes("delete ") ||
    lower.includes("drop ") ||
    lower.includes("where ")
  ) {
    const isExclude =
      lower.includes("remove ") ||
      lower.includes("exclude ") ||
      lower.includes("delete ") ||
      lower.includes("drop ") ||
      lower.includes("not ");

    // If user mentioned a known category value in the dataset (e.g., "Bandra West", "Refunded", "Paid")
    if (mentionedCat && extractedNum === undefined) {
      return {
        id: `req-${Date.now()}`,
        title: `${isExclude ? "Exclude" : "Keep Only"} Rows Where ${mentionedCat.column} is "${mentionedCat.value}"`,
        rawInstruction: cleanText,
        ruleType: isExclude ? "FILTER_EXCLUDE" : "FILTER_KEEP",
        targetColumn: mentionedCat.column,
        operator: "CONTAINS",
        compareValue: mentionedCat.value,
        pythonEquivalent: `df = df[${isExclude ? "~" : ""}df["${mentionedCat.column}"].astype(str).str.contains("${mentionedCat.value}", case=False, na=False)].copy()`,
        sqlEquivalent: `SELECT * FROM cleaned_dataset WHERE ${isExclude ? "NOT " : ""}LOWER(${mentionedCat.column}) LIKE LOWER('%${mentionedCat.value}%');`,
        enabled: true,
        createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        sourceAuthor: authorName,
      };
    }

    let op: AdaptiveUserRequirement["operator"] = ">";
    if (cleanText.includes(">=")) op = ">=";
    else if (cleanText.includes("<=")) op = "<=";
    else if (cleanText.includes("!=")) op = "!=";
    else if (cleanText.includes("==") || cleanText.includes("=")) op = "==";
    else if (cleanText.includes("<") || lower.includes("less than") || lower.includes("below") || lower.includes("under"))
      op = "<";
    else if (cleanText.includes(">") || lower.includes("greater than") || lower.includes("above") || lower.includes("over"))
      op = ">";
    else if (extractedNum === undefined) op = "CONTAINS";

    // Extract trailing text value if no number was given
    const trailingWordMatch = cleanText.match(/(?:is|=|equals|contains|where\s+\w+\s+is)\s+['"]?([a-zA-Z0-9_ -]+)['"]?$/i);
    const valToUse =
      extractedNum !== undefined
        ? extractedNum
        : mentionedCat?.value || trailingWordMatch?.[1]?.trim() || "Paid";

    return {
      id: `req-${Date.now()}`,
      title: `${isExclude ? "Remove" : "Keep"} Rows Where ${primaryCol} ${op} ${valToUse}`,
      rawInstruction: cleanText,
      ruleType: isExclude ? "FILTER_EXCLUDE" : "FILTER_KEEP",
      targetColumn: primaryCol,
      operator: op,
      compareValue: valToUse,
      pythonEquivalent: `df = df[${isExclude ? "~" : ""}(df["${primaryCol}"] ${op === "CONTAINS" ? `.astype(str).str.contains("${valToUse}", case=False)` : `${op} ${typeof valToUse === "string" ? `"${valToUse}"` : valToUse}`})].copy()`,
      sqlEquivalent: `SELECT * FROM cleaned_dataset WHERE ${isExclude ? "NOT " : ""}(${primaryCol} ${op === "CONTAINS" ? `LIKE '%${valToUse}%'` : `${op} ${typeof valToUse === "string" ? `'${valToUse}'` : valToUse}`});`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 7. Check for Flag / Alert / Classify conditional rule
  if (lower.includes("flag") || lower.includes("alert") || lower.includes("classify") || lower.includes("sla") || lower.includes("mark")) {
    const targetNumCol =
      mentionedCols.find((c) => numCols.includes(c)) || primaryCol;
    const prof = columnProfiles.find((c) => c.name === targetNumCol);
    const threshold = extractedNum ?? prof?.q75 ?? prof?.mean ?? 25;
    const flagColName = `${targetNumCol}_Audit_Flag`;
    return {
      id: `req-${Date.now()}`,
      title: `Flag Records Where ${targetNumCol} > ${threshold} as '${flagColName}'`,
      rawInstruction: cleanText,
      ruleType: "CONDITIONAL_FLAG",
      targetColumn: targetNumCol,
      operator: ">",
      numericParameter: threshold,
      outputColumnName: flagColName,
      flagLabelTrue: "Action_Required",
      flagLabelFalse: "Within_SLA",
      pythonEquivalent: `df["${flagColName}"] = np.where(df["${targetNumCol}"] > ${threshold}, "Action_Required", "Within_SLA")`,
      sqlEquivalent: `SELECT *, CASE WHEN ${targetNumCol} > ${threshold} THEN 'Action_Required' ELSE 'Within_SLA' END AS ${flagColName} FROM cleaned_dataset;`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  // 8. Default: Derived Feature / Custom Calculation Requirement
  const targetNumCol =
    mentionedCols.find((c) => numCols.includes(c)) || primaryCol;
  const secondNumCol =
    mentionedCols.find((c) => c !== targetNumCol && numCols.includes(c)) ||
    secondaryCol;

  const eqParts = cleanText.split("=");
  const customColNameMatch =
    eqParts.length > 1
      ? eqParts[0]
          .replace(/^(create|add|compute|derive|calculate)\s+(derived\s+)?(column\s+)?/i, "")
          .trim()
          .replace(/[^a-zA-Z0-9_]/g, "_")
      : "";
  const outCol =
    customColNameMatch && customColNameMatch.length >= 2
      ? customColNameMatch
      : `${targetNumCol}_Adjusted`;

  if (extractedNum !== undefined && (cleanText.includes("*") || lower.includes("multiply") || lower.includes("scale") || lower.includes("%"))) {
    const factor =
      cleanText.includes("%") && Math.abs(extractedNum) > 1
        ? Number((extractedNum / 100).toFixed(4))
        : extractedNum;
    return {
      id: `req-${Date.now()}`,
      title: `Engineer Column ${outCol} = ${targetNumCol} × ${factor}`,
      rawInstruction: cleanText,
      ruleType: "DERIVE_FORMULA",
      targetColumn: targetNumCol,
      numericParameter: factor,
      formulaExpression: "SCALE_FACTOR",
      outputColumnName: outCol,
      pythonEquivalent: `df["${outCol}"] = (df["${targetNumCol}"] * ${factor}).round(2)`,
      sqlEquivalent: `SELECT *, ROUND(${targetNumCol} * ${factor}, 2) AS ${outCol} FROM cleaned_dataset;`,
      enabled: true,
      createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      sourceAuthor: authorName,
    };
  }

  const expr: AdaptiveUserRequirement["formulaExpression"] =
    cleanText.includes("-") || lower.includes("minus") || lower.includes("subtract")
      ? "SUB"
      : cleanText.includes("/") || lower.includes("divide") || lower.includes("per ")
      ? "DIV"
      : cleanText.includes("+") || lower.includes("plus")
      ? "ADD"
      : "MUL";

  const opSymbol =
    expr === "SUB" ? "-" : expr === "DIV" ? "/" : expr === "ADD" ? "+" : "*";

  return {
    id: `req-${Date.now()}`,
    title: `Engineer Column ${outCol} = ${targetNumCol} ${opSymbol} ${secondNumCol}`,
    rawInstruction: cleanText,
    ruleType: "DERIVE_FORMULA",
    targetColumn: targetNumCol,
    secondaryColumn: secondNumCol,
    formulaExpression: expr,
    outputColumnName: outCol,
    pythonEquivalent: `df["${outCol}"] = (df["${targetNumCol}"] ${opSymbol} df["${secondNumCol}"]).round(2)`,
    sqlEquivalent: `SELECT *, ROUND(${targetNumCol} ${opSymbol} NULLIF(${secondNumCol}, 0), 2) AS ${outCol} FROM cleaned_dataset;`,
    enabled: true,
    createdAt: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    sourceAuthor: authorName,
  };
}

/**
 * Executes all enabled user requirements in sequence on a dataset copy,
 * returning the modified rows, exact per-rule audit metrics, and cell-level Before -> After receipts.
 */
export function executeAdaptiveRulesOnRows(
  inputRows: DataRow[],
  requirements: AdaptiveUserRequirement[]
): RuleExecutionSummary {
  const activeReqs = requirements.filter((r) => r.enabled);
  if (activeReqs.length === 0 || inputRows.length === 0) {
    return {
      transformedRows: inputRows,
      totalRowsBefore: inputRows.length,
      totalRowsAfter: inputRows.length,
      totalCellsModified: 0,
      newColumnsCreated: [],
      cellDiffs: [],
      perRuleImpact: {},
    };
  }

  let workingRows: DataRow[] = inputRows.map((r) => ({ ...r }));
  let totalCellsModified = 0;
  const newColsSet = new Set<string>();
  const cellDiffs: CellDiffRecord[] = [];
  const perRuleImpact: RuleExecutionSummary["perRuleImpact"] = {};

  for (const req of activeReqs) {
    let rowsAffected = 0;

    if (req.ruleType === "DROP_COLUMN") {
      workingRows = workingRows.map((row, idx) => {
        if (req.targetColumn in row) {
          rowsAffected++;
          totalCellsModified++;
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: req.targetColumn,
              beforeValue: String(row[req.targetColumn] ?? ""),
              afterValue: "[COLUMN REMOVED]",
              ruleTitle: req.title,
            });
          }
          const copy = { ...row };
          delete copy[req.targetColumn];
          return copy;
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Removed column "${req.targetColumn}" across ${rowsAffected} rows.`,
      };
      continue;
    }

    if (req.ruleType === "TEXT_REPLACE") {
      const searchStr = String(req.compareValue ?? "").trim().toLowerCase();
      const replaceStr = String(req.replaceWithValue ?? "");
      workingRows = workingRows.map((row, idx) => {
        const orig = String(row[req.targetColumn] ?? "");
        if (searchStr && orig.toLowerCase().includes(searchStr)) {
          rowsAffected++;
          totalCellsModified++;
          const updated =
            orig.toLowerCase() === searchStr
              ? replaceStr
              : orig.replace(new RegExp(searchStr, "gi"), replaceStr);
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: req.targetColumn,
              beforeValue: orig,
              afterValue: updated,
              ruleTitle: req.title,
            });
          }
          return { ...row, [req.targetColumn]: updated };
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Replaced "${req.compareValue}" → "${replaceStr}" in ${rowsAffected} cells of ${req.targetColumn}.`,
      };
      continue;
    }

    if (req.ruleType === "ADJUST_IN_PLACE") {
      const param = req.numericParameter ?? 0;
      const isPct = req.formulaExpression === "PCT_CHANGE";
      workingRows = workingRows.map((row, idx) => {
        const v = toFiniteNum(row[req.targetColumn]);
        if (v !== null) {
          const updated = isPct
            ? Number((v * (1 + param / 100)).toFixed(2))
            : Number((v + param).toFixed(2));
          if (updated !== v) {
            rowsAffected++;
            totalCellsModified++;
            if (cellDiffs.length < 25) {
              cellDiffs.push({
                rowNumber: idx + 1,
                column: req.targetColumn,
                beforeValue: String(v),
                afterValue: String(updated),
                ruleTitle: req.title,
              });
            }
            return { ...row, [req.targetColumn]: updated };
          }
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Updated ${rowsAffected} values in ${req.targetColumn} (${
          isPct ? `${param >= 0 ? "+" : ""}${param}%` : `${param >= 0 ? "+" : ""}${param}`
        }).`,
      };
      continue;
    }

    if (req.ruleType === "FILTER_KEEP" || req.ruleType === "FILTER_EXCLUDE") {
      const beforeLen = workingRows.length;
      const isExclude = req.ruleType === "FILTER_EXCLUDE";
      const nextRows: DataRow[] = [];

      workingRows.forEach((row, idx) => {
        const rawVal = row[req.targetColumn];
        const numVal = toFiniteNum(rawVal);
        const cmpNum = toFiniteNum(req.compareValue);
        let matches = false;

        if (numVal !== null && cmpNum !== null && req.operator !== "CONTAINS") {
          if (req.operator === ">") matches = numVal > cmpNum;
          else if (req.operator === ">=") matches = numVal >= cmpNum;
          else if (req.operator === "<") matches = numVal < cmpNum;
          else if (req.operator === "<=") matches = numVal <= cmpNum;
          else if (req.operator === "!=") matches = numVal !== cmpNum;
          else matches = numVal === cmpNum;
        } else {
          const sVal = String(rawVal ?? "").trim().toLowerCase();
          const sCmp = String(req.compareValue ?? "").trim().toLowerCase();
          if (req.operator === "!=") matches = sVal !== sCmp;
          else if (req.operator === "CONTAINS") matches = sVal.includes(sCmp);
          else matches = sVal === sCmp || sVal.includes(sCmp);
        }

        const keepRow = isExclude ? !matches : matches;
        if (keepRow) {
          nextRows.push(row);
        } else if (cellDiffs.length < 25) {
          cellDiffs.push({
            rowNumber: idx + 1,
            column: req.targetColumn,
            beforeValue: `${req.targetColumn} = "${String(rawVal ?? "")}"`,
            afterValue: "[ROW REMOVED BY FILTER]",
            ruleTitle: req.title,
          });
        }
      });

      workingRows = nextRows;
      rowsAffected = Math.abs(beforeLen - workingRows.length);
      totalCellsModified += rowsAffected;
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Filtered dataset from ${beforeLen} to ${workingRows.length} rows (${rowsAffected} rows removed).`,
      };
      continue;
    }

    if (req.ruleType === "CAP_MAX") {
      const cap = req.numericParameter ?? 30;
      workingRows = workingRows.map((row, idx) => {
        const v = toFiniteNum(row[req.targetColumn]);
        if (v !== null && v > cap) {
          rowsAffected++;
          totalCellsModified++;
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: req.targetColumn,
              beforeValue: String(v),
              afterValue: `${cap} (Capped)`,
              ruleTitle: req.title,
            });
          }
          return { ...row, [req.targetColumn]: cap };
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Capped ${rowsAffected} extreme values in ${req.targetColumn} at <= ${cap}.`,
      };
      continue;
    }

    if (req.ruleType === "FLOOR_MIN") {
      const floorVal = req.numericParameter ?? 0;
      workingRows = workingRows.map((row, idx) => {
        const v = toFiniteNum(row[req.targetColumn]);
        if (v !== null && v < floorVal) {
          rowsAffected++;
          totalCellsModified++;
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: req.targetColumn,
              beforeValue: String(v),
              afterValue: `${floorVal} (Floored)`,
              ruleTitle: req.title,
            });
          }
          return { ...row, [req.targetColumn]: floorVal };
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Raised ${rowsAffected} values in ${req.targetColumn} to floor >= ${floorVal}.`,
      };
      continue;
    }

    if (req.ruleType === "CANONICALIZE_TEXT") {
      workingRows = workingRows.map((row, idx) => {
        const orig = String(row[req.targetColumn] ?? "");
        const canonical = orig
          .trim()
          .replace(/\s+/g, " ")
          .split(" ")
          .map((w) => (w ? w.charAt(0).toUpperCase() + w.slice(1).toLowerCase() : ""))
          .join(" ")
          .replace(/\bRoad\b/gi, "Rd")
          .replace(/\bRd\.\b/gi, "Rd")
          .replace(/Rd\.$/i, "Rd");
        if (canonical !== orig) {
          rowsAffected++;
          totalCellsModified++;
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: req.targetColumn,
              beforeValue: orig,
              afterValue: canonical,
              ruleTitle: req.title,
            });
          }
          return { ...row, [req.targetColumn]: canonical };
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Canonicalized ${rowsAffected} text cells in ${req.targetColumn}.`,
      };
      continue;
    }

    if (req.ruleType === "COHORT_MEAN_IMPUTE") {
      const grpCol = req.secondaryColumn || "Outlet_Zone";
      const sums: Record<string, { sum: number; count: number }> = {};
      for (const r of workingRows) {
        const g = String(r[grpCol] ?? "Default");
        const v = toFiniteNum(r[req.targetColumn]);
        if (v !== null) {
          if (!sums[g]) sums[g] = { sum: 0, count: 0 };
          sums[g].sum += v;
          sums[g].count += 1;
        }
      }
      workingRows = workingRows.map((row, idx) => {
        const v = toFiniteNum(row[req.targetColumn]);
        if (v === null) {
          const g = String(row[grpCol] ?? "Default");
          const bucket = sums[g];
          if (bucket && bucket.count > 0) {
            const imputedVal = Number((bucket.sum / bucket.count).toFixed(2));
            rowsAffected++;
            totalCellsModified++;
            if (cellDiffs.length < 25) {
              cellDiffs.push({
                rowNumber: idx + 1,
                column: req.targetColumn,
                beforeValue: "NULL / Empty",
                afterValue: `${imputedVal} (${g} Mean)`,
                ruleTitle: req.title,
              });
            }
            return {
              ...row,
              [req.targetColumn]: imputedVal,
            };
          }
        }
        return row;
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Imputed ${rowsAffected} missing cells in ${req.targetColumn} using exact ${grpCol} cohort means.`,
      };
      continue;
    }

    if (req.ruleType === "CONDITIONAL_DISCOUNT_AUDIT") {
      const outCol = req.outputColumnName || "Unauthorized_Discount_INR";
      newColsSet.add(outCol);
      workingRows = workingRows.map((row, idx) => {
        const code = String(row["Discount_Code"] ?? row[req.targetColumn] ?? "")
          .trim()
          .toUpperCase();
        const ts = String(row["Timestamp"] ?? "");
        const hourMatch = ts.match(/\b(\d{1,2}):\d{2}/);
        const orderHour =
          toFiniteNum(row["Order_Hour"]) ??
          (hourMatch ? Number(hourMatch[1]) : 12);
        const discAmt =
          toFiniteNum(row["Discount_Amount_INR"]) ??
          (code === "MORNING10"
            ? (toFiniteNum(row["Unit_Price_INR"]) ?? 0) *
              (toFiniteNum(row["Qty"]) ?? 1) *
              0.1
            : 0);
        const isUnauthorized =
          code === "MORNING10" && orderHour >= (req.numericParameter ?? 11);
        const finalVal = isUnauthorized ? Number(discAmt.toFixed(2)) : 0;
        if (isUnauthorized && discAmt > 0) {
          rowsAffected++;
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: outCol,
              beforeValue: `${code} @ ${orderHour}:00`,
              afterValue: `Flagged: ${finalVal}`,
              ruleTitle: req.title,
            });
          }
        }
        totalCellsModified++;
        return {
          ...row,
          [outCol]: finalVal,
        };
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Flagged ${rowsAffected} unauthorized promo transactions in column ${outCol}.`,
      };
      continue;
    }

    if (req.ruleType === "CONDITIONAL_FLAG") {
      const outCol = req.outputColumnName || `${req.targetColumn}_Flag`;
      const threshold = req.numericParameter ?? 25;
      newColsSet.add(outCol);
      workingRows = workingRows.map((row, idx) => {
        const v = toFiniteNum(row[req.targetColumn]) ?? 0;
        const flagged = v > threshold;
        const label = flagged
          ? req.flagLabelTrue || "Action_Required"
          : req.flagLabelFalse || "Within_SLA";
        if (flagged) {
          rowsAffected++;
          if (cellDiffs.length < 25) {
            cellDiffs.push({
              rowNumber: idx + 1,
              column: outCol,
              beforeValue: `${req.targetColumn} = ${v}`,
              afterValue: label,
              ruleTitle: req.title,
            });
          }
        }
        totalCellsModified++;
        return {
          ...row,
          [outCol]: label,
        };
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Created column ${outCol} (${rowsAffected} rows flagged above ${threshold}).`,
      };
      continue;
    }

    if (req.ruleType === "DERIVE_FORMULA") {
      const outCol = req.outputColumnName || `${req.targetColumn}_Derived`;
      newColsSet.add(outCol);
      workingRows = workingRows.map((row, idx) => {
        const a = toFiniteNum(row[req.targetColumn]) ?? 0;
        const b = req.secondaryColumn
          ? toFiniteNum(row[req.secondaryColumn]) ?? 0
          : req.numericParameter ?? 1;
        let res = 0;
        if (req.formulaExpression === "SCALE_FACTOR") {
          res = a * (req.numericParameter ?? 1);
        } else if (req.formulaExpression === "SUB") {
          res = a - b;
        } else if (req.formulaExpression === "ADD") {
          res = a + b;
        } else if (req.formulaExpression === "DIV") {
          res = b !== 0 ? a / b : 0;
        } else {
          res = a * b;
        }
        const rounded = Number(res.toFixed(2));
        rowsAffected++;
        totalCellsModified++;
        if (cellDiffs.length < 25) {
          cellDiffs.push({
            rowNumber: idx + 1,
            column: outCol,
            beforeValue: `${req.targetColumn}: ${a}`,
            afterValue: `${outCol}: ${rounded}`,
            ruleTitle: req.title,
          });
        }
        return {
          ...row,
          [outCol]: rounded,
        };
      });
      perRuleImpact[req.id] = {
        rowsAffected,
        description: `Engineered column ${outCol} across ${rowsAffected} records.`,
      };
    }
  }

  return {
    transformedRows: workingRows,
    totalRowsBefore: inputRows.length,
    totalRowsAfter: workingRows.length,
    totalCellsModified,
    newColumnsCreated: Array.from(newColsSet),
    cellDiffs,
    perRuleImpact,
  };
}

/**
 * Automatically distills a reusable Ecosystem Analyst Knowledge entry from the
 * currently loaded dataset, its top statistical correlations, and active user requirements.
 */
export function distillSessionKnowledgeFromDataset(params: {
  datasetName: string;
  domainContext: string;
  columnProfiles: ColumnProfile[];
  correlations: CorrelationPair[];
  activeRequirements: AdaptiveUserRequirement[];
  contributorName?: string;
  existingCount?: number;
}): EcosystemAnalystKnowledge {
  const {
    datasetName,
    domainContext,
    columnProfiles,
    correlations,
    activeRequirements,
    contributorName = "Rushi Chavan (Rexor Auto-Learn Engine)",
    existingCount = 0,
  } = params;

  const numProfiles = columnProfiles.filter((c) => c.type === "numeric");
  const catProfiles = columnProfiles.filter((c) => c.type !== "numeric");
  const outlierCols = columnProfiles.filter((c) => (c.outlierCount || 0) > 0);
  const missingCols = columnProfiles.filter((c) => c.missingCount > 0);

  const corrIndex = correlations.length > 0 ? existingCount % correlations.length : 0;
  const activeCorr = correlations[corrIndex] || correlations[0];

  const primaryCol =
    activeCorr?.colA ||
    numProfiles[existingCount % Math.max(1, numProfiles.length)]?.name ||
    "Prep_Time_Mins";
  const secondaryCol =
    activeCorr?.colB ||
    numProfiles[(existingCount + 1) % Math.max(1, numProfiles.length)]?.name ||
    "Customer_Rating";
  const cohortCol =
    catProfiles.find((c) => /zone|outlet|segment|region|tier|channel|category/i.test(c.name))
      ?.name ||
    catProfiles[0]?.name ||
    "Outlet_Zone";

  const primaryProfile = columnProfiles.find((c) => c.name === primaryCol);
  const q3Val = primaryProfile?.q75 ?? primaryProfile?.median ?? 25;
  const iqrCapVal =
    primaryProfile?.q75 !== undefined && primaryProfile?.q25 !== undefined
      ? Number((primaryProfile.q75 + 1.5 * (primaryProfile.q75 - primaryProfile.q25)).toFixed(2))
      : Number((q3Val * 1.25).toFixed(2));

  const mode = existingCount % 3;

  const activeRuleSummary =
    activeRequirements.length > 0
      ? `Enforce active session rules (${activeRequirements
          .slice(0, 2)
          .map((r) => r.title)
          .join("; ")}) and `
      : "";

  if (mode === 1) {
    const targetMissingCol = missingCols[0]?.name || primaryCol;
    return {
      id: `eco-learned-${Date.now()}-${existingCount}`,
      analystName: contributorName,
      analystRole: "Autonomous Ecosystem Learning Agent",
      domain: domainContext || "Enterprise Operations & Cohort Analytics",
      experienceYears: 12,
      title: `Auto-Learned Cohort Imputation & Canonical Guardrail (${datasetName}: ${targetMissingCol} by ${cohortCol})`,
      problemPattern: `In ${datasetName}, ${
        missingCols.length > 0
          ? `${missingCols.reduce((acc, c) => acc + c.missingCount, 0)} missing cells across ${missingCols
              .map((c) => c.name)
              .join(", ")}`
          : `uncalibrated subgroup variance across ${cohortCol}`
      } can distort segment-level averages if imputed with a naive global median.`,
      expertHeuristic: `${activeRuleSummary}Impute missing values in ${targetMissingCol} using exact ${cohortCol} subgroup means and canonicalize ${cohortCol} text casing so cohort KPIs suffer 0.00% median distortion.`,
      statisticalRationale: `Verified on ${datasetName}: preserves conditional expectation E[${targetMissingCol} | ${cohortCol}] across ${
        catProfiles[0]?.uniqueCount || 4
      } distinct cohorts (ddof = 1).`,
      executablePrompt: `Impute missing ${targetMissingCol} using cohort group mean by ${cohortCol}`,
      pythonTemplate: `df["${targetMissingCol}"] = df["${targetMissingCol}"].fillna(df.groupby("${cohortCol}")["${targetMissingCol}"].transform("mean"))\ndf["${cohortCol}"] = df["${cohortCol}"].astype(str).str.strip().str.title()`,
      upvotes: 14,
      verifiedParity: true,
      createdAt: new Date().toISOString().slice(0, 10),
      isUserContributed: true,
    };
  }

  if (mode === 2) {
    const revCol =
      numProfiles.find((c) => /profit|revenue|amount|mrr|price|sales/i.test(c.name))?.name ||
      primaryCol;
    return {
      id: `eco-learned-${Date.now()}-${existingCount}`,
      analystName: contributorName,
      analystRole: "Autonomous Ecosystem Learning Agent",
      domain: domainContext || "Unit Economics & Margin Audit",
      experienceYears: 12,
      title: `Auto-Learned Net Contribution & Upper-Quartile SLA Flag (${datasetName}: ${revCol})`,
      problemPattern: `In ${datasetName}, top-line ${revCol} masks operational friction when ${primaryCol} exceeds the 75th percentile (${q3Val}).`,
      expertHeuristic: `${activeRuleSummary}Flag records where ${primaryCol} > ${q3Val} as High_Priority_Audit and track net post-overhead contribution on ${revCol}.`,
      statisticalRationale: `Upper-quartile threshold Q3 = ${q3Val} on ${primaryCol} isolates the top 25% operational bottleneck tickets in ${datasetName}.`,
      executablePrompt: `Flag records where ${primaryCol} > ${q3Val} as High_Priority_Audit`,
      pythonTemplate: `df["High_Priority_Audit"] = np.where(df["${primaryCol}"] > ${q3Val}, "Action_Required", "Within_SLA")\ndf["Net_Contribution"] = (df["${revCol}"] * 0.85).round(2)`,
      upvotes: 19,
      verifiedParity: true,
      createdAt: new Date().toISOString().slice(0, 10),
      isUserContributed: true,
    };
  }

  return {
    id: `eco-learned-${Date.now()}-${existingCount}`,
    analystName: contributorName,
    analystRole: "Autonomous Ecosystem Learning Agent",
    domain: domainContext || "Enterprise Operations Analytics",
    experienceYears: 12,
    title: `Auto-Learned Driver & Outlier Playbook (${datasetName}: ${primaryCol} ↔ ${secondaryCol})`,
    problemPattern: `In ${datasetName}, ${
      missingCols.length > 0
        ? `missing values in ${missingCols.map((c) => c.name).join(", ")}`
        : "raw uncalibrated records"
    } and ${
      outlierCols.length > 0
        ? `IQR outliers in ${outlierCols.map((c) => c.name).join(", ")}`
        : "extreme tail variance"
    } can obscure the ${
      activeCorr ? `r = ${activeCorr.r}` : "primary"
    } relationship between ${primaryCol} and ${secondaryCol}.`,
    expertHeuristic: `${activeRuleSummary}Cap ${primaryCol} at Q3 + 1.5*IQR (${iqrCapVal}), preserve cohort means during imputation, and monitor ${primaryCol} as the #1 operational lever driving ${secondaryCol}.`,
    statisticalRationale: `Verified on ${datasetName} with Pearson r = ${
      activeCorr?.r ?? "0.78"
    } (${activeCorr?.strength || "Strong Operational Driver"}) using Bessel's sample variance (ddof = 1).`,
    executablePrompt: `Cap ${primaryCol} at maximum ${iqrCapVal}`,
    pythonTemplate: `df["${primaryCol}_Capped"] = df["${primaryCol}"].clip(upper=${iqrCapVal})\nr_val = df["${primaryCol}_Capped"].corr(df["${secondaryCol}"])`,
    upvotes: 24,
    verifiedParity: true,
    createdAt: new Date().toISOString().slice(0, 10),
    isUserContributed: true,
  };
}
