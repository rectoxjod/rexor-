import { SampleDatasetPreset } from "../types/rexor";
import { HIGH_FRICTION_PROBLEMS } from "../utils/highFrictionProblemsEngine";

const CORE_DATASETS: SampleDatasetPreset[] = [
  {
    id: "industry-business-assessment",
    name: "Simulated Industry Business Assessment Dataset (Tasks 1–5 Official Deliverable)",
    sourceType: "Excel Workbook",
    domainContext: "Omnichannel Retail, Warehouse Fulfillment, Discount Profitability & Return Rate Audit",
    defaultBusinessQuestion:
      "Discover and clean all deliberate data-quality issues (duplicate Order IDs, missing values, inconsistent categories, unusual quantities/discounts), calculate all 7 Business KPIs, answer the 7 Management Questions, and build the Executive Dashboard & 1-Page Management Report.",
    description:
      "38 simulated industry business orders with deliberate duplicate Order_IDs, missing cells, inconsistent category/region/warehouse naming, negative quantities (-4), >100% discount errors (1.45), returned orders, and warehouse delivery delays.",
    rawCsv: `Order_ID,Order_Date,Product_Category,Product_Name,Region,Sales_Channel,Warehouse,Quantity,Unit_Price,Discount_Rate,Unit_Cost,Order_Status,Delivery_Status
ORD-5001,2026-07-12,Electronics,UltraBook Pro 15,North,Online,WH-North,2,"$1,250.00",0.05,720,Completed,On-Time
ORD-5002,15/07/2026,electronics,NoiseCancel Headphones X2,north,online,wh-north,4,$320.00,0.10,150,Completed,On-Time
ORD-5003,2026-07-19,Home & Kitchen,Smart Espresso Maker,West,Retail Store,WH-West,3,$450.00,0.00,240,Completed,On-Time
ORD-5003,2026-07-19,Home & Kitchen,Smart Espresso Maker,West,Retail Store,WH-West,3,$450.00,0.00,240,Completed,On-Time
ORD-5004,22-07-2026,Apparel,Merino Performance Jacket,South,Marketplace,WH-South,5,$180.00,0.25,95,Returned,Delayed
ORD-5005,2026-07-28,ELECTRONICS,4K Studio Monitor 27,East,B2B Partner,WH-East,3,$680.00,0.05,390,Completed,On-Time
ORD-5006,2026-08-03,home & kitchen,AirPurifier Max HEPA,North Region,Online,WH-North,-4,$290.00,0.10,155,Completed,On-Time
ORD-5007,08/08/2026,Apparel,TrailRunner Carbon Shoes,South,Marketplace,wh-south,6,$160.00,0.35,92,Returned,Delayed
ORD-5008,2026-08-14,Electronics,UltraBook Pro 15,North,B2B Partner,WH-North,3,"$1,250.00",0.00,720,Completed,On-Time
ORD-5009,19-08-2026,Office Supplies,Ergonomic Mesh Chair,West,Retail Store,WH-West,4,,0.10,165,Completed,On-Time
ORD-5010,2026-08-24,Electronics,Wireless Mech Keyboard,East,Online,WH-East,5,$140.00,-0.10,68,Completed,On-Time
ORD-5011,2026-08-29,Home & Kitchen,Robot Vacuum LiDAR,South,Online,WH-South,2,$580.00,1.45,340,Returned,Delayed
ORD-5012,2026-09-04,Electronics,UltraBook Pro 15,West,Online,WH-West,2,"$1,250.00",0.05,720,Completed,On-Time
ORD-5013,09/09/2026,apparel,Merino Performance Jacket,East,Marketplace,WH-East,4,$180.00,0.30,95,Returned,Delayed
ORD-5014,2026-09-14,Office Supplies,Standing Desk Dual-Motor,North,B2B Partner,WH-North,3,$740.00,0.05,410,Completed,On-Time
ORD-5014,2026-09-14,Office Supplies,Standing Desk Dual-Motor,North,B2B Partner,WH-North,3,$740.00,0.05,410,Completed,On-Time
ORD-5015,18-09-2026,Electronics,NoiseCancel Headphones X2,,Online,WH-North,5,$320.00,0.00,150,Completed,On-Time
ORD-5016,2026-09-23,Home & Kitchen,Smart Espresso Maker,South,Retail Store,WH-South,3,$450.00,0.25,240,Completed,Delayed
ORD-5017,2026-09-28,Apparel,TrailRunner Carbon Shoes,West,Marketplace,WH-West,450,$160.00,0.35,92,Returned,On-Time
ORD-5018,2026-10-03,Electronics,4K Studio Monitor 27,North,Online,WH-North,4,$680.00,0.00,390,Completed,On-Time
ORD-5019,07/10/2026,Electronics,UltraBook Pro 15,North,B2B Partner,WH-North,3,"$1,250.00",0.05,720,Completed,On-Time
ORD-5020,2026-10-11,Office Supplies,Ergonomic Mesh Chair,East,Online,WH-East,6,$310.00,,165,Completed,On-Time
ORD-5021,15-10-2026,Home & Kitchen,Robot Vacuum LiDAR,South,Marketplace,WH-South,2,$580.00,0.30,340,Returned,Delayed
ORD-5022,2026-10-19,Electronics,Wireless Mech Keyboard,West,Retail Store,WH-West,8,$140.00,15%,68,Completed,On-Time
ORD-5023,2026-10-22,Office Supplies,Standing Desk Dual-Motor,North,Online,WH-North,3,$740.00,0.00,410,Completed,On-Time
ORD-5024,25/10/2026,Apparel,Merino Performance Jacket,South,Online,WH-South,4,$180.00,0.25,95,Completed,Delayed
ORD-5025,2026-10-28,Electronics,UltraBook Pro 15,East,Online,WH-East,2,"$1,250.00",0.05,720,Completed,On-Time
ORD-5025,2026-10-28,Electronics,UltraBook Pro 15,East,Online,WH-East,2,"$1,250.00",0.05,720,Completed,On-Time
ORD-5026,2026-10-30,Home & Kitchen,AirPurifier Max HEPA,West,Retail Store,WH-West,5,$290.00,0.05,155,Completed,On-Time
ORD-5027,2026-11-04,Electronics,4K Studio Monitor 27,North,B2B Partner,WH-North,3,$680.00,0.05,390,Completed,On-Time
ORD-5028,09/11/2026,Apparel,TrailRunner Carbon Shoes,South,Marketplace,WH-South,3,$160.00,85%,92,Returned,Delayed
ORD-5029,2026-11-14,Office Supplies,Standing Desk Dual-Motor,West,Online,WH-West,2,$740.00,0.10,410,Completed,On-Time
ORD-5030,19-11-2026,Home & Kitchen,Smart Espresso Maker,North,Online,WH-North,4,$450.00,0.00,240,Completed,On-Time
ORD-5031,2026-11-23,Electronics,NoiseCancel Headphones X2,South,Online,WH-South,3,$320.00,0.20,150,Completed,Delayed
ORD-5032,2026-11-27,Office Supplies,Ergonomic Mesh Chair,East,B2B Partner,WH-East,5,$310.00,0.05,165,Completed,On-Time
ORD-5033,2026-11-29,Electronics,UltraBook Pro 15,North,Online,WH-North,2,"$1,250.00",0.00,720,Cancelled,On-Time
ORD-5034,2026-12-03,Home & Kitchen,Robot Vacuum LiDAR,West,Online,WH-West,2,$580.00,0.10,340,Completed,On-Time
ORD-5035,2026-12-08,Electronics,UltraBook Pro 15,North,Online,WH-North,3,"$1,250.00",0.05,720,Completed,On-Time`,
  },
  {
    id: "bistro-operations-raw",
    name: "Bistro POS Operations & Promo Leakage Audit (bistro_operations_raw.csv)",
    sourceType: "CSV Upload",
    domainContext: "Multi-Outlet Hospitality POS, Promo Abuse & Kitchen Prep Telemetry",
    defaultBusinessQuestion:
      "How much net revenue and gross margin are we losing to POS duplicate logs, unpaid/refunded orders, unauthorized post-11AM MORNING10 discounts, and kitchen prep-time bottlenecks across Outlet Zones?",
    description:
      "32 raw POS tickets with ₹ currency strings, 'college road' vs 'College Rd.' naming splits, mixed DD/MM/YYYY & ISO timestamps, duplicate POS logs with different Order_IDs, 145.0m prep outlier, and post-11AM promo leakage.",
    rawCsv: `Order_ID,Timestamp,Outlet_Zone,Server_ID,Item_Name,Pax,Qty,Unit_Price_INR,Unit_Cost_INR,Discount_Code,Payment_Status,Prep_Time_Mins,Customer_Rating
ORD-9001,2026-10-14 09:15:00,College Rd,SRV-101,Artisan Sourdough Egg Benedict,2,2,₹420,135,MORNING10,Paid,14.0,4.8
ORD-9002,14/10/2026 09:42:00,college road,SRV-102,Cold Brew Hazelnut Carafe,2,2,₹340,95,MORNING10,Paid,11.5,4.9
ORD-9003,14-10-2026 10:18:00,College Rd.,SRV-101,Avocado Burrata Tartine,3,3,₹480,155,MORNING10,Paid,15.0,4.7
ORD-9004,2026-10-14 12:30:00,Bandra West,SRV-204,Truffle Mushroom Risotto,4,3,₹680,220,VIP20,Paid,21.0,4.4
ORD-9005,2026-10-14 12:30:00,Bandra West,SRV-204,Truffle Mushroom Risotto,4,3,₹680,220,VIP20,Paid,21.0,4.4
ORD-9006,14/10/2026 13:15:00,College Rd,SRV-103,Smoked Salmon Bagel Platter,2,2,₹540,180,MORNING10,Paid,28.5,3.6
ORD-9007,2026-10-14 13:40:00,Indiranagar,SRV-301,Woodfired Burrata Margherita,4,2,₹620,190,BOGO50,Paid,18.0,4.6
ORD-9008,14-10-2026 14:10:00,college road,SRV-102,Spicy Harissa Chicken Bowl,2,2,₹460,150,MORNING10,Paid,31.0,3.4
ORD-9009,2026-10-14 14:55:00,Bandra West,SRV-205,Chargrilled Prawn Linguine,2,2,₹740,250,NONE,Refunded,34.0,2.8
ORD-9010,14/10/2026 15:20:00,Cyber Hub,SRV-401,Matcha Tiramisu & Espresso,2,2,₹490,140,WEEKEND15,Paid,13.0,4.8
ORD-9011,2026-10-14 16:05:00,Indiranagar,SRV-302,Belgian Liege Waffle Stack,3,3,₹390,110,BOGO50,Paid,16.5,4.5
ORD-9012,14-10-2026 16:45:00,College Rd.,SRV-101,Peri-Peri Halloumi Skewers,4,2,₹510,165,MORNING10,Paid,145.0,2.1
ORD-9013,2026-10-14 17:30:00,Cyber Hub,SRV-402,Artisanal Cheese & Charcuterie,4,2,₹890,310,VIP20,Paid,19.0,4.5
ORD-9014,14/10/2026 18:15:00,bandra west,SRV-204,Korean Gochujang Fried Chicken,3,3,₹560,185,NONE,Paid,24.0,4.1
ORD-9015,2026-10-14 18:50:00,Indiranagar,SRV-301,Wild Mushroom Stroganoff,2,2,₹590,195,WEEKEND15,Failed,29.0,
ORD-9016,14-10-2026 19:20:00,College Rd,SRV-103,Pesto Bocconcini Flatbread,3,3,₹520,170,BOGO50,Paid,26.0,3.8
ORD-9017,14/10/2026 19:20:00,college road,SRV-103,Pesto Bocconcini Flatbread,3,3,₹520,170,BOGO50,Paid,26.0,3.8
ORD-9018,2026-10-14 19:55:00,Bandra West,SRV-206,Pan-Seared Norwegian Salmon,2,2,₹920,340,VIP20,Paid,22.0,4.3
ORD-9019,14/10/2026 20:15:00,Cyber Hub,SRV-401,Truffle Parmesan Fries & Aioli,4,4,₹380,95,BOGO50,Paid,14.5,4.7
ORD-9020,2026-10-14 20:40:00,Indiranagar,SRV-303,Herb Crusted Lamb Chops,2,2,₹860,310,VIP20,Paid,25.0,4.0
ORD-9021,14-10-2026 21:05:00,College Rd,SRV-102,Dark Chocolate Ganache Tart,2,2,₹410,120,MORNING10,Paid,19.5,4.2
ORD-9022,2026-10-14 21:30:00,Cyber Hub,SRV-403,Mediterranean Mezze Platter,4,2,₹640,205,WEEKEND15,Paid,20.0,4.4
ORD-9023,14/10/2026 10:05:00,Bandra West,SRV-204,Brioche French Toast Berry,2,2,₹440,130,MORNING10,Paid,13.5,4.8
ORD-9024,2026-10-14 10:35:00,Indiranagar,SRV-301,Shakshuka Skillet & Pita,2,2,₹450,140,MORNING10,Paid,16.0,4.6
ORD-9025,14-10-2026 12:10:00,Cyber Hub,SRV-402,Grilled Chicken Caesar Salad,2,2,₹470,145,MORNING10,Paid,17.5,4.5
ORD-9026,2026-10-14 13:25:00,Bandra West,SRV-205,Lobster Thermidor Ravioli,2,2,₹950,350,VIP20,Paid,27.0,3.9
ORD-9027,14/10/2026 15:40:00,Indiranagar,SRV-302,Vietnamese Iced Coffee Duo,2,2,₹360,90,BOGO50,Paid,12.0,4.9
ORD-9028,2026-10-14 17:10:00,College Rd.,SRV-101,Loaded Nachos Grande,4,2,₹490,150,NONE,Refunded,32.0,3.1
ORD-9029,14-10-2026 20:00:00,Bandra West,SRV-206,Burrata & Fig Prosciutto Pizza,4,3,₹760,245,WEEKEND15,Paid,23.0,
ORD-9030,2026-10-14 21:15:00,Indiranagar,SRV-303,Basque Burnt Cheesecake,3,3,₹480,145,VIP20,Paid,15.5,4.7
ORD-9031,14/10/2026 21:45:00,Cyber Hub,SRV-401,Gourmet Wagyu Sliders,3,3,₹790,275,BOGO50,Paid,29.5,3.5
ORD-9032,2026-10-14 22:05:00,College Rd,SRV-103,Classic Affogato Al Caffe,2,2,₹350,95,NONE,Paid,12.5,4.8`,
  },
  {
    id: "b2b-saas-churn",
    name: "Enterprise SaaS Revenue & Churn Cohort",
    sourceType: "PostgreSQL Dump",
    domainContext: "B2B Cloud Software Retention & Expansion Analytics",
    defaultBusinessQuestion:
      "Why is net revenue retention dropping in mid-market and enterprise segments, and which onboarding or support factors drive account churn?",
    description:
      "38 account records containing raw billing anomalies ($ formatting), missing MRR cells, duplicate sync rows, support ticket spikes, and seat utilization metrics.",
    rawCsv: `account_id,company_name,segment,region,onboarding_days,seat_utilization_pct,monthly_support_tickets,nps_score,mrr_usd,expansion_usd,churn_risk_score,account_status,renewal_date
ACC-1001,Vanguard Logistics,Enterprise,North America,14,88.5,2,62,"$18,500",4200,12,Retained,2026-11-15
ACC-1002,Helios BioLabs,Enterprise,EMEA,19,82.0,3,54,$14200,2800,18,Retained,2026-12-01
ACC-1003,Apex Retail Group,Mid-Market,North America,47,34.2,11,18,"$6,400",0,84,Churned,2026-09-10
ACC-1003,Apex Retail Group,Mid-Market,North America,47,34.2,11,18,"$6,400",0,84,Churned,2026-09-10
ACC-1004,Nordic Freight AS,Enterprise,EMEA,22,79.4,4,49,16800,3100,24,Retained,2026/11/20
ACC-1005,Stratos FinTech,Mid-Market,North America,52,29.0,14,12,"$5,800",0,91,Churned,2026-08-22
ACC-1006,Kaito Robotics,Enterprise,APAC,16,91.2,1,71,"$22,400",6500,8,Retained,2026-12-18
ACC-1007,Meridian Health,Mid-Market,North America,38,,9,24,"$7,100",0,76,At-Risk,2026-10-30
ACC-1008,Cobalt Energy,Enterprise,North America,18,85.0,2,58,19200,4800,15,Retained,2026-11-28
ACC-1009,pulse media ltd,SMB,EMEA,41,41.5,8,29,"$2,100",0,68,Churned,2026-09-05
ACC-1010,Orion Semiconductors,Enterprise,APAC,15,89.8,2,66,"$24,000",7200,9,Retained,2026-12-12
ACC-1011,Vertex Construction,Mid-Market,North America,55,26.4,15,10,"$6,200",0,94,Churned,2026-08-14
ACC-1012,Lumina Diagnostics,Mid-Market,EMEA,24,74.1,3,48,,1400,29,Retained,2026-11-04
ACC-1013,Summit Hospitality,SMB,North America,44,38.0,10,21,"$1,950",0,79,Churned,2026-09-19
ACC-1014,Aether Aerospace,Enterprise,North America,12,94.0,1,74,"$28,500",8900,6,Retained,2026-12-24
ACC-1015,TerraAgri Systems,Mid-Market,LATAM,49,31.8,12,15,"$5,400",0,88,Churned,2026-09-02
ACC-1015,TerraAgri Systems,Mid-Market,LATAM,49,31.8,12,15,"$5,400",0,88,Churned,2026-09-02
ACC-1016,BlueWave Marine,Mid-Market,EMEA,21,77.6,3,52,"$8,900",1900,22,Retained,2026-11-11
ACC-1017,Quantum Ledger,Enterprise,North America,61,22.5,19,8,"$15,600",0,96,Churned,2026-08-30
ACC-1018,Boreal Timber,SMB,North America,19,71.0,2,50,"$2,400",450,25,Retained,2026-11-09
ACC-1019,Zenith Pharma,Enterprise,EMEA,17,86.3,2,61,"$21,000",5400,14,Retained,2026-12-05
ACC-1020,NovaGrid Utilities,Mid-Market,APAC,43,39.2,9,27,"$6,800",0,73,At-Risk,2026-10-29
ACC-1021,Ironclad Security,Enterprise,North America,15,90.4,2,68,"$23,100",6100,11,Retained,2026-12-19
ACC-1022,Cascade Apparel,SMB,North America,48,33.0,11,19,"$1,800",0,82,Churned,2026-09-12
ACC-1023,Solstice Solar,Mid-Market,EMEA,25,72.8,4,45,"$7,900",1200,31,Retained,2026-11-17
ACC-1024,Atlas Cloudware,Enterprise,North America,13,92.7,1,72,"$26,400",7800,7,Retained,2026-12-22
ACC-1025,Pinnacle Legal,Mid-Market,North America,51,28.5,13,14,,0,89,Churned,2026-08-25
ACC-1026,Pacific ColdChain,Enterprise,APAC,20,81.2,3,55,"$17,400",3600,19,Retained,2026-11-23
ACC-1027,Metro Transit Tech,Mid-Market,EMEA,39,44.1,8,31,"$7,200",0,67,At-Risk,2026-10-27
ACC-1028,Veloce Motors,Enterprise,EMEA,16,87.9,2,64,"$20,500",4900,13,Retained,2026-12-08
ACC-1029,Harbor Financial,Mid-Market,North America,23,76.0,3,51,"$8,400",1750,23,Retained,2026-11-14
ACC-1030,Kestrel Defense,Enterprise,North America,14,91.5,1,69,"$25,200",7100,8,Retained,2026-12-16
ACC-1031,ClearView Optics,SMB,APAC,46,35.6,10,22,"$2,250",0,78,Churned,2026-09-08
ACC-1032,Valiant Insure,Mid-Market,North America,58,24.8,42,9,"$6,900",0,95,Churned,2026-08-19
ACC-1033,Alpine Precision,Enterprise,EMEA,18,84.6,2,59,"$18,900",4100,16,Retained,2026-11-29
ACC-1034,Redwood Bio,Mid-Market,North America,26,71.4,4,46,"$7,600",1100,28,Retained,2026-11-06
ACC-1035,Echo Stream,SMB,LATAM,50,30.2,12,16,"$1,900",0,86,Churned,2026-08-29
ACC-1036,Titan Heavy Ind,Enterprise,North America,15,89.1,2,65,"$22,800",5900,10,Retained,2026-12-14`,
  },
  {
    id: "supply-chain-logistics",
    name: "Global Supply Chain & Freight Lead-Time Audit",
    sourceType: "Excel Workbook",
    domainContext: "Manufacturing Procurement, Port Customs & Freight Cost Optimization",
    defaultBusinessQuestion:
      "Which shipping corridors and carrier tiers are causing customs delays, defect spikes, and freight cost overruns?",
    description:
      "36 international shipment records with duplicate manifest entries, missing customs clearance hours, unformatted freight costs, and port delay outliers.",
    rawCsv: `shipment_id,origin_hub,destination_hub,carrier_tier,transport_mode,customs_clearance_hrs,transit_days,on_time_pct,defect_rate_pct,freight_cost_usd,order_value_usd,delay_status,ship_date
SHP-401,Shenzhen,Los Angeles,Tier-1 Express,Ocean,18,14,94.2,0.4,"$12,400",185000,On-Schedule,2026-08-04
SHP-402,Ningbo,Rotterdam,Tier-3 Spot,Ocean,64,29,61.5,3.2,"$19,800",142000,Delayed,2026-08-09
SHP-402,Ningbo,Rotterdam,Tier-3 Spot,Ocean,64,29,61.5,3.2,"$19,800",142000,Delayed,2026-08-09
SHP-403,Frankfurt,Chicago,Tier-1 Express,Air,6,3,98.1,0.1,"$24,500",310000,On-Schedule,2026-08-14
SHP-404,Ho Chi Minh,Los Angeles,Tier-2 Standard,Ocean,42,19,76.4,1.8,$14900,164000,Minor-Delay,2026-08-19
SHP-405,Mumbai,Felixstowe,Tier-3 Spot,Ocean,72,33,54.0,4.1,"$21,200",128000,Delayed,2026-08-25
SHP-406,Tokyo,Seattle,Tier-1 Express,Air,5,2,99.0,0.1,"$26,800",340000,On-Schedule,2026-09-01
SHP-407,Busan,Long Beach,Tier-2 Standard,Ocean,,16,84.5,1.1,"$13,600",195000,On-Schedule,2026-09-05
SHP-408,Qingdao,Hamburg,Tier-3 Spot,Ocean,68,31,58.2,3.6,"$20,400",135000,Delayed,2026-09-10
SHP-409,Taipei,Dallas,Tier-1 Express,Air,7,3,97.4,0.2,"$25,100",298000,On-Schedule,2026-09-14
SHP-410,Monterrey,Detroit,Tier-1 Express,Rail,11,4,95.6,0.3,"$6,800",172000,On-Schedule,2026-09-18
SHP-411,Shanghai,Savannah,Tier-2 Standard,Ocean,38,21,79.0,1.5,,178000,Minor-Delay,2026-09-22
SHP-412,Kaohsiung,Rotterdam,Tier-3 Spot,Ocean,76,35,51.8,4.4,"$22,600",121000,Delayed,2026-09-27
SHP-413,Osaka,San Francisco,Tier-1 Express,Air,6,2,98.6,0.1,"$27,400",355000,On-Schedule,2026-10-02
SHP-414,Yantian,Newark,Tier-2 Standard,Ocean,35,22,81.2,1.4,"$15,800",182000,On-Schedule,2026-10-06
SHP-415,Santos,Miami,Tier-3 Spot,Ocean,59,18,64.0,2.9,"$14,200",119000,Delayed,2026-10-11
SHP-415,Santos,Miami,Tier-3 Spot,Ocean,59,18,64.0,2.9,"$14,200",119000,Delayed,2026-10-11
SHP-416,Antwerp,Newark,Tier-1 Express,Ocean,14,10,96.0,0.3,"$11,200",215000,On-Schedule,2026-10-15
SHP-417,Penang,Los Angeles,Tier-2 Standard,Ocean,44,20,74.8,1.9,"$15,400",159000,Minor-Delay,2026-10-19
SHP-418,Chennai,Rotterdam,Tier-3 Spot,Ocean,81,36,49.5,4.7,"$23,500",115000,Delayed,2026-10-24
SHP-419,Seoul,Chicago,Tier-1 Express,Air,6,3,98.4,0.2,"$25,900",320000,On-Schedule,2026-10-28
SHP-420,Guadalajara,Houston,Tier-1 Express,Rail,12,4,94.8,0.4,"$6,400",168000,On-Schedule,2026-11-02
SHP-421,Xiamen,Long Beach,Tier-2 Standard,Ocean,,17,82.9,1.2,"$14,100",188000,On-Schedule,2026-11-06
SHP-422,Jakarta,felixstowe,Tier-3 Spot,Ocean,70,32,56.4,3.8,"$20,900",131000,Delayed,2026-11-10
SHP-423,Milan,New York,Tier-1 Express,Air,7,3,97.8,0.2,"$23,800",289000,On-Schedule,2026-11-14
SHP-424,Ningbo,Savannah,Tier-2 Standard,Ocean,41,22,77.5,1.6,"$16,100",174000,Minor-Delay,2026-11-18
SHP-425,Bangkok,Los Angeles,Tier-3 Spot,Ocean,66,28,60.1,3.4,"$19,200",138000,Delayed,2026-11-22
SHP-426,Shenzhen,Rotterdam,Tier-1 Express,Ocean,19,18,93.5,0.5,"$14,800",224000,On-Schedule,2026-11-26
SHP-427,Ho Chi Minh,Seattle,Tier-2 Standard,Ocean,39,18,80.4,1.3,"$14,500",171000,On-Schedule,2026-12-01
SHP-428,Mumbai,Newark,Tier-3 Spot,Ocean,145,38,44.2,5.8,"$38,900",124000,Delayed,2026-12-05
SHP-429,Frankfurt,Atlanta,Tier-1 Express,Air,6,3,98.2,0.1,"$24,200",305000,On-Schedule,2026-12-10
SHP-430,Busan,Tacoma,Tier-1 Express,Ocean,16,12,95.1,0.4,"$11,900",208000,On-Schedule,2026-12-15`,
  },
  {
    id: "omnichannel-marketing-roas",
    name: "Omnichannel Paid Acquisition & Attribution ROAS",
    sourceType: "REST API Stream",
    domainContext: "Growth Marketing, CAC Efficiency & Multi-Touch Conversion",
    defaultBusinessQuestion:
      "Where should we reallocate $500k in quarterly ad spend to maximize net contribution margin and eliminate high-CAC wasted spend?",
    description:
      "34 campaign cohorts across Paid Search, Paid Social, Retargeting, and Influencer channels with missing CAC values, duplicate API webhook rows, and spend outliers.",
    rawCsv: `campaign_id,channel,funnel_stage,geo_market,ad_spend_usd,impressions_k,ctr_pct,conversion_rate_pct,cac_usd,ltv_usd,roas_multiple,profit_contribution_usd,campaign_date
CMP-201,Paid Search Brand,Bottom-Funnel,US-East,"$42,000",680,4.8,6.4,68,490,5.42,185600,2026-08-05
CMP-202,Paid Social Video,Top-Funnel,US-West,"$68,500",2450,1.1,0.9,285,310,1.09,6100,2026-08-12
CMP-202,Paid Social Video,Top-Funnel,US-West,"$68,500",2450,1.1,0.9,285,310,1.09,6100,2026-08-12
CMP-203,Lifecycle Retargeting,Bottom-Funnel,US-East,"$28,000",510,3.9,5.8,74,465,4.95,110600,2026-08-19
CMP-204,Technical Content Syndication,Mid-Funnel,Europe,"$35,000",420,2.7,3.8,112,440,3.68,93800,2026-08-26
CMP-205,Influencer Sponsorship,Top-Funnel,US-West,"$54,000",1890,0.9,0.7,310,295,0.92,-4300,2026-09-02
CMP-206,Paid Search High-Intent,Bottom-Funnel,Europe,"$39,500",610,4.5,5.9,,475,4.88,153200,2026-09-09
CMP-207,Display Programmatic,Top-Funnel,APAC,"$48,000",3100,0.6,0.5,340,280,0.78,-10500,2026-09-16
CMP-208,LinkedIn ABM Executive,Mid-Funnel,US-East,"$46,000",390,2.4,4.2,128,580,4.15,144900,2026-09-23
CMP-209,Paid Social Carousel,Mid-Funnel,Europe,"$37,200",1120,1.8,2.1,165,360,2.18,43900,2026-09-30
CMP-210,Lifecycle Retargeting,Bottom-Funnel,US-West,"$31,000",540,4.1,6.1,71,480,5.12,127700,2026-10-07
CMP-211,Paid Search Competitor,Mid-Funnel,US-East,"$44,000",580,2.9,3.4,134,450,3.21,97200,2026-10-14
CMP-212,Display Programmatic,Top-Funnel,US-East,"$51,000",3400,0.5,0.4,365,275,0.71,-14800,2026-10-21
CMP-212,Display Programmatic,Top-Funnel,US-East,"$51,000",3400,0.5,0.4,365,275,0.71,-14800,2026-10-21
CMP-213,YouTube Product Demo,Mid-Funnel,US-West,"$38,500",890,2.6,3.5,118,430,3.54,97800,2026-10-28
CMP-214,Paid Search Brand,Bottom-Funnel,APAC,"$29,000",490,4.6,6.0,72,460,5.05,117450,2026-11-04
CMP-215,Influencer Sponsorship,Top-Funnel,Europe,"$49,000",1650,1.0,0.8,295,305,0.98,-980,2026-11-11
CMP-216,LinkedIn ABM Executive,Mid-Funnel,Europe,"$41,000",350,2.5,4.0,131,560,3.96,121360,2026-11-18
CMP-217,Paid Social Video,Top-Funnel,APAC,"$58,000",2180,1.2,1.0,,300,1.14,8120,2026-11-25
CMP-218,Technical Content Syndication,Mid-Funnel,US-East,"$36,500",460,2.8,3.9,108,455,3.82,102930,2026-12-02
CMP-219,Paid Search High-Intent,Bottom-Funnel,US-West,"$45,000",710,4.7,6.2,69,495,5.36,196200,2026-12-07
CMP-220,Display Programmatic,Top-Funnel,Europe,"$46,500",2950,0.6,0.5,350,285,0.79,-9765,2026-12-11
CMP-221,Lifecycle Retargeting,Bottom-Funnel,Europe,"$26,500",470,4.0,5.7,76,455,4.81,100965,2026-12-15
CMP-222,YouTube Product Demo,Mid-Funnel,US-East,"$40,200",940,2.7,3.7,114,445,3.71,108940,2026-12-18
CMP-223,Paid Social Carousel,Mid-Funnel,US-West,"$39,000",1250,1.9,2.3,158,370,2.34,52260,2026-12-21
    CMP-224,LinkedIn ABM Executive,Mid-Funnel,US-West,"$47,500",410,2.6,4.3,124,590,4.28,155800,2026-12-24`,
  },
];

export const SAMPLE_DATASETS: SampleDatasetPreset[] = [
  ...CORE_DATASETS,
  ...HIGH_FRICTION_PROBLEMS.map((p) => ({
    id: p.id,
    name: `${p.numberLabel}: ${p.shortTitle}`,
    sourceType: "CSV Upload" as const,
    domainContext: p.domainContext,
    defaultBusinessQuestion: p.defaultBusinessQuestion,
    description: p.contextAndPainPoint,
    rawCsv: p.rawCsv,
  })),
];

